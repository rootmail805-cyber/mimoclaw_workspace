"""
QuantFlow V2.0 — A股量化交易系统 GUI
深色科技风格，包含首页看板、回测、策略商店、实盘交易、风险仪表盘、设置

by QuantFlow Team
"""

import sys
import os
import threading
import time
import importlib
from pathlib import Path
from datetime import datetime, timedelta, date
from tkinter import (
    Tk, Frame, Label, Button, Entry, OptionMenu, StringVar, IntVar,
    Text, Scrollbar, END, RIGHT, LEFT, Y, BOTH, X,
    W, E, N, S, messagebox, ttk, LabelFrame,
    Canvas, Toplevel,
)
from tkinter import font as tkfont

APP_DIR = Path(__file__).parent
sys.path.insert(0, str(APP_DIR))

# ── 主题系统 ──
from gui.theme import get_theme, list_themes, DEFAULT_THEME

def _init_colors(theme_name=None):
    """初始化配色方案"""
    return get_theme(theme_name or DEFAULT_THEME)

C = _init_colors()

# 旧主题引用（热切换时用于颜色映射）
_OLD_C = dict(C)

# ── 主窗口类 ──
# 注意：现在使用 C = _init_colors() 动态加载主题
class QuantFlowApp:
    """QuantFlow V2.0 主应用"""

    def __init__(self):
        # 加载保存的主题
        global C
        try:
            from config.manager import get_config
            saved_theme = get_config().get("ui.theme", DEFAULT_THEME)
            C = _init_colors(saved_theme)
        except Exception:
            pass

        self.root = Tk()
        self.root.title("QuantFlow V2.0 | A股量化交易系统 | BY Ricardo（V root_ss）")
        self.root.geometry("1400x900")
        self.root.configure(bg=C["bg"])
        self.root.minsize(1200, 800)

        # 延迟导入避免启动慢
        self._db = None
        self._config = None
        self._data_mgr = None
        self._engine = None
        self._risk_mgr = None
        self._notifier = None
        self._market_timing = None

        # 状态
        self._connected = False
        self._auto_running = False
        self._syncing = False
        self._broker_lock = threading.Lock()  # 线程安全锁

        # 策略名称映射（中文→英文ID）— 全局统一
        self._strat_id_map = {
            "双均线策略": "dual_ma",
            "MACD策略": "macd",
            "布林带策略": "bollinger",
            "RSI策略": "rsi",
            "KDJ策略": "kdj",
            "ATR通道突破": "atr_breakout",
            "动量突破策略": "momentum",
            "VWAP策略": "vwap",
        }
        # YAML模板策略名 → 内置策略ID 的映射（策略商店用）
        self._template_to_builtin = {
            "ma_cross_v1": "dual_ma",
            "rsi_reversal_v1": "rsi",
            "volume_breakout_v1": "momentum",
            "macd_v1": "macd",
            "bollinger_v1": "bollinger",
            "kdj_v1": "kdj",
            "atr_breakout_v1": "atr_breakout",
            "vwap_v1": "vwap",
        }
        # 统一显示名映射（确保所有界面名称一致）
        self._strategy_display_names = {
            "dual_ma": "双均线策略",
            "macd": "MACD策略",
            "bollinger": "布林带策略",
            "rsi": "RSI策略",
            "kdj": "KDJ策略",
            "atr_breakout": "ATR通道突破",
            "momentum": "动量突破策略",
            "vwap": "VWAP策略",
        }

        self._setup_fonts()

        # 启动环境自检
        if not self._check_environment():
            return  # 环境不满足，已提示用户

        self._build_ui()
        self._init_backend()

    def _setup_fonts(self):
        """初始化字体（清晰+科技风+高对比度）"""
        ff = C.get("font_family", "Consolas")
        ff_ui = C.get("font_family_ui", "Segoe UI")
        self._font_title = tkfont.Font(family=ff, size=C.get("font_size_title", 16), weight="bold")
        self._font_heading = tkfont.Font(family=ff, size=C.get("font_size_heading", 13), weight="bold")
        self._font_body = tkfont.Font(family=ff, size=C.get("font_size_body", 11))
        self._font_small = tkfont.Font(family=ff, size=C.get("font_size_small", 9))
        self._font_big_num = tkfont.Font(family=ff, size=C.get("font_size_big_num", 36), weight="bold")
        self._font_medium_num = tkfont.Font(family=ff, size=C.get("font_size_medium_num", 20), weight="bold")

    def _check_environment(self):
        """启动环境自检：检查必需包，缺失时自动安装"""
        required = {
            "akshare": "akshare",
            "pandas": "pandas",
            "numpy": "numpy",
            "yaml": "PyYAML",
            "dotenv": "python-dotenv",
            "loguru": "loguru",
            "requests": "requests",
            "psutil": "psutil",
        }

        missing = []
        for import_name, pip_name in required.items():
            try:
                __import__(import_name)
            except ImportError:
                missing.append(pip_name)

        if not missing:
            return True

        # 有缺失包 — 弹窗询问
        missing_str = ", ".join(missing)
        msg = (
            f"检测到以下依赖包未安装:\n\n"
            f"{missing_str}\n\n"
            f"是否自动安装？\n"
            f"（将使用 pip 从清华镜像源安装）"
        )
        if messagebox.askyesno("环境检测 — 缺少依赖", msg):
            self._show_install_progress(missing)
            return True
        else:
            messagebox.showinfo("提示", "缺少必要依赖，程序无法运行。\n请手动安装后再启动。")
            return False

    def _show_install_progress(self, packages):
        """显示安装进度窗口并执行安装"""
        win = Toplevel(self.root)
        win.title("安装依赖")
        win.geometry("500x300")
        win.configure(bg=C["bg"])
        win.transient(self.root)
        win.grab_set()

        Label(win, text="正在安装依赖包...", font=("Consolas", 12, "bold"),
              bg=C["bg"], fg=C["accent"]).pack(pady=16)

        log_text = Text(win, bg=C["bg_card"], fg=C["text"],
                        font=("Consolas", 9), relief="flat", wrap="word")
        log_text.pack(fill=BOTH, expand=True, padx=16, pady=(0, 8))

        progress = Label(win, text="安装中...", font=("Consolas", 10),
                         bg=C["bg"], fg=C["orange"])
        progress.pack(pady=8)

        def _do_install():
            import subprocess
            mirror = "https://pypi.tuna.tsinghua.edu.cn/simple"
            total = len(packages)
            for i, pkg in enumerate(packages):
                self.root.after(0, lambda p=pkg: log_text.insert(END, f"  安装 {p}...\n"))
                self.root.after(0, lambda: log_text.see(END))
                try:
                    result = subprocess.run(
                        [sys.executable, "-m", "pip", "install", "-i", mirror, pkg],
                        capture_output=True, text=True, timeout=120,
                    )
                    if result.returncode == 0:
                        self.root.after(0, lambda p=pkg: log_text.insert(END, f"  [OK] {p}\n"))
                    else:
                        err = result.stderr[-200:] if result.stderr else "未知错误"
                        self.root.after(0, lambda e=err: log_text.insert(END, f"  [X] 失败: {e}\n"))
                except subprocess.TimeoutExpired:
                    self.root.after(0, lambda: log_text.insert(END, f"  [X] 超时\n"))
                except Exception as e:
                    self.root.after(0, lambda e=e: log_text.insert(END, f"  [X] {e}\n"))
                self.root.after(0, lambda: log_text.see(END))

            self.root.after(0, lambda: progress.config(text="安装完成！", fg=C["green"]))
            self.root.after(2000, win.destroy)

        threading.Thread(target=_do_install, daemon=True).start()

    def _init_backend(self):
        """初始化后端模块"""
        def _do_init():
            try:
                from config.manager import get_config
                from core.db import get_db
                from core.data.data_manager import DataManager
                from core.risk.enhanced_risk import EnhancedRiskManager
                from core.notification.notifier import NotificationManager
                from core.market_timing import MarketTimingFilter

                self._config = get_config()
                self._db = get_db()
                self._data_mgr = DataManager(self._config)
                self._risk_mgr = EnhancedRiskManager(self._config)
                self._notifier = NotificationManager(self._config)
                self._notifier.start()
                self._risk_mgr.set_notifier(self._notifier)
                self._market_timing = MarketTimingFilter(self._config)

                self.root.after(0, lambda: self._log_system("后端模块初始化完成"))
            except Exception as e:
                self.root.after(0, lambda e=e: self._log_system(f"[!] 后端初始化失败: {e}"))

        threading.Thread(target=_do_init, daemon=True).start()

    def _log_system(self, msg):
        """写入系统日志"""
        if hasattr(self, '_sys_log'):
            timestamp = datetime.now().strftime("%H:%M:%S")
            self._sys_log.insert(END, f"  [{timestamp}] {msg}\n")
            self._sys_log.see(END)

    # ════════════════════════════════════════════════════════════════
    #  UI 构建
    # ════════════════════════════════════════════════════════════════

    def _build_ui(self):
        """构建主界面"""
        # 标签页样式
        style = ttk.Style()
        style.theme_use("default")
        style.configure("TNotebook", background=C["bg"], borderwidth=0, padding=0)
        style.configure("TNotebook.Tab",
                        background=C["bg_panel"],
                        foreground=C["text_dim"],
                        padding=[20, 12],
                        font=("Consolas", 10, "bold"))
        style.map("TNotebook.Tab",
                  background=[("selected", C["bg_card"])],
                  foreground=[("selected", C["accent"])])
        style.configure("TFrame", background=C["bg"])

        # 顶部标题栏
        self._build_header()

        # 标签页
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=BOTH, expand=True, padx=8, pady=(0, 4))

        # 构建各标签页
        self._build_dashboard_tab()    # 首页看板
        self._build_backtest_tab()     # 回测
        self._build_screener_tab()     # 扫股器
        self._build_strategy_tab()     # 策略商店
        self._build_live_tab()         # 实盘交易
        self._build_risk_tab()         # 风险仪表盘
        self._build_advanced_risk_tab() # 高级风控（自适应/压力测试/归因）
        self._build_factor_tab()        # 多因子选股
        self._build_settings_tab()     # 设置

        # 底部状态栏
        self._build_status_bar()

    def _build_header(self):
        """顶部标题栏（科技风增强）"""
        header = Frame(self.root, bg=C["bg_card"], height=56)
        header.pack(fill=X, padx=8, pady=(8, 4))
        header.pack_propagate(False)

        # 左侧标题
        title_frame = Frame(header, bg=C["bg_card"])
        title_frame.pack(side=LEFT, padx=16)
        Label(title_frame, text="◆ QUANTFLOW", font=("Consolas", 17, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(side=LEFT)
        Label(title_frame, text=" V2.0", font=("Consolas", 17),
              bg=C["bg_card"], fg=C["text_dim"]).pack(side=LEFT)
        Label(title_frame, text="  A股量化交易系统", font=("Consolas", 10),
              bg=C["bg_card"], fg=C["text_muted"]).pack(side=LEFT, padx=(12, 0))
        Label(title_frame, text="  BY Ricardo（V root_ss）", font=("Consolas", 8),
              bg=C["bg_card"], fg=C["text_muted"]).pack(side=LEFT, padx=(12, 0))

        # 右侧状态
        self._status_dot = Label(header, text=" ● ", font=("Consolas", 12),
                                  bg=C["bg_card"], fg=C["text_muted"])
        self._status_dot.pack(side=RIGHT, padx=16)
        self._status_text = Label(header, text="初始化中", font=("Consolas", 10),
                                   bg=C["bg_card"], fg=C["text_dim"])
        self._status_text.pack(side=RIGHT)

    def _build_status_bar(self):
        """底部状态栏"""
        bar = Frame(self.root, bg=C["bg_card"], height=26)
        bar.pack(fill=X, padx=8, pady=(0, 8))
        bar.pack_propagate(False)

        self._status_bar_label = Label(bar, text="  系统: 初始化中 │ 数据源: AKSHARE │ SINA │ TENCENT",
                                        font=("Consolas", 9), bg=C["bg_card"], fg=C["text_muted"])
        self._status_bar_label.pack(side=LEFT, padx=12)

        Label(bar, text="QuantFlow V2.0  ", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_muted"]).pack(side=RIGHT, padx=12)

    def _set_status(self, text, color=None):
        """更新状态栏"""
        if color is None:
            color = C["accent"]
        self._status_dot.config(fg=color)
        self._status_text.config(text=text, fg=color)
        self._status_bar_label.config(text=f"  系统: {text} | 数据源: AKSHARE")

    # ════════════════════════════════════════════════════════════════
    #  首页看板
    # ════════════════════════════════════════════════════════════════

    def _build_dashboard_tab(self):
        """首页看板"""
        tab = Frame(self.notebook, bg=C["bg"])
        self.notebook.add(tab, text="  ◆ 首页看板  ")

        # 今日盈亏
        pnl_frame = Frame(tab, bg=C["bg_card"], padx=24, pady=20)
        pnl_frame.pack(fill=X, padx=12, pady=(12, 6))

        pnl_top = Frame(pnl_frame, bg=C["bg_card"])
        pnl_top.pack(fill=X)
        Label(pnl_top, text="今日盈亏", font=("Consolas", 11),
              bg=C["bg_card"], fg=C["text_dim"]).pack(side=LEFT)
        Button(pnl_top, text="↻ 刷新", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["text"], relief="flat",
               command=self._refresh_dashboard).pack(side=RIGHT)

        self._dash_pnl = Label(pnl_frame, text="¥0.00", font=("Consolas", 36, "bold"),
                                bg=C["bg_card"], fg=C["text_bright"])
        self._dash_pnl.pack(anchor=W, pady=(8, 0))

        self._dash_pnl_sub = Label(pnl_frame, text="", font=("Consolas", 11),
                                    bg=C["bg_card"], fg=C["text_dim"])
        self._dash_pnl_sub.pack(anchor=W)
        cards_frame = Frame(tab, bg=C["bg"])
        cards_frame.pack(fill=X, padx=12, pady=6)

        self._dash_cards = {}
        card_defs = [
            ("本月收益", "¥--", C["accent"]),
            ("胜率", "--%", C["cyan"]),
            ("持仓数", "--只", C["orange"]),
            ("风控状态", "正常", C["green"]),
        ]
        for title, default, color in card_defs:
            card = Frame(cards_frame, bg=C["bg_card"], padx=16, pady=14)
            card.pack(side=LEFT, fill=BOTH, expand=True, padx=(0, 6))
            Label(card, text=title, font=("Consolas", 9),
                  bg=C["bg_card"], fg=C["text_dim"]).pack(anchor=W)
            lbl = Label(card, text=default, font=("Consolas", 16, "bold"),
                        bg=C["bg_card"], fg=color)
            lbl.pack(anchor=W, pady=(4, 0))
            self._dash_cards[title] = lbl

        # 下半部分：持仓 + 最近交易
        bottom = Frame(tab, bg=C["bg"])
        bottom.pack(fill=BOTH, expand=True, padx=12, pady=6)

        # 持仓快照
        pos_frame = Frame(bottom, bg=C["bg_card"])
        pos_frame.pack(side=LEFT, fill=BOTH, expand=True, padx=(0, 4))

        pf_header = Frame(pos_frame, bg=C["bg_card"])
        pf_header.pack(fill=X, padx=12, pady=8)
        Label(pf_header, text="  ◆ 持仓快照", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["cyan"]).pack(side=LEFT)

        # 持仓表头
        pos_headers = Frame(pos_frame, bg=C["bg_input"])
        pos_headers.pack(fill=X, padx=12)
        for h in ["代码", "数量", "成本", "现价", "盈亏"]:
            Label(pos_headers, text=h, font=("Consolas", 8, "bold"),
                  bg=C["bg_input"], fg=C["text_dim"], width=10, anchor=W).pack(side=LEFT, padx=2)

        self._dash_pos_frame = Frame(pos_frame, bg=C["bg_card"])
        self._dash_pos_frame.pack(fill=BOTH, expand=True, padx=12, pady=4)
        Label(self._dash_pos_frame, text="  暂无持仓", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_muted"]).pack(anchor=W, pady=20)

        # 最近交易
        trade_frame = Frame(bottom, bg=C["bg_card"])
        trade_frame.pack(side=RIGHT, fill=BOTH, expand=True, padx=(4, 0))

        tf_header = Frame(trade_frame, bg=C["bg_card"])
        tf_header.pack(fill=X, padx=12, pady=8)
        Label(tf_header, text="  ◆ 最近交易", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["cyan"]).pack(side=LEFT)

        trade_headers = Frame(trade_frame, bg=C["bg_input"])
        trade_headers.pack(fill=X, padx=12)
        for h in ["时间", "方向", "代码", "数量", "价格", "盈亏"]:
            Label(trade_headers, text=h, font=("Consolas", 8, "bold"),
                  bg=C["bg_input"], fg=C["text_dim"], width=9, anchor=W).pack(side=LEFT, padx=1)

        self._dash_trade_frame = Frame(trade_frame, bg=C["bg_card"])
        self._dash_trade_frame.pack(fill=BOTH, expand=True, padx=12, pady=4)
        Label(self._dash_trade_frame, text="  暂无交易记录", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_muted"]).pack(anchor=W, pady=20)

        # 系统日志
        log_frame = Frame(tab, bg=C["bg_card"])
        log_frame.pack(fill=X, padx=12, pady=(6, 12))
        Label(log_frame, text="  ◆ 系统日志", font=("Consolas", 9, "bold"),
              bg=C["bg_card"], fg=C["text_dim"]).pack(anchor=W, padx=12, pady=4)
        self._sys_log = Text(log_frame, bg=C["bg"], fg=C["text_dim"],
                              font=("Consolas", 8), height=4, relief="flat",
                              wrap="word", padx=8, pady=4)
        self._sys_log.pack(fill=X, padx=12, pady=(0, 8))

        # 导出和战报按钮
        btn_row = Frame(pnl_frame, bg=C["bg_card"])
        btn_row.pack(side=RIGHT, padx=4)
        Button(btn_row, text="📤 导出交易记录", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["cyan"], relief="flat",
               command=self._export_trades_csv).pack(side=LEFT, padx=2)
        Button(btn_row, text="📊 生成战报", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["orange"], relief="flat",
               command=self._generate_daily_report).pack(side=LEFT, padx=2)
        Button(btn_row, text="📈 基准对比", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["text"], relief="flat",
               command=self._run_benchmark_compare).pack(side=LEFT, padx=2)

        self._log_system("首页看板已加载")

    def _export_trades_csv(self):
        """导出交易记录为CSV文件"""
        from tkinter import filedialog
        import csv

        trades = []
        if hasattr(self, '_broker') and self._broker:
            try:
                with self._broker_lock:
                    trades = self._broker.get_trade_history() or []
            except Exception:
                pass

        if not trades:
            messagebox.showinfo("提示", "暂无交易记录可导出")
            return

        filepath = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV文件", "*.csv"), ("所有文件", "*.*")],
            initialfile=f"trades_{date.today().isoformat()}.csv"
        )
        if not filepath:
            return

        try:
            with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.DictWriter(f, fieldnames=["time", "symbol", "direction", "volume", "price", "commission", "pnl", "strategy_id"])
                writer.writeheader()
                for t in trades:
                    writer.writerow({k: t.get(k, "") for k in ["time", "symbol", "direction", "volume", "price", "commission", "pnl", "strategy_id"]})
            messagebox.showinfo("成功", f"已导出 {len(trades)} 条记录到:\n{filepath}")
        except Exception as e:
            messagebox.showerror("错误", f"导出失败: {e}")

    def _generate_daily_report(self):
        """生成每日战报"""
        def _do():
            try:
                from core.daily_report import DailyReporter
                reporter = DailyReporter(self._config)

                account = None
                positions = {}
                trades = []

                if hasattr(self, '_broker') and self._broker:
                    with self._broker_lock:
                        account = self._broker.get_account()
                        positions = self._broker.get_positions() or {}
                        trades = self._broker.get_trade_history() or []

                if account is None:
                    self.root.after(0, lambda: messagebox.showinfo("提示", "请先连接券商"))
                    return

                report = reporter.generate_daily(account, positions, trades)
                message = reporter.format_daily_message(report)

                self.root.after(0, lambda: self._show_report_window("每日战报", message))
                self.root.after(0, lambda: self._log_system("每日战报已生成"))

            except Exception as e:
                self.root.after(0, lambda e=e: messagebox.showerror("错误", f"战报生成失败: {e}"))

        threading.Thread(target=_do, daemon=True).start()

    def _run_benchmark_compare(self):
        """基准对比分析"""
        def _do():
            try:
                from core.benchmark import BenchmarkAnalyzer
                analyzer = BenchmarkAnalyzer(self._config)

                trades = []
                if hasattr(self, '_broker') and self._broker:
                    with self._broker_lock:
                        trades = self._broker.get_trade_history() or []

                if not trades:
                    self.root.after(0, lambda: messagebox.showinfo("提示", "暂无交易数据，无法进行基准对比"))
                    return

                # 构建权益曲线
                equity = [1000000]
                for t in trades:
                    equity.append(equity[-1] + t.get("pnl", 0))
                import pandas as pd
                dates = pd.date_range(end=pd.Timestamp.now(), periods=len(equity), freq="D")
                equity_df = pd.DataFrame({"total_assets": equity}, index=dates)

                result = analyzer.compare(equity_df)

                lines = ["═══ 基准对比分析 ═══", ""]
                for k, v in result.items():
                    if isinstance(v, float):
                        lines.append(f"  {k}: {v:+.4f}")
                    else:
                        lines.append(f"  {k}: {v}")

                self.root.after(0, lambda: self._show_report_window("基准对比", "\n".join(lines)))

            except Exception as e:
                self.root.after(0, lambda e=e: messagebox.showerror("错误", f"基准对比失败: {e}"))

        threading.Thread(target=_do, daemon=True).start()

    def _show_report_window(self, title, content):
        """显示报告弹窗"""
        win = Toplevel(self.root)
        win.title(title)
        win.geometry("600x500")
        win.configure(bg=C["bg"])

        text = Text(win, bg=C["bg"], fg=C["text"], font=("Consolas", 9),
                     relief="flat", wrap="word", padx=12, pady=12)
        text.pack(fill=BOTH, expand=True, padx=8, pady=8)
        text.insert(END, content)

        Button(win, text="关闭", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["text"], relief="flat",
               command=win.destroy).pack(pady=(0, 8))

    def _refresh_dashboard(self):
        """刷新首页数据（从纸盘/实盘同步 — 实时联动）"""
        def _do():
            try:
                trades = []
                total_pnl = 0
                month_pnl = 0
                win_rate = 0
                positions = {}
                total_assets = 0
                cash = 0
                market_value = 0
                unrealized_pnl = 0

                # 从券商适配器获取数据
                if hasattr(self, '_broker') and self._broker:
                    try:
                        with self._broker_lock:
                            acct = self._broker.get_account()
                            positions = self._broker.get_positions() or {}
                            # 获取交易记录
                            if hasattr(self._broker, 'get_trade_history'):
                                trades = self._broker.get_trade_history() or []
                        total_assets = acct.total_assets
                        cash = acct.cash
                        market_value = acct.market_value
                        unrealized_pnl = acct.unrealized_pnl
                    except Exception:
                        pass

                # 计算今日盈亏（未实现盈亏 + 今日已实现盈亏）
                today_str = date.today().isoformat()
                today_realized = sum(
                    t.get("pnl", 0) for t in trades
                    if t.get("time", "")[:10] == today_str and t.get("direction") == "SELL"
                )
                total_pnl = unrealized_pnl + today_realized

                # 计算本月收益
                month_str = today_str[:7]  # "2026-07"
                month_trades = [
                    t for t in trades
                    if t.get("time", "")[:7] == month_str and t.get("direction") == "SELL"
                ]
                month_pnl = sum(t.get("pnl", 0) for t in month_trades)

                # 计算胜率（已平仓交易）
                sell_trades = [t for t in trades if t.get("direction") == "SELL"]
                if sell_trades:
                    win_count = len([t for t in sell_trades if t.get("pnl", 0) > 0])
                    win_rate = round(win_count / len(sell_trades) * 100, 1)

                pnl_color = C["green"] if total_pnl >= 0 else C["red"]
                sign = "+" if total_pnl >= 0 else ""

                # 持仓数
                pos_count = len(positions)

                self.root.after(0, lambda: self._update_dashboard(
                    total_pnl, pnl_color, sign,
                    month_pnl, win_rate, trades,
                    total_assets=total_assets, cash=cash,
                    market_value=market_value,
                    pos_count=pos_count, positions=positions,
                ))
            except Exception as e:
                self.root.after(0, lambda e=e: self._log_system(f"[!] 刷新失败: {e}"))

        threading.Thread(target=_do, daemon=True).start()

    def _update_dashboard(self, total_pnl, pnl_color, sign, month_pnl, win_rate, trades,
                          total_assets=0, cash=0, market_value=0,
                          pos_count=0, positions=None):
        """更新首页显示"""
        self._dash_pnl.config(text=f"¥{sign}{total_pnl:,.2f}", fg=pnl_color)
        self._dash_cards["本月收益"].config(text=f"¥{sign}{month_pnl:,.2f}")
        self._dash_cards["胜率"].config(text=f"{win_rate}%")
        self._dash_cards["持仓数"].config(text=f"{pos_count}只")

        # 更新风控状态卡片
        if hasattr(self, '_broker') and self._broker:
            try:
                risk_info = "正常"
                risk_color = C["green"]
                if hasattr(self._broker, '_stop_rules'):
                    with self._broker_lock:
                        active_rules = len(self._broker._stop_rules)
                    if active_rules > 0:
                        risk_info = f"正常({active_rules}条规则)"
                self._dash_cards["风控状态"].config(text=risk_info, fg=risk_color)
            except Exception:
                pass

        # 更新持仓快照
        if positions:
            for w in self._dash_pos_frame.winfo_children():
                w.destroy()
            for sym, pos in list(positions.items())[:5]:
                row = Frame(self._dash_pos_frame, bg=C["bg_card"])
                row.pack(fill=X)
                pos_pnl = getattr(pos, 'pnl', 0)
                pos_pnl_c = C["green"] if pos_pnl >= 0 else C["red"]
                Label(row, text=sym, font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=10, anchor=W).pack(side=LEFT, padx=2)
                Label(row, text=str(getattr(pos, 'volume', 0)), font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=10, anchor=W).pack(side=LEFT, padx=2)
                Label(row, text=f"{getattr(pos, 'avg_cost', 0):.2f}", font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=10, anchor=W).pack(side=LEFT, padx=2)
                Label(row, text=f"{getattr(pos, 'current_price', 0):.2f}", font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=10, anchor=W).pack(side=LEFT, padx=2)
                Label(row, text=f"{pos_pnl:+.0f}", font=("Consolas", 8), bg=C["bg_card"], fg=pos_pnl_c, width=10, anchor=W).pack(side=LEFT, padx=2)

        # 更新交易列表
        for w in self._dash_trade_frame.winfo_children():
            w.destroy()
        if trades:
            for t in trades[:8]:
                row = Frame(self._dash_trade_frame, bg=C["bg_card"])
                row.pack(fill=X)
                direction = t.get("direction", "")
                dir_color = C["green"] if direction == "BUY" else C["red"]
                pnl = t.get("pnl", 0)
                pnl_c = C["green"] if pnl >= 0 else C["red"]
                time_str = t.get("time", t.get("trade_time", ""))  # 兼容两种字段名
                Label(row, text=time_str[11:19] if len(time_str) > 19 else time_str, font=("Consolas", 8),
                      bg=C["bg_card"], fg=C["text_dim"], width=9, anchor=W).pack(side=LEFT, padx=1)
                Label(row, text=direction, font=("Consolas", 8, "bold"),
                      bg=C["bg_card"], fg=dir_color, width=9, anchor=W).pack(side=LEFT, padx=1)
                Label(row, text=t.get("symbol", ""), font=("Consolas", 8),
                      bg=C["bg_card"], fg=C["text"], width=9, anchor=W).pack(side=LEFT, padx=1)
                Label(row, text=str(t.get("volume", t.get("quantity", 0))), font=("Consolas", 8),
                      bg=C["bg_card"], fg=C["text"], width=9, anchor=W).pack(side=LEFT, padx=1)
                Label(row, text=f"¥{t.get('price', 0):.2f}", font=("Consolas", 8),
                      bg=C["bg_card"], fg=C["text"], width=9, anchor=W).pack(side=LEFT, padx=1)
                Label(row, text=f"{pnl:+.0f}", font=("Consolas", 8),
                      bg=C["bg_card"], fg=pnl_c, width=9, anchor=W).pack(side=LEFT, padx=1)
        else:
            Label(self._dash_trade_frame, text="  暂无交易记录", font=("Consolas", 9),
                  bg=C["bg_card"], fg=C["text_muted"]).pack(anchor=W, pady=20)

    # ════════════════════════════════════════════════════════════════
    #  回测标签页
    # ════════════════════════════════════════════════════════════════

    def _build_backtest_tab(self):
        """回测标签页"""
        tab = Frame(self.notebook, bg=C["bg"])
        self.notebook.add(tab, text="  ◆ 回测  ")

        left = Frame(tab, bg=C["bg_panel"], width=340)
        left.pack(side=LEFT, fill=Y, padx=(0, 1))
        left.pack_propagate(False)

        right = Frame(tab, bg=C["bg"])
        right.pack(side=LEFT, fill=BOTH, expand=True)

        # 左侧参数
        param_title = Frame(left, bg=C["bg_card"], height=36)
        param_title.pack(fill=X)
        param_title.pack_propagate(False)
        Label(param_title, text="  ◆ 回测参数", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(side=LEFT, padx=10)

        param_body = Frame(left, bg=C["bg_panel"])
        param_body.pack(fill=BOTH, expand=True, padx=14, pady=14)

        Label(param_body, text="股票代码", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._bt_symbol = StringVar(value="600000.SH")
        Entry(param_body, textvariable=self._bt_symbol, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["accent"], insertbackground=C["accent"],
              relief="flat").pack(fill=X, ipady=6, pady=(0, 8))

        Label(param_body, text="交易策略", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._bt_strategy = StringVar(value="双均线策略")
        bt_strat_display = ["双均线策略", "MACD策略", "布林带策略", "RSI策略",
                            "KDJ策略", "ATR通道突破", "动量突破策略", "VWAP策略"]
        OptionMenu(param_body, self._bt_strategy, *bt_strat_display).pack(fill=X, pady=(0, 8))

        # 策略参数标签映射（动态切换）
        self._bt_param_labels = {
            "双均线策略":   ("短期均线", "长期均线", "5", "20"),
            "MACD策略":    ("快线周期", "慢线周期", "12", "26"),
            "布林带策略":  ("布林周期", "标准差倍数", "20", "2.0"),
            "RSI策略":     ("RSI周期", "超卖阈值", "14", "30"),
            "KDJ策略":     ("RSV周期", "K平滑", "9", "3"),
            "ATR通道突破": ("SMA周期", "ATR周期", "20", "14"),
            "动量突破策略": ("价格周期", "成交量倍数", "20", "2.0"),
            "VWAP策略":    ("VWAP周期", "ATR周期", "20", "14"),
        }

        Label(param_body, text="开始日期", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._bt_start = StringVar(value=(datetime.now() - timedelta(days=365*3)).strftime("%Y-%m-%d"))
        Entry(param_body, textvariable=self._bt_start, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["text"], insertbackground=C["accent"],
              relief="flat").pack(fill=X, ipady=6, pady=(0, 8))

        Label(param_body, text="结束日期", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._bt_end = StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        Entry(param_body, textvariable=self._bt_end, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["text"], insertbackground=C["accent"],
              relief="flat").pack(fill=X, ipady=6, pady=(0, 8))

        self._bt_label_short = Label(param_body, text="短期均线", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"])
        self._bt_label_short.pack(anchor=W)
        self._bt_short = StringVar(value="5")
        Entry(param_body, textvariable=self._bt_short, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["text"], relief="flat").pack(fill=X, ipady=6, pady=(0, 8))

        self._bt_label_long = Label(param_body, text="长期均线", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"])
        self._bt_label_long.pack(anchor=W)
        self._bt_long = StringVar(value="20")
        Entry(param_body, textvariable=self._bt_long, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["text"], relief="flat").pack(fill=X, ipady=6, pady=(0, 8))

        # 策略切换时动态更新参数标签
        def _on_strategy_change(*_):
            labels = self._bt_param_labels.get(self._bt_strategy.get(),
                                                ("参数A", "参数B", "5", "20"))
            self._bt_label_short.config(text=labels[0])
            self._bt_label_long.config(text=labels[1])
            self._bt_short.set(labels[2])
            self._bt_long.set(labels[3])
        self._bt_strategy.trace_add("write", _on_strategy_change)

        Button(param_body, text="▶  运行回测", font=("Consolas", 11, "bold"),
               bg=C["accent"], fg=C["bg"], relief="flat", cursor="hand2",
               command=self._run_backtest).pack(fill=X, ipady=10, pady=(16, 0))

        # 右侧结果
        result_title = Frame(right, bg=C["bg_card"], height=36)
        result_title.pack(fill=X)
        result_title.pack_propagate(False)
        Label(result_title, text="  ◆ 回测结果", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(side=LEFT, padx=8)

        self._bt_result = Text(right, bg=C["bg"], fg=C["text"],
                                font=("Consolas", 9), relief="flat",
                                wrap="word", padx=16, pady=12)
        bt_scroll = Scrollbar(right, command=self._bt_result.yview,
                               bg=C["bg_panel"], troughcolor=C["bg"], width=8)
        self._bt_result.configure(yscrollcommand=bt_scroll.set)
        bt_scroll.pack(side=RIGHT, fill=Y)
        self._bt_result.pack(fill=BOTH, expand=True)

        self._bt_result.tag_configure("accent", foreground=C["accent"])
        self._bt_result.tag_configure("cyan", foreground=C["cyan"])
        self._bt_result.tag_configure("red", foreground=C["red"])
        self._bt_result.tag_configure("orange", foreground=C["orange"])
        self._bt_result.tag_configure("dim", foreground=C["text_dim"])

        self._log_system("回测模块已加载")

    def _run_backtest(self):
        """运行回测"""
        symbol = self._bt_symbol.get().strip()
        strategy_display = self._bt_strategy.get()
        strategy_name = self._strat_id_map.get(strategy_display, "dual_ma")
        start = self._bt_start.get().strip()
        end = self._bt_end.get().strip()

        if not symbol:
            messagebox.showwarning("提示", "请输入股票代码")
            return

        self._bt_result.delete("1.0", END)
        self._bt_result.insert(END, f"  回测启动\n", "accent")
        self._bt_result.insert(END, f"  股票: {symbol} | 策略: {strategy_name}\n", "dim")
        self._bt_result.insert(END, f"  区间: {start} ~ {end}\n\n")

        def _do():
            try:
                from core.data.data_manager import DataManager
                from core.backtest.engine import BacktestEngine
                from config.manager import get_config

                config = get_config()
                data_mgr = DataManager(config)

                self.root.after(0, lambda: self._bt_result.insert(END, "  [*] 获取数据...\n", "cyan"))
                data = data_mgr.get_history(symbol, start, end, freq="daily")

                if data is None or data.empty:
                    self.root.after(0, lambda: self._bt_result.insert(
                        END, f"  [!] 获取 {symbol} 数据失败\n", "red"))
                    self.root.after(0, lambda: self._bt_result.insert(
                        END, "  可能原因: 股票代码错误 / 所有数据源不可用 / 日期无交易日\n", "dim"))
                    return

                self.root.after(0, lambda: self._bt_result.insert(
                    END, f"  [+] 获取 {len(data)} 根K线\n", "accent"))

                # 加载策略
                strategy_map = {
                    "dual_ma": ("strategies.dual_ma", "DualMAStrategy"),
                    "macd": ("strategies.macd_strategy", "MACDStrategy"),
                    "bollinger": ("strategies.bollinger_strategy", "BollingerStrategy"),
                    "rsi": ("strategies.rsi_strategy", "RSIStrategy"),
                    "kdj": ("strategies.kdj_strategy", "KDJStrategy"),
                    "atr_breakout": ("strategies.atr_breakout_strategy", "ATRBreakoutStrategy"),
                    "momentum": ("strategies.momentum_strategy", "MomentumBreakoutStrategy"),
                    "vwap": ("strategies.vwap_strategy", "VWAPStrategy"),
                }

                mod_path, cls_name = strategy_map.get(strategy_name, strategy_map["dual_ma"])
                mod = importlib.import_module(mod_path)
                strategy_cls = getattr(mod, cls_name)
                short_w = int(self._bt_short.get() or 5)
                long_w = int(self._bt_long.get() or 20)
                strategy = strategy_cls(
                    strategy_id=f"{strategy_name}_{symbol}",
                    params={"short_window": short_w, "long_window": long_w},
                )

                self.root.after(0, lambda: self._bt_result.insert(END, "  [*] 运行回测引擎...\n", "cyan"))

                engine = BacktestEngine(config)
                engine.add_strategy(strategy)
                results = engine.run(data, symbol)

                # 显示结果
                def _show():
                    self._bt_result.insert(END, "  [+] 回测完成！\n\n", "accent")

                    if "error" in results:
                        self._bt_result.insert(END, f"  [!] {results['error']}\n", "red")
                        return

                    metrics = results.get("metrics", {})
                    final_acct = results.get("final_account")
                    final_equity = final_acct.total_assets if final_acct else 0
                    initial = 1000000

                    display = [
                        ("初始资金", f"¥{initial:,.2f}"),
                        ("最终资产", f"¥{final_equity:,.2f}"),
                        ("总收益率", f"{metrics.get('total_return', 0):.2%}"),
                        ("年化收益率", f"{metrics.get('annualized_return', 0):.2%}"),
                        ("最大回撤", f"{metrics.get('max_drawdown', 0):.2%}"),
                        ("夏普比率", f"{metrics.get('sharpe_ratio', 0):.4f}"),
                        ("胜率", f"{metrics.get('win_rate', 0):.2%}"),
                        ("总交易笔数", str(results.get('total_trades', 0))),
                    ]

                    for name, value in display:
                        self._bt_result.insert(END, f"  {name}: ", "dim")
                        self._bt_result.insert(END, f"{value}\n")

                    self._bt_result.insert(END, f"\n  回测耗时: {results.get('elapsed_seconds', 0):.2f}s\n", "dim")

                self.root.after(0, _show)

            except (ImportError, ModuleNotFoundError) as e:
                self.root.after(0, lambda e=e: self._bt_result.insert(
                    END, f"\n  [!] 缺少依赖: {e}\n  请运行: pip install -r requirements.txt\n", "red"))
            except (ValueError, TypeError) as e:
                self.root.after(0, lambda e=e: self._bt_result.insert(
                    END, f"\n  [!] 参数错误: {e}\n", "red"))
            except (ConnectionError, TimeoutError, OSError) as e:
                self.root.after(0, lambda e=e: self._bt_result.insert(
                    END, f"\n  [!] 网络错误: {e}\n  请检查网络连接后重试\n", "red"))
            except Exception as e:
                self.root.after(0, lambda e=e: self._bt_result.insert(
                    END, f"\n  [!] 回测失败: {type(e).__name__}: {e}\n", "red"))

        threading.Thread(target=_do, daemon=True).start()

    def _toggle_shadow_mode(self):
        """切换影子模式（试驾模式）"""
        if not self._shadow_mode:
            # 启动影子模式
            from core.shadow import ShadowTrader
            strategy_display = self._auto_strat.get()
            strategy_id = self._strat_id_map.get(strategy_display, "dual_ma")
            symbol = self._auto_sym.get().strip()

            if not symbol:
                messagebox.showwarning("提示", "请输入股票代码")
                return

            # 创建策略实例
            import importlib
            strategy_map = {
                "dual_ma": ("strategies.dual_ma", "DualMAStrategy"),
                "macd": ("strategies.macd_strategy", "MACDStrategy"),
                "bollinger": ("strategies.bollinger_strategy", "BollingerStrategy"),
                "rsi": ("strategies.rsi_strategy", "RSIStrategy"),
                "kdj": ("strategies.kdj_strategy", "KDJStrategy"),
                "atr_breakout": ("strategies.atr_breakout_strategy", "ATRBreakoutStrategy"),
                "momentum": ("strategies.momentum_strategy", "MomentumBreakoutStrategy"),
                "vwap": ("strategies.vwap_strategy", "VWAPStrategy"),
            }
            entry = strategy_map.get(strategy_id)
            if not entry:
                return
            mod = importlib.import_module(entry[0])
            cls = getattr(mod, entry[1])
            strategy = cls(strategy_id=f"shadow_{strategy_id}_{symbol}")

            self._shadow_trader = ShadowTrader(self._config)
            self._shadow_trader.start(strategy, symbol, strategy_display)
            self._shadow_mode = True

            # 初始化冲突仲裁器
            from core.arbitrator import ConflictArbitrator, ConflictMode
            mode_map = {
                "策略信号优先": ConflictMode.STRATEGY_PRIORITY,
                "止盈止损优先": ConflictMode.STOP_PRIORITY,
                "动态优先（推荐）": ConflictMode.DYNAMIC,
            }
            arb_mode = mode_map.get(self._conflict_mode.get(), ConflictMode.DYNAMIC)
            self._shadow_arbitrator = ConflictArbitrator(mode=arb_mode)

            self._shadow_btn.config(text="■ 停止试驾模式", bg=C["red"], fg="white")
            self._shadow_status.config(text=f"🚗 影子运行中: {strategy_display} on {symbol}（不实际下单）", fg=C["orange"])
            self._live_log_insert(f"  [+] 影子模式启动: {strategy_display} on {symbol}\n", "orange")
            self._live_log_insert(f"  [仲裁] 模式: {self._shadow_arbitrator.get_mode_display()}\n", "cyan")
        else:
            # 停止影子模式
            if hasattr(self, '_shadow_trader') and self._shadow_trader:
                report = self._shadow_trader.get_report()
                self._shadow_trader.stop()
                self._live_log_insert(
                    f"  [+] 影子模式停止。运行{report.running_days}天，总盈亏: ¥{report.total_pnl:,.2f}\n", "orange")

                # 检查是否满20天，给出评估
                eval_result = self._shadow_trader.get_evaluation()
                if eval_result:
                    self._live_log_insert(
                        f"  📊 试驾评估: 年化{eval_result['annualized_return_pct']:.1f}%, "
                        f"回撤{eval_result['max_drawdown_pct']:.1f}%, "
                        f"夏普{eval_result['sharpe_ratio']:.2f}\n", "accent")
                    self._live_log_insert(f"  💡 建议: {eval_result['recommendation']}\n", "cyan")

            self._shadow_mode = False
            self._shadow_btn.config(text="🚗 试驾模式（影子跟单）", bg=C["bg_input"], fg=C["orange"])
            self._shadow_status.config(text="影子模式未启动", fg=C["text_muted"])

    # ════════════════════════════════════════════════════════════════
    #  扫股器（多标的批量回测）
    # ════════════════════════════════════════════════════════════════

    def _build_screener_tab(self):
        """扫股器 — 多标的批量回测"""
        tab = Frame(self.notebook, bg=C["bg"])
        self.notebook.add(tab, text="  ◆ 扫股器  ")

        # 左侧参数
        left = Frame(tab, bg=C["bg_panel"], width=340)
        left.pack(side=LEFT, fill=Y, padx=(0, 1))
        left.pack_propagate(False)

        right = Frame(tab, bg=C["bg"])
        right.pack(side=LEFT, fill=BOTH, expand=True)

        # 左侧参数面板
        param_title = Frame(left, bg=C["bg_card"], height=36)
        param_title.pack(fill=X)
        param_title.pack_propagate(False)
        Label(param_title, text="  ◆ 扫股器参数", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(side=LEFT, padx=10)

        param_body = Frame(left, bg=C["bg_panel"])
        param_body.pack(fill=BOTH, expand=True, padx=14, pady=14)

        # 策略选择
        Label(param_body, text="交易策略", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._scr_strategy = StringVar(value="双均线策略")
        strat_display = list(self._strat_id_map.keys())
        OptionMenu(param_body, self._scr_strategy, *strat_display).pack(fill=X, pady=(0, 8))

        # 股票池选择
        Label(param_body, text="股票池", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._scr_pool = StringVar(value="沪深300龙头")
        from core.screener import STOCK_POOLS
        pool_names = list(STOCK_POOLS.keys()) + ["自定义..."]
        OptionMenu(param_body, self._scr_pool, *pool_names).pack(fill=X, pady=(0, 4))

        # 自定义股票池输入
        Label(param_body, text="自定义股票代码（每行一个，或逗号分隔）", font=("Consolas", 8),
              bg=C["bg_panel"], fg=C["text_muted"]).pack(anchor=W)
        self._scr_custom = Text(param_body, bg=C["bg_input"], fg=C["text"],
                                font=("Consolas", 8), height=4, relief="flat", wrap="word")
        self._scr_custom.pack(fill=X, pady=(0, 8))

        # 日期范围
        Label(param_body, text="开始日期", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._scr_start = StringVar(value=(datetime.now() - timedelta(days=365*3)).strftime("%Y-%m-%d"))
        Entry(param_body, textvariable=self._scr_start, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["text"], relief="flat").pack(fill=X, ipady=6, pady=(0, 8))

        Label(param_body, text="结束日期", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._scr_end = StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        Entry(param_body, textvariable=self._scr_end, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["text"], relief="flat").pack(fill=X, ipady=6, pady=(0, 8))

        # 进度
        self._scr_progress = Label(param_body, text="", font=("Consolas", 9),
                                    bg=C["bg_panel"], fg=C["orange"])
        self._scr_progress.pack(anchor=W, pady=4)

        # 按钮
        btn_frame = Frame(param_body, bg=C["bg_panel"])
        btn_frame.pack(fill=X, pady=(8, 0))
        Button(btn_frame, text="▶  开始批量回测", font=("Consolas", 11, "bold"),
               bg=C["accent"], fg=C["bg"], relief="flat", cursor="hand2",
               command=self._run_screener).pack(fill=X, ipady=10, pady=(0, 4))
        Button(btn_frame, text="■  停止", font=("Consolas", 9),
               bg=C["red"], fg="white", relief="flat",
               command=self._cancel_screener).pack(fill=X, ipady=4)

        # 右侧结果
        result_title = Frame(right, bg=C["bg_card"], height=36)
        result_title.pack(fill=X)
        result_title.pack_propagate(False)
        Label(result_title, text="  ◆ 回测排行榜", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(side=LEFT, padx=8)

        # 排序选项
        sort_frame = Frame(result_title, bg=C["bg_card"])
        sort_frame.pack(side=RIGHT, padx=8)
        Label(sort_frame, text="排序:", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).pack(side=LEFT)
        self._scr_sort = StringVar(value="年化收益率")
        sort_options = ["年化收益率", "夏普比率", "最大回撤", "胜率", "交易次数"]
        OptionMenu(sort_frame, self._scr_sort, *sort_options,
                   command=lambda _: self._sort_screener_results()).pack(side=LEFT)

        # 结果表格
        cols = ["排名", "代码", "名称", "年化收益", "最大回撤", "夏普", "胜率", "交易数", "操作"]
        col_widths = [5, 10, 10, 10, 10, 8, 8, 8, 12]

        table_header = Frame(right, bg=C["bg_input"])
        table_header.pack(fill=X, padx=8, pady=(4, 0))
        for h, w in zip(cols, col_widths):
            Label(table_header, text=h, font=("Consolas", 8, "bold"),
                  bg=C["bg_input"], fg=C["text_dim"], width=w, anchor=W).pack(side=LEFT, padx=1)

        # 可滚动结果区域
        result_canvas = Canvas(right, bg=C["bg"], highlightthickness=0)
        result_scroll = Scrollbar(right, orient="vertical", command=result_canvas.yview)
        self._scr_result_frame = Frame(result_canvas, bg=C["bg"])
        self._scr_result_frame.bind("<Configure>", lambda e: result_canvas.configure(scrollregion=result_canvas.bbox("all")))
        result_canvas.create_window((0, 0), window=self._scr_result_frame, anchor="nw")
        result_canvas.configure(yscrollcommand=result_scroll.set)
        result_canvas.pack(side=LEFT, fill=BOTH, expand=True, padx=8, pady=4)
        result_scroll.pack(side=RIGHT, fill=Y)

        def _scr_scroll(e):
            result_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        result_canvas.bind("<Enter>", lambda e: result_canvas.bind_all("<MouseWheel>", _scr_scroll))
        result_canvas.bind("<Leave>", lambda e: result_canvas.unbind_all("<MouseWheel>"))

        self._scr_results = []  # 存储结果数据
        self._screener = None
        Label(self._scr_result_frame, text="  选择股票池和策略，点击开始批量回测",
              font=("Consolas", 10), bg=C["bg"], fg=C["text_muted"]).pack(pady=40)

        self._log_system("扫股器已加载")

    def _run_screener(self):
        """运行批量回测"""
        from core.screener import StockScreener, STOCK_POOLS

        strategy_display = self._scr_strategy.get()
        strategy_id = self._strat_id_map.get(strategy_display, "dual_ma")
        pool_name = self._scr_pool.get()
        start = self._scr_start.get().strip()
        end = self._scr_end.get().strip()

        # 获取股票列表
        if pool_name == "自定义...":
            custom_text = self._scr_custom.get("1.0", END).strip()
            if not custom_text:
                messagebox.showwarning("提示", "请输入自定义股票代码")
                return
            symbols = [s.strip() for s in custom_text.replace(",", "\n").split("\n") if s.strip()]
        else:
            symbols = STOCK_POOLS.get(pool_name, [])

        if not symbols:
            messagebox.showwarning("提示", "股票池为空")
            return

        self._scr_progress.config(text=f"准备回测 {len(symbols)} 只股票...")

        def _do():
            screener = StockScreener(self._config)
            self._screener = screener

            def progress_cb(current, total, symbol):
                self.root.after(0, lambda: self._scr_progress.config(
                    text=f"正在回测第 {current}/{total} 只: {symbol}"))

            run = screener.run_batch(symbols, strategy_id, start, end, progress_cb)
            self._scr_results = run.results

            self.root.after(0, lambda: self._display_screener_results(run))

        threading.Thread(target=_do, daemon=True).start()

    def _cancel_screener(self):
        if self._screener:
            self._screener.cancel()
            self._scr_progress.config(text="已停止")

    def _display_screener_results(self, run):
        """显示扫股器结果"""
        for w in self._scr_result_frame.winfo_children():
            w.destroy()

        self._scr_progress.config(
            text=f"完成! {run.completed}/{run.symbol_count} 成功, 耗时{run.elapsed_seconds:.1f}s")

        if not run.results:
            Label(self._scr_result_frame, text="  无结果",
                  font=("Consolas", 10), bg=C["bg"], fg=C["text_muted"]).pack(pady=40)
            return

        for rank, r in enumerate(run.results, 1):
            row = Frame(self._scr_result_frame, bg=C["bg_card"])
            row.pack(fill=X, padx=2, pady=1)

            # 颜色
            ret_color = C["green"] if r.annualized_return >= 0 else C["red"]

            if r.error:
                Label(row, text=f"  {rank}", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"], width=5, anchor=W).pack(side=LEFT)
                Label(row, text=r.symbol, font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=10, anchor=W).pack(side=LEFT)
                Label(row, text=f"错误: {r.error}", font=("Consolas", 8), bg=C["bg_card"], fg=C["red"], width=40, anchor=W).pack(side=LEFT)
            else:
                medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(rank, f"{rank}")
                Label(row, text=f" {medal}", font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=5, anchor=W).pack(side=LEFT)
                Label(row, text=r.symbol, font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=10, anchor=W).pack(side=LEFT)
                Label(row, text=r.name[:6], font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"], width=10, anchor=W).pack(side=LEFT)
                Label(row, text=f"{r.annualized_return:.1%}", font=("Consolas", 8, "bold"), bg=C["bg_card"], fg=ret_color, width=10, anchor=W).pack(side=LEFT)
                Label(row, text=f"{r.max_drawdown:.1%}", font=("Consolas", 8), bg=C["bg_card"], fg=C["red"], width=10, anchor=W).pack(side=LEFT)
                Label(row, text=f"{r.sharpe_ratio:.2f}", font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=8, anchor=W).pack(side=LEFT)
                Label(row, text=f"{r.win_rate:.0%}", font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=8, anchor=W).pack(side=LEFT)
                Label(row, text=str(r.total_trades), font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=8, anchor=W).pack(side=LEFT)
                Button(row, text="回测", font=("Consolas", 7),
                       bg=C["accent"], fg=C["bg"], relief="flat",
                       command=lambda s=r.symbol: self._apply_screener_result(s)).pack(side=LEFT, padx=2, ipady=1)
                Button(row, text="模拟", font=("Consolas", 7),
                       bg=C["cyan"], fg=C["bg"], relief="flat",
                       command=lambda s=r.symbol: self._apply_screener_to_sim(s)).pack(side=LEFT, padx=2, ipady=1)

    def _apply_screener_result(self, symbol):
        """应用扫股器结果 — 跳转到回测（传递策略选择）"""
        self._bt_symbol.set(symbol)
        # 传递扫股器的策略选择到回测页
        scr_strategy = self._scr_strategy.get()
        if scr_strategy in self._strat_id_map:
            self._bt_strategy.set(scr_strategy)
        self.notebook.select(1)  # 切换到回测标签
        self._log_system(f"扫股器: 已选择 {symbol}，策略: {scr_strategy}")

    def _apply_screener_to_sim(self, symbol):
        """应用扫股器结果 — 跳转到模拟交易并填入股票代码（传递策略选择）"""
        self._trade_sym.set(symbol)
        self._auto_sym.set(symbol)
        # 传递扫股器的策略选择到自动交易
        scr_strategy = self._scr_strategy.get()
        if scr_strategy in self._strat_id_map:
            self._auto_strat.set(scr_strategy)
        # 切换到实盘交易标签（第4个标签，索引3）
        self.notebook.select(3)
        self._fetch_realtime_price()
        self._log_system(f"扫股器: 已将 {symbol} 填入模拟交易，策略: {scr_strategy}")

    def _sort_screener_results(self):
        """排序扫股器结果"""
        if not self._scr_results:
            return
        sort_key = self._scr_sort.get()
        key_map = {
            "年化收益率": lambda r: r.annualized_return,
            "夏普比率": lambda r: r.sharpe_ratio,
            "最大回撤": lambda r: -r.max_drawdown,  # 回撤越小越好
            "胜率": lambda r: r.win_rate,
            "交易次数": lambda r: r.total_trades,
        }
        key_fn = key_map.get(sort_key, lambda r: r.annualized_return)
        self._scr_results.sort(key=key_fn, reverse=True)
        # 重新显示
        class FakeRun:
            pass
        run = FakeRun()
        run.results = self._scr_results
        run.completed = len([r for r in self._scr_results if not r.error])
        run.symbol_count = len(self._scr_results)
        run.elapsed_seconds = 0
        self._display_screener_results(run)

    # ════════════════════════════════════════════════════════════════
    #  策略商店
    # ════════════════════════════════════════════════════════════════

    def _build_strategy_tab(self):
        """策略商店"""
        tab = Frame(self.notebook, bg=C["bg"])
        self.notebook.add(tab, text="  ◆ 策略商店  ")

        # 标题
        title = Frame(tab, bg=C["bg_card"], height=36)
        title.pack(fill=X, padx=8, pady=(8, 4))
        title.pack_propagate(False)
        Label(title, text="  ◆ 策略模板 — 选择策略，一键运行", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(side=LEFT, padx=8)

        Button(title, text="🔄 刷新", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["text"], relief="flat",
               command=self._load_strategy_templates).pack(side=RIGHT, padx=8)

        # 策略卡片区域（可滚动）
        canvas = Canvas(tab, bg=C["bg"], highlightthickness=0)
        scrollbar = Scrollbar(tab, orient="vertical", command=canvas.yview)
        self._strat_scroll_frame = Frame(canvas, bg=C["bg"])

        self._strat_scroll_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self._strat_scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side=LEFT, fill=BOTH, expand=True, padx=8, pady=4)
        scrollbar.pack(side=RIGHT, fill=Y)

        # 鼠标滚轮支持（仅鼠标在canvas上时生效）
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        def _bind_scroll(e):
            canvas.bind_all("<MouseWheel>", _on_mousewheel)
        def _unbind_scroll(e):
            canvas.unbind_all("<MouseWheel>")
        canvas.bind("<Enter>", _bind_scroll)
        canvas.bind("<Leave>", _unbind_scroll)

        self._strat_cards_frame = self._strat_scroll_frame
        self._load_strategy_templates()

        self._log_system("策略商店已加载")

    def _load_strategy_templates(self):
        """加载策略模板卡片"""
        for w in self._strat_cards_frame.winfo_children():
            w.destroy()

        from core.strategy.template_loader import StrategyTemplateLoader
        loader = StrategyTemplateLoader()
        templates = loader.load_all()

        if not templates:
            Label(self._strat_cards_frame, text="  未找到策略模板文件",
                  font=("Consolas", 10), bg=C["bg"], fg=C["text_muted"]).pack(pady=40)
            return

        for tmpl in templates:
            self._create_strategy_card(tmpl, loader)

    def _create_strategy_card(self, tmpl, loader):
        """创建单个策略卡片（含详细使用说明）"""
        risk_color = loader.get_risk_color(tmpl.get("risk_level", "medium"))
        risk_label = loader.get_risk_label(tmpl.get("risk_level", "medium"))
        bt = tmpl.get("backtest_result", {})

        card = Frame(self._strat_cards_frame, bg=C["bg_card"], padx=16, pady=12)
        card.pack(fill=X, padx=8, pady=4)

        # 上行：名称 + 风险标签 + 信号类型
        top = Frame(card, bg=C["bg_card"])
        top.pack(fill=X)

        Label(top, text=tmpl.get("display_name", ""), font=("Consolas", 12, "bold"),
              bg=C["bg_card"], fg=C["text_bright"]).pack(side=LEFT)

        Label(top, text=f" {risk_label} ", font=("Consolas", 8, "bold"),
              bg=risk_color, fg=C["bg"]).pack(side=LEFT, padx=8)

        market = tmpl.get("suitable_market", "")
        if market:
            Label(top, text=f" {market} ", font=("Consolas", 8),
                  bg=C["bg_input"], fg=C["text_dim"]).pack(side=LEFT, padx=4)

        signal_type = tmpl.get("signal_type", "")
        signal_labels = {"trend": "趋势跟踪", "reversal": "反转", "breakout": "突破", "rotation": "轮动"}
        if signal_type:
            Label(top, text=f" {signal_labels.get(signal_type, signal_type)} ", font=("Consolas", 8),
                  bg=C["bg_input"], fg=C["cyan"]).pack(side=LEFT, padx=4)

        # 描述
        Label(card, text=tmpl.get("description", ""), font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"], wraplength=800, justify="left").pack(anchor=W, pady=4)

        # 参数详情
        params = tmpl.get("parameters", [])
        if params:
            param_frame = Frame(card, bg=C["bg_input"], padx=10, pady=6)
            param_frame.pack(fill=X, pady=4)
            Label(param_frame, text="参数配置:", font=("Consolas", 8, "bold"),
                  bg=C["bg_input"], fg=C["cyan"]).pack(anchor=W)
            for p in params:
                p_text = (f"  • {p.get('display_name', p.get('name', ''))}"
                          f"  默认={p.get('default', '')}"
                          f"  范围=[{p.get('min', '')}~{p.get('max', '')}]"
                          f"  {p.get('description', '')}")
                Label(param_frame, text=p_text, font=("Consolas", 8),
                      bg=C["bg_input"], fg=C["text_dim"], wraplength=800, justify="left").pack(anchor=W)

        # 回测摘要
        if bt:
            bt_frame = Frame(card, bg=C["bg_card"])
            bt_frame.pack(anchor=W, pady=4)
            for label, value in [
                ("年化收益", f"{bt.get('annualized_return', 0):.1%}"),
                ("最大回撤", f"{bt.get('max_drawdown', 0):.1%}"),
                ("胜率", f"{bt.get('win_rate', 0):.0%}"),
                ("交易次数", str(bt.get('total_trades', 0))),
            ]:
                Label(bt_frame, text=f"{label}: {value}  ", font=("Consolas", 8),
                      bg=C["bg_card"], fg=C["text_dim"]).pack(side=LEFT)
            if bt.get("period"):
                Label(bt_frame, text=f"回测区间: {bt['period']}  ", font=("Consolas", 8),
                      bg=C["bg_card"], fg=C["text_dim"]).pack(side=LEFT)

        # 使用提示
        tips = {
            "ma_cross_v1": "适合趋势明确的行情。金叉买入、死叉卖出。震荡市容易频繁止损。",
            "rsi_reversal_v1": "适合震荡市低买高卖。RSI<30买入,>70卖出。趋势行情中慎用。",
            "market_timing_dca_v1": "适合长期定投。大盘在均线上方时买入，下方时暂停。风险最低。",
            "volume_breakout_v1": "适合捕捉强势股启动。放量突破买入，需要严格止损。",
            "low_valuation_rotation_v1": "适合全行情。定期轮动买入低估值股票，卖出高估值持仓。",
        }
        sid = tmpl.get("strategy_id", "")
        if sid in tips:
            tip_frame = Frame(card, bg=C["bg_card"])
            tip_frame.pack(fill=X, pady=2)
            Label(tip_frame, text=f"💡 使用建议: {tips[sid]}", font=("Consolas", 8),
                  bg=C["bg_card"], fg=C["orange"], wraplength=800, justify="left").pack(anchor=W)

        # 按钮行
        btn_row = Frame(card, bg=C["bg_card"])
        btn_row.pack(anchor=E, pady=(4, 0))

        Button(btn_row, text="▶ 使用此策略", font=("Consolas", 9, "bold"),
               bg=C["accent"], fg=C["bg"], relief="flat", cursor="hand2",
               command=lambda t=tmpl: self._use_strategy(t)).pack(side=LEFT, padx=4)

    def _use_strategy(self, tmpl):
        """使用策略 — 跳转到回测并预填参数"""
        self.notebook.select(1)  # 切换到回测标签
        strategy_id = tmpl.get("strategy_id", "")
        # 先查模板→内置映射
        builtin_id = self._template_to_builtin.get(strategy_id)
        if builtin_id:
            display_name = self._strategy_display_names.get(builtin_id, tmpl.get("display_name", ""))
        else:
            display_name = tmpl.get("display_name", "")
        # 尝试设置回测策略下拉框
        if display_name in self._strat_id_map:
            self._bt_strategy.set(display_name)
        else:
            # 模板策略不在内置列表中，提示用户
            self._bt_result.delete("1.0", END)
            self._bt_result.insert(END, f"  策略 '{display_name}' 是独立模板策略\n", "orange")
            self._bt_result.insert(END, f"  请在回测页面手动选择内置策略运行\n", "dim")
            self._bt_result.insert(END, f"  可用内置策略: {', '.join(self._strat_id_map.keys())}\n", "dim")
        params = tmpl.get("parameters", [])
        for p in params:
            if p.get("name") in ("short_period", "short_window"):
                self._bt_short.set(str(p.get("default", 5)))
            elif p.get("name") in ("long_period", "long_window"):
                self._bt_long.set(str(p.get("default", 20)))


    # ════════════════════════════════════════════════════════════════
    #  实盘交易（专业级模拟盘）
    # ════════════════════════════════════════════════════════════════

    def _build_live_tab(self):
        """实盘交易 — 专业级模拟盘"""
        tab = Frame(self.notebook, bg=C["bg"])
        self.notebook.add(tab, text="  ◈ 实盘交易  ")

        # 左侧：连接 + 下单 + 策略
        left = Frame(tab, bg=C["bg_panel"], width=460)
        left.pack(side=LEFT, fill=Y, padx=(0, 1))
        left.pack_propagate(False)

        # 左侧可滚动
        left_canvas = Canvas(left, bg=C["bg_panel"], highlightthickness=0)
        left_scroll = Scrollbar(left, orient="vertical", command=left_canvas.yview)
        left_inner = Frame(left_canvas, bg=C["bg_panel"])
        left_inner.bind("<Configure>", lambda e: left_canvas.configure(scrollregion=left_canvas.bbox("all")))
        left_canvas.create_window((0, 0), window=left_inner, anchor="nw")
        left_canvas.configure(yscrollcommand=left_scroll.set)
        left_canvas.pack(side=LEFT, fill=BOTH, expand=True)
        left_scroll.pack(side=RIGHT, fill=Y)

        def _left_scroll(e):
            left_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        def _bind_left(e):
            left_canvas.bind_all("<MouseWheel>", _left_scroll)
        def _unbind_left(e):
            left_canvas.unbind_all("<MouseWheel>")
        left_canvas.bind("<Enter>", _bind_left)
        left_canvas.bind("<Leave>", _unbind_left)

        # ── 券商连接 ──
        conn_title = Frame(left_inner, bg=C["bg_card"], height=36)
        conn_title.pack(fill=X)
        conn_title.pack_propagate(False)
        Label(conn_title, text="  ◆ 券商连接", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(side=LEFT, padx=8)

        conn_body = Frame(left_inner, bg=C["bg_panel"])
        conn_body.pack(fill=X, padx=14, pady=10)

        Label(conn_body, text="选择券商", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._live_broker = StringVar(value="🎮 模拟交易（纸盘）")
        broker_options = [
            ("simulation", "🎮 模拟交易（纸盘）"),
            ("easytrader_yinhe", "🏦 银河证券"),
            ("easytrader_huatai", "🏦 华泰证券"),
            ("easytrader_guangfa", "🏦 广发证券"),
            ("qmt", "⚡ QMT 迅投量化"),
            ("ptrade", "⚡ Ptrade 恒生量化"),
        ]
        self._broker_id_map = {display: bid for bid, display in broker_options}
        OptionMenu(conn_body, self._live_broker, *[d for _, d in broker_options]).pack(fill=X, pady=(0, 2))

        # 券商详细说明（匹配度/配置需求/配置方法）
        self._broker_descriptions = {
            "🎮 模拟交易（纸盘）": {
                "match": "★★★★★ 完美匹配",
                "need": "无需额外安装，开箱即用",
                "config": "无需配置。自动使用系统初始资金（默认100万）进行模拟交易。",
            },
            "🏦 银河证券": {
                "match": "★★★★☆ 高度匹配",
                "need": "需安装 easytrader + pywinauto，需银河证券客户端",
                "config": "1) pip install easytrader pywinauto\n2) 安装银河证券双子星客户端并登录\n3) 填写银河资金账号和交易密码\n4) 客户端需保持前台运行",
            },
            "🏦 华泰证券": {
                "match": "★★★★☆ 高度匹配",
                "need": "需安装 easytrader + pywinauto，需华泰网上交易客户端",
                "config": "1) pip install easytrader pywinauto\n2) 安装华泰网上交易系统客户端并登录\n3) 填写华泰资金账号和交易密码\n4) 客户端需保持前台运行",
            },
            "🏦 广发证券": {
                "match": "★★★★☆ 高度匹配",
                "need": "需安装 easytrader + pywinauto，需广发证券客户端",
                "config": "1) pip install easytrader pywinauto\n2) 安装广发证券客户端并登录\n3) 填写广发资金账号和交易密码\n4) 客户端需保持前台运行",
            },
            "⚡ QMT 迅投量化": {
                "match": "★★★★★ 最佳方案",
                "need": "需开通QMT权限（通常要求资产50万+），需安装QMT客户端",
                "config": "1) 联系券商开通QMT量化权限\n2) 下载安装QMT迅投客户端\n3) 在QMT客户端中登录并保持运行\n4) 填写QMT路径和账号信息\n5) 系统通过xtquant库与QMT通信",
            },
            "⚡ Ptrade 恒生量化": {
                "match": "★★★★☆ 高度匹配",
                "need": "需开通Ptrade权限（通常要求资产50万+），需券商分配Ptrade账号",
                "config": "1) 联系券商开通Ptrade量化权限\n2) 获取Ptrade服务器地址和账号\n3) 填写Ptrade连接信息（服务器/账号/密码）\n4) Ptrade为服务端模式，无需本地客户端",
            },
        }

        Label(conn_body, text="初始资金", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._init_balance = StringVar(value="1000000")
        Entry(conn_body, textvariable=self._init_balance, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["accent"], relief="flat").pack(fill=X, ipady=4, pady=(0, 6))

        Label(conn_body, text="账号（可选）", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._live_account = StringVar()
        Entry(conn_body, textvariable=self._live_account, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["text"], relief="flat").pack(fill=X, ipady=4, pady=(0, 6))

        Label(conn_body, text="密码（可选）", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._live_password = StringVar()
        Entry(conn_body, textvariable=self._live_password, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["text"], relief="flat", show="*").pack(fill=X, ipady=4, pady=(0, 8))

        btn_frame = Frame(conn_body, bg=C["bg_panel"])
        btn_frame.pack(fill=X, pady=(0, 6))
        Button(btn_frame, text="🔗 连接", font=("Consolas", 10, "bold"),
               bg=C["cyan"], fg=C["bg"], relief="flat",
               command=self._connect_broker).pack(side=LEFT, fill=X, expand=True, padx=(0, 3), ipady=7)
        Button(btn_frame, text="✖ 断开", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["red"], relief="flat",
               command=self._disconnect_broker).pack(side=LEFT, fill=X, expand=True, padx=(3, 0), ipady=7)

        self._live_conn_status = Label(conn_body, text="状态: 未连接",
                                        font=("Consolas", 9), bg=C["bg_panel"], fg=C["text_dim"])
        self._live_conn_status.pack(anchor=W, pady=4)

        # ── 交易时段提示 ──
        self._trading_hours_label = Label(conn_body, text="", font=("Consolas", 8),
                                           bg=C["bg_panel"], fg=C["text_dim"])
        self._trading_hours_label.pack(anchor=W)
        self._update_trading_hours_label()

        # ── 券商说明标签 ──
        self._broker_desc_label = Label(conn_body, text="", font=("Consolas", 8),
                                         bg=C["bg_panel"], fg=C["text_dim"],
                                         wraplength=320, justify="left")
        self._broker_desc_label.pack(anchor=W, pady=(2, 4))
        self._update_broker_desc()
        self._live_broker.trace_add("write", lambda *_: self._update_broker_desc())

        # ── 进程守护 ──
        guardian_frame = LabelFrame(conn_body, text="  ◆ 进程守护  ",
                                     font=("Consolas", 9, "bold"), bg=C["bg_card"],
                                     fg=C["green"], labelanchor="nw")
        guardian_frame.pack(fill=X, pady=4)

        g_body = Frame(guardian_frame, bg=C["bg_card"])
        g_body.pack(fill=X, padx=10, pady=8)

        self._guardian_status_label = Label(g_body, text="守护未启动", font=("Consolas", 8),
                                             bg=C["bg_card"], fg=C["text_muted"])
        self._guardian_status_label.pack(side=LEFT)

        self._guardian_btn = Button(g_body, text="🛡️ 启动守护", font=("Consolas", 8),
                                     bg=C["bg_input"], fg=C["green"], relief="flat",
                                     command=self._toggle_guardian)
        self._guardian_btn.pack(side=RIGHT, padx=4, ipady=2)

        self._guardian = None

        # ── 手动下单 ──
        trade_frame = LabelFrame(conn_body, text="  ◆ 手动下单  ",
                                  font=("Consolas", 9, "bold"), bg=C["bg_card"],
                                  fg=C["cyan"], labelanchor="nw")
        trade_frame.pack(fill=X, pady=8)

        t_input = Frame(trade_frame, bg=C["bg_card"])
        t_input.pack(fill=X, padx=10, pady=10)

        Label(t_input, text="股票代码", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=0, sticky=W, pady=(0, 2))
        self._trade_sym = StringVar(value="600000")
        sym_entry = Entry(t_input, textvariable=self._trade_sym, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["text"], relief="flat", width=8)
        sym_entry.grid(row=1, column=0, padx=(0, 6), ipady=4)
        sym_entry.bind("<FocusOut>", lambda e: self._fetch_realtime_price())
        # 同步股票代码到策略自动交易
        self._trade_sym.trace_add("write", self._sync_sym_to_auto)

        Label(t_input, text="数量", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=1, sticky=W, pady=(0, 2))
        self._trade_qty = StringVar(value="100")
        Entry(t_input, textvariable=self._trade_qty, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["text"], relief="flat", width=6).grid(row=1, column=1, padx=(0, 6), ipady=4)

        Label(t_input, text="当前价", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=2, sticky=W, pady=(0, 2))
        self._trade_price = StringVar()
        Entry(t_input, textvariable=self._trade_price, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["accent"], relief="flat", width=8).grid(row=1, column=2, ipady=4)

        Button(t_input, text="🔄", font=("Consolas", 8),
               bg=C["bg_input"], fg=C["text"], relief="flat", width=3,
               command=self._fetch_realtime_price).grid(row=1, column=3, padx=4)

        # 仓位快捷按钮
        qty_frame = Frame(trade_frame, bg=C["bg_card"])
        qty_frame.pack(fill=X, padx=10, pady=(0, 6))
        Label(qty_frame, text="快捷:", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).pack(side=LEFT)
        for label, pct in [("全仓", 100), ("半仓", 50), ("1/4仓", 25)]:
            Button(qty_frame, text=label, font=("Consolas", 8),
                   bg=C["bg_input"], fg=C["text"], relief="flat",
                   command=lambda p=pct: self._calc_quantity(p)).pack(side=LEFT, padx=3, ipady=2)

        t_btns = Frame(trade_frame, bg=C["bg_card"])
        t_btns.pack(fill=X, padx=8, pady=(0, 8))
        Button(t_btns, text="▲ 买入", font=("Consolas", 9, "bold"),
               bg=C["accent"], fg=C["bg"], relief="flat",
               command=lambda: self._manual_trade("BUY")).pack(side=LEFT, fill=X, expand=True, padx=(0, 2), ipady=5)
        Button(t_btns, text="▼ 卖出", font=("Consolas", 9, "bold"),
               bg=C["red"], fg="white", relief="flat",
               command=lambda: self._manual_trade("SELL")).pack(side=LEFT, fill=X, expand=True, padx=(2, 0), ipady=5)

        # 智能执行选项
        exec_row = Frame(trade_frame, bg=C["bg_card"])
        exec_row.pack(fill=X, padx=8, pady=(0, 4))
        self._use_smart_exec = IntVar(value=0)
        from tkinter import Checkbutton
        Checkbutton(exec_row, text="智能执行(TWAP)", variable=self._use_smart_exec,
                     font=("Consolas", 8), bg=C["bg_card"], fg=C["cyan"],
                     selectcolor=C["bg_input"], activebackground=C["bg_card"]).pack(side=LEFT)
        Label(exec_row, text="大单自动拆分", font=("Consolas", 7),
              bg=C["bg_card"], fg=C["text_muted"]).pack(side=LEFT, padx=4)

        # ── 止损止盈 ──
        sl_frame = LabelFrame(conn_body, text="  ◆ 止损止盈  ",
                               font=("Consolas", 9, "bold"), bg=C["bg_card"],
                               fg=C["orange"], labelanchor="nw")
        sl_frame.pack(fill=X, pady=4)

        sl_input = Frame(sl_frame, bg=C["bg_card"])
        sl_input.pack(fill=X, padx=8, pady=6)

        Label(sl_input, text="止损价", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=0, sticky=W)
        self._stop_loss_price = StringVar()
        Entry(sl_input, textvariable=self._stop_loss_price, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["red"], relief="flat", width=8).grid(row=1, column=0, padx=(0, 4), ipady=3)

        Label(sl_input, text="止盈价", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=1, sticky=W)
        self._take_profit_price = StringVar()
        Entry(sl_input, textvariable=self._take_profit_price, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["accent"], relief="flat", width=8).grid(row=1, column=1, padx=(0, 4), ipady=3)

        Label(sl_input, text="移动止损%", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=2, sticky=W)
        self._trailing_stop_pct = StringVar()
        Entry(sl_input, textvariable=self._trailing_stop_pct, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["orange"], relief="flat", width=6).grid(row=1, column=2, ipady=3)

        sl_btn_row = Frame(sl_frame, bg=C["bg_card"])
        sl_btn_row.pack(fill=X, padx=10, pady=(0, 8))
        Button(sl_btn_row, text="设置止损止盈", font=("Consolas", 8),
               bg=C["bg_input"], fg=C["orange"], relief="flat",
               command=self._set_stop_rules).pack(side=LEFT, fill=X, expand=True, padx=(0, 3), ipady=4)
        Button(sl_btn_row, text="自动计算(2.3:1)", font=("Consolas", 8),
               bg=C["bg_input"], fg=C["cyan"], relief="flat",
               command=self._auto_calc_stop_loss).pack(side=LEFT, fill=X, expand=True, padx=(3, 0), ipady=4)

        # 盈亏比配置行
        ratio_row = Frame(sl_frame, bg=C["bg_card"])
        ratio_row.pack(fill=X, padx=10, pady=(0, 6))
        Label(ratio_row, text="盈亏比:", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).pack(side=LEFT)
        self._risk_reward_ratio = StringVar(value="2.3")
        Entry(ratio_row, textvariable=self._risk_reward_ratio, font=("Consolas", 8),
              bg=C["bg_input"], fg=C["cyan"], relief="flat", width=5).pack(side=LEFT, padx=4, ipady=1)
        Label(ratio_row, text=":1", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).pack(side=LEFT)
        Label(ratio_row, text="  (止盈距离 = 止损距离 × 盈亏比)", font=("Consolas", 7),
              bg=C["bg_card"], fg=C["text_muted"]).pack(side=LEFT, padx=4)

        # ── 策略自动交易 ──
        auto_frame = LabelFrame(conn_body, text="  ◆ 策略自动交易  ",
                                 font=("Consolas", 9, "bold"), bg=C["bg_card"],
                                 fg=C["orange"], labelanchor="nw")
        auto_frame.pack(fill=X, pady=4)

        a_input = Frame(auto_frame, bg=C["bg_card"])
        a_input.pack(fill=X, padx=10, pady=8)

        Label(a_input, text="股票", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=0, sticky=W)
        self._auto_sym = StringVar(value="600000")
        Entry(a_input, textvariable=self._auto_sym, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["text"], relief="flat", width=8).grid(row=1, column=0, padx=(0, 4), ipady=3)
        # 同步股票代码到手动下单
        self._auto_sym.trace_add("write", self._sync_sym_to_manual)

        Label(a_input, text="策略", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=1, sticky=W)
        self._auto_strat = StringVar(value="双均线策略")
        strat_display = list(self._strat_id_map.keys())
        OptionMenu(a_input, self._auto_strat, *strat_display).grid(row=1, column=1, padx=(0, 4))

        # 冲突仲裁模式
        Label(a_input, text="冲突规则", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=2, sticky=W)
        self._conflict_mode = StringVar(value="动态优先（推荐）")
        conflict_options = ["策略信号优先", "止盈止损优先", "动态优先（推荐）"]
        OptionMenu(a_input, self._conflict_mode, *conflict_options).grid(row=1, column=2, padx=(0, 4))

        self._auto_running = False
        self._auto_btn = Button(a_input, text="▶ 启动策略", font=("Consolas", 9, "bold"),
                                bg=C["cyan"], fg=C["bg"], relief="flat",
                                command=self._toggle_auto_strategy)
        self._auto_btn.grid(row=1, column=3, padx=4, ipady=3)

        # 影子模式开关
        shadow_row = Frame(auto_frame, bg=C["bg_card"])
        shadow_row.pack(fill=X, padx=10, pady=(0, 8))
        self._shadow_mode = False
        self._shadow_btn = Button(shadow_row, text="🚗 试驾模式（影子跟单）", font=("Consolas", 8),
                                   bg=C["bg_input"], fg=C["orange"], relief="flat",
                                   command=self._toggle_shadow_mode)
        self._shadow_btn.pack(fill=X, ipady=3)
        self._shadow_status = Label(shadow_row, text="影子模式未启动", font=("Consolas", 7),
                                     bg=C["bg_card"], fg=C["text_muted"])
        self._shadow_status.pack(anchor=W, pady=2)

        # 右侧：账户 + 持仓 + 挂单 + 日志
        right = Frame(tab, bg=C["bg"])
        right.pack(side=LEFT, fill=BOTH, expand=True)

        # 账户摘要
        acct = Frame(right, bg=C["bg_card"], padx=12, pady=8)
        acct.pack(fill=X, padx=8, pady=(8, 2))

        Label(acct, text="  ◆ 账户", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["cyan"]).pack(side=LEFT)

        self._live_acct_labels = {}
        for key, lbl_text in [("total", "总资产"), ("cash", "可用资金"), ("market", "市值"), ("pnl", "浮动盈亏")]:
            f = Frame(acct, bg=C["bg_card"])
            f.pack(side=LEFT, padx=(16, 0))
            Label(f, text=lbl_text, font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"]).pack()
            lbl = Label(f, text="¥--", font=("Consolas", 11, "bold"),
                        bg=C["bg_card"], fg=C["text_bright"])
            lbl.pack()
            self._live_acct_labels[key] = lbl

        # 持仓表格
        pos_f = Frame(right, bg=C["bg_card"])
        pos_f.pack(fill=X, padx=8, pady=2)

        pos_header = Frame(pos_f, bg=C["bg_card"])
        pos_header.pack(fill=X, padx=12, pady=4)
        Label(pos_header, text="  ◆ 持仓", font=("Consolas", 9, "bold"),
              bg=C["bg_card"], fg=C["text_dim"]).pack(side=LEFT)
        Button(pos_header, text="🔄 刷新", font=("Consolas", 8),
               bg=C["bg_input"], fg=C["text"], relief="flat",
               command=self._refresh_live_positions).pack(side=RIGHT)

        pos_cols = Frame(pos_f, bg=C["bg_input"])
        pos_cols.pack(fill=X, padx=12)
        for h, w in [("代码", 8), ("数量", 6), ("可用", 6), ("成本", 8), ("现价", 8), ("盈亏", 12), ("止损", 6), ("止盈", 6)]:
            Label(pos_cols, text=h, font=("Consolas", 8, "bold"),
                  bg=C["bg_input"], fg=C["text_dim"], width=w, anchor=W).pack(side=LEFT, padx=1)

        self._live_pos_frame = Frame(pos_f, bg=C["bg_card"])
        self._live_pos_frame.pack(fill=X, padx=12, pady=4)
        Label(self._live_pos_frame, text="  暂无持仓", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_muted"]).pack(anchor=W, pady=8)

        # 挂单列表
        pending_f = Frame(right, bg=C["bg_card"])
        pending_f.pack(fill=X, padx=8, pady=2)
        Label(pending_f, text="  ◆ 挂单", font=("Consolas", 9, "bold"),
              bg=C["bg_card"], fg=C["text_dim"]).pack(anchor=W, padx=12, pady=4)

        self._pending_frame = Frame(pending_f, bg=C["bg_card"])
        self._pending_frame.pack(fill=X, padx=12, pady=4)
        Label(self._pending_frame, text="  无挂单", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_muted"]).pack(anchor=W, pady=4)

        # 交易日志
        log_f = Frame(right, bg=C["bg"])
        log_f.pack(fill=BOTH, expand=True, padx=8, pady=2)

        log_title = Frame(log_f, bg=C["bg_card"], height=28)
        log_title.pack(fill=X)
        log_title.pack_propagate(False)
        Label(log_title, text="  ◆ 交易日志", font=("Consolas", 9, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(side=LEFT, padx=8)

        self._live_log = Text(log_f, bg=C["bg"], fg=C["text"],
                               font=("Consolas", 8), relief="flat",
                               wrap="word", padx=8, pady=4)
        log_scroll = Scrollbar(log_f, command=self._live_log.yview,
                                bg=C["bg_panel"], troughcolor=C["bg"], width=6)
        self._live_log.configure(yscrollcommand=log_scroll.set)
        log_scroll.pack(side=RIGHT, fill=Y)
        self._live_log.pack(fill=BOTH, expand=True)

        self._live_log.tag_configure("accent", foreground=C["accent"])
        self._live_log.tag_configure("cyan", foreground=C["cyan"])
        self._live_log.tag_configure("red", foreground=C["red"])
        self._live_log.tag_configure("orange", foreground=C["orange"])
        self._live_log.tag_configure("dim", foreground=C["text_dim"])

        self._live_log_insert("  实盘交易模块已就绪。\n", "dim")
        self._live_log_insert("  功能: T+1 | 涨跌停 | 止损止盈 | 策略自动交易\n", "dim")

        # 定时刷新
        self._start_position_refresh()

        self._log_system("实盘交易模块已加载")

    # ── 辅助方法 ───────────────────────────────────────────────────

    def _live_log_insert(self, msg, tag=None):
        if tag:
            self._live_log.insert(END, msg, tag)
        else:
            self._live_log.insert(END, msg)
        self._live_log.see(END)

    def _sync_sym_to_auto(self, *_):
        """手动下单股票变更时，同步到策略自动交易"""
        if hasattr(self, '_auto_sym') and hasattr(self, '_syncing') and self._syncing:
            return
        self._syncing = True
        try:
            self._auto_sym.set(self._trade_sym.get())
        finally:
            self._syncing = False

    def _sync_sym_to_manual(self, *_):
        """策略股票变更时，同步到手动下单"""
        if hasattr(self, '_trade_sym') and hasattr(self, '_syncing') and self._syncing:
            return
        self._syncing = True
        try:
            self._trade_sym.set(self._auto_sym.get())
        finally:
            self._syncing = False

    def _update_broker_desc(self):
        """更新券商说明标签"""
        display = self._live_broker.get()
        desc = self._broker_descriptions.get(display, {})
        if desc:
            text = (f"匹配度: {desc['match']}  |  {desc['need']}\n"
                    f"配置: {desc['config']}")
            self._broker_desc_label.config(text=text, fg=C["text_dim"])
        else:
            self._broker_desc_label.config(text="")

    def _update_trading_hours_label(self):
        """更新交易时段提示"""
        try:
            from core.execution.broker_adapter import SimulationAdapter
            if SimulationAdapter.is_trading_hours():
                self._trading_hours_label.config(text="🟢 交易时段中", fg=C["accent"])
            elif SimulationAdapter.is_trading_day():
                self._trading_hours_label.config(text="🟡 非交易时段", fg=C["orange"])
            else:
                self._trading_hours_label.config(text="🔴 非交易日", fg=C["red"])
        except Exception:
            pass
        self.root.after(60000, self._update_trading_hours_label)

    def _calc_quantity(self, pct):
        """根据可用资金计算可买数量"""
        if not hasattr(self, '_broker') or not self._broker:
            return
        try:
            price_str = self._trade_price.get()
            if not price_str:
                self._fetch_realtime_price()
                return
            price = float(price_str)
            with self._broker_lock:
                acct = self._broker.get_account()
            available = acct.cash * pct / 100
            qty = int(available / price / 100) * 100
            if qty >= 100:
                self._trade_qty.set(str(qty))
            else:
                self._live_log_insert(f"  [!] 可用资金不足1手\n", "orange")
        except Exception as e:
            self._live_log_insert(f"  [!] 计算失败: {e}\n", "red")

    def _auto_set_stop_on_buy(self, symbol, buy_price):
        """买入后自动设置止损止盈（如果用户未手动设置）"""
        if not hasattr(self, '_broker') or not self._broker or buy_price <= 0:
            return
        # 检查是否已有止损止盈设置
        with self._broker_lock:
            existing = self._broker._stop_rules.get(symbol, {})
        if existing.get('stop_loss') or existing.get('take_profit'):
            return  # 已有设置，不覆盖

        try:
            ratio = float(self._risk_reward_ratio.get())
        except ValueError:
            ratio = 2.3

        stop_distance = buy_price * 0.03
        stop_loss = round(buy_price - stop_distance, 2)
        take_profit = round(buy_price + stop_distance * ratio, 2)

        try:
            with self._broker_lock:
                self._broker.set_stop_loss(symbol, stop_loss=stop_loss, take_profit=take_profit)
            self._live_log_insert(
                f"  [+] 自动止损止盈: {symbol} 止损={stop_loss:.2f} 止盈={take_profit:.2f} (盈亏比{ratio}:1)\n",
                "accent")
            # 同步到UI输入框
            self._stop_loss_price.set(f"{stop_loss:.2f}")
            self._take_profit_price.set(f"{take_profit:.2f}")
        except Exception as e:
            self._live_log_insert(f"  [!] 自动止损设置失败: {e}\n", "red")

    def _auto_calc_stop_loss(self):
        """自动计算止损止盈价（基于盈亏比）"""
        price_str = self._trade_price.get().strip()
        if not price_str:
            self._fetch_realtime_price()
            return
        try:
            price = float(price_str)
        except ValueError:
            messagebox.showwarning("提示", "请先获取当前价")
            return

        try:
            ratio = float(self._risk_reward_ratio.get())
        except ValueError:
            ratio = 2.3

        # 默认止损距离为当前价的3%
        stop_distance = price * 0.03
        stop_loss = round(price - stop_distance, 2)
        take_profit = round(price + stop_distance * ratio, 2)

        self._stop_loss_price.set(f"{stop_loss:.2f}")
        self._take_profit_price.set(f"{take_profit:.2f}")

        self._live_log_insert(
            f"  [+] 自动计算: 止损={stop_loss:.2f}(-3%) 止盈={take_profit:.2f}(+{3*ratio:.1f}%) 盈亏比={ratio}:1\n",
            "accent")

    def _set_stop_rules(self):
        """设置止损止盈规则"""
        if not hasattr(self, '_broker') or not self._broker:
            messagebox.showwarning("提示", "请先连接券商")
            return
        symbol = self._trade_sym.get().strip()
        if not symbol:
            messagebox.showwarning("提示", "请输入股票代码")
            return

        sl = self._stop_loss_price.get().strip()
        tp = self._take_profit_price.get().strip()
        trail = self._trailing_stop_pct.get().strip()

        kwargs = {}
        if sl:
            try:
                kwargs["stop_loss"] = float(sl)
            except ValueError:
                messagebox.showwarning("提示", "止损价必须为数字")
                return
        if tp:
            try:
                kwargs["take_profit"] = float(tp)
            except ValueError:
                messagebox.showwarning("提示", "止盈价必须为数字")
                return
        if trail:
            try:
                kwargs["trailing_pct"] = float(trail)
            except ValueError:
                messagebox.showwarning("提示", "移动止损%必须为数字")
                return

        if kwargs:
            with self._broker_lock:
                self._broker.set_stop_loss(symbol, **kwargs)
            self._live_log_insert(f"  [+] 止损止盈已设置: {symbol} {kwargs}\n", "accent")
        else:
            messagebox.showwarning("提示", "请至少设置一个止损/止盈条件")

    def _start_position_refresh(self):
        """定时刷新持仓价格"""
        if self._connected and hasattr(self, '_broker') and self._broker:
            try:
                positions = self._broker.get_positions()
                if positions:
                    # Update prices from akshare (non-blocking)
                    with self._broker_lock:
                        threading.Thread(target=self._update_position_prices,
                                     args=(list(positions.keys()),), daemon=True).start()
            except Exception:
                pass
        self.root.after(30000, self._start_position_refresh)

    def _update_position_prices(self, symbols):
        """后台更新持仓价格（多源fallback）"""
        prices = {}

        # Source 1: akshare
        try:
            import akshare as ak
            df = ak.stock_zh_a_spot_em()
            for symbol in symbols:
                code = symbol.split(".")[0] if "." in symbol else symbol
                row = df[df["代码"] == code]
                if not row.empty:
                    price = float(row.iloc[0].get("最新价", 0))
                    if price > 0:
                        prices[symbol] = price
        except Exception:
            pass

        # Source 2: Tencent (for missing symbols)
        missing = [s for s in symbols if s not in prices]
        if missing:
            try:
                import requests
                codes = ",".join(
                    ("sh" if s.split(".")[0].startswith("6") else "sz") + s.split(".")[0]
                    for s in missing
                )
                r = requests.get(f"https://qt.gtimg.cn/q={codes}", timeout=10)
                for line in r.text.strip().split("\n"):
                    parts = line.split("~")
                    if len(parts) >= 4:
                        code = parts[2] if len(parts) > 2 else ""
                        price = float(parts[3]) if parts[3] else 0
                        if code and price > 0:
                            for s in missing:
                                if s.split(".")[0] == code:
                                    prices[s] = price
            except Exception:
                pass

        # Source 3: Sina (for still missing symbols)
        still_missing = [s for s in symbols if s not in prices]
        if still_missing:
            try:
                import requests
                h = {'Referer': 'https://finance.sina.com.cn', 'User-Agent': 'Mozilla/5.0'}
                codes = ",".join(
                    ("sh" if s.split(".")[0].startswith("6") else "sz") + s.split(".")[0]
                    for s in still_missing
                )
                r = requests.get(f"https://hq.sinajs.cn/list={codes}", headers=h, timeout=10)
                for line in r.text.strip().split("\n"):
                    if '"' in line:
                        parts = line.split('"')[1].split(',')
                        if len(parts) >= 4:
                            code = line.split('_')[2].split('=')[0] if '_' in line else ""
                            price = float(parts[3]) if parts[3] else 0
                            if code and price > 0:
                                for s in still_missing:
                                    if s.split(".")[0] == code:
                                        prices[s] = price
            except Exception:
                pass

        if prices and hasattr(self, '_broker') and self._broker:
            with self._broker_lock:
                self._broker.update_prices(prices)
            self.root.after(0, self._refresh_live_positions)

    # ── 连接/断开 ──────────────────────────────────────────────────

    def _connect_broker(self):
        display = self._live_broker.get()
        broker_id = self._broker_id_map.get(display, "simulation")
        self._live_log_insert(f"\n[*] 正在连接: {display}\n", "cyan")
        self._live_conn_status.config(text="状态: 连接中...", fg=C["orange"])

        def _do():
            try:
                from core.execution.broker_registry import create_broker_adapter
                from config.manager import get_config
                config = get_config()
                # 使用用户自定义初始金额（优先）或配置文件默认值
                try:
                    custom_balance = float(self._init_balance.get().replace(",", ""))
                except (ValueError, AttributeError):
                    custom_balance = config.get("execution.simulation.initial_balance", 1000000)
                cfg = {"initial_balance": custom_balance,
                       "account": self._live_account.get()}
                adapter = create_broker_adapter(broker_id, cfg)
                adapter.set_callbacks(
                    on_filled=lambda o: self.root.after(0, self._refresh_live_positions),
                )
                success = adapter.connect()
                if success:
                    with self._broker_lock:
                        self._broker = adapter
                        self._connected = True
                    acct = adapter.get_account()
                    def _update():
                        self._live_conn_status.config(text="状态: 已连接", fg=C["accent"])
                        self._live_acct_labels["total"].config(text=f"¥{acct.total_assets:,.0f}")
                        self._live_acct_labels["cash"].config(text=f"¥{acct.cash:,.0f}")
                        self._live_acct_labels["market"].config(text=f"¥{acct.market_value:,.0f}")
                        self._live_log_insert(f"[+] 已连接: {display}\n", "accent")
                        self._set_status("已连接", C["accent"])
                    self.root.after(0, _update)
                    self.root.after(500, self._refresh_dashboard)  # 连接成功后刷新首页
                else:
                    self.root.after(0, lambda: self._live_conn_status.config(text="状态: 连接失败", fg=C["red"]))
                    self.root.after(0, lambda: self._live_log_insert("[!] 连接失败\n", "red"))
            except Exception as e:
                self.root.after(0, lambda e=e: self._live_log_insert(f"[!] 连接错误: {type(e).__name__}: {e}\n", "red"))

        threading.Thread(target=_do, daemon=True).start()

    def _disconnect_broker(self):
        # 停止守护
        if self._guardian and self._guardian.is_monitoring:
            self._guardian.stop_monitoring()
            self._guardian_status_label.config(text="守护已停止", fg=C["text_muted"])
            self._guardian_btn.config(text="🛡️ 启动守护")

        with self._broker_lock:
            if hasattr(self, '_broker') and self._broker:
                self._broker.disconnect()
            self._connected = False
            self._broker = None
        self._live_conn_status.config(text="状态: 未连接", fg=C["text_dim"])
        self._live_log_insert("[!] 已断开连接\n", "orange")
        self._set_status("未连接", C["text_dim"])

    def _toggle_guardian(self):
        """切换进程守护"""
        from core.broker_guardian import BrokerGuardian, BROKER_CONFIGS

        if self._guardian and self._guardian.is_monitoring:
            self._guardian.stop_monitoring()
            self._guardian_status_label.config(text="守护已停止", fg=C["text_muted"])
            self._guardian_btn.config(text="🛡️ 启动守护")
            self._live_log_insert("[!] 进程守护已停止\n", "orange")
            return

        # 获取当前券商ID
        broker_display = self._live_broker.get()
        broker_id_map = {v: k for k, v in {
            "🎮 模拟交易（纸盘）": "simulation",
            "🏦 银河证券": "easytrader_yinhe",
            "🏦 华泰证券": "easytrader_huatai",
            "🏦 广发证券": "easytrader_guangfa",
            "⚡ QMT 迅投量化": "qmt",
            "⚡ Ptrade 恒生量化": "ptrade",
        }.items()}
        broker_id = broker_id_map.get(broker_display, "simulation")

        if broker_id == "simulation":
            messagebox.showinfo("提示", "模拟交易无需进程守护")
            return

        self._guardian = BrokerGuardian(self._config)
        if hasattr(self, '_notifier') and self._notifier:
            self._guardian.set_notifier(self._notifier)

        def _on_health(report):
            self.root.after(0, lambda r=report: self._guardian_status_label.config(
                text=f"✅ {r.broker_name} | 进程: {'存活' if r.process_alive else '异常'} | "
                     f"重启: {r.restart_count}次",
                fg=C["green"] if r.process_alive and r.connection_alive else C["orange"]
            ))

        def _on_crash(broker_id, reason):
            self.root.after(0, lambda: self._live_log_insert(
                f"  🚨 券商进程崩溃！原因: {reason}\n", "red"))

        self._guardian.set_callbacks(on_status=_on_health, on_crash=_on_crash)
        success = self._guardian.start_monitoring(broker_id)

        if success:
            self._guardian_btn.config(text="🛡️ 停止守护")
            self._live_log_insert(f"[+] 进程守护已启动: {broker_display}\n", "green")
        else:
            messagebox.showwarning("提示", "无法启动进程守护，请检查券商配置")

    # ── 获取实时价格 ───────────────────────────────────────────────

    def _fetch_realtime_price(self):
        symbol = self._trade_sym.get().strip()
        if not symbol:
            return
        code = symbol.split(".")[0] if "." in symbol else symbol
        self._live_log_insert(f"  [*] 获取 {code} 价格...\n", "dim")

        def _do():
            # Try akshare -> Sina -> Tencent
            for source_name, fetch_fn in [
                ("akshare", self._fetch_price_akshare),
                ("Sina", self._fetch_price_sina),
                ("Tencent", self._fetch_price_tencent),
            ]:
                try:
                    result = fetch_fn(code)
                    if result:
                        name, price = result
                        self.root.after(0, lambda: self._trade_price.set(f"{price:.2f}"))
                        self.root.after(0, lambda: self._live_log_insert(
                            f"  [+] {name}({code}) ¥{price:.2f} [{source_name}]\n", "accent"))
                        return
                except Exception:
                    continue

            self.root.after(0, lambda: self._live_log_insert(
                f"  [!] 获取价格失败（所有数据源不可用）\n", "red"))

        threading.Thread(target=_do, daemon=True).start()

    def _fetch_price_akshare(self, code):
        import akshare as ak
        df = ak.stock_zh_a_spot_em()
        row = df[df["代码"] == code]
        if row.empty:
            return None
        price = float(row.iloc[0].get("最新价", 0))
        name = str(row.iloc[0].get("名称", ""))
        return (name, price) if price > 0 else None

    def _fetch_price_sina(self, code):
        import requests
        prefix = "sh" if code.startswith("6") else "sz"
        h = {'Referer': 'https://finance.sina.com.cn', 'User-Agent': 'Mozilla/5.0'}
        r = requests.get(f"https://hq.sinajs.cn/list={prefix}{code}", headers=h, timeout=10)
        if r.status_code != 200:
            return None
        parts = r.text.split('"')[1].split(',')
        if len(parts) < 4:
            return None
        return (parts[0], float(parts[3])) if float(parts[3]) > 0 else None

    def _fetch_price_tencent(self, code):
        import requests
        prefix = "sh" if code.startswith("6") else "sz"
        r = requests.get(f"https://qt.gtimg.cn/q={prefix}{code}", timeout=10)
        parts = r.text.split("~")
        if len(parts) < 4:
            return None
        return (parts[1], float(parts[3])) if float(parts[3]) > 0 else None

    # ── 手动下单 ───────────────────────────────────────────────────

    def _manual_trade(self, side):
        with self._broker_lock:
            if not self._connected or not hasattr(self, '_broker') or not self._broker:
                messagebox.showwarning("提示", "请先连接券商")
                return
        symbol = self._trade_sym.get().strip()
        qty_str = self._trade_qty.get().strip()
        price_str = self._trade_price.get().strip()
        if not symbol:
            messagebox.showwarning("提示", "请输入股票代码")
            return
        try:
            qty = int(qty_str)
            if qty <= 0:
                raise ValueError
        except ValueError:
            messagebox.showwarning("提示", "数量必须为正整数")
            return
        price = None
        if price_str:
            try:
                price = float(price_str)
            except ValueError:
                messagebox.showwarning("提示", "价格必须为正数")
                return

        from core.models import Order, OrderSide, OrderType
        order = Order(
            order_id="", symbol=symbol,
            side=OrderSide.BUY if side == "BUY" else OrderSide.SELL,
            order_type=OrderType.LIMIT if price else OrderType.MARKET,
            volume=qty, price=price or 0, strategy_id="manual",
        )

        # 风险管理器预检查
        if hasattr(self, '_risk_mgr') and self._risk_mgr:
            try:
                with self._broker_lock:
                    positions = self._broker.get_positions() or {}
                    account = self._broker.get_account()
                from core.risk.pre_trade import PreTradeChecker
                checker = PreTradeChecker(self._config)
                result = checker.check(order, positions, account)
                if not result.passed:
                    self._live_log_insert(f"[!] 风控拦截: {result.reason}\n", "red")
                    return
            except Exception:
                pass

        self._live_log_insert(f"\n[*] {side} {symbol} x{qty}", "cyan")
        if price:
            self._live_log_insert(f" @{price}", "cyan")
        self._live_log_insert("...\n")

        def _do():
            try:
                # 智能执行模式
                if hasattr(self, '_use_smart_exec') and self._use_smart_exec.get() and qty >= 500:
                    from core.execution.smart_executor import SmartExecutor, AlgoOrderConfig, ExecutionAlgo
                    executor = SmartExecutor(self._broker, self._config)
                    with self._broker_lock:
                        executor._broker_lock = self._broker_lock
                    config = AlgoOrderConfig(
                        algo=ExecutionAlgo.TWAP,
                        total_volume=qty,
                        duration_minutes=10,
                        num_slices=max(3, qty // 200),
                    )
                    side_enum = OrderSide.BUY if side == "BUY" else OrderSide.SELL
                    algo_id = executor.execute(symbol, side_enum, config,
                                               arrival_price=price or 0,
                                               progress_callback=lambda c, t, s: self.root.after(
                                                   0, lambda: self._live_log_insert(
                                                       f"  [智能执行] 切片 {c}/{t}: {s}\n", "dim")))
                    self.root.after(0, lambda: self._live_log_insert(
                        f"[+] 智能执行已提交: {algo_id} (TWAP拆分为{config.num_slices}笔)\n", "accent"))
                else:
                    # 普通下单
                    with self._broker_lock:
                        success = self._broker.submit_order(order)
                    if success:
                        self.root.after(0, lambda: self._live_log_insert(f"[+] 下单成功\n", "accent"))
                        self.root.after(0, self._refresh_live_positions)
                        self.root.after(500, self._refresh_dashboard)
                        if side == "BUY":
                            self.root.after(100, lambda: self._auto_set_stop_on_buy(symbol, price or float(self._trade_price.get() or 0)))
                    else:
                        self.root.after(0, lambda: self._live_log_insert(f"[!] 下单失败（T+1/余额不足/涨跌停）\n", "red"))
            except Exception as e:
                self.root.after(0, lambda e=e: self._live_log_insert(f"[!] 下单错误: {type(e).__name__}: {e}\n", "red"))

        threading.Thread(target=_do, daemon=True).start()

    # ── 刷新持仓 ───────────────────────────────────────────────────

    def _refresh_live_positions(self):
        if not self._connected or not hasattr(self, '_broker'):
            return
        try:
            with self._broker_lock:
                positions = self._broker.get_positions()
            for w in self._live_pos_frame.winfo_children():
                w.destroy()

            if not positions:
                Label(self._live_pos_frame, text="  暂无持仓", font=("Consolas", 9),
                      bg=C["bg_card"], fg=C["text_muted"]).pack(anchor=W, pady=8)
            else:
                for symbol, pos in positions.items():
                    display_price = pos.current_price if pos.current_price > 0 else pos.avg_cost
                    pnl = (display_price - pos.avg_cost) * pos.volume
                    pnl_pct = ((display_price / pos.avg_cost) - 1) * 100 if pos.avg_cost > 0 else 0
                    pnl_color = C["accent"] if pnl >= 0 else C["red"]
                    available = max(0, pos.volume - pos.today_buy_volume)

                    # Stop rules
                    with self._broker_lock:
                        rules = self._broker._stop_rules.get(symbol, {})
                    sl_text = f"{rules.get('stop_loss', '-')}"
                    tp_text = f"{rules.get('take_profit', '-')}"

                    row = Frame(self._live_pos_frame, bg=C["bg_card"])
                    row.pack(fill=X)
                    for val, w, color in [
                        (symbol, 8, C["text"]),
                        (str(pos.volume), 6, C["text"]),
                        (str(available), 6, C["text_dim"]),
                        (f"{pos.avg_cost:.2f}", 8, C["text"]),
                        (f"{display_price:.2f}", 8, C["text"]),
                        (f"{pnl:+,.0f}({pnl_pct:+.1f}%)", 12, pnl_color),
                        (sl_text, 6, C["red"]),
                        (tp_text, 6, C["accent"]),
                    ]:
                        Label(row, text=str(val), font=("Consolas", 8),
                              bg=C["bg_card"], fg=color, width=w, anchor=W).pack(side=LEFT, padx=1)

            # Refresh account
            with self._broker_lock:
                acct = self._broker.get_account()
            self._live_acct_labels["total"].config(text=f"¥{acct.total_assets:,.0f}")
            self._live_acct_labels["cash"].config(text=f"¥{acct.cash:,.0f}")
            self._live_acct_labels["market"].config(text=f"¥{acct.market_value:,.0f}")
            pnl_color = C["accent"] if acct.unrealized_pnl >= 0 else C["red"]
            self._live_acct_labels["pnl"].config(text=f"¥{acct.unrealized_pnl:+,.0f}", fg=pnl_color)

            # Refresh pending orders
            self._refresh_pending_orders()

        except Exception as e:
            self._live_log_insert(f"[!] 刷新失败: {e}\n", "red")

    def _refresh_pending_orders(self):
        """刷新挂单列表"""
        for w in self._pending_frame.winfo_children():
            w.destroy()

        if not hasattr(self, '_broker') or not self._broker:
            return

        with self._broker_lock:
            pending = self._broker.get_pending_orders()
        if not pending:
            Label(self._pending_frame, text="  无挂单", font=("Consolas", 9),
                  bg=C["bg_card"], fg=C["text_muted"]).pack(anchor=W, pady=4)
            return

        for oid, order in pending.items():
            row = Frame(self._pending_frame, bg=C["bg_card"])
            row.pack(fill=X)
            side_color = C["accent"] if order.side.value == "BUY" else C["red"]
            Label(row, text=f"{order.symbol}", font=("Consolas", 8),
                  bg=C["bg_card"], fg=C["text"], width=8, anchor=W).pack(side=LEFT, padx=1)
            Label(row, text=f"{order.side.value}", font=("Consolas", 8),
                  bg=C["bg_card"], fg=side_color, width=4, anchor=W).pack(side=LEFT, padx=1)
            Label(row, text=f"x{order.volume}", font=("Consolas", 8),
                  bg=C["bg_card"], fg=C["text"], width=6, anchor=W).pack(side=LEFT, padx=1)
            Label(row, text=f"@{order.price:.2f}", font=("Consolas", 8),
                  bg=C["bg_card"], fg=C["text"], width=8, anchor=W).pack(side=LEFT, padx=1)
            Button(row, text="撤单", font=("Consolas", 7),
                   bg=C["bg_input"], fg=C["red"], relief="flat",
                   command=lambda o=oid: self._cancel_order(o)).pack(side=RIGHT, padx=2)

    def _cancel_order(self, order_id):
        if hasattr(self, '_broker') and self._broker:
            with self._broker_lock:
                success = self._broker.cancel_order(order_id)
            if success:
                self._live_log_insert(f"  [+] 已撤单: {order_id}\n", "accent")
                self._refresh_pending_orders()
            else:
                self._live_log_insert(f"  [!] 撤单失败\n", "red")

    # ── 策略自动交易 ───────────────────────────────────────────────

    def _toggle_auto_strategy(self):
        if not self._connected or not hasattr(self, '_broker'):
            messagebox.showwarning("提示", "请先连接券商")
            return
        if self._auto_running:
            self._auto_running = False
            self._auto_btn.config(text="▶ 启动策略", bg=C["cyan"])
            self._live_log_insert("[!] 策略已停止\n", "orange")
            return
        symbol = self._auto_sym.get().strip()
        strategy_display = self._auto_strat.get()
        strategy_name = self._strat_id_map.get(strategy_display, "dual_ma")
        if not symbol:
            messagebox.showwarning("提示", "请输入股票代码")
            return
        self._auto_running = True
        self._auto_btn.config(text="■ 停止策略", bg=C["red"])
        self._live_log_insert(f"\n[*] 启动策略: {strategy_display} on {symbol}\n", "accent")

        # 初始化冲突仲裁器
        from core.arbitrator import ConflictArbitrator, ConflictMode
        mode_map = {
            "策略信号优先": ConflictMode.STRATEGY_PRIORITY,
            "止盈止损优先": ConflictMode.STOP_PRIORITY,
            "动态优先（推荐）": ConflictMode.DYNAMIC,
        }
        arb_mode = mode_map.get(self._conflict_mode.get(), ConflictMode.DYNAMIC)
        arbitrator = ConflictArbitrator(mode=arb_mode)
        self._live_log_insert(f"  [仲裁] 模式: {arbitrator.get_mode_display()}\n", "cyan")

        def _run():
            import importlib as _il
            from datetime import datetime as _dt, timedelta as _td

            strategy_module_map = {
                "dual_ma": ("strategies.dual_ma", "DualMAStrategy"),
                "macd": ("strategies.macd_strategy", "MACDStrategy"),
                "bollinger": ("strategies.bollinger_strategy", "BollingerStrategy"),
                "rsi": ("strategies.rsi_strategy", "RSIStrategy"),
                "kdj": ("strategies.kdj_strategy", "KDJStrategy"),
                "atr_breakout": ("strategies.atr_breakout_strategy", "ATRBreakoutStrategy"),
                "momentum": ("strategies.momentum_strategy", "MomentumBreakoutStrategy"),
                "vwap": ("strategies.vwap_strategy", "VWAPStrategy"),
            }
            try:
                mod_path, cls_name = strategy_module_map[strategy_name]
                mod = _il.import_module(mod_path)
                strategy = getattr(mod, cls_name)(strategy_id=f"{strategy_name}_{symbol}")
            except Exception as e:
                self.root.after(0, lambda e=e: self._live_log_insert(f"[!] 策略加载失败: {e}\n", "red"))
                self._auto_running = False
                self.root.after(0, lambda: self._auto_btn.config(text="▶ 启动策略", bg=C["cyan"]))
                return

            data_mgr = None
            check_count = 0
            fail_count = 0
            strategy.on_start()  # 启动策略（循环外）
            warmup_done = False  # 是否已完成预热

            while self._auto_running:
                try:
                    if data_mgr is None:
                        from core.data.data_manager import DataManager
                        from config.manager import get_config
                        data_mgr = DataManager(get_config())

                    end = _dt.now().strftime("%Y-%m-%d")
                    start = (_dt.now() - _td(days=120)).strftime("%Y-%m-%d")
                    data = data_mgr.get_history(symbol, start, end, freq="daily")

                    if data is None or data.empty:
                        fail_count += 1
                        err = data_mgr.last_error or "空数据"
                        self.root.after(0, lambda: self._live_log_insert(f"  [!] 数据获取失败: {err}\n", "red"))
                        if fail_count >= 3:
                            self.root.after(0, lambda: self._live_log_insert(f"  [X] 连续失败，策略停止\n", "red"))
                            self._auto_running = False
                            self.root.after(0, lambda: self._auto_btn.config(text="▶ 启动策略", bg=C["cyan"]))
                            strategy.on_stop()
                            return
                        time.sleep(30)
                        continue

                    fail_count = 0
                    from core.models import Bar, SignalAction
                    from datetime import datetime as _dt

                    # 首次运行：灌入所有历史K线进行预热
                    if not warmup_done and len(data) > 1:
                        self.root.after(0, lambda n=len(data): self._live_log_insert(
                            f"  [预热] 灌入{n}根历史K线...\n", "dim"))
                        for idx in range(len(data) - 1):
                            row = data.iloc[idx]
                            warmup_bar = Bar(symbol=symbol,
                                             open=float(row.get('open', 0)),
                                             high=float(row.get('high', 0)),
                                             low=float(row.get('low', 0)),
                                             close=float(row.get('close', 0)),
                                             volume=int(row.get('volume', 0)),
                                             turnover=float(row.get('turnover', 0)),
                                             timestamp=data.index[idx] if hasattr(data.index[idx], 'strftime') else _dt.now())
                            strategy._feed_bar(warmup_bar)
                        warmup_done = True
                        self.root.after(0, lambda: self._live_log_insert(
                            f"  [预热] 完成，策略已就绪\n", "accent"))

                    last_row = data.iloc[-1]
                    ts = data.index[-1] if hasattr(data.index[-1], 'strftime') else _dt.now()
                    bar = Bar(symbol=symbol, open=float(last_row.get('open', 0)),
                              high=float(last_row.get('high', 0)), low=float(last_row.get('low', 0)),
                              close=float(last_row.get('close', 0)), volume=int(last_row.get('volume', 0)),
                              turnover=float(last_row.get('turnover', 0)), timestamp=ts)
                    signal = strategy._feed_bar(bar)

                    if signal and signal.action.value in ('BUY', 'SELL'):
                        color = "cyan" if signal.action.value == "BUY" else "red"
                        self.root.after(0, lambda s=signal, c=color: self._live_log_insert(
                            f"  [SIGNAL] {s.action.value} {s.symbol} x{s.volume}\n", c))

                        # 冲突仲裁检查
                        has_stop = False
                        stop_loss = 0.0
                        take_profit = 0.0
                        avg_cost = 0.0
                        try:
                            with self._broker_lock:
                                pos = self._broker.get_positions().get(symbol)
                                if pos:
                                    avg_cost = pos.avg_cost
                                rules = getattr(self._broker, '_stop_rules', {}).get(symbol, {})
                                stop_loss = rules.get('stop_loss', 0.0)
                                take_profit = rules.get('take_profit', 0.0)
                                has_stop = bool(rules)
                        except Exception:
                            pass

                        arb_result = arbitrator.arbitrate(
                            symbol=symbol,
                            strategy_id=strategy_name,
                            signal_action=signal.action.value,
                            current_price=float(last_row.get('close', 0)),
                            avg_cost=avg_cost,
                            stop_loss=stop_loss,
                            take_profit=take_profit,
                            has_active_stop=has_stop,
                        )

                        self.root.after(0, lambda r=arb_result: self._live_log_insert(
                            f"  {r.log_message}\n", "cyan" if r.allowed else "orange"))

                        if not arb_result.allowed:
                            continue  # 仲裁拒绝，跳过此信号

                        from core.models import Order, OrderSide, OrderType
                        order = Order(order_id="", symbol=signal.symbol,
                                      side=OrderSide.BUY if signal.action.value == 'BUY' else OrderSide.SELL,
                                      order_type=OrderType.MARKET, volume=signal.volume or 100,
                                      price=signal.price or float(last_row.get('close', 0)),
                                      strategy_id=strategy_name)
                        try:
                            with self._broker_lock:
                                success = self._broker.submit_order(order)
                            if success:
                                self.root.after(0, lambda: self._live_log_insert("  -> 已执行\n", "accent"))
                                self.root.after(0, self._refresh_live_positions)
                                self.root.after(500, self._refresh_dashboard)  # 同步刷新首页
                                # 漂移检测：每次成交后检查策略健康
                                try:
                                    from core.drift_detector import DriftDetector
                                    if not hasattr(self, '_drift_detector'):
                                        self._drift_detector = DriftDetector(self._config)
                                    trades_for_check = []
                                    with self._broker_lock:
                                        trades_for_check = self._broker.get_trade_history() or []
                                    alerts = self._drift_detector.check_all(
                                        strategy_id=strategy_name,
                                        strategy_name=strategy_display,
                                        symbol=symbol,
                                        recent_trades=trades_for_check[-50:],
                                        daily_returns=[],
                                    )
                                    for a in alerts:
                                        self.root.after(0, lambda a=a: self._live_log_insert(
                                            f"  ⚠️ {a.title}: {a.message[:60]}...\n", "orange"))
                                except Exception:
                                    pass
                        except Exception as e:
                            self.root.after(0, lambda e=e: self._live_log_insert(f"  -> 失败: {e}\n", "red"))
                    else:
                        check_count += 1
                        if check_count % 60 == 0:
                            self.root.after(0, lambda: self._live_log_insert(
                                    f"  [.] 运行中... ({check_count}次检查)\n", "dim"))

                except Exception as e:
                    self.root.after(0, lambda e=e: self._live_log_insert(f"[!] 异常: {e}\n", "red"))

                time.sleep(60)

            strategy.on_stop()  # 循环结束后停止策略
            self.root.after(0, lambda: self._live_log_insert("[!] 策略已停止\n", "orange"))

        threading.Thread(target=_run, daemon=True).start()

    def _build_risk_tab(self):
        """风险仪表盘"""
        tab = Frame(self.notebook, bg=C["bg"])
        self.notebook.add(tab, text="  ◆ 风险仪表盘  ")

        # 四个指标卡片
        indicators = [
            ("账户安全线", "circuit_breaker", "距离硬熔断的缓冲空间", 73),
            ("单日亏损限额", "daily_loss", "今日已亏损占限额比例", 12),
            ("持仓集中度", "concentration", "最大单票持仓占比", 25),
            ("系统健康度", "health", "所有组件运行状态汇总", 100),
        ]

        self._risk_bars = {}

        for title, key, desc, default in indicators:
            card = Frame(tab, bg=C["bg_card"], padx=16, pady=12)
            card.pack(fill=X, padx=12, pady=4)

            Label(card, text=title, font=("Consolas", 10, "bold"),
                  bg=C["bg_card"], fg=C["text_bright"]).pack(anchor=W)

            Label(card, text=desc, font=("Consolas", 8),
                  bg=C["bg_card"], fg=C["text_dim"]).pack(anchor=W)

            bar_frame = Frame(card, bg=C["bg_card"])
            bar_frame.pack(fill=X, pady=4)

            bar_bg = Frame(bar_frame, bg=C["bg_input"], height=16)
            bar_bg.pack(fill=X)
            bar_bg.pack_propagate(False)

            color = C["green"] if default >= 60 else C["orange"] if default >= 30 else C["red"]
            bar_fill = Frame(bar_bg, bg=color, width=default * 3)
            bar_fill.pack(side=LEFT, fill=Y)

            value_label = Label(bar_frame, text=f"{default}%", font=("Consolas", 9, "bold"),
                                bg=C["bg_card"], fg=color)
            value_label.pack(anchor=E)

            self._risk_bars[key] = (bar_fill, value_label, bar_bg)

        # 风控事件时间线
        timeline_frame = Frame(tab, bg=C["bg_card"])
        timeline_frame.pack(fill=BOTH, expand=True, padx=12, pady=8)

        Label(timeline_frame, text="  ◆ 风控事件时间线", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(anchor=W, padx=12, pady=8)

        self._risk_timeline = Text(timeline_frame, bg=C["bg"], fg=C["text"],
                                    font=("Consolas", 8), relief="flat",
                                    wrap="word", padx=8, pady=4, height=10)
        self._risk_timeline.pack(fill=BOTH, expand=True, padx=12, pady=(0, 12))

        Button(timeline_frame, text="🔄 刷新风控数据", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["text"], relief="flat",
               command=self._refresh_risk).pack(padx=12, pady=(0, 12))

        self._log_system("风险仪表盘已加载")

    def _refresh_risk(self):
        """刷新风控数据（连接真实数据）"""
        def _do():
            try:
                # 从券商获取真实账户数据
                breaker_pct = 0
                daily_loss_pct = 0
                concentration_pct = 0
                health_pct = 100

                if hasattr(self, '_broker') and self._broker:
                    try:
                        with self._broker_lock:
                            acct = self._broker.get_account()
                            positions = self._broker.get_positions() or {}
                            initial_cap = getattr(self._broker, '_initial', 0)

                        # 计算持仓集中度
                        if acct.total_assets > 0 and positions:
                            max_pos_value = max(
                                (p.volume * (p.current_price if p.current_price > 0 else p.avg_cost)
                                 for p in positions.values()),
                                default=0
                            )
                            concentration_pct = round(max_pos_value / acct.total_assets * 100)

                        # 计算距离硬熔断的缓冲空间
                        if initial_cap > 0:
                            drawdown_pct = max(0, (initial_cap - acct.total_assets) / initial_cap * 100)
                            breaker_threshold = 5.0  # 5% 硬熔断
                            breaker_pct = max(0, round((breaker_threshold - drawdown_pct) / breaker_threshold * 100))

                        # 持仓数影响健康度
                        pos_count = len(positions)
                        health_pct = max(50, 100 - pos_count * 5)
                    except Exception:
                        pass

                # 获取风控事件
                events = []
                if self._db:
                    try:
                        events = self._db.get_risk_events(limit=20)
                    except Exception:
                        pass

                self.root.after(0, lambda: self._update_risk_bars(
                    breaker_pct, daily_loss_pct, concentration_pct, health_pct))
                self.root.after(0, lambda: self._update_risk_timeline(events))
            except Exception as e:
                self.root.after(0, lambda e=e: self._risk_timeline.insert(END, f"刷新失败: {e}\n"))
        threading.Thread(target=_do, daemon=True).start()

    def _update_risk_bars(self, breaker_pct, daily_loss_pct, concentration_pct, health_pct):
        """更新风控仪表盘进度条"""
        bar_data = {
            "circuit_breaker": breaker_pct,
            "daily_loss": daily_loss_pct,
            "concentration": concentration_pct,
            "health": health_pct,
        }
        for key, pct in bar_data.items():
            if key in self._risk_bars:
                bar_fill, value_label, bar_bg = self._risk_bars[key]
                pct = max(0, min(100, pct))
                color = C["green"] if pct >= 60 else C["orange"] if pct >= 30 else C["red"]
                # 更新进度条宽度
                bar_fill.config(bg=color, width=max(1, pct * 3))
                value_label.config(text=f"{pct}%", fg=color)

    def _update_risk_timeline(self, events):
        self._risk_timeline.delete("1.0", END)
        if not events:
            self._risk_timeline.insert(END, "  暂无风控事件\n", "dim")
            return
        for e in events:
            severity = e.get("severity", "info")
            emoji = {"info": "🔵", "warning": "🟡", "critical": "🔴"}.get(severity, "⚪")
            self._risk_timeline.insert(END,
                f"  {emoji} [{e.get('event_time', '')[:19]}] {e.get('description', '')}\n")

    # ════════════════════════════════════════════════════════════════
    #  高级风控（自适应风控 + 压力测试 + 收益归因）
    # ════════════════════════════════════════════════════════════════

    def _build_advanced_risk_tab(self):
        """高级风控标签页"""
        tab = Frame(self.notebook, bg=C["bg"])
        self.notebook.add(tab, text="  ◆ 高级风控  ")

        # 上半部分：自适应风控状态
        top = Frame(tab, bg=C["bg"])
        top.pack(fill=X, padx=12, pady=(12, 6))

        # 波动率状态卡片
        vol_card = Frame(top, bg=C["bg_card"], padx=16, pady=12)
        vol_card.pack(side=LEFT, fill=BOTH, expand=True, padx=(0, 4))

        Label(vol_card, text="◆ 波动率自适应风控", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(anchor=W)

        self._vol_regime_label = Label(vol_card, text="状态: --", font=("Consolas", 9),
                                        bg=C["bg_card"], fg=C["text"])
        self._vol_regime_label.pack(anchor=W, pady=(4, 0))

        self._vol_value_label = Label(vol_card, text="年化波动率: --", font=("Consolas", 9),
                                        bg=C["bg_card"], fg=C["text_dim"])
        self._vol_value_label.pack(anchor=W)

        self._vol_recommendation = Label(vol_card, text="", font=("Consolas", 8),
                                           bg=C["bg_card"], fg=C["text_dim"],
                                           wraplength=500, justify="left")
        self._vol_recommendation.pack(anchor=W, pady=(4, 0))

        Button(vol_card, text="🔄 更新风控状态", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["text"], relief="flat",
               command=self._refresh_adaptive_risk).pack(anchor=W, pady=(8, 0))

        # 压力测试卡片
        stress_card = Frame(top, bg=C["bg_card"], padx=16, pady=12)
        stress_card.pack(side=LEFT, fill=BOTH, expand=True, padx=(4, 0))

        Label(stress_card, text="◆ 压力测试", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["orange"]).pack(anchor=W)

        self._stress_result = Text(stress_card, bg=C["bg"], fg=C["text"],
                                     font=("Consolas", 8), height=8, relief="flat",
                                     wrap="word")
        self._stress_result.pack(fill=BOTH, expand=True, pady=(4, 0))

        Button(stress_card, text="⚡ 运行压力测试", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["orange"], relief="flat",
               command=self._run_stress_test).pack(anchor=W, pady=(8, 0))

        # 下半部分：收益归因
        bottom = Frame(tab, bg=C["bg_card"])
        bottom.pack(fill=BOTH, expand=True, padx=12, pady=(6, 12))

        Label(bottom, text="  ◆ 收益归因分析", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["cyan"]).pack(anchor=W, padx=12, pady=8)

        self._attribution_result = Text(bottom, bg=C["bg"], fg=C["text"],
                                          font=("Consolas", 8), relief="flat",
                                          wrap="word", padx=12, pady=8)
        self._attribution_result.pack(fill=BOTH, expand=True, padx=12, pady=(0, 8))

        Button(bottom, text="📊 运行归因分析", font=("Consolas", 9),
               bg=C["bg_input"], fg=C["cyan"], relief="flat",
               command=self._run_attribution).pack(anchor=W, padx=12, pady=(0, 12))

        self._log_system("高级风控模块已加载")

    def _refresh_adaptive_risk(self):
        """刷新自适应风控状态"""
        def _do():
            try:
                from core.risk.adaptive_risk import AdaptiveRiskManager
                manager = AdaptiveRiskManager(self._config)

                # 从券商获取日收益率数据
                daily_returns = []
                if hasattr(self, '_broker') and self._broker:
                    try:
                        with self._broker_lock:
                            acct = self._broker.get_account()
                            positions = self._broker.get_positions() or {}
                        # 简化：用持仓的当前收益率
                        for sym, pos in positions.items():
                            if pos.current_price > 0 and pos.avg_cost > 0:
                                daily_returns.append((pos.current_price - pos.avg_cost) / pos.avg_cost)
                    except Exception:
                        pass

                if not daily_returns:
                    daily_returns = [0.001, -0.002, 0.003, -0.001, 0.002]  # 默认

                state = manager.calculate_risk_state(daily_returns)

                self.root.after(0, lambda: self._vol_regime_label.config(
                    text=f"状态: {manager.get_regime_label(state.regime)}",
                    fg=manager.get_regime_color(state.regime)))
                self.root.after(0, lambda: self._vol_value_label.config(
                    text=f"年化波动率: {state.current_volatility:.1%} | "
                         f"百分位: {state.volatility_percentile:.0f}%"))
                self.root.after(0, lambda: self._vol_recommendation.config(
                    text=state.recommendation))

            except Exception as e:
                self.root.after(0, lambda e=e: self._vol_recommendation.config(
                    text=f"计算失败: {e}"))

        threading.Thread(target=_do, daemon=True).start()

    def _run_stress_test(self):
        """运行压力测试"""
        def _do():
            try:
                from core.risk.stress_test import StressTestEngine
                engine = StressTestEngine(self._config)

                positions = {}
                total_assets = 1000000
                daily_returns = []

                if hasattr(self, '_broker') and self._broker:
                    try:
                        with self._broker_lock:
                            acct = self._broker.get_account()
                            positions = self._broker.get_positions() or {}
                        total_assets = acct.total_assets
                    except Exception:
                        pass

                results = engine.run_all_scenarios(positions, total_assets, daily_returns)

                def _show():
                    self._stress_result.delete("1.0", END)
                    for r in results:
                        self._stress_result.insert(END, engine.format_scenario_result(r) + "\n\n")

                self.root.after(0, _show)

            except Exception as e:
                self.root.after(0, lambda e=e: self._stress_result.insert(END, f"失败: {e}\n"))

        threading.Thread(target=_do, daemon=True).start()

    def _run_attribution(self):
        """运行收益归因分析"""
        def _do():
            try:
                from core.attribution import AttributionEngine
                engine = AttributionEngine(self._config)

                # 获取交易记录
                trades = []
                if hasattr(self, '_broker') and self._broker:
                    try:
                        with self._broker_lock:
                            trades = self._broker.get_trade_history() or []
                    except Exception:
                        pass

                # 构建简化权益曲线
                if trades:
                    import pandas as pd
                    equity = [1000000]
                    for t in trades:
                        equity.append(equity[-1] + t.get("pnl", 0))
                    dates = pd.date_range(end=pd.Timestamp.now(), periods=len(equity), freq="D")
                    equity_df = pd.DataFrame({"total_assets": equity}, index=dates)
                else:
                    equity_df = pd.DataFrame(columns=["total_assets"])

                attr = engine.attribute(equity_df, trades=trades)

                def _show():
                    self._attribution_result.delete("1.0", END)
                    self._attribution_result.insert(END, engine.format_attribution(attr))

                self.root.after(0, _show)

            except Exception as e:
                self.root.after(0, lambda e=e: self._attribution_result.insert(END, f"失败: {e}\n"))

        threading.Thread(target=_do, daemon=True).start()

    # ════════════════════════════════════════════════════════════════
    #  多因子选股
    # ════════════════════════════════════════════════════════════════

    def _build_factor_tab(self):
        """多因子选股标签页"""
        tab = Frame(self.notebook, bg=C["bg"])
        self.notebook.add(tab, text="  ◆ 多因子选股  ")

        # 左侧：配置
        left = Frame(tab, bg=C["bg_panel"], width=340)
        left.pack(side=LEFT, fill=Y, padx=(0, 1))
        left.pack_propagate(False)

        right = Frame(tab, bg=C["bg"])
        right.pack(side=LEFT, fill=BOTH, expand=True)

        # 左侧配置面板
        param_title = Frame(left, bg=C["bg_card"], height=36)
        param_title.pack(fill=X)
        param_title.pack_propagate(False)
        Label(param_title, text="  ◆ 因子配置", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(side=LEFT, padx=10)

        param_body = Frame(left, bg=C["bg_panel"])
        param_body.pack(fill=BOTH, expand=True, padx=14, pady=14)

        # 股票池选择
        Label(param_body, text="股票池", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._factor_pool = StringVar(value="沪深300龙头")
        from core.screener import STOCK_POOLS
        pool_names = list(STOCK_POOLS.keys()) + ["自定义..."]
        OptionMenu(param_body, self._factor_pool, *pool_names).pack(fill=X, pady=(0, 8))

        # 自定义输入
        Label(param_body, text="自定义代码（每行一个）", font=("Consolas", 8),
              bg=C["bg_panel"], fg=C["text_muted"]).pack(anchor=W)
        self._factor_custom = Text(param_body, bg=C["bg_input"], fg=C["text"],
                                     font=("Consolas", 8), height=3, relief="flat", wrap="word")
        self._factor_custom.pack(fill=X, pady=(0, 8))

        # 返回数量
        Label(param_body, text="返回前N只", font=("Consolas", 9),
              bg=C["bg_panel"], fg=C["text_dim"]).pack(anchor=W)
        self._factor_top_n = StringVar(value="20")
        Entry(param_body, textvariable=self._factor_top_n, font=("Consolas", 10),
              bg=C["bg_input"], fg=C["text"], relief="flat").pack(fill=X, ipady=4, pady=(0, 8))

        # 进度
        self._factor_progress = Label(param_body, text="", font=("Consolas", 9),
                                        bg=C["bg_panel"], fg=C["orange"])
        self._factor_progress.pack(anchor=W, pady=4)

        # 按钮
        Button(param_body, text="▶  开始多因子选股", font=("Consolas", 11, "bold"),
               bg=C["accent"], fg=C["bg"], relief="flat", cursor="hand2",
               command=self._run_factor_scoring).pack(fill=X, ipady=10, pady=(8, 0))

        # 右侧结果
        result_title = Frame(right, bg=C["bg_card"], height=36)
        result_title.pack(fill=X)
        result_title.pack_propagate(False)
        Label(result_title, text="  ◆ 多因子评分排行榜", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(side=LEFT, padx=8)

        # 结果表格
        cols = ["排名", "代码", "综合得分", "推荐等级", "估值", "动量", "波动率"]
        col_widths = [5, 10, 10, 10, 10, 10, 10]

        table_header = Frame(right, bg=C["bg_input"])
        table_header.pack(fill=X, padx=8, pady=(4, 0))
        for h, w in zip(cols, col_widths):
            Label(table_header, text=h, font=("Consolas", 8, "bold"),
                  bg=C["bg_input"], fg=C["text_dim"], width=w, anchor=W).pack(side=LEFT, padx=1)

        result_canvas = Canvas(right, bg=C["bg"], highlightthickness=0)
        result_scroll = Scrollbar(right, orient="vertical", command=result_canvas.yview)
        self._factor_result_frame = Frame(result_canvas, bg=C["bg"])
        self._factor_result_frame.bind("<Configure>", lambda e: result_canvas.configure(scrollregion=result_canvas.bbox("all")))
        result_canvas.create_window((0, 0), window=self._factor_result_frame, anchor="nw")
        result_canvas.configure(yscrollcommand=result_scroll.set)
        result_canvas.pack(side=LEFT, fill=BOTH, expand=True, padx=8, pady=4)
        result_scroll.pack(side=RIGHT, fill=Y)

        def _factor_scroll(e):
            result_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        result_canvas.bind("<Enter>", lambda e: result_canvas.bind_all("<MouseWheel>", _factor_scroll))
        result_canvas.bind("<Leave>", lambda e: result_canvas.unbind_all("<MouseWheel>"))

        Label(self._factor_result_frame, text="  选择股票池，点击开始多因子选股",
              font=("Consolas", 10), bg=C["bg"], fg=C["text_muted"]).pack(pady=40)

        self._log_system("多因子选股模块已加载")

    def _run_factor_scoring(self):
        """运行多因子选股"""
        from core.factor_engine import FactorEngine
        from core.screener import STOCK_POOLS

        pool_name = self._factor_pool.get()
        try:
            top_n = int(self._factor_top_n.get())
        except ValueError:
            top_n = 20

        # 获取股票列表
        if pool_name == "自定义...":
            custom_text = self._factor_custom.get("1.0", END).strip()
            if not custom_text:
                messagebox.showwarning("提示", "请输入自定义股票代码")
                return
            symbols = [s.strip() for s in custom_text.replace(",", "\n").split("\n") if s.strip()]
        else:
            symbols = STOCK_POOLS.get(pool_name, [])

        if not symbols:
            messagebox.showwarning("提示", "股票池为空")
            return

        self._factor_progress.config(text=f"正在分析 {len(symbols)} 只股票...")

        def _do():
            engine = FactorEngine(self._config)
            results = engine.score_stocks(symbols, top_n=top_n)

            def _show():
                for w in self._factor_result_frame.winfo_children():
                    w.destroy()

                self._factor_progress.config(
                    text=f"完成! 分析{len(symbols)}只，返回前{len(results)}只")

                if not results:
                    Label(self._factor_result_frame, text="  无结果",
                          font=("Consolas", 10), bg=C["bg"], fg=C["text_muted"]).pack(pady=40)
                    return

                for r in results:
                    row = Frame(self._factor_result_frame, bg=C["bg_card"])
                    row.pack(fill=X, padx=2, pady=1)

                    medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(r.rank, f"{r.rank}")
                    score_color = C["green"] if r.total_score >= 60 else C["orange"] if r.total_score >= 40 else C["red"]
                    rec_color = C["green"] if "推荐" in r.recommendation else C["orange"] if r.recommendation == "中性" else C["red"]

                    # 因子分数摘要
                    val_score = r.factors.get("pe_ttm", None)
                    mom_score = r.factors.get("return_20d", None)
                    vol_score = r.factors.get("volatility_20d", None)

                    Label(row, text=f" {medal}", font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=5, anchor=W).pack(side=LEFT)
                    Label(row, text=r.symbol, font=("Consolas", 8), bg=C["bg_card"], fg=C["text"], width=10, anchor=W).pack(side=LEFT)
                    Label(row, text=f"{r.total_score:.1f}", font=("Consolas", 8, "bold"), bg=C["bg_card"], fg=score_color, width=10, anchor=W).pack(side=LEFT)
                    Label(row, text=r.recommendation, font=("Consolas", 8), bg=C["bg_card"], fg=rec_color, width=10, anchor=W).pack(side=LEFT)
                    Label(row, text=f"{val_score.z_score:+.2f}" if val_score else "--", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"], width=10, anchor=W).pack(side=LEFT)
                    Label(row, text=f"{mom_score.z_score:+.2f}" if mom_score else "--", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"], width=10, anchor=W).pack(side=LEFT)
                    Label(row, text=f"{vol_score.z_score:+.2f}" if vol_score else "--", font=("Consolas", 8), bg=C["bg_card"], fg=C["text_dim"], width=10, anchor=W).pack(side=LEFT)

            self.root.after(0, _show)

        threading.Thread(target=_do, daemon=True).start()

    # ════════════════════════════════════════════════════════════════
    #  设置
    # ════════════════════════════════════════════════════════════════

    def _build_settings_tab(self):
        """设置页面"""
        tab = Frame(self.notebook, bg=C["bg"])
        self.notebook.add(tab, text="  ◆ 设置  ")

        # 可滚动区域
        canvas = Canvas(tab, bg=C["bg"], highlightthickness=0)
        scrollbar = Scrollbar(tab, orient="vertical", command=canvas.yview)
        scroll_frame = Frame(canvas, bg=C["bg"])
        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=LEFT, fill=BOTH, expand=True, padx=8, pady=8)
        scrollbar.pack(side=RIGHT, fill=Y)

        # 鼠标滚轮支持（仅鼠标在canvas上时生效）
        def _on_settings_scroll(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        def _bind_settings_scroll(e):
            canvas.bind_all("<MouseWheel>", _on_settings_scroll)
        def _unbind_settings_scroll(e):
            canvas.unbind_all("<MouseWheel>")
        canvas.bind("<Enter>", _bind_settings_scroll)
        canvas.bind("<Leave>", _unbind_settings_scroll)

        # ── 系统信息 ──
        info_frame = LabelFrame(scroll_frame, text="  ◆ 系统信息  ",
                                 font=("Consolas", 10, "bold"), bg=C["bg_card"],
                                 fg=C["accent"], labelanchor="nw")
        info_frame.pack(fill=X, padx=8, pady=4)
        info_body = Frame(info_frame, bg=C["bg_card"])
        info_body.pack(fill=X, padx=12, pady=8)
        Label(info_body, text="QuantFlow V2.0 — A股量化交易系统", font=("Consolas", 11, "bold"),
              bg=C["bg_card"], fg=C["text_bright"]).pack(anchor=W)
        Label(info_body, text="BY Ricardo（V root_ss）", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"]).pack(anchor=W, pady=(2, 0))

        # ── 主题配置 ──
        theme_frame = LabelFrame(scroll_frame, text="  ◆ 界面风格  ",
                                  font=("Consolas", 10, "bold"), bg=C["bg_card"],
                                  fg=C["cyan"], labelanchor="nw")
        theme_frame.pack(fill=X, padx=8, pady=4)
        th_body = Frame(theme_frame, bg=C["bg_card"])
        th_body.pack(fill=X, padx=12, pady=8)

        Label(th_body, text="当前主题: 科技深色", font=("Consolas", 10, "bold"),
              bg=C["bg_card"], fg=C["accent"]).pack(anchor=W)
        Label(th_body, text="深邃科技风 | 高对比度 | 专业量化氛围", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"]).pack(anchor=W, pady=(2, 0))
        Label(th_body, text="配色: 深黑底 + 科技绿强调 + 冰蓝信息色", font=("Consolas", 8),
              bg=C["bg_card"], fg=C["text_muted"]).pack(anchor=W)

        # 通知配置
        notif_frame = LabelFrame(scroll_frame, text="  ◆ 通知配置  ",
                                  font=("Consolas", 10, "bold"), bg=C["bg_card"],
                                  fg=C["orange"], labelanchor="nw")
        notif_frame.pack(fill=X, padx=8, pady=4)

        n_body = Frame(notif_frame, bg=C["bg_card"])
        n_body.pack(fill=X, padx=12, pady=8)

        Label(n_body, text="主通知通道", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=0, sticky=W, pady=2)
        self._set_primary_channel = StringVar(value="dingtalk")
        OptionMenu(n_body, self._set_primary_channel, "dingtalk", "feishu", "wechat").grid(row=0, column=1, padx=8, pady=2)

        Label(n_body, text="Webhook 地址", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"]).grid(row=1, column=0, sticky=W, pady=2)
        self._set_webhook = StringVar()
        Entry(n_body, textvariable=self._set_webhook, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["text"], relief="flat", width=50).grid(row=1, column=1, padx=8, pady=2)

        Label(n_body, text="备用通道 Token", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"]).grid(row=2, column=0, sticky=W, pady=2)
        self._set_backup_token = StringVar()
        Entry(n_body, textvariable=self._set_backup_token, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["text"], relief="flat", width=50).grid(row=2, column=1, padx=8, pady=2)

        # 大盘择时配置
        timing_frame = LabelFrame(scroll_frame, text="  ◆ 大盘择时  ",
                                   font=("Consolas", 10, "bold"), bg=C["bg_card"],
                                   fg=C["green"], labelanchor="nw")
        timing_frame.pack(fill=X, padx=8, pady=4)

        mt_body = Frame(timing_frame, bg=C["bg_card"])
        mt_body.pack(fill=X, padx=12, pady=8)

        self._market_timing_enabled = IntVar(value=0)
        from tkinter import Checkbutton as CB2
        CB2(mt_body, text="启用大盘择时过滤", variable=self._market_timing_enabled,
             font=("Consolas", 9), bg=C["bg_card"], fg=C["text"],
             selectcolor=C["bg_input"], activebackground=C["bg_card"]).grid(row=0, column=0, sticky=W, pady=2)
        Label(mt_body, text="大盘在均线下方时暂停买入信号", font=("Consolas", 8),
              bg=C["bg_card"], fg=C["text_muted"]).grid(row=1, column=0, sticky=W)

        # 风控参数
        risk_frame = LabelFrame(scroll_frame, text="  ◆ 风控参数  ",
                                 font=("Consolas", 10, "bold"), bg=C["bg_card"],
                                 fg=C["red"], labelanchor="nw")
        risk_frame.pack(fill=X, padx=8, pady=4)

        r_body = Frame(risk_frame, bg=C["bg_card"])
        r_body.pack(fill=X, padx=12, pady=8)

        Label(r_body, text="硬熔断阈值(%)", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=0, sticky=W, pady=2)
        self._set_breaker = StringVar(value="5")
        Entry(r_body, textvariable=self._set_breaker, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["text"], relief="flat", width=8).grid(row=0, column=1, padx=8, pady=2)

        Label(r_body, text="单日亏损限额(%)", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"]).grid(row=1, column=0, sticky=W, pady=2)
        self._set_daily_loss = StringVar(value="5")
        Entry(r_body, textvariable=self._set_daily_loss, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["text"], relief="flat", width=8).grid(row=1, column=1, padx=8, pady=2)

        Label(r_body, text="单票最大持仓占比(%)", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"]).grid(row=2, column=0, sticky=W, pady=2)
        self._set_max_pos = StringVar(value="60")
        Entry(r_body, textvariable=self._set_max_pos, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["text"], relief="flat", width=8).grid(row=2, column=1, padx=8, pady=2)

        # 交易参数
        trade_frame = LabelFrame(scroll_frame, text="  ◆ 交易参数  ",
                                  font=("Consolas", 10, "bold"), bg=C["bg_card"],
                                  fg=C["cyan"], labelanchor="nw")
        trade_frame.pack(fill=X, padx=8, pady=4)

        t_body = Frame(trade_frame, bg=C["bg_card"])
        t_body.pack(fill=X, padx=12, pady=8)

        Label(t_body, text="佣金费率", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"]).grid(row=0, column=0, sticky=W, pady=2)
        self._set_commission = StringVar(value="0.00025")
        Entry(t_body, textvariable=self._set_commission, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["text"], relief="flat", width=12).grid(row=0, column=1, padx=8, pady=2)
        Label(t_body, text="万2.5 = 0.00025", font=("Consolas", 8),
              bg=C["bg_card"], fg=C["text_muted"]).grid(row=0, column=2, pady=2)

        Label(t_body, text="滑点率", font=("Consolas", 9),
              bg=C["bg_card"], fg=C["text_dim"]).grid(row=1, column=0, sticky=W, pady=2)
        self._set_slippage = StringVar(value="0.001")
        Entry(t_body, textvariable=self._set_slippage, font=("Consolas", 9),
              bg=C["bg_input"], fg=C["text"], relief="flat", width=12).grid(row=1, column=1, padx=8, pady=2)
        Label(t_body, text="0.1% = 0.001", font=("Consolas", 8),
              bg=C["bg_card"], fg=C["text_muted"]).grid(row=1, column=2, pady=2)

        # 保存按钮
        Button(scroll_frame, text="💾 保存设置", font=("Consolas", 11, "bold"),
               bg=C["accent"], fg=C["bg"], relief="flat",
               command=self._save_settings).pack(fill=X, padx=8, pady=16, ipady=10)

        self._log_system("设置页面已加载")

    def _apply_theme(self):
        """主题已固定为科技深色，无需切换"""
        self._log_system("当前主题: 科技深色（已固定）")

    def _save_settings(self):
        """保存设置到配置文件"""
        try:
            from config.manager import get_config
            config = get_config()

            config.set("notification.primary_channel", self._set_primary_channel.get())
            config.set("notification.dingtalk.webhook", self._set_webhook.get())
            config.set("notification.wechat.token", self._set_backup_token.get())
            config.set("risk.circuit_breaker.threshold", float(self._set_breaker.get()) / 100)
            config.set("risk.daily_loss_limit", float(self._set_daily_loss.get()) / 100)
            config.set("risk.max_position_concentration", float(self._set_max_pos.get()) / 100)
            config.set("trading.commission_rate", float(self._set_commission.get()))
            config.set("trading.slippage_rate", float(self._set_slippage.get()))

            if self._db:
                self._db.log_config_change("settings_saved", "", "user updated settings")

            messagebox.showinfo("成功", "设置已保存")
            self._log_system("设置已保存")
        except Exception as e:
            messagebox.showerror("错误", f"保存失败: {e}")

    # ════════════════════════════════════════════════════════════════
    #  启动
    # ════════════════════════════════════════════════════════════════

    def run(self):
        """启动应用"""
        self._set_status("运行中", C["accent"])
        self._log_system("QuantFlow V2.0 已启动")
        self.root.mainloop()


# ── 入口 ──
if __name__ == "__main__":
    app = QuantFlowApp()
    app.run()
