"""
RSI (Relative Strength Index) Strategy.
Oversold/overbought detection with direction confirmation and extreme value signals.
"""

import numpy as np
from typing import Optional, Dict, Any

from core.strategy.base import BaseStrategy
from core.strategy.registry import StrategyRegistry
from core.models import Bar, Signal, SignalAction
from core.strategy import indicators as ind


@StrategyRegistry.register("rsi")
class RSIStrategy(BaseStrategy):
    """RSI Oversold/Overbought Strategy.

    Logic:
        - BUY when RSI crosses above oversold threshold AND RSI rising for 2 consecutive bars
        - BUY immediately when RSI < extreme_oversold (20)
        - SELL when RSI crosses below overbought threshold AND RSI falling for 2 consecutive bars
        - SELL immediately when RSI > extreme_overbought (80)

    Uses indicators.rsi() for calculation.

    Parameters:
        - period: RSI calculation period (default: 14)
        - oversold: Oversold threshold (default: 30)
        - overbought: Overbought threshold (default: 70)
        - extreme_oversold: Extreme oversold level, direct buy (default: 20)
        - extreme_overbought: Extreme overbought level, direct sell (default: 80)
        - direction_bars: Number of consecutive bars for direction confirmation (default: 2)
        - volume: Trade volume (default: 100)
    """

    def __init__(self, strategy_id: str, params: Optional[Dict[str, Any]] = None):
        super().__init__(strategy_id, params)
        self.period = self.get_param("period", 14)
        self.oversold = self.get_param("oversold", 30)
        self.overbought = self.get_param("overbought", 70)
        self.extreme_oversold = self.get_param("extreme_oversold", 20)
        self.extreme_overbought = self.get_param("extreme_overbought", 80)
        self.direction_bars = self.get_param("direction_bars", 2)
        self.trade_volume = self.get_param("volume", 100)

    def on_bar(self, bar: Bar) -> Optional[Signal]:
        """Generate signals based on RSI levels with direction confirmation."""
        # Need enough history: period + direction_bars + buffer
        lookback = self.period + self.direction_bars + 5
        closes = self.get_close_prices(bar.symbol, lookback)

        if len(closes) < self.period + self.direction_bars + 1:
            return None

        # Calculate RSI for recent bars using indicators module
        rsi_values = ind.rsi(closes, self.period)

        curr_rsi = rsi_values[-1]
        prev_rsi = rsi_values[-2]

        pos = self.get_position(bar.symbol)

        # === Extreme value signals ===

        # RSI < extreme_oversold → wait for bounce back above threshold to confirm
        if curr_rsi < self.extreme_oversold:
            # Mark that we saw extreme oversold, but don't buy yet
            # (Buying at RSI=15 in a crash is suicide — wait for the bounce)
            pass

        # RSI was below extreme, now bounces back above → confirmed BUY
        if prev_rsi < self.extreme_oversold and curr_rsi >= self.extreme_oversold:
            if pos.volume == 0:
                if not self.check_trend(bar.symbol, "BUY"):
                    return None
                confidence = max(0, (self.extreme_oversold - prev_rsi) / self.extreme_oversold)
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.BUY,
                    volume=self.trade_volume,
                    strategy_id=self.strategy_id,
                    confidence=confidence,
                    reason=f"RSI extreme bounce: {prev_rsi:.1f} -> {curr_rsi:.1f} (from <{self.extreme_oversold})",
                )

        # RSI > extreme_overbought → direct SELL (no confirmation needed for exits)
        if curr_rsi > self.extreme_overbought:
            if pos.volume > 0:
                confidence = max(0, (curr_rsi - self.extreme_overbought) / (100 - self.extreme_overbought))
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=confidence,
                    reason=f"RSI extreme overbought: {curr_rsi:.1f} > {self.extreme_overbought}",
                )

        # === Threshold crossover with direction confirmation ===

        # Check RSI direction: rising for direction_bars consecutive bars
        rsi_rising = all(
            rsi_values[-(i + 1)] > rsi_values[-(i + 2)]
            for i in range(self.direction_bars)
        )
        # Check RSI direction: falling for direction_bars consecutive bars
        rsi_falling = all(
            rsi_values[-(i + 1)] < rsi_values[-(i + 2)]
            for i in range(self.direction_bars)
        )

        # RSI crosses above oversold AND rising for 2 bars -> BUY
        if prev_rsi <= self.oversold and curr_rsi > self.oversold and rsi_rising:
            if pos.volume == 0:
                # Trend filter: don't buy in downtrend
                if not self.check_trend(bar.symbol, "BUY"):
                    return None
                confidence = max(0, (self.oversold - prev_rsi) / self.oversold)
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.BUY,
                    volume=self.trade_volume,
                    strategy_id=self.strategy_id,
                    confidence=confidence,
                    reason=f"RSI oversold bounce: {prev_rsi:.1f} -> {curr_rsi:.1f} (rising x{self.direction_bars})",
                )

        # RSI crosses below overbought AND falling for 2 bars -> SELL
        elif prev_rsi >= self.overbought and curr_rsi < self.overbought and rsi_falling:
            if pos.volume > 0:
                confidence = max(0, (prev_rsi - self.overbought) / (100 - self.overbought))
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=confidence,
                    reason=f"RSI overbought reversal: {prev_rsi:.1f} -> {curr_rsi:.1f} (falling x{self.direction_bars})",
                )

        return None
