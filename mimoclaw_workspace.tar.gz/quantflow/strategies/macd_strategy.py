"""
MACD Strategy for QuantFlow.
Uses MACD histogram crossovers with volume confirmation for signal generation.
"""

import numpy as np
from typing import Optional, Dict, Any

from core.strategy.base import BaseStrategy
from core.strategy.registry import StrategyRegistry
from core.models import Bar, Signal, SignalAction
from core.strategy import indicators as ind


@StrategyRegistry.register("macd")
class MACDStrategy(BaseStrategy):
    """MACD (Moving Average Convergence Divergence) Strategy.

    Logic:
        - BUY when histogram turns from negative to positive AND volume > 20-day avg
        - SELL when histogram turns from positive to negative

    Uses indicators.macd() for correct MACD line, signal line, and histogram calculation.

    Parameters:
        - fast_period: EMA fast period (default: 12)
        - slow_period: EMA slow period (default: 26)
        - signal_period: Signal line period (default: 9)
        - volume_ma_period: Volume MA period for confirmation (default: 20)
        - volume: Trade volume (default: 100)
    """

    def __init__(self, strategy_id: str, params: Optional[Dict[str, Any]] = None):
        super().__init__(strategy_id, params)
        self.fast_period = self.get_param("fast_period", 12)
        self.slow_period = self.get_param("slow_period", 26)
        self.signal_period = self.get_param("signal_period", 9)
        self.volume_ma_period = self.get_param("volume_ma_period", 20)
        self.trade_volume = self.get_param("volume", 100)

    def on_bar(self, bar: Bar) -> Optional[Signal]:
        """Generate signals based on MACD histogram crossover with volume confirmation."""
        lookback = self.slow_period + self.signal_period + 5
        closes = self.get_close_prices(bar.symbol, lookback)

        if len(closes) < self.slow_period + self.signal_period:
            return None

        # Calculate MACD using indicators module
        macd_line, signal_line, histogram = ind.macd(
            closes, self.fast_period, self.slow_period, self.signal_period
        )

        curr_hist = histogram[-1]
        prev_hist = histogram[-2]

        # Volume confirmation: current volume > 20-day average volume
        bars = self.get_bars(bar.symbol, self.volume_ma_period + 1)
        if len(bars) < self.volume_ma_period + 1:
            return None
        vol_array = np.array([b.volume for b in bars])
        vol_ma = np.mean(vol_array[-self.volume_ma_period - 1:-1])  # avg of prior bars
        volume_ok = bar.volume > vol_ma

        pos = self.get_position(bar.symbol)

        # Histogram turns positive -> BUY (with volume confirmation)
        if prev_hist <= 0 and curr_hist > 0:
            if pos.volume == 0 and volume_ok:
                # Trend filter: only buy in uptrend
                if not self.check_trend(bar.symbol, "BUY"):
                    return None
                confidence = min(abs(curr_hist) / 0.5, 1.0)
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.BUY,
                    volume=self.trade_volume,
                    strategy_id=self.strategy_id,
                    confidence=confidence,
                    reason=(
                        f"MACD bullish crossover: hist={curr_hist:.4f}, "
                        f"vol={bar.volume} > avg={vol_ma:.0f}"
                    ),
                )

        # Histogram turns negative -> SELL
        elif prev_hist >= 0 and curr_hist < 0:
            if pos.volume > 0:
                confidence = min(abs(curr_hist) / 0.5, 1.0)
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=confidence,
                    reason=f"MACD bearish crossover: hist={curr_hist:.4f}",
                )

        return None
