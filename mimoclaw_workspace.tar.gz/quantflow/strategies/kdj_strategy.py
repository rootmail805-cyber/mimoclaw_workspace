"""
KDJ (Stochastic Oscillator) Strategy.
Buy on oversold golden cross, sell on overbought death cross.
"""

import numpy as np
from typing import Optional, Dict, Any

from core.strategy.base import BaseStrategy
from core.strategy.registry import StrategyRegistry
from core.models import Bar, Signal, SignalAction


@StrategyRegistry.register("kdj")
class KDJStrategy(BaseStrategy):
    """KDJ Stochastic Oscillator Strategy.

    Logic:
        - BUY when K crosses above D and J < 20 (oversold golden cross)
        - SELL when K crosses below D and J > 80 (overbought death cross)

    Parameters:
        - n: RSV period (default: 9)
        - m1: K smoothing period (default: 3)
        - m2: D smoothing period (default: 3)
        - volume: Trade volume (default: 100)
    """

    def __init__(self, strategy_id: str, params: Optional[Dict[str, Any]] = None):
        super().__init__(strategy_id, params)
        self.n = self.get_param("n", 9)
        self.m1 = self.get_param("m1", 3)
        self.m2 = self.get_param("m2", 3)
        self.trade_volume = self.get_param("volume", 100)
        self._prev_k = 50.0
        self._prev_d = 50.0

    def _calculate_kdj(self, highs: np.ndarray, lows: np.ndarray, closes: np.ndarray):
        """Calculate K, D, J values."""
        if len(closes) < self.n:
            return 50.0, 50.0, 50.0

        highest = np.max(highs[-self.n:])
        lowest = np.min(lows[-self.n:])

        if highest == lowest:
            rsv = 50.0
        else:
            rsv = (closes[-1] - lowest) / (highest - lowest) * 100

        k = (2 * self._prev_k + rsv) / self.m1
        d = (2 * self._prev_d + k) / self.m2
        j = 3 * k - 2 * d

        return k, d, j

    def on_bar(self, bar: Bar) -> Optional[Signal]:
        """Generate signals based on KDJ indicator."""
        n_bars = self.n + 5
        highs = self.get_high_prices(bar.symbol, n_bars)
        lows = self.get_low_prices(bar.symbol, n_bars)
        closes = self.get_close_prices(bar.symbol, n_bars)

        if len(closes) < self.n:
            return None

        k, d, j = self._calculate_kdj(highs, lows, closes)

        pos = self.get_position(bar.symbol)
        prev_k, prev_d = self._prev_k, self._prev_d

        # Update state
        self._prev_k = k
        self._prev_d = d

        # K crosses above D with J < 30 -> BUY (oversold golden cross)
        if prev_k <= prev_d and k > d and j < 30:
            if pos.volume == 0:
                # Trend filter
                if not self.check_trend(bar.symbol, "BUY"):
                    return None
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.BUY,
                    volume=self.trade_volume,
                    strategy_id=self.strategy_id,
                    confidence=max(0, (30 - j) / 30),
                    reason=f"KDJ golden cross: K={k:.1f} D={d:.1f} J={j:.1f}",
                )

        # K crosses below D with J > 70 -> SELL (overbought death cross)
        elif prev_k >= prev_d and k < d and j > 70:
            if pos.volume > 0:
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=max(0, (j - 70) / 30),
                    reason=f"KDJ death cross: K={k:.1f} D={d:.1f} J={j:.1f}",
                )

        return None
