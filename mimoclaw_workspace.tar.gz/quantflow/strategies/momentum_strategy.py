"""
Momentum Breakout Strategy.
Captures strong price moves backed by volume surges.
Based on the principle: price + volume = conviction.
"""

import numpy as np
from typing import Optional, Dict, Any

from core.strategy.base import BaseStrategy
from core.strategy.registry import StrategyRegistry
from core.models import Bar, Signal, SignalAction
from core.strategy import indicators as ind


@StrategyRegistry.register("momentum")
class MomentumBreakoutStrategy(BaseStrategy):
    """Momentum Breakout Strategy.

    Core idea from real trading experience:
        - Strong price move + volume surge = institutional buying → follow them
        - Price breaks recent high with 2x+ volume → high probability continuation
        - Use ATR for dynamic stop-loss distance

    Logic:
        - BUY: price closes above 20-day high AND volume > 2x 20-day avg AND ADX > 20
        - SELL: price closes below 10-day low OR trailing ATR stop

    This strategy is designed for catching the start of big moves.
    It's conservative (few signals) but high quality.

    Parameters:
        - price_period: Period for highest/lowest price (default: 20)
        - volume_multiplier: Volume must be N times the average (default: 2.0)
        - volume_ma_period: Volume MA period (default: 20)
        - atr_period: ATR for stop-loss (default: 14)
        - atr_stop_multiplier: ATR multiplier for trailing stop (default: 2.5)
        - adx_period: ADX period for trend confirmation (default: 14)
        - adx_threshold: Minimum ADX to confirm trend (default: 20)
        - volume: Trade volume (default: 100)
    """

    def __init__(self, strategy_id: str, params: Optional[Dict[str, Any]] = None):
        super().__init__(strategy_id, params)
        self.price_period = self.get_param("price_period", 20)
        self.volume_multiplier = self.get_param("volume_multiplier", 2.0)
        self.volume_ma_period = self.get_param("volume_ma_period", 20)
        self.atr_period = self.get_param("atr_period", 14)
        self.atr_stop_mult = self.get_param("atr_stop_multiplier", 2.5)
        self.adx_period = self.get_param("adx_period", 14)
        self.adx_threshold = self.get_param("adx_threshold", 20)
        self.trade_volume = self.get_param("volume", 100)
        self._entry_prices: Dict[str, float] = {}      # symbol -> entry price
        self._highest_since: Dict[str, float] = {}      # symbol -> highest price

    def on_bar(self, bar: Bar) -> Optional[Signal]:
        """Generate signals based on momentum breakout with volume confirmation."""
        lookback = max(self.price_period, self.volume_ma_period, self.atr_period * 3) + 10
        bars = self.get_bars(bar.symbol, lookback)

        if len(bars) < self.price_period + 1:
            return None

        closes = np.array([b.close for b in bars])
        highs = np.array([b.high for b in bars])
        lows = np.array([b.low for b in bars])
        volumes = np.array([b.volume for b in bars])

        pos = self.get_position(bar.symbol)

        # === SELL LOGIC (check first — always check stops before new entries) ===

        if pos.volume > 0:
            # Update trailing stop tracker
            prev_high = self._highest_since.get(bar.symbol, 0.0)
            self._highest_since[bar.symbol] = max(prev_high, bar.high)

            # ATR trailing stop
            atr_vals = ind.atr(highs, lows, closes, self.atr_period)
            curr_atr = atr_vals[-1]
            stop_price = self._highest_since[bar.symbol] - self.atr_stop_mult * curr_atr

            if bar.close < stop_price:
                self._entry_prices.pop(bar.symbol, None)
                self._highest_since.pop(bar.symbol, None)
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=0.8,
                    reason=f"Momentum trailing stop: {bar.close:.2f} < {stop_price:.2f} (ATR stop)",
                )

            # Price breaks below 10-day low → exit
            recent_lows = lows[-10:]
            if bar.close < np.min(recent_lows[:-1]):
                self._entry_prices.pop(bar.symbol, None)
                self._highest_since.pop(bar.symbol, None)
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=0.7,
                    reason=f"Momentum breakdown: {bar.close:.2f} < 10-day low",
                )

            return None

        # === BUY LOGIC ===

        # Condition 1: Price closes above 20-day high
        period_highs = highs[-(self.price_period + 1):-1]
        highest_20 = np.max(period_highs)
        if closes[-1] <= highest_20:
            return None

        # Condition 2: Volume surge — current volume > N times 20-day average
        vol_avg = np.mean(volumes[-(self.volume_ma_period + 1):-1])
        if vol_avg <= 0 or bar.volume < vol_avg * self.volume_multiplier:
            return None

        # Condition 3: ADX confirms trend strength
        adx_vals, plus_di, minus_di = ind.adx(highs, lows, closes, self.adx_period)
        curr_adx = adx_vals[-1]
        if curr_adx < self.adx_threshold:
            return None

        # Condition 4: +DI > -DI (uptrend direction)
        if plus_di[-1] <= minus_di[-1]:
            return None

        # All conditions met → BUY
        self._entry_prices[bar.symbol] = bar.close
        self._highest_since[bar.symbol] = bar.high
        confidence = min(bar.volume / vol_avg / self.volume_multiplier, 1.0)

        return Signal(
            symbol=bar.symbol,
            action=SignalAction.BUY,
            volume=self.trade_volume,
            strategy_id=self.strategy_id,
            confidence=confidence,
            reason=(
                f"Momentum breakout: close={bar.close:.2f} > 20d high={highest_20:.2f}, "
                f"vol={bar.volume}={bar.volume / vol_avg:.1f}x avg, ADX={curr_adx:.1f}"
            ),
        )
