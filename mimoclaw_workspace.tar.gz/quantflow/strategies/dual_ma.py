"""
Dual Moving Average Crossover Strategy.
Classic trend-following strategy: buy on golden cross, sell on death cross.
"""

import numpy as np
from typing import Optional, Dict, Any

from core.strategy.base import BaseStrategy
from core.strategy.registry import StrategyRegistry
from core.models import Bar, Signal, SignalAction


@StrategyRegistry.register("dual_ma")
class DualMAStrategy(BaseStrategy):
    """Dual Moving Average Crossover Strategy.

    Logic:
        - BUY when short MA crosses above long MA (golden cross)
        - SELL when short MA crosses below long MA (death cross)

    Parameters:
        - short_window: Short MA period (default: 5)
        - long_window: Long MA period (default: 20)
        - volume: Trade volume per signal (default: 100)
    """

    def __init__(self, strategy_id: str, params: Optional[Dict[str, Any]] = None):
        super().__init__(strategy_id, params)
        self.short_window = self.get_param("short_window", 5)
        self.long_window = self.get_param("long_window", 20)
        self.trade_volume = self.get_param("volume", 100)

        # 参数验证
        if self.short_window <= 0 or self.long_window <= 0:
            raise ValueError(f"均线周期必须为正数: short={self.short_window}, long={self.long_window}")
        if self.short_window >= self.long_window:
            # 自动交换
            self.short_window, self.long_window = min(self.short_window, self.long_window), max(self.short_window, self.long_window)
        if self.trade_volume <= 0:
            raise ValueError(f"交易数量必须为正数: volume={self.trade_volume}")

    def on_bar(self, bar: Bar) -> Optional[Signal]:
        """Process each bar and generate signals on crossover."""
        closes = self.get_close_prices(bar.symbol, self.long_window + 1)

        if len(closes) < self.long_window + 1:
            return None

        # Calculate moving averages
        short_ma = np.mean(closes[-self.short_window:])
        long_ma = np.mean(closes[-self.long_window:])

        # Previous values for crossover detection
        prev_closes = closes[:-1]
        prev_short_ma = np.mean(prev_closes[-self.short_window:])
        prev_long_ma = np.mean(prev_closes[-self.long_window:])

        pos = self.get_position(bar.symbol)

        # Golden cross: short MA crosses above long MA
        if prev_short_ma <= prev_long_ma and short_ma > long_ma:
            if pos.volume == 0:
                # Trend filter: only buy in uptrend
                if not self.check_trend(bar.symbol, "BUY"):
                    return None
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.BUY,
                    volume=self.trade_volume,
                    strategy_id=self.strategy_id,
                    reason=f"Golden cross: MA{self.short_window}={short_ma:.2f} > MA{self.long_window}={long_ma:.2f}",
                )

        # Death cross: short MA crosses below long MA
        elif prev_short_ma >= prev_long_ma and short_ma < long_ma:
            if pos.volume > 0:
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    reason=f"Death cross: MA{self.short_window}={short_ma:.2f} < MA{self.long_window}={long_ma:.2f}",
                )

        return None
