"""Built-in trading strategies for QuantFlow."""

from strategies.dual_ma import DualMAStrategy
from strategies.macd_strategy import MACDStrategy
from strategies.bollinger_strategy import BollingerStrategy
from strategies.rsi_strategy import RSIStrategy
from strategies.kdj_strategy import KDJStrategy
from strategies.atr_breakout_strategy import ATRBreakoutStrategy
from strategies.momentum_strategy import MomentumBreakoutStrategy
from strategies.vwap_strategy import VWAPStrategy

__all__ = [
    "DualMAStrategy",
    "MACDStrategy",
    "BollingerStrategy",
    "RSIStrategy",
    "KDJStrategy",
    "ATRBreakoutStrategy",
    "MomentumBreakoutStrategy",
    "VWAPStrategy",
]
