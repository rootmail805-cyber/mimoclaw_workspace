"""
Bollinger Bands Mean Reversion Strategy v2.
Fixes: repeated signal bug, adds reversal confirmation + volume filter.
"""

import numpy as np
from typing import Optional, Dict, Any

from core.strategy.base import BaseStrategy
from core.strategy.registry import StrategyRegistry
from core.models import Bar, Signal, SignalAction
from core.strategy import indicators as ind


@StrategyRegistry.register("bollinger")
class BollingerStrategy(BaseStrategy):
    """Bollinger Bands Mean Reversion Strategy v2.

    Improvements over v1:
        - Fixed: no longer triggers every bar while price is below band
        - Requires price to REVERSE back inside the band (not just be outside)
        - Added volume confirmation (volume > 20-day avg)
        - Added Bollinger Band width filter (skip when bands too narrow = low vol)

    Logic:
        - BUY: price was below lower band, now crosses back above it + volume OK
        - SELL: price was above upper band, now crosses back below it

    Parameters:
        - period: Moving average period (default: 20)
        - num_std: Number of standard deviations (default: 2.0)
        - volume_ma_period: Volume MA for confirmation (default: 20)
        - min_band_width: Minimum band width as % of middle (default: 0.02)
        - volume: Trade volume (default: 100)
    """

    def __init__(self, strategy_id: str, params: Optional[Dict[str, Any]] = None):
        super().__init__(strategy_id, params)
        self.period = self.get_param("period", 20)
        self.num_std = self.get_param("num_std", 2.0)
        self.volume_ma_period = self.get_param("volume_ma_period", 20)
        self.min_band_width = self.get_param("min_band_width", 0.02)
        self.trade_volume = self.get_param("volume", 100)

    def on_bar(self, bar: Bar) -> Optional[Signal]:
        """Generate signals based on Bollinger Bands reversal."""
        lookback = max(self.period, self.volume_ma_period) + 5
        closes = self.get_close_prices(bar.symbol, lookback)

        if len(closes) < self.period + 2:
            return None

        # Calculate Bollinger Bands for current and previous bar
        recent = closes[-self.period:]
        middle = np.mean(recent)
        std = np.std(recent)

        if std == 0:
            return None

        upper = middle + self.num_std * std
        lower = middle - self.num_std * std

        # Band width filter: skip when bands are too narrow (low volatility)
        band_width = (upper - lower) / middle if middle > 0 else 0
        if band_width < self.min_band_width:
            return None

        # Previous bar's bands (for crossover detection)
        prev_closes = closes[:-1]
        prev_recent = prev_closes[-self.period:]
        prev_middle = np.mean(prev_recent)
        prev_std = np.std(prev_recent)
        prev_upper = prev_middle + self.num_std * prev_std
        prev_lower = prev_middle - self.num_std * prev_std

        price = closes[-1]
        prev_price = closes[-2]

        pos = self.get_position(bar.symbol)

        # Volume confirmation
        bars = self.get_bars(bar.symbol, self.volume_ma_period + 1)
        vol_ok = True
        if len(bars) >= self.volume_ma_period + 1:
            vol_array = np.array([b.volume for b in bars])
            vol_ma = np.mean(vol_array[-self.volume_ma_period - 1:-1])
            vol_ok = bar.volume > vol_ma

        # BUY: price was below lower band, now crosses back above it
        # (Mean reversion: price bounced off the bottom)
        if prev_price < prev_lower and price > lower:
            if pos.volume == 0 and vol_ok:
                # Trend filter: don't buy in strong downtrend
                if not self.check_trend(bar.symbol, "BUY"):
                    return None
                confidence = min((lower - prev_price) / (upper - lower), 1.0)
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.BUY,
                    volume=self.trade_volume,
                    strategy_id=self.strategy_id,
                    confidence=confidence,
                    reason=f"BB reversal UP: {prev_price:.2f} < {prev_lower:.2f} -> {price:.2f} > {lower:.2f}",
                )

        # SELL: price was above upper band, now crosses back below it
        elif prev_price > prev_upper and price < upper:
            if pos.volume > 0:
                confidence = min((prev_price - prev_upper) / (upper - lower), 1.0)
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=confidence,
                    reason=f"BB reversal DOWN: {prev_price:.2f} > {prev_upper:.2f} -> {price:.2f} < {upper:.2f}",
                )

        return None
