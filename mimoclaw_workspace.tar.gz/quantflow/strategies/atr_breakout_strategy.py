"""
ATR Channel Breakout Strategy.
Buy when price breaks above SMA+2*ATR, sell when price breaks below SMA-2*ATR.
"""

import numpy as np
from typing import Optional, Dict, Any

from core.strategy.base import BaseStrategy
from core.strategy.registry import StrategyRegistry
from core.models import Bar, Signal, SignalAction


@StrategyRegistry.register("atr_breakout")
class ATRBreakoutStrategy(BaseStrategy):
    """ATR Channel Breakout Strategy.

    Logic:
        - BUY when price breaks above SMA + multiplier * ATR (upper band)
        - SELL when price breaks below SMA - multiplier * ATR (lower band)

    Parameters:
        - sma_period: SMA calculation period (default: 20)
        - atr_period: ATR calculation period (default: 14)
        - multiplier: ATR multiplier for channel width (default: 2.0)
        - volume: Trade volume (default: 100)
    """

    def __init__(self, strategy_id: str, params: Optional[Dict[str, Any]] = None):
        super().__init__(strategy_id, params)
        self.sma_period = self.get_param("sma_period", 20)
        self.atr_period = self.get_param("atr_period", 14)
        self.multiplier = self.get_param("multiplier", 2.0)
        self.trade_volume = self.get_param("volume", 100)
        self._highest_since: Dict[str, float] = {}  # symbol -> highest price since entry

    def _calculate_atr(self, highs: np.ndarray, lows: np.ndarray, closes: np.ndarray) -> float:
        """Calculate Average True Range."""
        if len(closes) < self.atr_period + 1:
            return 0.0

        tr_list = []
        for i in range(1, len(closes)):
            tr = max(
                highs[i] - lows[i],
                abs(highs[i] - closes[i - 1]),
                abs(lows[i] - closes[i - 1]),
            )
            tr_list.append(tr)

        if len(tr_list) < self.atr_period:
            return 0.0

        return float(np.mean(tr_list[-self.atr_period:]))

    def on_bar(self, bar: Bar) -> Optional[Signal]:
        """Generate signals based on ATR channel breakout."""
        n_bars = max(self.sma_period, self.atr_period) + 5
        highs = self.get_high_prices(bar.symbol, n_bars)
        lows = self.get_low_prices(bar.symbol, n_bars)
        closes = self.get_close_prices(bar.symbol, n_bars)

        if len(closes) < max(self.sma_period, self.atr_period + 1):
            return None

        sma = float(np.mean(closes[-self.sma_period:]))
        atr = self._calculate_atr(highs, lows, closes)

        if atr == 0:
            return None

        upper = sma + self.multiplier * atr
        lower = sma - self.multiplier * atr

        current_close = closes[-1]
        prev_close = closes[-2]

        pos = self.get_position(bar.symbol)

        # === Trailing stop check (before band breakout check) ===
        if pos.volume > 0:
            prev_high = self._highest_since.get(bar.symbol, 0.0)
            self._highest_since[bar.symbol] = max(prev_high, bar.high)
            stop_price = self._highest_since[bar.symbol] - 2.0 * atr

            if bar.close < stop_price:
                self._highest_since.pop(bar.symbol, None)
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=0.8,
                    reason=f"ATR trailing stop: {bar.close:.2f} < {stop_price:.2f} (peak - 2*ATR)",
                )

        # Price breaks above upper band -> BUY
        if prev_close <= upper and current_close > upper:
            if pos.volume == 0:
                # Trend filter: confirm uptrend
                if not self.check_trend(bar.symbol, "BUY"):
                    return None
                self._highest_since[bar.symbol] = bar.high
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.BUY,
                    volume=self.trade_volume,
                    strategy_id=self.strategy_id,
                    confidence=min(1.0, (current_close - upper) / atr),
                    reason=f"ATR breakout UP: {current_close:.2f} > {upper:.2f} (SMA={sma:.2f} ATR={atr:.2f})",
                )

        # Price breaks below lower band -> SELL
        elif prev_close >= lower and current_close < lower:
            if pos.volume > 0:
                self._highest_since.pop(bar.symbol, None)
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=min(1.0, (lower - current_close) / atr),
                    reason=f"ATR breakout DOWN: {current_close:.2f} < {lower:.2f} (SMA={sma:.2f} ATR={atr:.2f})",
                )

        return None
