"""
VWAP (Volume-Weighted Average Price) Strategy.
Institutional anchor strategy — buy below VWAP, sell above VWAP.
VWAP is the benchmark that institutional traders use to evaluate execution quality.
"""

import numpy as np
from typing import Optional, Dict, Any

from core.strategy.base import BaseStrategy
from core.strategy.registry import StrategyRegistry
from core.models import Bar, Signal, SignalAction
from core.strategy import indicators as ind


@StrategyRegistry.register("vwap")
class VWAPStrategy(BaseStrategy):
    """VWAP Mean Reversion Strategy.

    Core principle from institutional trading:
        - VWAP is the "fair price" for the day
        - Price significantly below VWAP = cheap → BUY
        - Price significantly above VWAP = expensive → SELL
        - Works best for intraday and short-term swing trading

    Logic:
        - BUY: price < VWAP - N*ATR AND RSI < 45 (oversold relative to VWAP)
        - SELL: price > VWAP + N*ATR AND RSI > 55 (overbought relative to VWAP)
        - Also SELL on VWAP crossover (price crosses below VWAP after buying above)

    The ATR bands around VWAP adapt to volatility, so the strategy
    works in both calm and volatile markets.

    Parameters:
        - vwap_period: Period for cumulative VWAP calculation (default: 20)
        - atr_period: ATR period for dynamic bands (default: 14)
        - band_multiplier: ATR multiplier for VWAP bands (default: 1.5)
        - rsi_period: RSI period for confirmation (default: 14)
        - rsi_oversold: RSI oversold threshold (default: 45)
        - rsi_overbought: RSI overbought threshold (default: 55)
        - volume: Trade volume (default: 100)
    """

    def __init__(self, strategy_id: str, params: Optional[Dict[str, Any]] = None):
        super().__init__(strategy_id, params)
        self.vwap_period = self.get_param("vwap_period", 20)
        self.atr_period = self.get_param("atr_period", 14)
        self.band_mult = self.get_param("band_multiplier", 1.5)
        self.rsi_period = self.get_param("rsi_period", 14)
        self.rsi_oversold = self.get_param("rsi_oversold", 45)
        self.rsi_overbought = self.get_param("rsi_overbought", 55)
        self.trade_volume = self.get_param("volume", 100)
        self._bought_above: Dict[str, bool] = {}  # symbol -> bought above VWAP

    def on_bar(self, bar: Bar) -> Optional[Signal]:
        """Generate signals based on VWAP deviation with ATR bands."""
        lookback = max(self.vwap_period, self.atr_period * 3, self.rsi_period + 5) + 10
        bars = self.get_bars(bar.symbol, lookback)

        if len(bars) < self.vwap_period + 1:
            return None

        closes = np.array([b.close for b in bars])
        highs = np.array([b.high for b in bars])
        lows = np.array([b.low for b in bars])
        volumes = np.array([b.volume for b in bars])

        # Calculate VWAP (cumulative over recent period)
        vwap = self._calculate_vwap(closes, highs, lows, volumes)

        # Calculate ATR for dynamic bands
        atr_vals = ind.atr(highs, lows, closes, self.atr_period)
        curr_atr = atr_vals[-1]

        if curr_atr == 0:
            return None

        upper_band = vwap + self.band_mult * curr_atr
        lower_band = vwap - self.band_mult * curr_atr

        # Calculate RSI for confirmation
        rsi_vals = ind.rsi(closes, self.rsi_period)
        curr_rsi = rsi_vals[-1]

        price = closes[-1]
        prev_price = closes[-2]

        pos = self.get_position(bar.symbol)

        # === SELL LOGIC ===

        if pos.volume > 0:
            bought_above = self._bought_above.get(bar.symbol, False)
            # Sell if price crosses below VWAP (losing the anchor)
            if prev_price > vwap and price < vwap and bought_above:
                self._bought_above[bar.symbol] = False
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=0.6,
                    reason=f"VWAP cross down: {price:.2f} < VWAP={vwap:.2f}",
                )

            # Sell if price > VWAP + N*ATR (overbought relative to VWAP)
            if price > upper_band and curr_rsi > self.rsi_overbought:
                self._bought_above[bar.symbol] = False
                return Signal(
                    symbol=bar.symbol,
                    action=SignalAction.SELL,
                    volume=pos.volume,
                    strategy_id=self.strategy_id,
                    confidence=min((price - vwap) / curr_atr / self.band_mult, 1.0),
                    reason=f"VWAP overbought: {price:.2f} > {upper_band:.2f} (VWAP+{self.band_mult}*ATR), RSI={curr_rsi:.1f}",
                )

            return None

        # === BUY LOGIC ===

        # Buy if price < VWAP - N*ATR AND RSI confirms oversold
        if price < lower_band and curr_rsi < self.rsi_oversold:
            # Trend filter
            if not self.check_trend(bar.symbol, "BUY"):
                return None

            self._bought_above[bar.symbol] = False
            confidence = min((vwap - price) / curr_atr / self.band_mult, 1.0)
            return Signal(
                symbol=bar.symbol,
                action=SignalAction.BUY,
                volume=self.trade_volume,
                strategy_id=self.strategy_id,
                confidence=confidence,
                reason=f"VWAP oversold: {price:.2f} < {lower_band:.2f} (VWAP-{self.band_mult}*ATR), RSI={curr_rsi:.1f}",
            )

        # Buy on VWAP bounce from below (price was below, now crossing above)
        if prev_price < vwap and price > vwap and curr_rsi < 50:
            if not self.check_trend(bar.symbol, "BUY"):
                return None

            self._bought_above[bar.symbol] = True
            return Signal(
                symbol=bar.symbol,
                action=SignalAction.BUY,
                volume=self.trade_volume,
                strategy_id=self.strategy_id,
                confidence=0.5,
                reason=f"VWAP bounce: {prev_price:.2f} -> {price:.2f} crossing above VWAP={vwap:.2f}",
            )

        return None

    def _calculate_vwap(
        self, closes: np.ndarray, highs: np.ndarray,
        lows: np.ndarray, volumes: np.ndarray,
    ) -> float:
        """Calculate VWAP over recent period.

        VWAP = sum(typical_price * volume) / sum(volume)
        where typical_price = (high + low + close) / 3
        """
        period = min(self.vwap_period, len(closes))
        recent_high = highs[-period:]
        recent_low = lows[-period:]
        recent_close = closes[-period:]
        recent_vol = volumes[-period:]

        typical = (recent_high + recent_low + recent_close) / 3.0
        total_vol = np.sum(recent_vol)

        if total_vol == 0:
            return float(closes[-1])

        return float(np.sum(typical * recent_vol) / total_vol)
