@echo off
chcp 936 >NUL 2>&1
cd /d "%~dp0"
title QuantFlow V2.0

echo.
echo ========================================
echo   QuantFlow V2.0
echo ========================================
echo.

if not exist "venv\Scripts\activate.bat" (
    echo [!] venv not found, creating...
    echo.
    python -m venv venv
    if errorlevel 1 (
        echo.
        echo [X] Failed to create venv!
        echo     Please install Python 3.10+ and check "Add to PATH"
        echo     https://www.python.org/downloads/
        echo.
        pause
        exit /b 1
    )
    echo [OK] venv created
    echo.

    echo [!] Installing dependencies, please wait...
    call venv\Scripts\activate.bat
    pip install -i https://pypi.tuna.tsinghua.edu.cn/simple --trusted-host pypi.tuna.tsinghua.edu.cn akshare pandas numpy pyyaml python-dotenv loguru requests psutil pydantic
    if errorlevel 1 (
        echo.
        echo [X] pip install failed! Check your network.
        echo.
        pause
        exit /b 1
    )
    echo.
    echo [OK] Dependencies installed
    echo.
)

call venv\Scripts\activate.bat
echo [*] Starting GUI...
echo.
python main.py

if errorlevel 1 (
    echo.
    echo ========================================
    echo [X] Program exited with error
    echo ========================================
)

echo.
echo Press any key to close...
pause >NUL
