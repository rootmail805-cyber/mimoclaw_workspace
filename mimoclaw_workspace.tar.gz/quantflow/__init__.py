"""
QuantFlow - Professional Quantitative Trading System
=====================================================
Compatible with Windows 10/11, Python 3.10+

Modules:
    - core.data: Market data acquisition, cleaning, storage
    - core.strategy: Strategy engine with indicators and signals
    - core.backtest: Historical backtesting and performance analysis
    - core.risk: Three-layer risk control architecture
    - core.execution: Order management and broker integration
    - core.monitor: Dashboard, alerts, and logging
"""

__version__ = "1.0.0"
__author__ = "QuantFlow Team"
