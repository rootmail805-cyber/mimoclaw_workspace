"""
from core.data.providers import rate_limited_get
Market timing filter for QuantFlow.
Uses CSI 300 index data to filter buy signals based on macro environment.
"""

from typing import Optional, Dict, Any, Tuple
from datetime import datetime, timedelta
import pandas as pd
from loguru import logger


class MarketTimingFilter:
    """Macro-level market timing filter using index data.

    Filters buy signals based on:
    - CSI 300 vs MA(N) position
    - RSI(14) level
    """

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._enabled = self._config.get("market_timing.enabled", False)
        self._index_code = self._config.get("market_timing.index_code", "000300")
        self._ma_period = self._config.get("market_timing.ma_period", 20)
        self._rsi_period = self._config.get("market_timing.rsi_period", 14)
        self._rsi_threshold = self._config.get("market_timing.rsi_threshold", 40)
        self._last_status: Optional[Dict] = None

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    def check(self, data: pd.DataFrame = None) -> Tuple[bool, str]:
        """Check if market conditions allow opening new positions.

        Args:
            data: DataFrame with CSI 300 daily data (optional, will fetch if None)

        Returns:
            (is_allowed, reason)
        """
        if not self._enabled:
            return True, "择时过滤器未启用"

        try:
            if data is None:
                data = self._fetch_index_data()

            if data is None or data.empty:
                logger.warning("Market timing: failed to get index data")
                return True, "无法获取大盘数据，跳过择时过滤"

            close_col = "close" if "close" in data.columns else "收盘"
            if close_col not in data.columns:
                return True, "数据格式异常，跳过择时过滤"

            close = data[close_col]

            # Calculate MA
            ma = close.rolling(self._ma_period).mean()
            latest_close = close.iloc[-1]
            latest_ma = ma.iloc[-1]
            above_ma = latest_close > latest_ma

            # Calculate RSI
            delta = close.diff()
            gain = delta.where(delta > 0, 0).rolling(self._rsi_period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(self._rsi_period).mean()
            rs = gain / loss.replace(0, 1e-10)
            rsi = 100 - (100 / (1 + rs))
            latest_rsi = rsi.iloc[-1]

            self._last_status = {
                "index_code": self._index_code,
                "close": latest_close,
                "ma": latest_ma,
                "above_ma": above_ma,
                "rsi": latest_rsi,
                "timestamp": datetime.now().isoformat(),
            }

            # Decision logic
            if not above_ma and latest_rsi < self._rsi_threshold:
                return False, (
                    f"大盘择时限制: {self._index_code} 指数({latest_close:.2f}) "
                    f"在MA{self._ma_period}({latest_ma:.2f})下方且RSI({latest_rsi:.1f})<{self._rsi_threshold}"
                )

            return True, f"大盘择时通过: 指数={latest_close:.2f}, MA={latest_ma:.2f}, RSI={latest_rsi:.1f}"

        except Exception as e:
            logger.error(f"Market timing check failed: {e}")
            return True, f"择时检查异常({e})，跳过过滤"

    def _fetch_index_data(self) -> Optional[pd.DataFrame]:
        """Fetch index data with multi-source fallback: akshare -> Sina -> Tencent."""
        end = datetime.now().strftime("%Y%m%d")
        start = (datetime.now() - timedelta(days=120)).strftime("%Y%m%d")

        # Source 1: akshare
        try:
            import akshare as ak
            df = ak.stock_zh_index_daily_em(
                symbol=f"sh{self._index_code}",
                start_date=start,
                end_date=end,
            )
            if df is not None and not df.empty:
                return df
        except Exception:
            pass

        # Source 2: Tencent K-line
        try:
            import requests
            code = f"sh{self._index_code}"
            url = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"
            params = {"param": f"{code},day,{start[:4]}-{start[4:6]}-{start[6:]},{end[:4]}-{end[4:6]}-{end[6:]},640,"}
            r = rate_limited_get(url, params=params, timeout=10)
            data = r.json()
            stock_data = data.get("data", {}).get(code, {})
            klines = stock_data.get("day", stock_data.get("qfqday", []))
            if klines:
                rows = []
                for k in klines:
                    if len(k) >= 5:
                        rows.append({"date": k[0], "open": float(k[1]), "close": float(k[2]),
                                     "high": float(k[3]), "low": float(k[4]), "volume": int(float(k[5])) if len(k) > 5 else 0})
                import pandas as pd
                df = pd.DataFrame(rows)
                if not df.empty:
                    df["date"] = pd.to_datetime(df["date"])
                    df = df.set_index("date")
                    return df
        except Exception:
            pass

        # Source 3: Sina K-line
        try:
            import requests, json
            code = f"sh{self._index_code}"
            h = {'Referer': 'https://finance.sina.com.cn', 'User-Agent': 'Mozilla/5.0'}
            r = requests.get(
                'https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData',
                params={'symbol': code, 'scale': '240', 'ma': 'no', 'datalen': '600'},
                headers=h, timeout=10)
            if r.status_code == 200:
                data = json.loads(r.text)
                if data:
                    rows = [{'date': d['day'], 'open': float(d['open']), 'close': float(d['close']),
                             'high': float(d['high']), 'low': float(d['low']), 'volume': int(float(d['volume']))}
                            for d in data]
                    import pandas as pd
                    df = pd.DataFrame(rows)
                    if not df.empty:
                        df['date'] = pd.to_datetime(df['date'])
                        df = df.set_index('date')
                        return df
        except Exception:
            pass

        logger.error("All index data sources failed")
        return None

    def get_status(self) -> Optional[Dict]:
        """Get last check status for display."""
        return self._last_status
