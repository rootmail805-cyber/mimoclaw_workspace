"""
Notification Manager for QuantFlow.
Supports: DingTalk/Feishu Webhook, WeChat PushPlus, local log.
All sends are async (non-blocking).
"""

import threading
import queue
import time
import json
import requests
from enum import Enum
from datetime import datetime
from typing import Optional, Dict, Any, Callable
from loguru import logger
from ..security.crypto import mask_webhook_url, validate_url


class NotificationLevel(Enum):
    """Notification severity levels."""
    ROUTINE = "routine"       # 🟢 日常 — 仅盘后简报
    ATTENTION = "attention"   # 🟡 关注 — 单笔亏损/对账偏差
    URGENT = "urgent"         # 🔴 紧急 — 熔断/客户端异常
    INFO = "info"             # 🔵 信息 — 系统启动/策略启动


class NotificationManager:
    """Async notification manager with retry and rate limiting."""

    def __init__(self, config: dict = None):
        from config.manager import get_config
        self._config = config or get_config()
        self._queue: queue.Queue = queue.Queue(maxsize=500)
        self._running = False
        self._worker_thread: Optional[threading.Thread] = None
        self._rate_limiter: Dict[str, float] = {}  # event_type -> last_send_time
        self._send_handlers: Dict[str, Callable] = {
            "dingtalk": self._send_dingtalk,
            "feishu": self._send_feishu,
            "wechat": self._send_wechat,
            "local": self._send_local,
        }

    def start(self):
        """Start notification worker thread."""
        if self._running:
            return
        self._running = True
        self._worker_thread = threading.Thread(target=self._worker, daemon=True, name="notif-worker")
        self._worker_thread.start()
        logger.info("Notification manager started")

    def stop(self):
        """Stop notification worker."""
        self._running = False
        if self._worker_thread:
            self._worker_thread.join(timeout=5)
        logger.info("Notification manager stopped")

    def send(self, level: NotificationLevel, event_type: str, title: str,
             content: str, force: bool = False):
        """Queue a notification for async sending.

        Args:
            level: Notification severity level
            event_type: Event type for rate limiting
            title: Short title
            content: Full content (supports Markdown for DingTalk/Feishu)
            force: Skip rate limiting (for urgent notifications)
        """
        # Rate limiting (skip for urgent)
        if not force and level != NotificationLevel.URGENT:
            last_send = self._rate_limiter.get(event_type, 0)
            min_interval = self._config.get("notification.rate_limit_seconds", 10)
            if time.time() - last_send < min_interval:
                logger.debug(f"Notification rate-limited: {event_type}")
                return

        notif = {
            "level": level.value,
            "event_type": event_type,
            "title": title,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "force": force,
        }

        try:
            self._queue.put_nowait(notif)
            self._rate_limiter[event_type] = time.time()
        except queue.Full:
            logger.warning("Notification queue full, dropping message")

    def _worker(self):
        """Worker thread: process notification queue."""
        while self._running:
            try:
                notif = self._queue.get(timeout=1)
            except queue.Empty:
                continue

            level = notif["level"]
            channels = self._get_channels_for_level(level)

            for channel in channels:
                handler = self._send_handlers.get(channel)
                if handler:
                    success = False
                    for attempt in range(3):
                        try:
                            success = handler(notif)
                            if success:
                                break
                        except Exception as e:
                            logger.error(f"Notification send error (attempt {attempt+1}): {e}")
                        # Exponential backoff: 5s, 15s, 30s
                        if attempt < 2:
                            time.sleep([5, 15][attempt])

                    if not success:
                        logger.error(f"Notification failed after 3 attempts: {notif['title']}")
                        # Save to DB as fallback
                        self._save_failed_notification(notif, channel)

    def _get_channels_for_level(self, level: str) -> list:
        """Determine which channels to use for a notification level."""
        if level == "urgent":
            # Dual channel: primary + backup
            primary = self._config.get("notification.primary_channel", "dingtalk")
            backup = self._config.get("notification.backup_channel", "local")
            return [primary, backup]
        elif level == "attention":
            return [self._config.get("notification.primary_channel", "dingtalk")]
        elif level == "info":
            return [self._config.get("notification.primary_channel", "dingtalk")]
        else:  # routine
            return ["local"]  # Only log locally

    def _send_dingtalk(self, notif: dict) -> bool:
        """Send to DingTalk/Feishu webhook."""
        webhook = self._config.get("notification.dingtalk.webhook", "")
        if not webhook:
            logger.debug("DingTalk webhook not configured")
            return False
        if not validate_url(webhook):
            logger.error(f"Invalid webhook URL: {mask_webhook_url(webhook)}")
            return False

        level_emoji = {"urgent": "🔴", "attention": "🟡", "info": "🔵", "routine": "🟢"}
        emoji = level_emoji.get(notif["level"], "⚪")

        payload = {
            "msgtype": "markdown",
            "markdown": {
                "title": f"{emoji} {notif['title']}",
                "text": f"## {emoji} {notif['title']}\n\n"
                        f"**时间**: {notif['timestamp']}\n\n"
                        f"{notif['content']}\n\n"
                        f"---\n*QuantFlow V2.0*"
            }
        }

        try:
            resp = requests.post(webhook, json=payload, timeout=10)
            result = resp.json()
            if result.get("errcode") == 0:
                logger.info(f"DingTalk notification sent: {notif['title']}")
                return True
            else:
                logger.error(f"DingTalk error: {result}")
                return False
        except Exception as e:
            logger.error(f"DingTalk send failed: {e}")
            return False

    def _send_feishu(self, notif: dict) -> bool:
        """Send to Feishu webhook."""
        webhook = self._config.get("notification.feishu.webhook", "")
        if not webhook:
            return False
        if not validate_url(webhook):
            return False

        payload = {
            "msg_type": "interactive",
            "card": {
                "header": {
                    "title": {"content": notif["title"], "tag": "plain_text"},
                    "template": "red" if notif["level"] == "urgent" else "blue",
                },
                "elements": [{
                    "tag": "div",
                    "text": {"content": notif["content"], "tag": "lark_md"},
                }],
            }
        }

        try:
            resp = requests.post(webhook, json=payload, timeout=10)
            result = resp.json()
            if result.get("code") == 0:
                logger.info(f"Feishu notification sent: {notif['title']}")
                return True
            else:
                logger.error(f"Feishu error: {result}")
                return False
        except Exception as e:
            logger.error(f"Feishu send failed: {e}")
            return False

    def _send_wechat(self, notif: dict) -> bool:
        """Send via PushPlus to WeChat."""
        token = self._config.get("notification.wechat.token", "")
        if not token:
            return False

        url = f"http://www.pushplus.plus/send?token={token}"
        payload = {
            "title": notif["title"],
            "content": notif["content"],
            "template": "txt",
        }

        try:
            resp = requests.post(url, json=payload, timeout=10)
            result = resp.json()
            if result.get("code") == 200:
                logger.info(f"WeChat notification sent: {notif['title']}")
                return True
            else:
                logger.error(f"WeChat error: {result}")
                return False
        except Exception as e:
            logger.error(f"WeChat send failed: {e}")
            return False

    def _send_local(self, notif: dict) -> bool:
        """Save notification to local log and database."""
        logger.info(f"[NOTIFICATION] {notif['level'].upper()}: {notif['title']} - {notif['content'][:100]}")
        try:
            from core.db import get_db
            db = get_db()
            db.insert_notification(
                channel="local",
                level=notif["level"],
                event_type=notif["event_type"],
                title=notif["title"],
                content=notif["content"],
            )
        except Exception as e:
            logger.error(f"Failed to save notification to DB: {e}")
        return True

    def _save_failed_notification(self, notif: dict, channel: str):
        """Save failed notification to database for later retry."""
        try:
            from core.db import get_db
            db = get_db()
            db.insert_notification(
                channel=channel,
                level=notif["level"],
                event_type=notif["event_type"],
                title=notif["title"],
                content=notif["content"],
            )
        except Exception:
            logger.error(f"Failed to save notification fallback: {notif['title']}")
