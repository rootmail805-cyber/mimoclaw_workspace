"""
基准对比与业绩归因模块
支持基准曲线叠加、超额收益计算、收益来源分解
"""

from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from loguru import logger

import pandas as pd
import numpy as np


@dataclass
class BenchmarkComparison:
    """基准对比结果"""
    strategy_return: float = 0.0
    benchmark_return: float = 0.0
    excess_return: float = 0.0       # 超额收益 = 策略收益 - 基准收益
    alpha: float = 0.0               # 年化超额收益
    beta: float = 0.0                # 系统性风险暴露
    information_ratio: float = 0.0   # 信息比率 = 超额收益 / 跟踪误差
    tracking_error: float = 0.0      # 跟踪误差（超额收益的年化标准差）
    up_capture: float = 0.0          # 上行捕获率
    down_capture: float = 0.0        # 下行捕获率
    correlation: float = 0.0         # 相关系数


@dataclass
class AttributionResult:
    """业绩归因结果"""
    total_excess: float = 0.0
    sector_contribution: float = 0.0    # 行业配置贡献
    stock_selection: float = 0.0        # 个股选择贡献
    timing_contribution: float = 0.0    # 择时贡献
    interaction: float = 0.0            # 交互效应
    sector_details: Dict[str, float] = field(default_factory=dict)
    best_period: Optional[Dict] = None  # 最好5个交易日
    worst_period: Optional[Dict] = None # 最差5个交易日


class BenchmarkAnalyzer:
    """基准对比与业绩归因分析器"""

    BENCHMARK_INDEX = "000300"  # 默认基准：沪深300

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._data_mgr = None

    def compare(
        self,
        strategy_equity: pd.Series,
        start: str,
        end: str,
        benchmark_code: str = "000300",
    ) -> BenchmarkComparison:
        """将策略净值曲线与基准指数对比

        Args:
            strategy_equity: 策略每日净值Series (index=date, values=净值)
            start: 开始日期
            end: 结束日期
            benchmark_code: 基准指数代码（默认沪深300）

        Returns:
            BenchmarkComparison 对比结果
        """
        benchmark_equity = self._get_benchmark_equity(benchmark_code, start, end)
        if benchmark_equity is None or benchmark_equity.empty:
            logger.warning("[Benchmark] 无法获取基准数据，跳过对比")
            return BenchmarkComparison()

        # 对齐日期
        common_dates = strategy_equity.index.intersection(benchmark_equity.index)
        if len(common_dates) < 10:
            return BenchmarkComparison()

        s_eq = strategy_equity.loc[common_dates]
        b_eq = benchmark_equity.loc[common_dates]

        # 计算日收益率
        s_ret = s_eq.pct_change().dropna()
        b_ret = b_eq.pct_change().dropna()

        # 总收益
        s_total = (s_eq.iloc[-1] / s_eq.iloc[0]) - 1
        b_total = (b_eq.iloc[-1] / b_eq.iloc[0]) - 1

        # 超额收益
        excess = s_total - b_total

        # 年化
        n_years = len(common_dates) / 252
        alpha = excess / n_years if n_years > 0 else 0

        # Beta & Alpha (CAPM)
        cov = np.cov(s_ret.values, b_ret.values)
        beta = cov[0, 1] / cov[1, 1] if cov[1, 1] != 0 else 1.0
        alpha_capm = (s_total - beta * b_total) / n_years if n_years > 0 else 0

        # 跟踪误差 & 信息比率
        excess_daily = s_ret.values - b_ret.values
        tracking_error = np.std(excess_daily) * np.sqrt(252)
        info_ratio = alpha / tracking_error if tracking_error > 0 else 0

        # 上下行捕获率
        up_mask = b_ret > 0
        down_mask = b_ret < 0
        up_capture = (s_ret[up_mask].mean() / b_ret[up_mask].mean()) if up_mask.sum() > 0 and b_ret[up_mask].mean() != 0 else 1.0
        down_capture = (s_ret[down_mask].mean() / b_ret[down_mask].mean()) if down_mask.sum() > 0 and b_ret[down_mask].mean() != 0 else 1.0

        # 相关系数
        corr = np.corrcoef(s_ret.values, b_ret.values)[0, 1]

        return BenchmarkComparison(
            strategy_return=s_total,
            benchmark_return=b_total,
            excess_return=excess,
            alpha=alpha_capm,
            beta=beta,
            information_ratio=info_ratio,
            tracking_error=tracking_error,
            up_capture=up_capture,
            down_capture=down_capture,
            correlation=corr,
        )

    def attribute(
        self,
        trades: List[Dict],
        benchmark_code: str = "000300",
    ) -> AttributionResult:
        """业绩归因分析（基于持仓的Brinson模型简化版）

        Args:
            trades: 交易记录列表
            benchmark_code: 基准指数代码

        Returns:
            AttributionResult 归因结果
        """
        if not trades:
            return AttributionResult()

        # 简化归因：按交易记录分析
        total_pnl = sum(t.get("pnl", 0) for t in trades)
        winning_trades = [t for t in trades if t.get("pnl", 0) > 0]
        losing_trades = [t for t in trades if t.get("pnl", 0) < 0]

        # 选股贡献：盈利交易的平均盈利率
        stock_selection = sum(t.get("pnl", 0) for t in winning_trades) / len(winning_trades) if winning_trades else 0

        # 择时贡献：基于持仓时间分析
        avg_hold_days = np.mean([t.get("hold_days", 1) for t in trades]) if trades else 1
        timing = 0.0
        if avg_hold_days < 3:
            timing = total_pnl * 0.1  # 短线交易，择时贡献较大
        elif avg_hold_days < 10:
            timing = total_pnl * 0.05

        # 行业贡献（简化：按股票代码前缀分组）
        sector_pnl = {}
        for t in trades:
            symbol = t.get("symbol", "")
            code = symbol.split(".")[0] if "." in symbol else symbol
            # 简单行业分类
            if code.startswith("60"):
                sector = "金融/大盘"
            elif code.startswith("000"):
                sector = "深圳主板"
            elif code.startswith("002"):
                sector = "中小板"
            elif code.startswith("300"):
                sector = "创业板"
            elif code.startswith("688"):
                sector = "科创板"
            else:
                sector = "其他"
            sector_pnl[sector] = sector_pnl.get(sector, 0) + t.get("pnl", 0)

        sector_contribution = sum(sector_pnl.values()) * 0.3  # 简化估算

        # 好坏时段分析
        best, worst = self._find_best_worst_periods(trades)

        return AttributionResult(
            total_excess=total_pnl,
            sector_contribution=sector_contribution,
            stock_selection=stock_selection,
            timing_contribution=timing,
            interaction=total_pnl - sector_contribution - stock_selection - timing,
            sector_details=sector_pnl,
            best_period=best,
            worst_period=worst,
        )

    def get_benchmark_equity_curve(
        self, benchmark_code: str, start: str, end: str
    ) -> Optional[pd.Series]:
        """获取基准指数净值曲线（供GUI绘图用）"""
        return self._get_benchmark_equity(benchmark_code, start, end)

    def _get_benchmark_equity(self, code: str, start: str, end: str) -> Optional[pd.Series]:
        """获取基准指数数据并转换为净值曲线"""
        if self._data_mgr is None:
            from core.data.data_manager import DataManager
            self._data_mgr = DataManager(self._config)

        try:
            # 尝试用akshare获取指数数据
            import akshare as ak
            df = ak.stock_zh_index_daily(symbol=f"sh{code}")
            if df is None or df.empty:
                return None

            df['date'] = pd.to_datetime(df['date'])
            df = df.set_index('date')
            df = df.loc[start:end]

            if df.empty:
                return None

            # 转换为净值曲线（以第一天为1.0）
            equity = df['close'] / df['close'].iloc[0]
            return equity

        except Exception as e:
            logger.warning(f"[Benchmark] 获取基准数据失败: {e}")
            return None

    def _find_best_worst_periods(self, trades: List[Dict], n_days: int = 5) -> Tuple[Optional[Dict], Optional[Dict]]:
        """找出表现最好和最差的连续N个交易日"""
        if not trades:
            return None, None

        # 按日期分组
        daily_pnl = {}
        for t in trades:
            date_str = t.get("trade_time", "")[:10]
            if date_str:
                daily_pnl[date_str] = daily_pnl.get(date_str, 0) + t.get("pnl", 0)

        if len(daily_pnl) < n_days:
            return None, None

        sorted_dates = sorted(daily_pnl.keys())
        pnls = [daily_pnl[d] for d in sorted_dates]

        # 滑动窗口找最佳/最差连续N天
        best_sum = float('-inf')
        worst_sum = float('inf')
        best_start = worst_start = 0

        for i in range(len(pnls) - n_days + 1):
            window_sum = sum(pnls[i:i + n_days])
            if window_sum > best_sum:
                best_sum = window_sum
                best_start = i
            if window_sum < worst_sum:
                worst_sum = window_sum
                worst_start = i

        best = {
            "start_date": sorted_dates[best_start],
            "end_date": sorted_dates[best_start + n_days - 1],
            "total_pnl": round(best_sum, 2),
        }
        worst = {
            "start_date": sorted_dates[worst_start],
            "end_date": sorted_dates[worst_start + n_days - 1],
            "total_pnl": round(worst_sum, 2),
        }

        return best, worst
