"""
策略失效预警（漂移检测）
自动监控策略表现，检测统计学上的显著变化并发出预警
"""

from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime, date, timedelta
from enum import Enum
from loguru import logger

import numpy as np


class AlertLevel(Enum):
    """预警级别"""
    INFO = "info"
    WARNING = "warning"    # 黄色预警
    CRITICAL = "critical"  # 红色预警


class AlertType(Enum):
    """预警类型"""
    CONSECUTIVE_LOSS = "consecutive_loss"        # 连续亏损
    RETURN_DEVIATION = "return_deviation"        # 收益偏离
    DRAWDOWN_BREACH = "drawdown_breach"          # 回撤突破
    VOLATILITY_SPIKE = "volatility_spike"        # 波动率飙升
    WIN_RATE_DROP = "win_rate_drop"              # 胜率下降


@dataclass
class DriftAlert:
    """漂移预警"""
    alert_time: str
    alert_type: AlertType
    alert_level: AlertLevel
    strategy_id: str
    strategy_name: str
    symbol: str
    title: str
    message: str
    current_value: float
    threshold: float
    suggestion: str
    acknowledged: bool = False


class DriftDetector:
    """策略漂移检测器

    监控已部署策略的近期表现，当策略行为发生统计学上的显著变化时发出预警。
    """

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._alert_history: List[DriftAlert] = []
        self._notifier = None
        self._max_history = 100

        # 检测参数
        self._consecutive_loss_threshold = 5       # 连续亏损笔数
        self._return_deviation_window = 20         # 近N日收益率
        self._return_deviation_baseline = 120      # 历史基准窗口
        self._return_deviation_std = 2.0           # 偏离标准差倍数
        self._drawdown_breach_pct = 0.8            # 回撤突破比例（历史最大回撤的80%）
        self._volatility_spike_std = 2.0           # 波动率飙升阈值
        self._win_rate_drop_threshold = 0.15       # 胜率下降阈值（15个百分点）

    def set_notifier(self, notifier):
        """设置通知管理器"""
        self._notifier = notifier

    def check_all(
        self,
        strategy_id: str,
        strategy_name: str,
        symbol: str,
        recent_trades: List[Dict],
        daily_returns: List[float],
        historical_max_drawdown: float = 0.1,
    ) -> List[DriftAlert]:
        """执行所有漂移检测

        Args:
            strategy_id: 策略ID
            strategy_name: 策略名称
            symbol: 股票代码
            recent_trades: 最近的交易记录
            daily_returns: 最近的每日收益率序列
            historical_max_drawdown: 回测历史最大回撤（如0.1表示10%）

        Returns:
            触发的预警列表
        """
        alerts = []

        # 1. 连续亏损检测
        alert = self._check_consecutive_loss(strategy_id, strategy_name, symbol, recent_trades)
        if alert:
            alerts.append(alert)

        # 2. 收益偏离检测
        alert = self._check_return_deviation(strategy_id, strategy_name, symbol, daily_returns)
        if alert:
            alerts.append(alert)

        # 3. 回撤突破检测
        alert = self._check_drawdown_breach(strategy_id, strategy_name, symbol, daily_returns, historical_max_drawdown)
        if alert:
            alerts.append(alert)

        # 4. 波动率飙升检测
        alert = self._check_volatility_spike(strategy_id, strategy_name, symbol, daily_returns)
        if alert:
            alerts.append(alert)

        # 5. 胜率下降检测
        alert = self._check_win_rate_drop(strategy_id, strategy_name, symbol, recent_trades, daily_returns)
        if alert:
            alerts.append(alert)

        # 保存并推送
        for a in alerts:
            self._alert_history.append(a)
            if len(self._alert_history) > self._max_history:
                self._alert_history = self._alert_history[-self._max_history:]
            self._push_alert(a)

        return alerts

    def _check_consecutive_loss(self, sid, sname, symbol, trades) -> Optional[DriftAlert]:
        """连续亏损检测"""
        if not trades or len(trades) < self._consecutive_loss_threshold:
            return None

        # 检查最近N笔交易是否全部亏损
        recent = trades[-self._consecutive_loss_threshold:]
        all_loss = all(t.get("pnl", 0) < 0 for t in recent)

        if all_loss:
            total_loss = sum(t.get("pnl", 0) for t in recent)
            return DriftAlert(
                alert_time=datetime.now().isoformat(),
                alert_type=AlertType.CONSECUTIVE_LOSS,
                alert_level=AlertLevel.WARNING,
                strategy_id=sid,
                strategy_name=sname,
                symbol=symbol,
                title="连续亏损预警",
                message=f"策略{ sname}在{symbol}上出现连续{self._consecutive_loss_threshold}笔亏损交易，累计亏损{total_loss:,.0f}元。近期交易连续亏损，请关注策略是否适应当前市场环境。",
                current_value=self._consecutive_loss_threshold,
                threshold=self._consecutive_loss_threshold,
                suggestion="建议检查策略是否适应当前市场风格，或暂停策略观察。",
            )
        return None

    def _check_return_deviation(self, sid, sname, symbol, daily_returns) -> Optional[DriftAlert]:
        """收益偏离检测"""
        if not daily_returns or len(daily_returns) < self._return_deviation_baseline:
            return None

        recent = daily_returns[-self._return_deviation_window:]
        baseline = daily_returns[-self._return_deviation_baseline:]

        recent_mean = np.mean(recent)
        baseline_mean = np.mean(baseline)
        baseline_std = np.std(baseline)

        threshold = baseline_mean - self._return_deviation_std * baseline_std

        if recent_mean < threshold and baseline_std > 0:
            deviation = (recent_mean - baseline_mean) / baseline_std
            return DriftAlert(
                alert_time=datetime.now().isoformat(),
                alert_type=AlertType.RETURN_DEVIATION,
                alert_level=AlertLevel.CRITICAL,
                strategy_id=sid,
                strategy_name=sname,
                symbol=symbol,
                title="收益严重偏离预警",
                message=f"策略{sname}近{self._return_deviation_window}日平均收益率({recent_mean:.4%})显著低于历史均值({baseline_mean:.4%})，偏离{deviation:.1f}个标准差。策略可能已不适应当前市场环境。",
                current_value=recent_mean,
                threshold=threshold,
                suggestion="强烈建议暂停策略，切换至保守型策略或降低仓位至50%以下。",
            )
        return None

    def _check_drawdown_breach(self, sid, sname, symbol, daily_returns, hist_max_dd) -> Optional[DriftAlert]:
        """回撤突破检测"""
        if not daily_returns or hist_max_dd <= 0:
            return None

        # 计算当前回撤
        equity = np.cumprod(1 + np.array(daily_returns))
        peak = np.maximum.accumulate(equity)
        drawdown = (peak - equity) / peak
        current_dd = drawdown[-1] if len(drawdown) > 0 else 0

        threshold = hist_max_dd * self._drawdown_breach_pct

        if current_dd >= threshold:
            return DriftAlert(
                alert_time=datetime.now().isoformat(),
                alert_type=AlertType.DRAWDOWN_BREACH,
                alert_level=AlertLevel.CRITICAL,
                strategy_id=sid,
                strategy_name=sname,
                symbol=symbol,
                title="回撤接近历史极值",
                message=f"策略{sname}当前回撤({current_dd:.1%})已达到历史最大回撤({hist_max_dd:.1%})的{current_dd / hist_max_dd * 100:.0f}%。回撤接近历史极值，建议检查策略逻辑是否仍然有效。",
                current_value=current_dd,
                threshold=threshold,
                suggestion="建议降低仓位或暂停策略，等待市场环境改善。",
            )
        return None

    def _check_volatility_spike(self, sid, sname, symbol, daily_returns) -> Optional[DriftAlert]:
        """波动率飙升检测"""
        if not daily_returns or len(daily_returns) < 60:
            return None

        recent_vol = np.std(daily_returns[-20:]) * np.sqrt(252)
        baseline_vol = np.std(daily_returns[-60:]) * np.sqrt(252)

        if baseline_vol > 0 and recent_vol > baseline_vol + self._volatility_spike_std * np.std(daily_returns[-60:]) * np.sqrt(252):
            return DriftAlert(
                alert_time=datetime.now().isoformat(),
                alert_type=AlertType.VOLATILITY_SPIKE,
                alert_level=AlertLevel.WARNING,
                strategy_id=sid,
                strategy_name=sname,
                symbol=symbol,
                title="波动率异常升高",
                message=f"策略{sname}近20日年化波动率({recent_vol:.1%})显著高于历史均值({baseline_vol:.1%})。市场波动加剧，策略风险上升。",
                current_value=recent_vol,
                threshold=baseline_vol,
                suggestion="建议降低仓位，增加止损保护。",
            )
        return None

    def _check_win_rate_drop(self, sid, sname, symbol, recent_trades, daily_returns) -> Optional[DriftAlert]:
        """胜率下降检测"""
        if not recent_trades or len(recent_trades) < 20:
            return None

        # 近期胜率
        recent_wins = len([t for t in recent_trades[-20:] if t.get("pnl", 0) > 0])
        recent_wr = recent_wins / min(len(recent_trades), 20)

        # 历史胜率
        all_wins = len([t for t in recent_trades if t.get("pnl", 0) > 0])
        hist_wr = all_wins / len(recent_trades) if recent_trades else 0

        if hist_wr - recent_wr > self._win_rate_drop_threshold:
            return DriftAlert(
                alert_time=datetime.now().isoformat(),
                alert_type=AlertType.WIN_RATE_DROP,
                alert_level=AlertLevel.WARNING,
                strategy_id=sid,
                strategy_name=sname,
                symbol=symbol,
                title="胜率显著下降",
                message=f"策略{sname}近期胜率({recent_wr:.0%})较历史胜率({hist_wr:.0%})下降{(hist_wr - recent_wr) * 100:.0f}个百分点。策略有效性可能在降低。",
                current_value=recent_wr,
                threshold=hist_wr - self._win_rate_drop_threshold,
                suggestion="建议观察后续交易表现，若持续下降考虑切换策略。",
            )
        return None

    def _push_alert(self, alert: DriftAlert):
        """推送预警通知"""
        if self._notifier is None:
            return

        level_emoji = {"info": "ℹ️", "warning": "⚠️", "critical": "🚨"}
        emoji = level_emoji.get(alert.alert_level.value, "⚠️")

        message = (
            f"{emoji} {alert.title}\n\n"
            f"策略: {alert.strategy_name}\n"
            f"标的: {alert.symbol}\n\n"
            f"{alert.message}\n\n"
            f"💡 建议: {alert.suggestion}"
        )

        try:
            self._notifier.send(title=alert.title, message=message)
        except Exception as e:
            logger.error(f"[Drift] 推送预警失败: {e}")

    def get_alert_history(self, limit: int = 30) -> List[DriftAlert]:
        """获取预警历史"""
        return self._alert_history[-limit:]

    def acknowledge(self, index: int):
        """确认预警"""
        if 0 <= index < len(self._alert_history):
            self._alert_history[index].acknowledged = True
