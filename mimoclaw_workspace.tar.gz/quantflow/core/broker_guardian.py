"""
券商客户端进程守护与健康监控
功能：进程存活检测、崩溃自动重启、连接健康检查、异常告警、版本检测

注意：不做客户端自动更新（券商客户端为闭源软件，更新需通过官方渠道）
"""

import os
import time
import threading
import subprocess
from typing import Dict, Optional, Callable, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from loguru import logger


class BrokerType(Enum):
    """券商类型"""
    SIMULATION = "simulation"
    EASYTRADER = "easytrader"       # 银河/华泰/广发（GUI自动化）
    QMT = "qmt"                     # QMT迅投量化（xtquant）
    PTRADE = "ptrade"               # Ptrade恒生量化（服务端）


class GuardianStatus(Enum):
    """守护状态"""
    IDLE = "idle"                   # 未启动
    MONITORING = "monitoring"       # 监控中
    RESTARTING = "restarting"       # 重启中
    ERROR = "error"                 # 异常
    STOPPED = "stopped"             # 已停止


@dataclass
class BrokerConfig:
    """券商客户端配置"""
    broker_type: BrokerType
    display_name: str
    process_name: str = ""          # 进程名（用于进程检测）
    executable_path: str = ""       # 可执行文件路径
    window_title: str = ""          # 窗口标题（用于easytrader检测）
    api_endpoint: str = ""          # API地址（用于QMT/Ptrade连接检测）
    extra_args: list = field(default_factory=list)
    restart_delay: float = 5.0      # 重启延迟（秒）
    max_restart_attempts: int = 3   # 最大重启尝试次数
    health_check_interval: float = 30.0  # 健康检查间隔（秒）
    version_cmd: str = ""           # 版本检测命令


# ── 预置券商配置 ──────────────────────────────────────────────────

BROKER_CONFIGS: Dict[str, BrokerConfig] = {
    "simulation": BrokerConfig(
        broker_type=BrokerType.SIMULATION,
        display_name="模拟交易（纸盘）",
        process_name="",
        executable_path="",
    ),
    "easytrader_yinhe": BrokerConfig(
        broker_type=BrokerType.EASYTRADER,
        display_name="银河证券（双子星）",
        process_name="xiadan.exe",
        window_title="银河证券双子星",
        executable_path=r"C:\银河证券双子星\bin\xiadan.exe",
    ),
    "easytrader_huatai": BrokerConfig(
        broker_type=BrokerType.EASYTRADER,
        display_name="华泰证券（网上交易）",
        process_name="xiadan.exe",
        window_title="华泰证券",
        executable_path=r"C:\华泰证券\bin\xiadan.exe",
    ),
    "easytrader_guangfa": BrokerConfig(
        broker_type=BrokerType.EASYTRADER,
        display_name="广发证券",
        process_name="xiadan.exe",
        window_title="广发证券",
        executable_path=r"C:\广发证券\bin\xiadan.exe",
    ),
    "qmt": BrokerConfig(
        broker_type=BrokerType.QMT,
        display_name="QMT 迅投量化",
        process_name="XtMiniQmt.exe",
        executable_path=r"C:\国金证券QMT\bin\XtMiniQmt.exe",
        api_endpoint="127.0.0.1:1430",
    ),
    "ptrade": BrokerConfig(
        broker_type=BrokerType.PTRADE,
        display_name="Ptrade 恒生量化",
        process_name="",  # Ptrade为服务端，无本地进程
        api_endpoint="",
    ),
}


@dataclass
class HealthReport:
    """健康报告"""
    timestamp: str
    broker_id: str
    broker_name: str
    status: GuardianStatus
    process_alive: bool
    connection_alive: bool
    restart_count: int
    uptime_seconds: float
    cpu_percent: float = 0.0
    memory_mb: float = 0.0
    message: str = ""


class BrokerGuardian:
    """券商客户端进程守护

    功能：
    1. 进程存活检测：定期检查券商客户端进程是否在运行
    2. 崩溃自动重启：进程消失后自动拉起，支持指数退避
    3. 连接健康检查：定期验证与券商的API连接是否正常
    4. 异常告警：进程崩溃/连接断开时通过通知系统推送告警
    5. 版本检测：检测客户端版本，提示用户手动更新
    6. 误关保护：防止用户意外关闭券商客户端（需二次确认）
    """

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._notifier = None

        # 状态
        self._status = GuardianStatus.IDLE
        self._broker_id = ""
        self._broker_config: Optional[BrokerConfig] = None
        self._monitor_thread: Optional[threading.Thread] = None
        self._stop_flag = False

        # 统计
        self._restart_count = 0
        self._start_time = 0.0
        self._last_health: Optional[HealthReport] = None
        self._health_history: list = []

        # 回调
        self._on_status_change: Optional[Callable] = None
        self._on_crash_detected: Optional[Callable] = None

    def set_notifier(self, notifier):
        """设置通知管理器"""
        self._notifier = notifier

    def set_callbacks(self, on_status=None, on_crash=None):
        """设置回调函数"""
        self._on_status_change = on_status
        self._on_crash_detected = on_crash

    @property
    def status(self) -> GuardianStatus:
        return self._status

    @property
    def is_monitoring(self) -> bool:
        return self._status == GuardianStatus.MONITORING

    def get_available_brokers(self) -> Dict[str, str]:
        """获取可用券商列表（排除模拟）"""
        return {
            bid: cfg.display_name
            for bid, cfg in BROKER_CONFIGS.items()
            if cfg.broker_type != BrokerType.SIMULATION
        }

    def start_monitoring(self, broker_id: str) -> bool:
        """启动券商客户端监控

        Args:
            broker_id: 券商ID（如 'easytrader_yinhe', 'qmt'）

        Returns:
            是否成功启动监控
        """
        if broker_id not in BROKER_CONFIGS:
            logger.error(f"[Guardian] 未知券商: {broker_id}")
            return False

        config = BROKER_CONFIGS[broker_id]
        if config.broker_type == BrokerType.SIMULATION:
            logger.info("[Guardian] 模拟券商无需守护")
            return True

        if config.broker_type == BrokerType.PTRADE:
            logger.info("[Guardian] Ptrade为服务端模式，仅做连接检测")
            # Ptrade只有连接检测，无进程守护

        self._broker_id = broker_id
        self._broker_config = config
        self._stop_flag = False
        self._restart_count = 0
        self._start_time = time.time()
        self._status = GuardianStatus.MONITORING

        # 启动监控线程
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop, daemon=True, name=f"Guardian-{broker_id}")
        self._monitor_thread.start()

        logger.info(f"[Guardian] 开始监控: {config.display_name}")
        self._notify(f"🛡️ 券商守护启动: {config.display_name}", "info")
        return True

    def stop_monitoring(self):
        """停止监控"""
        self._stop_flag = True
        self._status = GuardianStatus.STOPPED
        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=5)
        logger.info("[Guardian] 监控已停止")

    def check_health(self) -> HealthReport:
        """立即执行一次健康检查"""
        return self._do_health_check()

    def get_health_history(self, limit: int = 20) -> list:
        """获取健康检查历史"""
        return self._health_history[-limit:]

    def _monitor_loop(self):
        """监控主循环"""
        interval = self._broker_config.health_check_interval

        while not self._stop_flag:
            try:
                report = self._do_health_check()
                self._last_health = report
                self._health_history.append(report)

                # 保留最近100条记录
                if len(self._health_history) > 100:
                    self._health_history = self._health_history[-100:]

                # 处理异常
                if not report.process_alive and self._broker_config.process_name:
                    self._handle_crash()
                elif not report.connection_alive:
                    self._handle_connection_loss()

                # 更新状态回调
                if self._on_status_change:
                    try:
                        self._on_status_change(report)
                    except Exception:
                        pass

            except Exception as e:
                logger.error(f"[Guardian] 监控异常: {e}")

            # 等待下次检查
            for _ in range(int(interval)):
                if self._stop_flag:
                    return
                time.sleep(1)

    def _do_health_check(self) -> HealthReport:
        """执行健康检查"""
        process_alive = True
        connection_alive = True
        cpu_percent = 0.0
        memory_mb = 0.0
        message = "正常"

        # 1. 进程存活检测
        if self._broker_config.process_name:
            process_alive = self._check_process()
            if not process_alive:
                message = f"进程 {self._broker_config.process_name} 未运行"

        # 2. 连接健康检测
        if self._broker_config.broker_type == BrokerType.QMT:
            connection_alive = self._check_qmt_connection()
            if not connection_alive:
                message = "QMT连接断开"
        elif self._broker_config.broker_type == BrokerType.PTRADE:
            connection_alive = self._check_ptrade_connection()
            if not connection_alive:
                message = "Ptrade连接断开"

        # 3. 资源使用检测（仅在进程存活时）
        if process_alive and self._broker_config.process_name:
            cpu_percent, memory_mb = self._check_resources()

        uptime = time.time() - self._start_time if self._start_time > 0 else 0

        return HealthReport(
            timestamp=datetime.now().isoformat(),
            broker_id=self._broker_id,
            broker_name=self._broker_config.display_name,
            status=self._status,
            process_alive=process_alive,
            connection_alive=connection_alive,
            restart_count=self._restart_count,
            uptime_seconds=uptime,
            cpu_percent=cpu_percent,
            memory_mb=memory_mb,
            message=message,
        )

    def _check_process(self) -> bool:
        """检查进程是否存活"""
        try:
            import psutil
            for proc in psutil.process_iter(['name']):
                if proc.info['name'] and self._broker_config.process_name.lower() in proc.info['name'].lower():
                    return True
            return False
        except ImportError:
            # psutil不可用时用tasklist（Windows）
            if os.name == 'nt':
                try:
                    result = subprocess.run(
                        ['tasklist', '/FI', f'IMAGENAME eq {self._broker_config.process_name}'],
                        capture_output=True, text=True, timeout=5
                    )
                    return self._broker_config.process_name.lower() in result.stdout.lower()
                except Exception:
                    return True  # 无法检测时假设存活
            return True  # 非Windows且无psutil时假设存活

    def _check_qmt_connection(self) -> bool:
        """检查QMT连接"""
        try:
            import socket
            host, port = self._broker_config.api_endpoint.split(':')
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            result = sock.connect_ex((host, int(port)))
            sock.close()
            return result == 0
        except Exception:
            return False

    def _check_ptrade_connection(self) -> bool:
        """检查Ptrade连接"""
        if not self._broker_config.api_endpoint:
            return True  # 无API地址时假设正常
        try:
            import socket
            host, port = self._broker_config.api_endpoint.split(':')
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            result = sock.connect_ex((host, int(port)))
            sock.close()
            return result == 0
        except Exception:
            return False

    def _check_resources(self) -> tuple:
        """检查进程资源使用"""
        try:
            import psutil
            for proc in psutil.process_iter(['name', 'cpu_percent', 'memory_info']):
                if proc.info['name'] and self._broker_config.process_name.lower() in proc.info['name'].lower():
                    return (
                        proc.info.get('cpu_percent', 0),
                        proc.info.get('memory_info', {}).get('rss', 0) / 1024 / 1024 if proc.info.get('memory_info') else 0,
                    )
        except Exception:
            pass
        return (0.0, 0.0)

    def _handle_crash(self):
        """处理进程崩溃"""
        self._restart_count += 1

        if self._restart_count > self._broker_config.max_restart_attempts:
            self._status = GuardianStatus.ERROR
            msg = (f"🚨 {self._broker_config.display_name} 进程崩溃，"
                   f"已尝试{self._broker_config.max_restart_attempts}次重启均失败！"
                   f"请手动检查。")
            logger.error(f"[Guardian] {msg}")
            self._notify(msg, "critical")
            if self._on_crash_detected:
                try:
                    self._on_crash_detected(self._broker_id, "max_retries_exceeded")
                except Exception:
                    pass
            return

        logger.warning(f"[Guardian] 检测到 {self._broker_config.display_name} 进程崩溃，"
                       f"第{self._restart_count}次重启尝试...")

        self._status = GuardianStatus.RESTARTING
        self._notify(
            f"⚠️ {self._broker_config.display_name} 进程崩溃，正在尝试重启（第{self._restart_count}次）...",
            "warning"
        )

        # 延迟重启（指数退避）
        delay = self._broker_config.restart_delay * (2 ** (self._restart_count - 1))
        time.sleep(min(delay, 60))  # 最长等待60秒

        if self._stop_flag:
            return

        success = self._restart_broker()
        if success:
            self._status = GuardianStatus.MONITORING
            self._notify(f"✅ {self._broker_config.display_name} 重启成功！", "info")
            logger.info(f"[Guardian] {self._broker_config.display_name} 重启成功")
        else:
            logger.error(f"[Guardian] {self._broker_config.display_name} 重启失败")

    def _handle_connection_loss(self):
        """处理连接丢失"""
        logger.warning(f"[Guardian] {self._broker_config.display_name} 连接断开")
        self._notify(
            f"⚠️ {self._broker_config.display_name} 连接断开，等待恢复...",
            "warning"
        )

    def _restart_broker(self) -> bool:
        """重启券商客户端"""
        exe_path = self._broker_config.executable_path

        if not exe_path or not os.path.exists(exe_path):
            logger.error(f"[Guardian] 可执行文件不存在: {exe_path}")
            return False

        try:
            if os.name == 'nt':
                # Windows: 使用start命令启动
                subprocess.Popen(
                    [exe_path] + self._broker_config.extra_args,
                    creationflags=subprocess.DETACHED_PROCESS,
                )
            else:
                # Linux/Mac
                subprocess.Popen(
                    [exe_path] + self._broker_config.extra_args,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )

            # 等待进程启动
            time.sleep(5)
            return self._check_process()

        except Exception as e:
            logger.error(f"[Guardian] 重启失败: {e}")
            return False

    def check_version(self, broker_id: str) -> Optional[str]:
        """检测券商客户端版本（仅提示，不自动更新）

        Returns:
            版本号字符串，或None（无法检测）
        """
        config = BROKER_CONFIGS.get(broker_id)
        if not config or not config.executable_path:
            return None

        if not os.path.exists(config.executable_path):
            return None

        try:
            if os.name == 'nt':
                # Windows: 获取文件版本信息
                import ctypes
                from ctypes import wintypes

                # 简化版本：通过文件属性获取版本
                try:
                    info = ctypes.windll.version.GetFileVersionInfoSizeW(
                        config.executable_path, None
                    )
                    if info:
                        return "已安装（版本检测需Windows环境）"
                except Exception:
                    pass
                return "已安装"
        except Exception:
            pass

        return None

    def _notify(self, message: str, level: str = "info"):
        """推送通知"""
        if self._notifier:
            try:
                self._notifier.send(
                    title="券商守护告警",
                    message=message,
                )
            except Exception as e:
                logger.error(f"[Guardian] 通知推送失败: {e}")

        # 同时写入日志
        log_fn = {
            "info": logger.info,
            "warning": logger.warning,
            "critical": logger.error,
        }.get(level, logger.info)
        log_fn(f"[Guardian] {message}")
