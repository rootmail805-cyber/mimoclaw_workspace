"""
Alert system for QuantFlow.
Sends notifications via DingTalk, WeChat, email, etc.
"""

import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from typing import List, Optional, Dict, Any
from loguru import logger

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


class Alerter:
    """Multi-channel alert system.

    Supported channels:
        - DingTalk webhook
        - Email (SMTP)
        - Console (always available)
    """

    def __init__(self, config):
        self._config = config
        self._enabled = config.get("monitor.alerts.enabled", True)
        self._channels = config.get("monitor.alerts.channels", [])
        self._alert_history: List[Dict[str, Any]] = []

    def send_alert(self, title: str, message: str, level: str = "WARNING") -> None:
        """Send an alert through all configured channels.

        Args:
            title: Alert title.
            message: Alert body.
            level: INFO, WARNING, ERROR, CRITICAL.
        """
        if not self._enabled:
            return

        alert = {
            "title": title,
            "message": message,
            "level": level,
            "timestamp": datetime.now().isoformat(),
        }
        self._alert_history.append(alert)

        # Always log
        log_msg = f"[ALERT][{level}] {title}: {message}"
        if level == "CRITICAL":
            logger.critical(log_msg)
        elif level == "ERROR":
            logger.error(log_msg)
        elif level == "WARNING":
            logger.warning(log_msg)
        else:
            logger.info(log_msg)

        # Send through configured channels
        for channel in self._channels:
            try:
                if channel == "dingtalk":
                    self._send_dingtalk(title, message, level)
                elif channel == "email":
                    self._send_email(title, message, level)
            except Exception as e:
                logger.error(f"Alert send failed via {channel}: {e}")

    def _send_dingtalk(self, title: str, message: str, level: str) -> None:
        """Send alert via DingTalk webhook."""
        if not HAS_REQUESTS:
            logger.warning("requests library not installed, DingTalk alert skipped")
            return

        webhook = self._config.get("monitor.alerts.dingtalk.webhook_url", "")
        if not webhook:
            return

        level_emoji = {
            "INFO": "ℹ️",
            "WARNING": "⚠️",
            "ERROR": "❌",
            "CRITICAL": "🔴",
        }

        payload = {
            "msgtype": "markdown",
            "markdown": {
                "title": f"QuantFlow {level_emoji.get(level, '📢')} {title}",
                "text": (
                    f"## {level_emoji.get(level, '')} {title}\n\n"
                    f"**级别**: {level}\n\n"
                    f"**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                    f"**详情**:\n\n{message}"
                ),
            },
        }

        response = requests.post(webhook, json=payload, timeout=10)
        if response.status_code == 200:
            logger.debug(f"DingTalk alert sent: {title}")
        else:
            logger.error(f"DingTalk alert failed: {response.status_code}")

    def _send_email(self, title: str, message: str, level: str) -> None:
        """Send alert via email."""
        smtp_host = self._config.get("monitor.alerts.email.smtp_host", "")
        if not smtp_host:
            return

        smtp_port = self._config.get("monitor.alerts.email.smtp_port", 465)
        from_addr = self._config.get("monitor.alerts.email.from_addr", "")
        to_addrs = self._config.get("monitor.alerts.email.to_addrs", [])
        password = self._config.get("monitor.alerts.email.password", "")

        if not all([from_addr, to_addrs, password]):
            return

        msg = MIMEMultipart()
        msg["From"] = from_addr
        msg["To"] = ", ".join(to_addrs)
        msg["Subject"] = f"[QuantFlow][{level}] {title}"

        body = f"""
QuantFlow Alert
===============

Level: {level}
Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Title: {title}

{message}
"""
        msg.attach(MIMEText(body, "plain", "utf-8"))

        with smtplib.SMTP_SSL(smtp_host, smtp_port) as server:
            server.login(from_addr, password)
            server.sendmail(from_addr, to_addrs, msg.as_string())

        logger.debug(f"Email alert sent: {title}")

    @property
    def alert_history(self) -> List[Dict[str, Any]]:
        return list(self._alert_history)
