"""
Dashboard for QuantFlow monitoring.
Provides a web-based monitoring interface.
"""

import json
from datetime import datetime
from typing import Dict, Any, Optional
from pathlib import Path
from loguru import logger


class Dashboard:
    """Web-based monitoring dashboard.

    Generates a static HTML dashboard that can be served by any web server
    or opened directly in a browser.
    """

    def __init__(self, port: int = 3000):
        self._port = port
        self._data: Dict[str, Any] = {}

    def update(self, data: Dict[str, Any]) -> None:
        """Update dashboard data."""
        self._data.update(data)
        self._data["last_update"] = datetime.now().isoformat()

    def generate_html(self, output_path: str = "./reports/dashboard.html") -> str:
        """Generate a static HTML dashboard."""
        from pathlib import Path
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>QuantFlow Dashboard</title>
    <meta http-equiv="refresh" content="30">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, "Microsoft YaHei", sans-serif; background: #0f0f23; color: #e0e0e0; }}
        .header {{ background: linear-gradient(135deg, #1a1a2e, #16213e); padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; }}
        .header h1 {{ font-size: 20px; color: #00d4ff; }}
        .header .status {{ padding: 6px 16px; border-radius: 20px; font-size: 13px; }}
        .status-ok {{ background: #00c853; color: white; }}
        .status-warn {{ background: #ff6d00; color: white; }}
        .status-error {{ background: #ff1744; color: white; }}
        .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; padding: 20px; }}
        .card {{ background: #1a1a2e; border-radius: 12px; padding: 20px; border: 1px solid #2a2a4a; }}
        .card h3 {{ font-size: 13px; color: #888; text-transform: uppercase; margin-bottom: 10px; }}
        .card .value {{ font-size: 28px; font-weight: bold; }}
        .positive {{ color: #00e676; }}
        .negative {{ color: #ff5252; }}
        .neutral {{ color: #40c4ff; }}
        .footer {{ text-align: center; padding: 20px; color: #555; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>⚡ QuantFlow Dashboard</h1>
        <span class="status status-ok">● 系统运行中</span>
    </div>

    <div class="grid">
        <div class="card">
            <h3>总资产</h3>
            <div class="value neutral">¥{self._data.get('total_assets', 0):,.2f}</div>
        </div>
        <div class="card">
            <h3>可用资金</h3>
            <div class="value">¥{self._data.get('cash', 0):,.2f}</div>
        </div>
        <div class="card">
            <h3>持仓市值</h3>
            <div class="value">¥{self._data.get('market_value', 0):,.2f}</div>
        </div>
        <div class="card">
            <h3>当日盈亏</h3>
            <div class="value {'positive' if self._data.get('daily_pnl',0)>=0 else 'negative'}">
                ¥{self._data.get('daily_pnl', 0):+,.2f}
            </div>
        </div>
        <div class="card">
            <h3>未实现盈亏</h3>
            <div class="value {'positive' if self._data.get('unrealized_pnl',0)>=0 else 'negative'}">
                ¥{self._data.get('unrealized_pnl', 0):+,.2f}
            </div>
        </div>
        <div class="card">
            <h3>最大回撤</h3>
            <div class="value negative">{self._data.get('max_drawdown', 0):.2%}</div>
        </div>
        <div class="card">
            <h3>今日交易笔数</h3>
            <div class="value neutral">{self._data.get('trades_today', 0)}</div>
        </div>
        <div class="card">
            <h3>活跃订单</h3>
            <div class="value">{self._data.get('active_orders', 0)}</div>
        </div>
        <div class="card">
            <h3>Kill Switch</h3>
            <div class="value {'negative' if self._data.get('kill_switch') else 'positive'}">
                {'🔴 已触发' if self._data.get('kill_switch') else '🟢 正常'}
            </div>
        </div>
        <div class="card">
            <h3>策略数量</h3>
            <div class="value neutral">{self._data.get('strategy_count', 0)}</div>
        </div>
    </div>

    <div class="footer">
        QuantFlow v1.0.0 | 最后更新: {self._data.get('last_update', 'N/A')}
    </div>
</body>
</html>"""

        with open(path, "w", encoding="utf-8") as f:
            f.write(html)

        logger.debug(f"Dashboard updated: {path}")
        return str(path)
