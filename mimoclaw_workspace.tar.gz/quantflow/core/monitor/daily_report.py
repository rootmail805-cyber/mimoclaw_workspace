"""
⚠️ DEPRECATED - 此模块已废弃，未被系统任何组件引用。
保留代码供未来参考，但不应在新代码中使用。
如需使用其中的功能，请先集成到 GUI 和业务流程中。
"""

"""
Daily trading report generator.
Generates structured reports at 15:30 each trading day.
"""

import json
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Dict, Any, List
from loguru import logger

from ..db import get_db
from ..notification import NotificationManager, NotificationLevel
from utils.life_translation import LifeTranslator


class DailyReportGenerator:
    """Generate and manage daily trading reports."""

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._db = get_db()
        self._translator = LifeTranslator(self._config)
        self._report_dir = Path("./reports/daily")
        self._report_dir.mkdir(parents=True, exist_ok=True)

    def generate(self, target_date: str = None) -> Dict[str, Any]:
        """Generate a daily report for the given date.

        Args:
            target_date: Date string (YYYY-MM-DD), defaults to today

        Returns:
            Report data dict
        """
        if target_date is None:
            target_date = date.today().isoformat()

        # Gather data
        trades = self._db.get_trades(start=target_date + "T00:00:00",
                                      end=target_date + "T23:59:59",
                                      limit=1000)
        daily_pnl = self._db.get_daily_pnl(start=target_date, end=target_date, limit=1)
        risk_events = self._db.get_risk_events(limit=20)
        running_strategies = self._db.get_running_strategies()

        # Calculate metrics
        total_pnl = sum(t.get("pnl", 0) for t in trades)
        total_commission = sum(t.get("commission", 0) for t in trades)
        total_tax = sum(t.get("tax", 0) for t in trades)
        trade_count = len(trades)
        win_count = sum(1 for t in trades if t.get("pnl", 0) > 0)
        loss_count = sum(1 for t in trades if t.get("pnl", 0) < 0)

        # Life translation
        life_text = self._translator.translate(total_pnl)

        report = {
            "date": target_date,
            "generated_at": datetime.now().isoformat(),
            "summary": {
                "total_pnl": round(total_pnl, 2),
                "total_commission": round(total_commission, 2),
                "total_tax": round(total_tax, 2),
                "trade_count": trade_count,
                "win_count": win_count,
                "loss_count": loss_count,
                "win_rate": round(win_count / trade_count * 100, 1) if trade_count > 0 else 0,
                "life_translation": life_text,
            },
            "trades": trades,
            "strategies": running_strategies,
            "risk_events": [e for e in risk_events
                           if e.get("event_time", "").startswith(target_date)],
        }

        # Save to files
        self._save_json(report, target_date)
        self._save_html(report, target_date)

        return report

    def _save_json(self, report: dict, target_date: str):
        """Save report as JSON."""
        path = self._report_dir / f"{target_date}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2, default=str)

    def _save_html(self, report: dict, target_date: str):
        """Save report as HTML."""
        s = report["summary"]
        pnl_color = "#27AE60" if s["total_pnl"] >= 0 else "#E74C3C"
        pnl_sign = "+" if s["total_pnl"] >= 0 else ""

        trades_html = ""
        for t in report.get("trades", [])[:20]:
            direction = t.get("direction", "")
            dir_color = "#00ff88" if direction == "BUY" else "#ef4444"
            pnl = t.get("pnl", 0)
            pnl_c = "#27AE60" if pnl >= 0 else "#E74C3C"
            trades_html += f"""
            <tr>
                <td>{t.get('trade_time', '')[:19]}</td>
                <td style="color:{dir_color}">{direction}</td>
                <td>{t.get('symbol', '')}</td>
                <td>{t.get('quantity', 0)}</td>
                <td>¥{t.get('price', 0):.2f}</td>
                <td style="color:{pnl_c}">{pnl:+.2f}</td>
            </tr>"""

        html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<title>QuantFlow 每日简报 {target_date}</title>
<style>
body {{ background: #0a0e14; color: #e0e0e0; font-family: 'Consolas', monospace; padding: 20px; }}
.card {{ background: #131d27; border-radius: 8px; padding: 16px; margin: 10px 0; }}
h1 {{ color: #00ff88; }}
.pnl {{ font-size: 36px; font-weight: bold; color: {pnl_color}; }}
.metric {{ display: inline-block; margin: 10px 20px; }}
.metric-label {{ color: #888; font-size: 12px; }}
.metric-value {{ font-size: 20px; font-weight: bold; }}
table {{ width: 100%; border-collapse: collapse; }}
th {{ text-align: left; color: #888; padding: 8px; border-bottom: 1px solid #1c2e40; }}
td {{ padding: 8px; border-bottom: 1px solid #1c2e40; }}
</style></head><body>
<h1>📊 QuantFlow 每日交易简报</h1>
<p style="color:#888">{target_date}</p>

<div class="card">
    <div class="pnl">{pnl_sign}¥{s['total_pnl']:,.2f}</div>
    <p style="color:#888">{s.get('life_translation', '')}</p>
    <div class="metric"><div class="metric-label">交易笔数</div><div class="metric-value">{s['trade_count']}</div></div>
    <div class="metric"><div class="metric-label">胜率</div><div class="metric-value">{s['win_rate']}%</div></div>
    <div class="metric"><div class="metric-label">手续费</div><div class="metric-value">¥{s['total_commission']:,.2f}</div></div>
</div>

<h2>📈 今日交易</h2>
<div class="card">
<table>
<tr><th>时间</th><th>方向</th><th>标的</th><th>数量</th><th>价格</th><th>盈亏</th></tr>
{trades_html if trades_html else '<tr><td colspan="6" style="color:#888">今日无交易</td></tr>'}
</table>
</div>

<h2>🛡️ 风控状态</h2>
<div class="card">
"""
        for event in report.get("risk_events", [])[:5]:
            html += f"<p>⚠️ {event.get('event_time', '')[:19]} — {event.get('description', '')}</p>"
        if not report.get("risk_events"):
            html += "<p style='color:#888'>今日无风控事件</p>"

        html += f"""
</div>
<hr style="border-color:#1c2e40">
<p style="color:#555;font-size:12px">by QuantFlow V2.0 | {report.get('generated_at', '')}</p>
</body></html>"""

        path = self._report_dir / f"{target_date}.html"
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)

    def send_report(self, report: dict, notifier: NotificationManager):
        """Send report via notification channels."""
        s = report["summary"]
        pnl_sign = "+" if s["total_pnl"] >= 0 else ""

        content = (
            f"**盈亏**: {pnl_sign}¥{s['total_pnl']:,.2f}\n"
            f"**手续费**: ¥{s['total_commission']:,.2f}\n"
            f"**交易**: {s['trade_count']}笔 (胜率{s['win_rate']}%)\n"
        )
        if s.get("life_translation"):
            content += f"\n💡 {s['life_translation']}\n"

        notifier.send(
            NotificationLevel.INFO,
            "daily_report",
            f"📊 每日交易简报 ({report['date']})",
            content,
        )
