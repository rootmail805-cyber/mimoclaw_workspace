"""
Health checker for QuantFlow.
Monitors system health and component status.
"""

import time
import psutil
from datetime import datetime
from typing import Dict, Any, List
from loguru import logger


class HealthChecker:
    """System health monitoring.

    Checks:
        - CPU and memory usage
        - Disk space
        - Module connectivity
        - Data feed status
        - Network latency
    """

    def __init__(self, config):
        self._interval = config.get("monitor.health_check.interval_seconds", 30)
        self._timeout = config.get("monitor.health_check.timeout_seconds", 5)
        self._checks: Dict[str, bool] = {}
        self._last_check: Dict[str, datetime] = {}

    def check_all(self) -> Dict[str, Any]:
        """Run all health checks and return status."""
        results = {
            "timestamp": datetime.now().isoformat(),
            "overall": "healthy",
            "checks": {},
        }

        # System metrics
        results["checks"]["cpu"] = self._check_cpu()
        results["checks"]["memory"] = self._check_memory()
        results["checks"]["disk"] = self._check_disk()

        # Determine overall status
        failed = [k for k, v in results["checks"].items() if v.get("status") != "ok"]
        if failed:
            results["overall"] = "degraded" if len(failed) <= 1 else "unhealthy"
            results["issues"] = failed

        return results

    def _check_cpu(self) -> Dict[str, Any]:
        """Check CPU usage."""
        try:
            cpu_pct = psutil.cpu_percent(interval=1)
            status = "ok" if cpu_pct < 80 else ("warning" if cpu_pct < 95 else "critical")
            return {
                "status": status,
                "cpu_percent": cpu_pct,
                "cpu_count": psutil.cpu_count(),
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def _check_memory(self) -> Dict[str, Any]:
        """Check memory usage."""
        try:
            mem = psutil.virtual_memory()
            status = "ok" if mem.percent < 80 else ("warning" if mem.percent < 95 else "critical")
            return {
                "status": status,
                "total_gb": round(mem.total / 1024**3, 2),
                "used_gb": round(mem.used / 1024**3, 2),
                "percent": mem.percent,
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def _check_disk(self) -> Dict[str, Any]:
        """Check disk space."""
        try:
            disk = psutil.disk_usage("/")
            status = "ok" if disk.percent < 85 else ("warning" if disk.percent < 95 else "critical")
            return {
                "status": status,
                "total_gb": round(disk.total / 1024**3, 2),
                "used_gb": round(disk.used / 1024**3, 2),
                "percent": disk.percent,
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def register_check(self, name: str, check_fn) -> None:
        """Register a custom health check function."""
        self._checks[name] = check_fn

    @property
    def interval(self) -> int:
        return self._interval
