"""
SQLite database layer with WAL mode.
All persistent data flows through this module.
"""

import sqlite3
import threading
import json
from pathlib import Path
from datetime import datetime, date
from typing import Any, Dict, List, Optional, Tuple
from contextlib import contextmanager
from loguru import logger

_DB_INSTANCE: Optional["Database"] = None
_DB_LOCK = threading.Lock()


def get_db(db_path: str = "./data/quantflow.db") -> "Database":
    """Get singleton database instance."""
    global _DB_INSTANCE
    if _DB_INSTANCE is None:
        with _DB_LOCK:
            if _DB_INSTANCE is None:
                _DB_INSTANCE = Database(db_path)
    return _DB_INSTANCE


class Database:
    """Thread-safe SQLite database with WAL mode."""

    def __init__(self, db_path: str = "./data/quantflow.db"):
        self._path = Path(db_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_schema()
        logger.info(f"Database initialized: {self._path}")

    def _get_conn(self) -> sqlite3.Connection:
        """Get thread-local connection."""
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(str(self._path), timeout=10)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return self._local.conn

    @contextmanager
    def cursor(self):
        """Context manager for cursor with auto-commit."""
        conn = self._get_conn()
        cur = conn.cursor()
        try:
            yield cur
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            cur.close()

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        """Execute a single SQL statement."""
        with self.cursor() as cur:
            return cur.execute(sql, params)

    def fetchall(self, sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """Execute query and return all rows as dicts."""
        with self.cursor() as cur:
            cur.execute(sql, params)
            return [dict(row) for row in cur.fetchall()]

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[Dict[str, Any]]:
        """Execute query and return first row as dict."""
        with self.cursor() as cur:
            cur.execute(sql, params)
            row = cur.fetchone()
            return dict(row) if row else None

    def _init_schema(self):
        """Initialize database schema."""
        with self.cursor() as cur:
            # Trade records
            cur.execute("""
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trade_time TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    quantity INTEGER NOT NULL,
                    price REAL NOT NULL,
                    amount REAL NOT NULL,
                    commission REAL DEFAULT 0,
                    tax REAL DEFAULT 0,
                    slippage REAL DEFAULT 0,
                    pnl REAL DEFAULT 0,
                    strategy_id TEXT,
                    signal_id TEXT,
                    order_id TEXT,
                    notes TEXT,
                    created_at TEXT DEFAULT (datetime('now'))
                )
            """)

            # Position snapshots
            cur.execute("""
                CREATE TABLE IF NOT EXISTS positions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    snapshot_time TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    quantity INTEGER NOT NULL,
                    avg_cost REAL NOT NULL,
                    current_price REAL,
                    market_value REAL,
                    unrealized_pnl REAL,
                    strategy_id TEXT,
                    created_at TEXT DEFAULT (datetime('now'))
                )
            """)

            # Daily PnL summary
            cur.execute("""
                CREATE TABLE IF NOT EXISTS daily_pnl (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT UNIQUE NOT NULL,
                    realized_pnl REAL DEFAULT 0,
                    unrealized_pnl REAL DEFAULT 0,
                    total_pnl REAL DEFAULT 0,
                    commission_total REAL DEFAULT 0,
                    tax_total REAL DEFAULT 0,
                    trade_count INTEGER DEFAULT 0,
                    win_count INTEGER DEFAULT 0,
                    loss_count INTEGER DEFAULT 0,
                    total_assets REAL DEFAULT 0,
                    created_at TEXT DEFAULT (datetime('now'))
                )
            """)

            # Risk events
            cur.execute("""
                CREATE TABLE IF NOT EXISTS risk_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_time TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    description TEXT NOT NULL,
                    details TEXT,
                    resolved INTEGER DEFAULT 0,
                    resolved_time TEXT,
                    created_at TEXT DEFAULT (datetime('now'))
                )
            """)

            # Notification records
            cur.execute("""
                CREATE TABLE IF NOT EXISTS notifications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    send_time TEXT NOT NULL,
                    channel TEXT NOT NULL,
                    level TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    title TEXT,
                    content TEXT,
                    status TEXT DEFAULT 'pending',
                    retry_count INTEGER DEFAULT 0,
                    error_msg TEXT,
                    created_at TEXT DEFAULT (datetime('now'))
                )
            """)

            # Strategy instances
            cur.execute("""
                CREATE TABLE IF NOT EXISTS strategy_instances (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    instance_id TEXT UNIQUE NOT NULL,
                    strategy_id TEXT NOT NULL,
                    display_name TEXT,
                    params TEXT,
                    status TEXT DEFAULT 'stopped',
                    symbol TEXT,
                    started_at TEXT,
                    stopped_at TEXT,
                    signal_count INTEGER DEFAULT 0,
                    exec_count INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT (datetime('now'))
                )
            """)

            # Order tracking
            cur.execute("""
                CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    order_id TEXT UNIQUE NOT NULL,
                    symbol TEXT NOT NULL,
                    side TEXT NOT NULL,
                    order_type TEXT NOT NULL,
                    quantity INTEGER NOT NULL,
                    price REAL,
                    filled_price REAL,
                    filled_quantity INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'PENDING',
                    strategy_id TEXT,
                    signal_id TEXT,
                    created_at TEXT DEFAULT (datetime('now')),
                    updated_at TEXT DEFAULT (datetime('now'))
                )
            """)

            # Circuit breaker state
            cur.execute("""
                CREATE TABLE IF NOT EXISTS circuit_breaker (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    breaker_type TEXT NOT NULL,
                    status TEXT DEFAULT 'inactive',
                    triggered_at TEXT,
                    trigger_reason TEXT,
                    cleared_at TEXT,
                    cleared_by TEXT,
                    created_at TEXT DEFAULT (datetime('now'))
                )
            """)

            # Backtest results
            cur.execute("""
                CREATE TABLE IF NOT EXISTS backtest_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    strategy_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    start_date TEXT NOT NULL,
                    end_date TEXT NOT NULL,
                    params TEXT,
                    annualized_return REAL,
                    max_drawdown REAL,
                    sharpe_ratio REAL,
                    win_rate REAL,
                    total_trades INTEGER,
                    result_json TEXT,
                    created_at TEXT DEFAULT (datetime('now'))
                )
            """)

            # Config change log
            cur.execute("""
                CREATE TABLE IF NOT EXISTS config_changes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    change_time TEXT NOT NULL,
                    config_key TEXT NOT NULL,
                    old_value TEXT,
                    new_value TEXT,
                    changed_by TEXT DEFAULT 'user',
                    created_at TEXT DEFAULT (datetime('now'))
                )
            """)

            # Create indexes
            cur.execute("CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_trades_time ON trades(trade_time)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_trades_strategy ON trades(strategy_id)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_daily_pnl_date ON daily_pnl(date)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_risk_events_time ON risk_events(event_time)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_symbol ON orders(symbol)")

    # ── Trade operations ──

    def insert_trade(self, trade: Dict[str, Any]) -> int:
        """Insert a trade record."""
        with self.cursor() as cur:
            cur.execute("""
                INSERT INTO trades (trade_time, symbol, direction, quantity, price, amount,
                    commission, tax, slippage, pnl, strategy_id, signal_id, order_id, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                trade.get("trade_time", datetime.now().isoformat()),
                trade["symbol"],
                trade["direction"],
                trade["quantity"],
                trade["price"],
                trade.get("amount", trade["quantity"] * trade["price"]),
                trade.get("commission", 0),
                trade.get("tax", 0),
                trade.get("slippage", 0),
                trade.get("pnl", 0),
                trade.get("strategy_id"),
                trade.get("signal_id"),
                trade.get("order_id"),
                trade.get("notes"),
            ))
            return cur.lastrowid

    def get_trades(self, symbol: str = None, start: str = None, end: str = None,
                   strategy_id: str = None, limit: int = 100) -> List[Dict]:
        """Query trades with filters."""
        conditions = []
        params = []
        if symbol:
            conditions.append("symbol = ?")
            params.append(symbol)
        if start:
            conditions.append("trade_time >= ?")
            params.append(start)
        if end:
            conditions.append("trade_time <= ?")
            params.append(end)
        if strategy_id:
            conditions.append("strategy_id = ?")
            params.append(strategy_id)

        where = " WHERE " + " AND ".join(conditions) if conditions else ""
        return self.fetchall(
            f"SELECT * FROM trades{where} ORDER BY trade_time DESC LIMIT ?",
            tuple(params) + (limit,)
        )

    # ── Daily PnL operations ──

    def upsert_daily_pnl(self, pnl_data: Dict[str, Any]) -> None:
        """Insert or update daily PnL summary."""
        with self.cursor() as cur:
            cur.execute("""
                INSERT INTO daily_pnl (date, realized_pnl, unrealized_pnl, total_pnl,
                    commission_total, tax_total, trade_count, win_count, loss_count, total_assets)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(date) DO UPDATE SET
                    realized_pnl=excluded.realized_pnl,
                    unrealized_pnl=excluded.unrealized_pnl,
                    total_pnl=excluded.total_pnl,
                    commission_total=excluded.commission_total,
                    tax_total=excluded.tax_total,
                    trade_count=excluded.trade_count,
                    win_count=excluded.win_count,
                    loss_count=excluded.loss_count,
                    total_assets=excluded.total_assets
            """, (
                pnl_data["date"],
                pnl_data.get("realized_pnl", 0),
                pnl_data.get("unrealized_pnl", 0),
                pnl_data.get("total_pnl", 0),
                pnl_data.get("commission_total", 0),
                pnl_data.get("tax_total", 0),
                pnl_data.get("trade_count", 0),
                pnl_data.get("win_count", 0),
                pnl_data.get("loss_count", 0),
                pnl_data.get("total_assets", 0),
            ))

    def get_daily_pnl(self, start: str = None, end: str = None, limit: int = 30) -> List[Dict]:
        """Get daily PnL history."""
        conditions = []
        params = []
        if start:
            conditions.append("date >= ?")
            params.append(start)
        if end:
            conditions.append("date <= ?")
            params.append(end)
        where = " WHERE " + " AND ".join(conditions) if conditions else ""
        return self.fetchall(
            f"SELECT * FROM daily_pnl{where} ORDER BY date DESC LIMIT ?",
            tuple(params) + (limit,)
        )

    # ── Risk events ──

    def insert_risk_event(self, event_type: str, severity: str, description: str,
                          details: str = None) -> int:
        """Record a risk event."""
        with self.cursor() as cur:
            cur.execute("""
                INSERT INTO risk_events (event_time, event_type, severity, description, details)
                VALUES (?, ?, ?, ?, ?)
            """, (datetime.now().isoformat(), event_type, severity, description, details))
            return cur.lastrowid

    def get_risk_events(self, limit: int = 20, severity: str = None) -> List[Dict]:
        """Get recent risk events."""
        if severity:
            return self.fetchall(
                "SELECT * FROM risk_events WHERE severity=? ORDER BY event_time DESC LIMIT ?",
                (severity, limit)
            )
        return self.fetchall(
            "SELECT * FROM risk_events ORDER BY event_time DESC LIMIT ?", (limit,)
        )

    # ── Notification records ──

    def insert_notification(self, channel: str, level: str, event_type: str,
                            title: str, content: str) -> int:
        """Record a notification."""
        with self.cursor() as cur:
            cur.execute("""
                INSERT INTO notifications (send_time, channel, level, event_type, title, content)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (datetime.now().isoformat(), channel, level, event_type, title, content))
            return cur.lastrowid

    def update_notification_status(self, notif_id: int, status: str, error_msg: str = None):
        """Update notification delivery status."""
        with self.cursor() as cur:
            cur.execute(
                "UPDATE notifications SET status=?, error_msg=? WHERE id=?",
                (status, error_msg, notif_id)
            )

    # ── Orders ──

    def insert_order(self, order: Dict[str, Any]) -> int:
        """Insert an order record."""
        with self.cursor() as cur:
            cur.execute("""
                INSERT INTO orders (order_id, symbol, side, order_type, quantity, price,
                    filled_price, filled_quantity, status, strategy_id, signal_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                order["order_id"], order["symbol"], order["side"],
                order.get("order_type", "MARKET"), order["quantity"],
                order.get("price"), order.get("filled_price"),
                order.get("filled_quantity", 0), order.get("status", "PENDING"),
                order.get("strategy_id"), order.get("signal_id"),
            ))
            return cur.lastrowid

    def update_order_status(self, order_id: str, status: str,
                            filled_price: float = None, filled_quantity: int = None):
        """Update order status."""
        sets = ["status=?", "updated_at=?"]
        params = [status, datetime.now().isoformat()]
        if filled_price is not None:
            sets.append("filled_price=?")
            params.append(filled_price)
        if filled_quantity is not None:
            sets.append("filled_quantity=?")
            params.append(filled_quantity)
        params.append(order_id)
        with self.cursor() as cur:
            cur.execute(f"UPDATE orders SET {','.join(sets)} WHERE order_id=?", tuple(params))

    # ── Circuit breaker ──

    def get_circuit_breaker(self, breaker_type: str = "account") -> Optional[Dict]:
        """Get circuit breaker state."""
        return self.fetchone(
            "SELECT * FROM circuit_breaker WHERE breaker_type=? ORDER BY id DESC LIMIT 1",
            (breaker_type,)
        )

    def set_circuit_breaker(self, breaker_type: str, status: str,
                            trigger_reason: str = None, cleared_by: str = None):
        """Set circuit breaker state."""
        with self.cursor() as cur:
            if status == "active":
                cur.execute("""
                    INSERT INTO circuit_breaker (breaker_type, status, triggered_at, trigger_reason)
                    VALUES (?, ?, ?, ?)
                """, (breaker_type, status, datetime.now().isoformat(), trigger_reason))
            elif status == "inactive":
                cur.execute("""
                    INSERT INTO circuit_breaker (breaker_type, status, cleared_at, cleared_by)
                    VALUES (?, ?, ?, ?)
                """, (breaker_type, status, datetime.now().isoformat(), cleared_by))

    # ── Strategy instances ──

    def upsert_strategy_instance(self, instance: Dict[str, Any]):
        """Insert or update strategy instance."""
        with self.cursor() as cur:
            cur.execute("""
                INSERT INTO strategy_instances
                    (instance_id, strategy_id, display_name, params, status, symbol, started_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(instance_id) DO UPDATE SET
                    status=excluded.status,
                    params=excluded.params,
                    started_at=excluded.started_at
            """, (
                instance["instance_id"], instance["strategy_id"],
                instance.get("display_name"), json.dumps(instance.get("params", {})),
                instance.get("status", "running"), instance.get("symbol"),
                instance.get("started_at", datetime.now().isoformat()),
            ))

    def get_running_strategies(self) -> List[Dict]:
        """Get all running strategy instances."""
        return self.fetchall(
            "SELECT * FROM strategy_instances WHERE status='running'"
        )

    # ── Backtest results ──

    def save_backtest_result(self, result: Dict[str, Any]):
        """Save backtest result."""
        with self.cursor() as cur:
            cur.execute("""
                INSERT INTO backtest_results
                    (strategy_id, symbol, start_date, end_date, params,
                     annualized_return, max_drawdown, sharpe_ratio, win_rate,
                     total_trades, result_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                result["strategy_id"], result["symbol"],
                result["start_date"], result["end_date"],
                json.dumps(result.get("params", {})),
                result.get("annualized_return"), result.get("max_drawdown"),
                result.get("sharpe_ratio"), result.get("win_rate"),
                result.get("total_trades"), json.dumps(result),
            ))

    # ── Config changes ──

    def log_config_change(self, key: str, old_val: Any, new_val: Any):
        """Log a configuration change."""
        with self.cursor() as cur:
            cur.execute("""
                INSERT INTO config_changes (change_time, config_key, old_value, new_value)
                VALUES (?, ?, ?, ?)
            """, (datetime.now().isoformat(), key, str(old_val), str(new_val)))

    # ── Statistics ──

    def get_month_summary(self, year: int = None, month: int = None) -> Dict:
        """Get monthly summary."""
        if year is None:
            year = date.today().year
        if month is None:
            month = date.today().month
        start = f"{year}-{month:02d}-01"
        if month == 12:
            end = f"{year+1}-01-01"
        else:
            end = f"{year}-{month+1:02d}-01"

        row = self.fetchone("""
            SELECT
                COUNT(*) as trade_count,
                SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as win_count,
                SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as loss_count,
                SUM(pnl) as total_pnl,
                SUM(commission) as total_commission,
                SUM(tax) as total_tax
            FROM trades
            WHERE trade_time >= ? AND trade_time < ?
        """, (start, end))

        return row or {"trade_count": 0, "win_count": 0, "loss_count": 0,
                       "total_pnl": 0, "total_commission": 0, "total_tax": 0}

    def close(self):
        """Close thread-local connection."""
        if hasattr(self._local, "conn") and self._local.conn:
            self._local.conn.close()
            self._local.conn = None
