"""Database layer — SQLite with WAL mode for concurrent read/write."""

from .database import Database, get_db
