"""
多因子选股引擎
支持估值、成长、质量、动量、波动率五大类因子，
用户可自定义因子权重，系统自动计算综合评分并排序选股。

因子体系：
- 估值因子：PE、PB、PS、股息率
- 成长因子：营收增速、净利润增速、ROE变化
- 质量因子：ROE、毛利率、资产负债率、现金流
- 动量因子：近N日涨幅、相对强度、均线偏离
- 波动率因子：历史波动率、下行波动率、Beta
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from loguru import logger


# ── 因子定义 ──────────────────────────────────────────────────

@dataclass
class FactorValue:
    """单个因子值"""
    name: str
    category: str       # valuation / growth / quality / momentum / volatility
    raw_value: float    # 原始值
    z_score: float = 0.0  # 标准化后的值
    percentile: float = 0.0  # 百分位排名


@dataclass
class StockScore:
    """股票综合评分"""
    symbol: str
    name: str = ""
    total_score: float = 0.0    # 综合得分（0-100）
    factors: Dict[str, FactorValue] = field(default_factory=dict)
    rank: int = 0
    recommendation: str = ""    # 强烈推荐 / 推荐 / 中性 / 谨慎 / 回避


@dataclass
class FactorConfig:
    """因子配置"""
    name: str
    category: str
    weight: float = 1.0
    direction: int = 1          # 1=越大越好, -1=越小越好
    enabled: bool = True


# ── 预设因子配置 ──────────────────────────────────────────────

DEFAULT_FACTORS = [
    # 估值因子（越低越好）
    FactorConfig("pe_ttm", "valuation", weight=1.0, direction=-1),
    FactorConfig("pb", "valuation", weight=0.8, direction=-1),
    FactorConfig("ps_ttm", "valuation", weight=0.5, direction=-1),
    FactorConfig("dividend_yield", "valuation", weight=0.6, direction=1),

    # 成长因子（越高越好）
    FactorConfig("revenue_growth", "growth", weight=1.0, direction=1),
    FactorConfig("profit_growth", "growth", weight=1.2, direction=1),
    FactorConfig("roe_change", "growth", weight=0.8, direction=1),

    # 质量因子（越高越好/越低越好视指标而定）
    FactorConfig("roe", "quality", weight=1.0, direction=1),
    FactorConfig("gross_margin", "quality", weight=0.6, direction=1),
    FactorConfig("debt_ratio", "quality", weight=0.5, direction=-1),
    FactorConfig("cash_flow_ratio", "quality", weight=0.7, direction=1),

    # 动量因子（越高越好）
    FactorConfig("return_20d", "momentum", weight=0.8, direction=1),
    FactorConfig("return_60d", "momentum", weight=0.6, direction=1),
    FactorConfig("relative_strength", "momentum", weight=0.7, direction=1),
    FactorConfig("ma_deviation", "momentum", weight=0.5, direction=-1),

    # 波动率因子（越低越好）
    FactorConfig("volatility_20d", "volatility", weight=0.6, direction=-1),
    FactorConfig("downside_vol", "volatility", weight=0.5, direction=-1),
    FactorConfig("beta", "volatility", weight=0.4, direction=-1),
]

# 因子分类权重
CATEGORY_WEIGHTS = {
    "valuation": 1.0,
    "growth": 1.2,
    "quality": 1.0,
    "momentum": 0.8,
    "volatility": 0.5,
}


class FactorEngine:
    """多因子选股引擎"""

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._data_mgr = None
        self._factor_configs: List[FactorConfig] = list(DEFAULT_FACTORS)
        self._category_weights = dict(CATEGORY_WEIGHTS)

    def set_factor_weights(self, weights: Dict[str, float]):
        """设置因子权重（用户自定义）

        Args:
            weights: {因子名: 权重} 字典
        """
        for fc in self._factor_configs:
            if fc.name in weights:
                fc.weight = weights[fc.name]

    def set_category_weights(self, weights: Dict[str, float]):
        """设置因子分类权重"""
        self._category_weights.update(weights)

    def score_stocks(
        self,
        symbols: List[str],
        start: str = None,
        end: str = None,
        top_n: int = 20,
    ) -> List[StockScore]:
        """对股票池进行多因子评分

        Args:
            symbols: 股票代码列表
            start: 数据开始日期（默认1年前）
            end: 数据结束日期（默认今天）
            top_n: 返回前N只股票

        Returns:
            按综合得分排序的 StockScore 列表
        """
        if start is None:
            start = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
        if end is None:
            end = datetime.now().strftime("%Y-%m-%d")

        if self._data_mgr is None:
            from core.data.data_manager import DataManager
            self._data_mgr = DataManager(self._config)

        # 收集所有股票的因子数据
        all_scores = []
        for symbol in symbols:
            try:
                score = self._calculate_stock_score(symbol, start, end)
                if score:
                    all_scores.append(score)
            except Exception as e:
                logger.warning(f"[FactorEngine] {symbol} 评分失败: {e}")

        # 标准化并排名
        if all_scores:
            all_scores = self._normalize_and_rank(all_scores)

        # 取前N只
        return all_scores[:top_n]

    def _calculate_stock_score(
        self, symbol: str, start: str, end: str
    ) -> Optional[StockScore]:
        """计算单只股票的因子评分"""
        # 获取价格数据
        data = self._data_mgr.get_history(symbol, start, end, freq="daily")
        if data is None or data.empty or len(data) < 60:
            return None

        closes = data["close"].values
        highs = data["high"].values
        lows = data["low"].values
        volumes = data["volume"].values

        factors = {}

        # ── 动量因子 ──
        if len(closes) >= 20:
            ret_20d = (closes[-1] / closes[-20] - 1) if closes[-20] > 0 else 0
            factors["return_20d"] = FactorValue("return_20d", "momentum", ret_20d)

        if len(closes) >= 60:
            ret_60d = (closes[-1] / closes[-60] - 1) if closes[-60] > 0 else 0
            factors["return_60d"] = FactorValue("return_60d", "momentum", ret_60d)

        # 相对强度（近20日收益 vs 近60日收益）
        if "return_20d" in factors and "return_60d" in factors:
            rs = factors["return_20d"].raw_value - factors["return_60d"].raw_value / 3
            factors["relative_strength"] = FactorValue("relative_strength", "momentum", rs)

        # 均线偏离度
        if len(closes) >= 20:
            ma20 = np.mean(closes[-20:])
            ma_dev = (closes[-1] - ma20) / ma20 if ma20 > 0 else 0
            factors["ma_deviation"] = FactorValue("ma_deviation", "momentum", ma_dev)

        # ── 波动率因子 ──
        if len(closes) >= 20:
            # 保护除零：过滤掉价格为0的项
            recent_closes = closes[-21:]
            safe_closes = recent_closes[recent_closes > 0]
            if len(safe_closes) >= 2:
                daily_returns = np.diff(safe_closes) / safe_closes[:-1]
                daily_returns = daily_returns[np.isfinite(daily_returns)]
                vol_20d = np.std(daily_returns) * np.sqrt(252) if len(daily_returns) > 1 else 0
            else:
                daily_returns = np.array([0.0])
                vol_20d = 0.0
            factors["volatility_20d"] = FactorValue("volatility_20d", "volatility", vol_20d)

            # 下行波动率
            neg_returns = daily_returns[daily_returns < 0]
            downside_vol = np.std(neg_returns) * np.sqrt(252) if len(neg_returns) > 2 else vol_20d
            factors["downside_vol"] = FactorValue("downside_vol", "volatility", downside_vol)

        # Beta（近60日）
        if len(closes) >= 60:
            safe_60 = closes[-61:]
            safe_60 = safe_60[safe_60 > 0]
            if len(safe_60) >= 2:
                returns_60d = np.diff(safe_60) / safe_60[:-1]
                returns_60d = returns_60d[np.isfinite(returns_60d)]
                var_60 = np.var(returns_60d)
                beta = np.cov(returns_60d, returns_60d)[0, 1] / var_60 if var_60 > 0 else 1.0
            else:
                beta = 1.0
            factors["beta"] = FactorValue("beta", "volatility", beta)

        # ── 估值因子（使用价格作为代理，真实场景需接入财务数据）──
        if len(closes) >= 20:
            avg_vol = np.mean(volumes[-20:])
            if avg_vol > 0:
                price_vol_ratio = closes[-1] / (avg_vol / 10000)
            else:
                price_vol_ratio = closes[-1]
            factors["pe_ttm"] = FactorValue("pe_ttm", "valuation", price_vol_ratio)

        # ── 质量因子（使用价格稳定性作为代理）──
        if len(closes) >= 60:
            # 价格稳定性 = 1 / 波动率
            stability = 1 / (factors.get("volatility_20d", FactorValue("", "", 1)).raw_value + 0.01)
            factors["roe"] = FactorValue("roe", "quality", stability)

        if not factors:
            return None

        return StockScore(
            symbol=symbol,
            factors=factors,
        )

    def _normalize_and_rank(self, scores: List[StockScore]) -> List[StockScore]:
        """标准化因子值并计算综合排名"""
        # 收集所有因子名称
        all_factor_names = set()
        for s in scores:
            all_factor_names.update(s.factors.keys())

        # 对每个因子做Z-score标准化
        for fname in all_factor_names:
            values = [s.factors[fname].raw_value for s in scores if fname in s.factors]
            if not values or len(values) < 2:
                continue
            mean_val = np.mean(values)
            std_val = np.std(values)
            if std_val == 0:
                continue

            for s in scores:
                if fname in s.factors:
                    z = (s.factors[fname].raw_value - mean_val) / std_val
                    s.factors[fname].z_score = z

        # 计算综合得分
        for s in scores:
            total = 0.0
            total_weight = 0.0
            for fc in self._factor_configs:
                if not fc.enabled or fc.name not in s.factors:
                    continue
                fv = s.factors[fc.name]
                cat_weight = self._category_weights.get(fc.category, 1.0)
                score = fv.z_score * fc.direction  # 方向调整
                total += score * fc.weight * cat_weight
                total_weight += fc.weight * cat_weight

            # 归一化到0-100
            if total_weight > 0:
                raw_score = total / total_weight
                # 用sigmoid映射到0-100
                s.total_score = round(100 / (1 + np.exp(-raw_score)), 1)
            else:
                s.total_score = 50.0

            # 推荐等级
            if s.total_score >= 75:
                s.recommendation = "强烈推荐"
            elif s.total_score >= 60:
                s.recommendation = "推荐"
            elif s.total_score >= 40:
                s.recommendation = "中性"
            elif s.total_score >= 25:
                s.recommendation = "谨慎"
            else:
                s.recommendation = "回避"

        # 排序
        scores.sort(key=lambda s: s.total_score, reverse=True)
        for i, s in enumerate(scores):
            s.rank = i + 1

        return scores

    def get_factor_explanation(self) -> str:
        """获取因子体系说明"""
        lines = [
            "═══ 多因子选股体系 ═══",
            "",
            "◆ 估值因子（权重1.0）：",
            "  PE_TTM / PB / PS_TTM / 股息率",
            "  → 寻找被市场低估的股票",
            "",
            "◆ 成长因子（权重1.2）：",
            "  营收增速 / 净利润增速 / ROE变化",
            "  → 寻找高成长性的企业",
            "",
            "◆ 质量因子（权重1.0）：",
            "  ROE / 毛利率 / 资产负债率 / 现金流",
            "  → 寻找财务健康的优质企业",
            "",
            "◆ 动量因子（权重0.8）：",
            "  近20日涨幅 / 近60日涨幅 / 相对强度 / 均线偏离",
            "  → 跟踪趋势，顺势而为",
            "",
            "◆ 波动率因子（权重0.5）：",
            "  历史波动率 / 下行波动率 / Beta",
            "  → 控制风险，偏好低波动标的",
        ]
        return "\n".join(lines)
