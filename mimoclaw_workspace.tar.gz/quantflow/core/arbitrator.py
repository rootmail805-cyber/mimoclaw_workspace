"""
策略信号与止盈止损冲突仲裁器
解决策略引擎生成的交易信号与用户预设的止盈止损挂单之间的优先级冲突

三种模式：
1. 策略信号优先 — 策略信号绝对优先执行，止盈止损仅供参考
2. 止盈止损优先 — 有止盈止损挂单时，暂停策略对该标的的交易决策
3. 动态优先（推荐）— 根据持仓盈亏状态动态切换仲裁方
"""

from enum import Enum
from typing import Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime
from loguru import logger


class ConflictMode(Enum):
    """冲突处理模式"""
    STRATEGY_PRIORITY = "strategy_priority"      # 策略信号优先
    STOP_PRIORITY = "stop_priority"              # 止盈止损优先
    DYNAMIC = "dynamic"                          # 动态优先（推荐）


@dataclass
class ArbitrationResult:
    """仲裁结果"""
    allowed: bool                    # 是否允许策略信号执行
    mode: ConflictMode               # 使用的模式
    reason: str                      # 仲裁理由
    action_taken: str                # 采取的动作
    log_message: str                 # 日志消息


@dataclass
class ArbitrationLog:
    """仲裁日志"""
    timestamp: str
    symbol: str
    strategy_id: str
    signal_action: str               # 策略信号动作（BUY/SELL）
    mode: ConflictMode
    result: str                      # ALLOWED / BLOCKED
    reason: str
    pnl_pct: float = 0.0            # 当前盈亏百分比
    stop_loss: float = 0.0
    take_profit: float = 0.0


class ConflictArbitrator:
    """策略信号与止盈止损冲突仲裁器"""

    def __init__(self, mode: ConflictMode = ConflictMode.DYNAMIC):
        self._mode = mode
        self._logs: list = []
        self._max_logs = 200

        # 动态模式阈值
        self._tp_lock_threshold = 0.80    # 浮盈 ≥ 止盈目标的80% → 止盈优先
        self._sl_force_threshold = 0.50   # 浮亏 ≥ 止损价的50% → 止损优先

    @property
    def mode(self) -> ConflictMode:
        return self._mode

    @mode.setter
    def mode(self, value: ConflictMode):
        self._mode = value
        logger.info(f"[Arbitrator] 冲突处理模式切换为: {value.value}")

    def set_dynamic_thresholds(self, tp_lock: float = 0.80, sl_force: float = 0.50):
        """设置动态模式阈值"""
        self._tp_lock_threshold = tp_lock
        self._sl_force_threshold = sl_force

    def arbitrate(
        self,
        symbol: str,
        strategy_id: str,
        signal_action: str,
        current_price: float,
        avg_cost: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        has_active_stop: bool = False,
    ) -> ArbitrationResult:
        """执行仲裁

        Args:
            symbol: 股票代码
            strategy_id: 策略ID
            signal_action: 策略信号动作（BUY/SELL）
            current_price: 当前价格
            avg_cost: 持仓成本
            stop_loss: 止损价
            take_profit: 止盈价
            has_active_stop: 是否有激活的止盈止损单

        Returns:
            ArbitrationResult 仲裁结果
        """
        if self._mode == ConflictMode.STRATEGY_PRIORITY:
            return self._arbitrate_strategy_priority(
                symbol, strategy_id, signal_action, has_active_stop)
        elif self._mode == ConflictMode.STOP_PRIORITY:
            return self._arbitrate_stop_priority(
                symbol, strategy_id, signal_action, has_active_stop,
                current_price, avg_cost, stop_loss, take_profit)
        else:  # DYNAMIC
            return self._arbitrate_dynamic(
                symbol, strategy_id, signal_action, has_active_stop,
                current_price, avg_cost, stop_loss, take_profit)

    def _arbitrate_strategy_priority(
        self, symbol, strategy_id, signal_action, has_active_stop
    ) -> ArbitrationResult:
        """模式一：策略信号优先"""
        if has_active_stop:
            log_msg = (f"[仲裁] 策略信号触发{signal_action}，止盈止损单处于激活状态，"
                       f"根据\"策略信号优先\"规则，执行策略信号，取消止盈止损单。")
        else:
            log_msg = f"[仲裁] 策略信号触发{signal_action}，无冲突，直接执行。"

        self._add_log(symbol, strategy_id, signal_action,
                      ConflictMode.STRATEGY_PRIORITY, "ALLOWED", log_msg)

        return ArbitrationResult(
            allowed=True,
            mode=ConflictMode.STRATEGY_PRIORITY,
            reason="策略信号优先模式：策略信号始终执行",
            action_taken=f"执行{signal_action}信号" + ("，取消止盈止损单" if has_active_stop else ""),
            log_message=log_msg,
        )

    def _arbitrate_stop_priority(
        self, symbol, strategy_id, signal_action, has_active_stop,
        current_price, avg_cost, stop_loss, take_profit
    ) -> ArbitrationResult:
        """模式二：止盈止损优先"""
        if has_active_stop:
            log_msg = (f"[仲裁] 策略信号触发{signal_action}，但止盈止损单处于激活状态，"
                       f"根据\"止盈止损优先\"规则，已忽略策略信号，维持止盈止损单。")
            self._add_log(symbol, strategy_id, signal_action,
                          ConflictMode.STOP_PRIORITY, "BLOCKED", log_msg)
            return ArbitrationResult(
                allowed=False,
                mode=ConflictMode.STOP_PRIORITY,
                reason="止盈止损优先模式：有激活的止盈止损单时暂停策略交易",
                action_taken="忽略策略信号，维持止盈止损单",
                log_message=log_msg,
            )
        else:
            log_msg = f"[仲裁] 策略信号触发{signal_action}，无止盈止损单，直接执行。"
            self._add_log(symbol, strategy_id, signal_action,
                          ConflictMode.STOP_PRIORITY, "ALLOWED", log_msg)
            return ArbitrationResult(
                allowed=True,
                mode=ConflictMode.STOP_PRIORITY,
                reason="无激活的止盈止损单，允许执行",
                action_taken=f"执行{signal_action}信号",
                log_message=log_msg,
            )

    def _arbitrate_dynamic(
        self, symbol, strategy_id, signal_action, has_active_stop,
        current_price, avg_cost, stop_loss, take_profit
    ) -> ArbitrationResult:
        """模式三：动态优先（推荐）"""
        if not has_active_stop:
            log_msg = f"[仲裁] 策略信号触发{signal_action}，无止盈止损单，直接执行。"
            self._add_log(symbol, strategy_id, signal_action,
                          ConflictMode.DYNAMIC, "ALLOWED", log_msg)
            return ArbitrationResult(
                allowed=True,
                mode=ConflictMode.DYNAMIC,
                reason="无激活的止盈止损单，允许执行",
                action_taken=f"执行{signal_action}信号",
                log_message=log_msg,
            )

        # 计算盈亏状态
        if avg_cost > 0:
            pnl_pct = (current_price - avg_cost) / avg_cost
        else:
            pnl_pct = 0.0

        # 判断是否接近止盈目标
        if take_profit > 0 and avg_cost > 0:
            tp_target_pct = (take_profit - avg_cost) / avg_cost
            tp_progress = pnl_pct / tp_target_pct if tp_target_pct > 0 else 0
        else:
            tp_progress = 0

        # 判断是否接近止损价
        if stop_loss > 0 and avg_cost > 0:
            sl_target_pct = (avg_cost - stop_loss) / avg_cost
            sl_progress = abs(pnl_pct) / sl_target_pct if pnl_pct < 0 and sl_target_pct > 0 else 0
        else:
            sl_progress = 0

        # 动态决策
        if tp_progress >= self._tp_lock_threshold:
            # 浮盈接近止盈目标 → 止盈优先，锁定利润
            log_msg = (f"[仲裁] 策略信号触发{signal_action}，但浮盈{pnl_pct:.1%}已达到"
                       f"止盈目标的{tp_progress:.0%}，根据\"动态优先\"规则，"
                       f"已忽略策略信号，维持止盈单锁定利润。")
            self._add_log(symbol, strategy_id, signal_action,
                          ConflictMode.DYNAMIC, "BLOCKED", log_msg, pnl_pct,
                          stop_loss, take_profit)
            return ArbitrationResult(
                allowed=False,
                mode=ConflictMode.DYNAMIC,
                reason=f"浮盈{pnl_pct:.1%}接近止盈目标，锁定利润",
                action_taken="忽略策略信号，维持止盈单",
                log_message=log_msg,
            )
        elif sl_progress >= self._sl_force_threshold:
            # 浮亏接近止损价 → 止损优先，强制保护
            log_msg = (f"[仲裁] 策略信号触发{signal_action}，但浮亏{pnl_pct:.1%}已达到"
                       f"止损线的{sl_progress:.0%}，根据\"动态优先\"规则，"
                       f"已忽略策略信号，维持止损单保护本金。")
            self._add_log(symbol, strategy_id, signal_action,
                          ConflictMode.DYNAMIC, "BLOCKED", log_msg, pnl_pct,
                          stop_loss, take_profit)
            return ArbitrationResult(
                allowed=False,
                mode=ConflictMode.DYNAMIC,
                reason=f"浮亏{pnl_pct:.1%}接近止损线，保护本金",
                action_taken="忽略策略信号，维持止损单",
                log_message=log_msg,
            )
        else:
            # 浮盈未达止盈目标的80%，浮亏未达止损线的50% → 策略信号优先
            log_msg = (f"[仲裁] 策略信号触发{signal_action}，当前盈亏{pnl_pct:.1%}"
                       f"处于安全区间，根据\"动态优先\"规则，执行策略信号。")
            self._add_log(symbol, strategy_id, signal_action,
                          ConflictMode.DYNAMIC, "ALLOWED", log_msg, pnl_pct,
                          stop_loss, take_profit)
            return ArbitrationResult(
                allowed=True,
                mode=ConflictMode.DYNAMIC,
                reason=f"盈亏{pnl_pct:.1%}处于安全区间，允许策略执行",
                action_taken=f"执行{signal_action}信号",
                log_message=log_msg,
            )

    def _add_log(self, symbol, strategy_id, signal_action, mode, result,
                 reason, pnl_pct=0.0, stop_loss=0.0, take_profit=0.0):
        """添加仲裁日志"""
        log = ArbitrationLog(
            timestamp=datetime.now().isoformat(),
            symbol=symbol,
            strategy_id=strategy_id,
            signal_action=signal_action,
            mode=mode,
            result=result,
            reason=reason,
            pnl_pct=pnl_pct,
            stop_loss=stop_loss,
            take_profit=take_profit,
        )
        self._logs.append(log)
        if len(self._logs) > self._max_logs:
            self._logs = self._logs[-self._max_logs:]
        logger.info(reason)

    def get_logs(self, limit: int = 50) -> list:
        """获取仲裁日志"""
        return self._logs[-limit:]

    def get_mode_display(self) -> str:
        """获取当前模式的中文显示名"""
        names = {
            ConflictMode.STRATEGY_PRIORITY: "策略信号优先",
            ConflictMode.STOP_PRIORITY: "止盈止损优先",
            ConflictMode.DYNAMIC: "动态优先（推荐）",
        }
        return names.get(self._mode, str(self._mode.value))
