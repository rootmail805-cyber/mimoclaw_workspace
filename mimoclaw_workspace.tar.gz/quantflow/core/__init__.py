"""Core modules for QuantFlow trading system."""
