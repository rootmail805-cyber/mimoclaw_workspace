"""
Position sizing framework for QuantFlow.
Implements multiple position sizing algorithms.
"""

from abc import ABC, abstractmethod
from typing import Optional
import numpy as np
from loguru import logger


class PositionSizer(ABC):
    """Abstract base for position sizing algorithms."""

    @abstractmethod
    def calculate_size(
        self,
        capital: float,
        price: float,
        stop_loss_price: Optional[float] = None,
        **kwargs,
    ) -> int:
        """Calculate the number of shares to trade.

        Args:
            capital: Available capital for this trade.
            price: Current price.
            stop_loss_price: Stop-loss price (for risk-based sizing).

        Returns:
            Number of shares (rounded to lot size).
        """
        pass

    @staticmethod
    def round_to_lot(size: int, lot_size: int = 100) -> int:
        """Round to nearest lot size (A-share: 100 shares per lot)."""
        return max(lot_size, (size // lot_size) * lot_size)


class FixedFractionSizer(PositionSizer):
    """Fixed fraction of capital per trade.

    Example: risk 2% of capital per trade.
    """

    def __init__(self, fraction: float = 0.10):
        """
        Args:
            fraction: Fraction of capital to allocate (0.0 ~ 1.0).
                      0.10 = allocate 10% of capital per trade.
        """
        if not 0 < fraction <= 1:
            raise ValueError(f"Fraction must be (0, 1], got {fraction}")
        self._fraction = fraction

    def calculate_size(self, capital: float, price: float, **kwargs) -> int:
        if price <= 0:
            return 0
        allocation = capital * self._fraction
        size = int(allocation / price)
        return self.round_to_lot(size)


class FixedRiskSizer(PositionSizer):
    """Risk a fixed percentage of capital per trade.

    Uses stop-loss distance to determine position size.
    Formula: shares = (capital × risk_pct) / (entry - stop_loss)
    """

    def __init__(self, risk_pct: float = 0.02):
        """
        Args:
            risk_pct: Maximum risk per trade as fraction of capital.
                      0.02 = risk at most 2% of capital.
        """
        if not 0 < risk_pct <= 1:
            raise ValueError(f"Risk pct must be (0, 1], got {risk_pct}")
        self._risk_pct = risk_pct

    def calculate_size(
        self, capital: float, price: float,
        stop_loss_price: Optional[float] = None, **kwargs,
    ) -> int:
        if price <= 0:
            return 0

        risk_amount = capital * self._risk_pct

        if stop_loss_price is not None and stop_loss_price > 0:
            risk_per_share = abs(price - stop_loss_price)
            if risk_per_share <= 0:
                return 0
            size = int(risk_amount / risk_per_share)
        else:
            # Fallback: use 2% of price as assumed risk
            size = int(risk_amount / (price * 0.02))

        return self.round_to_lot(size)


class ATRSizer(PositionSizer):
    """ATR-based position sizing.

    Uses Average True Range to dynamically adjust position size.
    Larger ATR → smaller position (more volatile = less size).
    Formula: shares = (capital × risk_pct) / (ATR × multiplier)
    """

    def __init__(self, risk_pct: float = 0.02, atr_multiplier: float = 2.0):
        """
        Args:
            risk_pct: Risk per trade as fraction of capital.
            atr_multiplier: Multiplier on ATR for stop distance.
        """
        self._risk_pct = risk_pct
        self._atr_mult = atr_multiplier

    def calculate_size(
        self, capital: float, price: float,
        atr_value: Optional[float] = None, **kwargs,
    ) -> int:
        if price <= 0:
            return 0

        risk_amount = capital * self._risk_pct

        if atr_value is not None and atr_value > 0:
            risk_per_share = atr_value * self._atr_mult
        else:
            # Fallback: estimate ATR as 2% of price
            risk_per_share = price * 0.02

        if risk_per_share <= 0:
            return 0

        size = int(risk_amount / risk_per_share)
        return self.round_to_lot(size)


class KellySizer(PositionSizer):
    """Kelly Criterion position sizing.

    Uses win rate and profit/loss ratio to determine optimal fraction.
    f* = (p × b - q) / b
    where p = win rate, q = 1-p, b = avg_win / avg_loss

    Applies half-Kelly for safety.
    """

    def __init__(self, half_kelly: bool = True, max_fraction: float = 0.25):
        self._half = half_kelly
        self._max_frac = max_fraction

    def calculate_size(
        self, capital: float, price: float,
        win_rate: Optional[float] = None,
        avg_win: Optional[float] = None,
        avg_loss: Optional[float] = None,
        **kwargs,
    ) -> int:
        if price <= 0 or capital <= 0:
            return 0

        if win_rate is None or avg_win is None or avg_loss is None or avg_loss == 0:
            # Default to 10% allocation if stats unavailable
            return FixedFractionSizer(0.10).calculate_size(capital, price)

        p = win_rate
        q = 1 - p
        b = abs(avg_win / avg_loss)

        if b == 0:
            return 0

        kelly_f = (p * b - q) / b

        if self._half:
            kelly_f /= 2.0

        # Cap at max fraction
        kelly_f = max(0, min(kelly_f, self._max_frac))

        allocation = capital * kelly_f
        size = int(allocation / price)
        return self.round_to_lot(size)


# ─── Factory ──────────────────────────────────────────────────────

def create_sizer(name: str, **kwargs) -> PositionSizer:
    """Create a position sizer by name.

    Supported: fixed_fraction, fixed_risk, atr, kelly
    """
    sizers = {
        "fixed_fraction": FixedFractionSizer,
        "fixed_risk": FixedRiskSizer,
        "atr": ATRSizer,
        "kelly": KellySizer,
    }
    cls = sizers.get(name)
    if cls is None:
        raise ValueError(f"Unknown sizer: {name}. Available: {list(sizers.keys())}")
    return cls(**kwargs)
