"""
Base strategy class for QuantFlow.
All strategies inherit from this and implement the required hooks.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
from datetime import datetime
import pandas as pd
import numpy as np
from loguru import logger

from ..models import Bar, Tick, Signal, SignalAction, Position


class BaseStrategy(ABC):
    """Abstract base strategy class.

    All trading strategies must inherit from this class and implement
    at least on_bar() or on_tick().

    Lifecycle:
        __init__ -> on_start -> on_bar/on_tick (repeated) -> on_stop

    Attributes:
        strategy_id: Unique identifier for this strategy instance.
        params: Strategy parameters dict.
        positions: Current positions by symbol.
        is_running: Whether the strategy is actively processing.
    """

    def __init__(self, strategy_id: str, params: Optional[Dict[str, Any]] = None):
        self.strategy_id = strategy_id
        self.params = params or {}
        self.positions: Dict[str, Position] = {}
        self.is_running = False
        self._bar_history: Dict[str, List[Bar]] = {}
        self._signals: List[Signal] = []
        self._logger = logger.bind(strategy=strategy_id)

    # === Lifecycle Hooks ===

    def on_start(self) -> None:
        """Called when the strategy starts. Override for initialization."""
        self.is_running = True
        self._logger.info(f"Strategy {self.strategy_id} started")

    def on_stop(self) -> None:
        """Called when the strategy stops. Override for cleanup."""
        self.is_running = False
        self._logger.info(f"Strategy {self.strategy_id} stopped")

    @abstractmethod
    def on_bar(self, bar: Bar) -> Optional[Signal]:
        """Called when a new bar (K-line) arrives.

        Args:
            bar: The new bar data.

        Returns:
            Signal or None.
        """
        pass

    def on_tick(self, tick: Tick) -> Optional[Signal]:
        """Called when a new tick arrives (optional, for tick-level strategies)."""
        return None

    def on_order(self, order_id: str, status: str, filled_price: float = 0.0) -> None:
        """Called when an order status changes."""
        self._logger.info(f"Order {order_id}: {status} @ {filled_price}")

    def on_trade(self, symbol: str, side: str, price: float, volume: int) -> None:
        """Called when a trade is executed."""
        self._update_position(symbol, side, price, volume)
        self._logger.info(f"Trade: {side} {volume} {symbol} @ {price}")

    # === Data Access Methods ===

    def get_close_prices(self, symbol: str, lookback: int = 20) -> np.ndarray:
        """Get recent close prices for a symbol."""
        history = self._bar_history.get(symbol, [])
        if not history:
            return np.array([])
        closes = [bar.close for bar in history[-lookback:]]
        return np.array(closes)

    def get_high_prices(self, symbol: str, lookback: int = 20) -> np.ndarray:
        """Get recent high prices for a symbol."""
        history = self._bar_history.get(symbol, [])
        if not history:
            return np.array([])
        return np.array([bar.high for bar in history[-lookback:]])

    def get_low_prices(self, symbol: str, lookback: int = 20) -> np.ndarray:
        """Get recent low prices for a symbol."""
        history = self._bar_history.get(symbol, [])
        if not history:
            return np.array([])
        return np.array([bar.low for bar in history[-lookback:]])

    def get_volume_history(self, symbol: str, lookback: int = 20) -> np.ndarray:
        """Get recent volume history for a symbol."""
        history = self._bar_history.get(symbol, [])
        if not history:
            return np.array([])
        return np.array([bar.volume for bar in history[-lookback:]])

    def get_bars(self, symbol: str, count: int = 100) -> List[Bar]:
        """Get recent bars for a symbol."""
        return self._bar_history.get(symbol, [])[-count:]

    def get_param(self, key: str, default: Any = None) -> Any:
        """Get a strategy parameter."""
        return self.params.get(key, default)

    # === Trend Filter ===

    def check_trend(
        self, symbol: str, direction: str, adx_period: int = 14, adx_threshold: float = 20.0,
    ) -> bool:
        """Check if the trend supports the intended trade direction.

        Uses ADX (Average Directional Index) to determine trend strength
        and +DI/-DI to determine trend direction.

        Args:
            symbol: Stock symbol.
            direction: "BUY" or "SELL".
            adx_period: ADX calculation period.
            adx_threshold: Minimum ADX for trend to be considered valid.

        Returns:
            True if trend supports the direction, False otherwise.
            Returns True if insufficient data (don't block signals on cold start).
        """
        from . import indicators as ind

        lookback = adx_period * 3 + 5
        bars = self.get_bars(symbol, lookback)
        if len(bars) < adx_period * 2 + 1:
            return True  # Not enough data, don't block

        highs = np.array([b.high for b in bars])
        lows = np.array([b.low for b in bars])
        closes = np.array([b.close for b in bars])

        adx_vals, plus_di, minus_di = ind.adx(highs, lows, closes, adx_period)

        curr_adx = adx_vals[-1]
        curr_plus = plus_di[-1]
        curr_minus = minus_di[-1]

        # ADX below threshold = no clear trend, allow all trades
        if curr_adx < adx_threshold:
            return True

        # Strong trend: only allow trades in the trend direction
        if direction == "BUY":
            return curr_plus > curr_minus  # Uptrend: +DI > -DI
        elif direction == "SELL":
            return curr_minus > curr_plus  # Downtrend: -DI > +DI

        return True

    # === Position Management ===

    def get_position(self, symbol: str) -> Position:
        """Get current position for a symbol."""
        if symbol not in self.positions:
            self.positions[symbol] = Position(symbol=symbol)
        return self.positions[symbol]

    def _update_position(self, symbol: str, side: str, price: float, volume: int) -> None:
        """Update position after a trade."""
        pos = self.get_position(symbol)

        if side == "BUY":
            # Update average cost
            total_cost = pos.avg_cost * pos.volume + price * volume
            pos.volume += volume
            pos.available_volume += volume  # Simplified: assume T+0 for backtest
            pos.avg_cost = total_cost / pos.volume if pos.volume > 0 else 0
            pos.today_buy_volume += volume
        elif side == "SELL":
            realized = (price - pos.avg_cost) * volume
            pos.realized_pnl += realized
            pos.volume -= volume
            pos.available_volume -= volume
            pos.today_sell_volume += volume
            if pos.volume <= 0:
                pos.volume = 0
                pos.avg_cost = 0
                pos.available_volume = 0

        pos.update_price(price)

    # === Internal Methods ===

    def _feed_bar(self, bar: Bar) -> Optional[Signal]:
        """Internal: feed a bar to the strategy."""
        if bar.symbol not in self._bar_history:
            self._bar_history[bar.symbol] = []
        self._bar_history[bar.symbol].append(bar)

        # Keep history bounded
        max_history = self.params.get("max_bar_history", 500)
        if len(self._bar_history[bar.symbol]) > max_history:
            self._bar_history[bar.symbol] = self._bar_history[bar.symbol][-max_history:]

        if not self.is_running:
            return None

        try:
            signal = self.on_bar(bar)
            if signal:
                self._signals.append(signal)
            return signal
        except Exception as e:
            self._logger.error(f"Error in on_bar: {e}")
            return None

    def _feed_tick(self, tick: Tick) -> Optional[Signal]:
        """Internal: feed a tick to the strategy."""
        if not self.is_running:
            return None
        try:
            return self.on_tick(tick)
        except Exception as e:
            self._logger.error(f"Error in on_tick: {e}")
            return None

    @property
    def signal_history(self) -> List[Signal]:
        return list(self._signals)

    def __repr__(self) -> str:
        return f"<Strategy:{self.strategy_id} running={self.is_running}>"
