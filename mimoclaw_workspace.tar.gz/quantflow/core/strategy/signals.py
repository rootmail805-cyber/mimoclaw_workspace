"""
⚠️ DEPRECATED - 此模块已废弃，未被系统任何组件引用。
保留代码供未来参考，但不应在新代码中使用。
如需使用其中的功能，请先集成到 GUI 和业务流程中。
"""

"""
Signal generation utilities for QuantFlow.
Common signal patterns and combinators.
"""

from typing import List, Optional
import numpy as np
from ..models import Signal, SignalAction


class SignalGenerator:
    """Utility class for generating common trading signals."""

    @staticmethod
    def crossover_signal(
        fast: np.ndarray,
        slow: np.ndarray,
        symbol: str,
        strategy_id: str,
        volume: int = 100,
    ) -> Optional[Signal]:
        """Generate signal on line crossover (fast crosses above/below slow).

        Returns BUY on golden cross, SELL on death cross, None otherwise.
        """
        if len(fast) < 2 or len(slow) < 2:
            return None

        prev_fast, curr_fast = fast[-2], fast[-1]
        prev_slow, curr_slow = slow[-2], slow[-1]

        # Golden cross: fast crosses above slow
        if prev_fast <= prev_slow and curr_fast > curr_slow:
            return Signal(
                symbol=symbol,
                action=SignalAction.BUY,
                volume=volume,
                strategy_id=strategy_id,
                reason=f"Golden cross: fast={curr_fast:.2f} > slow={curr_slow:.2f}",
            )

        # Death cross: fast crosses below slow
        if prev_fast >= prev_slow and curr_fast < curr_slow:
            return Signal(
                symbol=symbol,
                action=SignalAction.SELL,
                volume=volume,
                strategy_id=strategy_id,
                reason=f"Death cross: fast={curr_fast:.2f} < slow={curr_slow:.2f}",
            )

        return None

    @staticmethod
    def threshold_signal(
        indicator: np.ndarray,
        upper: float,
        lower: float,
        symbol: str,
        strategy_id: str,
        volume: int = 100,
    ) -> Optional[Signal]:
        """Generate signal when indicator crosses threshold levels.

        BUY when indicator drops below lower (oversold).
        SELL when indicator rises above upper (overbought).
        """
        if len(indicator) < 2:
            return None

        prev_val, curr_val = indicator[-2], indicator[-1]

        # Oversold bounce
        if prev_val <= lower and curr_val > lower:
            return Signal(
                symbol=symbol,
                action=SignalAction.BUY,
                volume=volume,
                strategy_id=strategy_id,
                reason=f"Oversold bounce: {prev_val:.2f} -> {curr_val:.2f} (threshold={lower})",
            )

        # Overbought reversal
        if prev_val >= upper and curr_val < upper:
            return Signal(
                symbol=symbol,
                action=SignalAction.SELL,
                volume=volume,
                strategy_id=strategy_id,
                reason=f"Overbought reversal: {prev_val:.2f} -> {curr_val:.2f} (threshold={upper})",
            )

        return None

    @staticmethod
    def momentum_signal(
        returns: np.ndarray,
        lookback: int = 20,
        threshold: float = 0.0,
        symbol: str = "",
        strategy_id: str = "",
        volume: int = 100,
    ) -> Optional[Signal]:
        """Generate signal based on momentum (cumulative returns over lookback)."""
        if len(returns) < lookback:
            return None

        momentum = np.sum(returns[-lookback:])

        if momentum > threshold:
            return Signal(
                symbol=symbol,
                action=SignalAction.BUY,
                volume=volume,
                confidence=min(abs(momentum) / 0.1, 1.0),
                strategy_id=strategy_id,
                reason=f"Momentum={momentum:.4f} > threshold={threshold}",
            )
        elif momentum < -threshold:
            return Signal(
                symbol=symbol,
                action=SignalAction.SELL,
                volume=volume,
                confidence=min(abs(momentum) / 0.1, 1.0),
                strategy_id=strategy_id,
                reason=f"Momentum={momentum:.4f} < -threshold={-threshold}",
            )

        return None
