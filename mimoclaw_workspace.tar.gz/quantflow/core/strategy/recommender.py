"""
⚠️ DEPRECATED - 此模块已废弃，未被系统任何组件引用。
保留代码供未来参考，但不应在新代码中使用。
如需使用其中的功能，请先集成到 GUI 和业务流程中。
"""

"""
Strategy Recommender Engine for QuantFlow.
Runs all strategies on a single stock, scores them, and recommends the best one.
"""

import time
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
import pandas as pd
import numpy as np
from loguru import logger

from config.manager import get_config
from core.data import DataManager
from core.backtest.engine import BacktestEngine
from core.backtest.performance import PerformanceAnalyzer


# ─── 评分权重配置 ─────────────────────────────────────────────────

SCORE_WEIGHTS = {
    "annualized_return":  0.30,   # 年化收益率 — 赚钱能力
    "sharpe_ratio":       0.25,   # 夏普比率 — 风险调整收益质量
    "max_drawdown":       0.20,   # 最大回撤 — 回撤越小越好（反向）
    "win_rate":           0.15,   # 胜率 — 交易胜率
    "profit_loss_ratio":  0.10,   # 盈亏比 — 赚亏比
}

# 每个指标的归一化范围（用于将原始值映射到 0-100）
METRIC_RANGES = {
    "annualized_return":  {"min": -0.20, "max": 0.50},   # -20% ~ +50%
    "sharpe_ratio":       {"min": -2.0,  "max": 3.0},    # -2 ~ +3
    "max_drawdown":       {"min": 0.0,   "max": 0.50},   # 0% ~ 50%（反向）
    "win_rate":           {"min": 0.0,   "max": 0.80},   # 0% ~ 80%
    "profit_loss_ratio":  {"min": 0.0,   "max": 3.0},    # 0 ~ 3
}


@dataclass
class StrategyScore:
    """单个策略的评分结果。"""
    strategy_id: str
    strategy_name: str
    # 原始指标
    total_return: float = 0.0
    annualized_return: float = 0.0
    max_drawdown: float = 0.0
    sharpe_ratio: float = 0.0
    sortino_ratio: float = 0.0
    calmar_ratio: float = 0.0
    win_rate: float = 0.0
    profit_loss_ratio: float = 0.0
    volatility: float = 0.0
    total_trades: int = 0
    elapsed_seconds: float = 0.0
    # 评分
    component_scores: Dict[str, float] = field(default_factory=dict)
    composite_score: float = 0.0
    rank: int = 0


@dataclass
class RecommendationResult:
    """推荐结果汇总。"""
    symbol: str
    period: str
    total_bars: int
    strategies_tested: int
    elapsed_seconds: float
    rankings: List[StrategyScore]
    best: Optional[StrategyScore] = None
    warning: Optional[str] = None


# ─── 策略名称映射 ─────────────────────────────────────────────────

STRATEGY_DISPLAY_NAMES = {
    "dual_ma":       "双均线策略",
    "macd":          "MACD 策略",
    "bollinger":     "布林带策略",
    "rsi":           "RSI 策略",
    "kdj":           "KDJ 随机指标",
    "atr_breakout":  "ATR 通道突破",
    "momentum":      "动量突破策略",
    "vwap":          "VWAP 策略",
}


class StrategyRecommender:
    """策略推荐引擎。

    流程:
        1. 拉取股票历史数据
        2. 逐个运行所有内置策略的回测
        3. 收集每个策略的绩效指标
        4. 对每个指标归一化并加权打分
        5. 排序并返回推荐结果
    """

    def __init__(self, config=None):
        self._config = config or get_config()
        self._data_mgr = DataManager(self._config)

    def recommend(
        self,
        symbol: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        freq: str = "daily",
        strategy_ids: Optional[List[str]] = None,
        progress_callback=None,
    ) -> RecommendationResult:
        """对指定股票运行所有策略并推荐最佳策略。

        Args:
            symbol: 股票代码（如 600000.SH）
            start: 开始日期（YYYY-MM-DD），默认近3年
            end: 结束日期（YYYY-MM-DD），默认今天
            freq: 数据频率
            strategy_ids: 指定策略列表，None 表示全部
            progress_callback: 进度回调 callback(current, total, strategy_name)

        Returns:
            RecommendationResult 包含排名和推荐
        """
        from datetime import datetime, timedelta

        if start is None:
            start = (datetime.now() - timedelta(days=365 * 3)).strftime("%Y-%m-%d")
        if end is None:
            end = datetime.now().strftime("%Y-%m-%d")

        # ── Step 1: 获取数据 ──
        logger.info(f"[Recommender] Fetching data: {symbol} ({start} ~ {end})")
        data = self._data_mgr.get_history(symbol, start, end, freq=freq)

        if data is None or data.empty:
            error_detail = self._data_mgr.last_error or "返回空数据"
            logger.error(f"[Recommender] Data fetch failed for {symbol}: {error_detail}")
            raise RuntimeError(
                f"无法获取 {symbol} 的历史数据 ({start}~{end})。\n"
                f"错误详情:\n{error_detail}\n\n"
                f"请检查: 1) 股票代码是否正确 2) 网络是否能访问东方财富API 3) akshare是否为最新版"
            )

        logger.info(f"[Recommender] Got {len(data)} bars")

        # ── Step 2: 获取策略列表 ──
        if strategy_ids is None:
            strategy_ids = ["dual_ma", "macd", "bollinger", "rsi", "kdj", "atr_breakout", "momentum", "vwap"]

        # ── Step 3: 逐个运行回测 ──
        scores: List[StrategyScore] = []
        total = len(strategy_ids)
        start_time = time.time()

        for idx, sid in enumerate(strategy_ids):
            if progress_callback:
                progress_callback(idx + 1, total, STRATEGY_DISPLAY_NAMES.get(sid, sid))

            try:
                score = self._run_single(sid, symbol, data, freq)
                scores.append(score)
                logger.info(
                    f"[Recommender] {sid}: return={score.annualized_return:.2%}, "
                    f"sharpe={score.sharpe_ratio:.4f}, mdd={score.max_drawdown:.2%}"
                )
            except Exception as e:
                logger.warning(f"[Recommender] Strategy {sid} failed: {e}")
                # 记录一个零分结果
                scores.append(StrategyScore(
                    strategy_id=sid,
                    strategy_name=STRATEGY_DISPLAY_NAMES.get(sid, sid),
                ))

        # ── Step 4: 打分 ──
        self._score_all(scores)

        # ── Step 5: 排序 ──
        scores.sort(key=lambda s: s.composite_score, reverse=True)
        for i, s in enumerate(scores):
            s.rank = i + 1

        # 检查是否所有策略都无交易（数据不足）
        all_zero = all(s.total_trades == 0 for s in scores)
        warning = None
        if all_zero:
            warning = (
                f"所有策略均未产生交易信号。数据量仅 {len(data)} 根K线，"
                f"大部分策略需要 50+ 根K线才能产生信号。"
                f"建议扩大日期范围（至少 1 年）。"
            )

        elapsed = time.time() - start_time
        best = scores[0] if scores and scores[0].total_trades > 0 else None

        best_name = best.strategy_name if best else 'N/A'
        best_score = best.composite_score if best else 0
        logger.info(f"[Recommender] Done in {elapsed:.1f}s. Best: {best_name} ({best_score:.0f}分)")

        return RecommendationResult(
            symbol=symbol,
            period=f"{start} ~ {end}",
            total_bars=len(data),
            strategies_tested=len(scores),
            elapsed_seconds=round(elapsed, 2),
            rankings=scores,
            best=best,
            warning=warning,
        )

    def _run_single(
        self, strategy_id: str, symbol: str, data: pd.DataFrame, freq: str,
    ) -> StrategyScore:
        """运行单个策略的回测并返回评分数据。"""
        # 导入策略类
        strategy_cls = self._get_strategy_class(strategy_id)
        if strategy_cls is None:
            raise ValueError(f"Unknown strategy: {strategy_id}")

        strategy = strategy_cls(
            strategy_id=f"rec_{strategy_id}_{symbol}",
            params={},
        )

        # 创建独立的回测引擎（不复用，避免状态污染）
        engine = BacktestEngine(self._config)
        engine.add_strategy(strategy)

        # 运行回测
        results = engine.run(data, symbol, freq)

        # 提取指标
        m = results.get("metrics", {})
        final_acct = results.get("final_account")

        return StrategyScore(
            strategy_id=strategy_id,
            strategy_name=STRATEGY_DISPLAY_NAMES.get(strategy_id, strategy_id),
            total_return=m.get("total_return", 0.0),
            annualized_return=m.get("annualized_return", 0.0),
            max_drawdown=m.get("max_drawdown", 0.0),
            sharpe_ratio=m.get("sharpe_ratio", 0.0),
            sortino_ratio=m.get("sortino_ratio", 0.0),
            calmar_ratio=m.get("calmar_ratio", 0.0),
            win_rate=m.get("win_rate", 0.0),
            profit_loss_ratio=m.get("profit_loss_ratio", 0.0),
            volatility=m.get("volatility", 0.0),
            total_trades=results.get("total_trades", 0),
            elapsed_seconds=results.get("elapsed_seconds", 0.0),
        )

    def _generate_synthetic_data(self, start: str, end: str) -> pd.DataFrame:
        """Generate synthetic OHLCV data with realistic trends and volatility."""
        import pandas as pd
        import numpy as np

        dates = pd.date_range(start, end, freq='B')
        if len(dates) == 0:
            return pd.DataFrame()

        np.random.seed(42)
        n = len(dates)

        # 生成有趋势的价格序列（多个阶段：上涨-盘整-下跌-上涨）
        # 比纯随机更接近真实股票行为
        returns = np.zeros(n)
        phase_len = n // 4
        returns[:phase_len] = np.random.normal(0.0015, 0.022, phase_len)       # 上涨阶段
        returns[phase_len:2*phase_len] = np.random.normal(0.0, 0.018, phase_len)  # 盘整
        returns[2*phase_len:3*phase_len] = np.random.normal(-0.001, 0.025, phase_len) # 下跌
        returns[3*phase_len:] = np.random.normal(0.001, 0.020, n - 3*phase_len)   # 反弹

        # 偶尔加入大波动（模拟涨跌停）
        for i in range(n):
            if np.random.random() < 0.02:  # 2%概率
                returns[i] = np.random.choice([-0.08, -0.05, 0.05, 0.08])

        prices = 10.0 * np.cumprod(1 + returns)

        # 生成成交量（上涨放量，下跌缩量）
        base_vol = np.random.randint(800000, 2000000, n).astype(float)
        for i in range(1, n):
            if returns[i] > 0.02:
                base_vol[i] *= 1.8  # 大涨放量
            elif returns[i] < -0.02:
                base_vol[i] *= 1.5  # 大跌也放量

        return pd.DataFrame({
            'open': prices * (1 + np.random.uniform(-0.008, 0.008, n)),
            'high': prices * (1 + abs(np.random.uniform(0, 0.015, n))),
            'low': prices * (1 - abs(np.random.uniform(0, 0.015, n))),
            'close': prices,
            'volume': base_vol.astype(int),
            'turnover': prices * base_vol,
        }, index=dates)

    def _get_strategy_class(self, strategy_id: str):
        """根据 strategy_id 获取策略类。"""
        from strategies.dual_ma import DualMAStrategy
        from strategies.macd_strategy import MACDStrategy
        from strategies.bollinger_strategy import BollingerStrategy
        from strategies.rsi_strategy import RSIStrategy
        from strategies.kdj_strategy import KDJStrategy
        from strategies.atr_breakout_strategy import ATRBreakoutStrategy
        from strategies.momentum_strategy import MomentumBreakoutStrategy
        from strategies.vwap_strategy import VWAPStrategy

        mapping = {
            "dual_ma": DualMAStrategy,
            "macd": MACDStrategy,
            "bollinger": BollingerStrategy,
            "rsi": RSIStrategy,
            "kdj": KDJStrategy,
            "atr_breakout": ATRBreakoutStrategy,
            "momentum": MomentumBreakoutStrategy,
            "vwap": VWAPStrategy,
        }
        return mapping.get(strategy_id)

    def _score_all(self, scores: List[StrategyScore]) -> None:
        """对所有策略进行归一化打分。"""
        if not scores:
            return

        # 对每个指标，收集所有策略的原始值
        raw_values: Dict[str, List[float]] = {}
        for metric_name in SCORE_WEIGHTS:
            raw_values[metric_name] = [getattr(s, metric_name, 0.0) for s in scores]

        # 逐个策略计算各指标得分
        for score in scores:
            component_total = 0.0

            for metric_name, weight in SCORE_WEIGHTS.items():
                raw = getattr(score, metric_name, 0.0)

                # 归一化到 0-100
                norm_score = self._normalize(metric_name, raw)

                # 最大回撤是反向指标：回撤越大，分数越低
                if metric_name == "max_drawdown":
                    norm_score = 100.0 - norm_score

                score.component_scores[metric_name] = round(norm_score, 1)
                component_total += norm_score * weight

            score.composite_score = round(component_total, 1)

    def _normalize(self, metric_name: str, value: float) -> float:
        """将原始指标值归一化到 0-100。

        使用配置的范围进行线性映射，超出范围则截断。
        """
        rng = METRIC_RANGES.get(metric_name)
        if rng is None:
            return 50.0  # 未知指标给中间分

        min_val = rng["min"]
        max_val = rng["max"]

        if max_val == min_val:
            return 50.0

        # 线性映射到 0-100
        normalized = (value - min_val) / (max_val - min_val) * 100.0

        # 截断到 0-100
        return max(0.0, min(100.0, normalized))


def format_recommendation(result: RecommendationResult) -> str:
    """将推荐结果格式化为可读文本。"""
    lines = []
    lines.append("═" * 60)
    lines.append(f"  策略推荐: {result.symbol} ({result.period})")
    lines.append("═" * 60)
    lines.append("")

    # 数据不足警告
    if result.warning:
        lines.append("  ⚠ 警告: " + result.warning)
        lines.append("")

    lines.append(f"  测试策略数: {result.strategies_tested}")
    lines.append(f"  数据量: {result.total_bars} 根K线")
    lines.append(f"  耗时: {result.elapsed_seconds:.1f} 秒")
    lines.append("")
    lines.append("─" * 60)
    lines.append(f"  {'排名':<4} {'策略':<14} {'综合分':>6} {'年化收益':>8} {'最大回撤':>8} {'夏普':>8}")
    lines.append("─" * 60)

    medals = {1: "🥇", 2: "🥈", 3: "🥉"}

    for s in result.rankings:
        medal = medals.get(s.rank, "  ")
        lines.append(
            f"  {medal}{s.rank:<2} {s.strategy_name:<12} "
            f"{s.composite_score:>5.0f}分 "
            f"{s.annualized_return:>7.2%} "
            f"{s.max_drawdown:>7.2%} "
            f"{s.sharpe_ratio:>8.2f}"
        )

    lines.append("─" * 60)

    if result.best:
        b = result.best
        lines.append("")
        lines.append(f"  💡 推荐策略: {b.strategy_name}")
        lines.append(f"     综合得分: {b.composite_score:.0f} 分")
        lines.append(f"     年化收益率: {b.annualized_return:.2%}")
        lines.append(f"     最大回撤: {b.max_drawdown:.2%}")
        lines.append(f"     夏普比率: {b.sharpe_ratio:.2f}")
        lines.append(f"     胜率: {b.win_rate:.2%}")
        lines.append(f"     盈亏比: {b.profit_loss_ratio:.2f}")
        lines.append(f"     总交易笔数: {b.total_trades}")
    elif result.warning:
        lines.append("")
        lines.append("  ❌ 无法推荐：所有策略均未产生交易信号")
        lines.append("     请扩大日期范围后重试（建议至少 1 年）")

    lines.append("═" * 60)
    return "\n".join(lines)
