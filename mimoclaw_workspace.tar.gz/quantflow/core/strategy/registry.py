"""
Strategy Registry for QuantFlow.
Manages strategy registration, instantiation, and lifecycle.
"""

from typing import Dict, Type, Optional, Any, List
from loguru import logger
from .base import BaseStrategy


class StrategyRegistry:
    """Registry for managing strategy classes and instances."""

    _classes: Dict[str, Type[BaseStrategy]] = {}
    _instances: Dict[str, BaseStrategy] = {}

    @classmethod
    def register(cls, name: Optional[str] = None):
        """Decorator to register a strategy class.

        Usage:
            @StrategyRegistry.register("dual_ma")
            class DualMAStrategy(BaseStrategy):
                ...
        """
        def decorator(strategy_cls: Type[BaseStrategy]):
            reg_name = name or strategy_cls.__name__
            cls._classes[reg_name] = strategy_cls
            logger.debug(f"Registered strategy: {reg_name}")
            return strategy_cls
        return decorator

    @classmethod
    def create(cls, name: str, strategy_id: str, params: Optional[Dict[str, Any]] = None) -> BaseStrategy:
        """Create a strategy instance by registered name."""
        if name not in cls._classes:
            raise ValueError(f"Strategy '{name}' not registered. Available: {list(cls._classes.keys())}")

        strategy_cls = cls._classes[name]
        instance = strategy_cls(strategy_id=strategy_id, params=params or {})
        cls._instances[strategy_id] = instance
        logger.info(f"Created strategy instance: {strategy_id} ({name})")
        return instance

    @classmethod
    def get_instance(cls, strategy_id: str) -> Optional[BaseStrategy]:
        """Get a running strategy instance by ID."""
        return cls._instances.get(strategy_id)

    @classmethod
    def list_registered(cls) -> List[str]:
        """List all registered strategy names."""
        return list(cls._classes.keys())

    @classmethod
    def list_instances(cls) -> List[str]:
        """List all active strategy instance IDs."""
        return list(cls._instances.keys())

    @classmethod
    def remove_instance(cls, strategy_id: str) -> None:
        """Remove a strategy instance."""
        if strategy_id in cls._instances:
            instance = cls._instances.pop(strategy_id)
            if instance.is_running:
                instance.on_stop()
            logger.info(f"Removed strategy instance: {strategy_id}")
