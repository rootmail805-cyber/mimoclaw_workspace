"""
Technical indicator library for QuantFlow.
Vectorized implementations using NumPy for maximum performance.
All functions operate on numpy arrays and return numpy arrays.
"""

import numpy as np
from typing import Tuple, Optional


def sma(data: np.ndarray, period: int) -> np.ndarray:
    """Simple Moving Average."""
    if len(data) < period:
        return np.full_like(data, np.nan)
    kernel = np.ones(period) / period
    result = np.convolve(data, kernel, mode='full')[:len(data)]
    result[:period - 1] = np.nan
    return result


def ema(data: np.ndarray, period: int, alpha: Optional[float] = None) -> np.ndarray:
    """Exponential Moving Average."""
    if alpha is None:
        alpha = 2.0 / (period + 1)
    result = np.empty_like(data, dtype=float)
    result[0] = data[0]
    for i in range(1, len(data)):
        result[i] = alpha * data[i] + (1 - alpha) * result[i - 1]
    return result


def macd(
    close: np.ndarray,
    fast: int = 12,
    slow: int = 26,
    signal: int = 9,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """MACD (Moving Average Convergence Divergence).

    Returns:
        (macd_line, signal_line, histogram)
    """
    ema_fast = ema(close, fast)
    ema_slow = ema(close, slow)
    macd_line = ema_fast - ema_slow
    signal_line = ema(macd_line, signal)
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram


def rsi(close: np.ndarray, period: int = 14) -> np.ndarray:
    """Relative Strength Index (Wilder's smoothing)."""
    deltas = np.diff(close)
    gains = np.where(deltas > 0, deltas, 0.0)
    losses = np.where(deltas < 0, -deltas, 0.0)

    result = np.empty(len(close), dtype=float)
    result[0] = 50.0  # Neutral for first bar

    if len(gains) < period:
        result[:] = 50.0
        return result

    # Initial averages
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])

    # Fill initial period
    for i in range(1, period + 1):
        result[i] = 50.0

    # Wilder's smoothing
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period

        if avg_loss == 0:
            result[i + 1] = 100.0
        else:
            rs = avg_gain / avg_loss
            result[i + 1] = 100.0 - (100.0 / (1.0 + rs))

    return result


def bollinger_bands(
    close: np.ndarray,
    period: int = 20,
    num_std: float = 2.0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Bollinger Bands.

    Returns:
        (upper, middle, lower)
    """
    middle = sma(close, period)
    std = np.empty_like(close, dtype=float)
    std[:] = np.nan

    for i in range(period - 1, len(close)):
        std[i] = np.std(close[i - period + 1:i + 1], ddof=0)

    upper = middle + num_std * std
    lower = middle - num_std * std
    return upper, middle, lower


def kdj(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    n: int = 9,
    m1: int = 3,
    m2: int = 3,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """KDJ Indicator (Stochastic Oscillator variant).

    Returns:
        (K, D, J)
    """
    length = len(close)
    rsv = np.zeros(length)

    for i in range(n - 1, length):
        highest = np.max(high[i - n + 1:i + 1])
        lowest = np.min(low[i - n + 1:i + 1])
        if highest == lowest:
            rsv[i] = 50.0
        else:
            rsv[i] = (close[i] - lowest) / (highest - lowest) * 100.0

    k = np.zeros(length)
    d = np.zeros(length)
    k[0] = 50.0
    d[0] = 50.0

    for i in range(1, length):
        k[i] = (2 * k[i - 1] + rsv[i]) / m1
        d[i] = (2 * d[i - 1] + k[i]) / m2

    j = 3 * k - 2 * d
    return k, d, j


def atr(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    period: int = 14,
) -> np.ndarray:
    """Average True Range."""
    length = len(close)
    tr = np.zeros(length)
    tr[0] = high[0] - low[0]

    for i in range(1, length):
        tr[i] = max(
            high[i] - low[i],
            abs(high[i] - close[i - 1]),
            abs(low[i] - close[i - 1]),
        )

    result = np.zeros(length)
    result[period - 1] = np.mean(tr[:period])
    for i in range(period, length):
        result[i] = (result[i - 1] * (period - 1) + tr[i]) / period

    return result


def obv(close: np.ndarray, volume: np.ndarray) -> np.ndarray:
    """On-Balance Volume."""
    result = np.zeros(len(close))
    result[0] = volume[0]
    for i in range(1, len(close)):
        if close[i] > close[i - 1]:
            result[i] = result[i - 1] + volume[i]
        elif close[i] < close[i - 1]:
            result[i] = result[i - 1] - volume[i]
        else:
            result[i] = result[i - 1]
    return result


def vwap(
    close: np.ndarray,
    volume: np.ndarray,
    high: Optional[np.ndarray] = None,
    low: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Volume-Weighted Average Price (cumulative)."""
    typical = close.copy()
    if high is not None and low is not None:
        typical = (high + low + close) / 3.0

    cum_tv = np.cumsum(typical * volume)
    cum_vol = np.cumsum(volume)
    # Avoid division by zero
    result = np.where(cum_vol > 0, cum_tv / cum_vol, close)
    return result


def williams_r(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    period: int = 14,
) -> np.ndarray:
    """Williams %R (range: -100 to 0)."""
    length = len(close)
    result = np.full(length, np.nan)

    for i in range(period - 1, length):
        highest = np.max(high[i - period + 1:i + 1])
        lowest = np.min(low[i - period + 1:i + 1])
        if highest == lowest:
            result[i] = -50.0
        else:
            result[i] = -100.0 * (highest - close[i]) / (highest - lowest)

    return result


def cci(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    period: int = 20,
) -> np.ndarray:
    """Commodity Channel Index."""
    tp = (high + low + close) / 3.0
    tp_sma = sma(tp, period)

    result = np.full(len(close), np.nan)
    for i in range(period - 1, len(close)):
        md = np.mean(np.abs(tp[i - period + 1:i + 1] - tp_sma[i]))
        if md == 0:
            result[i] = 0.0
        else:
            result[i] = (tp[i] - tp_sma[i]) / (0.015 * md)

    return result


def adx(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    period: int = 14,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Average Directional Index.

    Returns:
        (adx, plus_di, minus_di)
    """
    length = len(close)
    tr = np.zeros(length)
    plus_dm = np.zeros(length)
    minus_dm = np.zeros(length)

    for i in range(1, length):
        hl = high[i] - low[i]
        hc = abs(high[i] - close[i - 1])
        lc = abs(low[i] - close[i - 1])
        tr[i] = max(hl, hc, lc)

        up = high[i] - high[i - 1]
        down = low[i - 1] - low[i]

        if up > down and up > 0:
            plus_dm[i] = up
        if down > up and down > 0:
            minus_dm[i] = down

    # Smoothed TR and DM
    atr_vals = np.zeros(length)
    plus_dm_smooth = np.zeros(length)
    minus_dm_smooth = np.zeros(length)

    atr_vals[period] = np.sum(tr[1:period + 1])
    plus_dm_smooth[period] = np.sum(plus_dm[1:period + 1])
    minus_dm_smooth[period] = np.sum(minus_dm[1:period + 1])

    for i in range(period + 1, length):
        atr_vals[i] = atr_vals[i - 1] - atr_vals[i - 1] / period + tr[i]
        plus_dm_smooth[i] = plus_dm_smooth[i - 1] - plus_dm_smooth[i - 1] / period + plus_dm[i]
        minus_dm_smooth[i] = minus_dm_smooth[i - 1] - minus_dm_smooth[i - 1] / period + minus_dm[i]

    # DI
    plus_di = np.zeros(length)
    minus_di = np.zeros(length)
    dx = np.zeros(length)

    for i in range(period, length):
        if atr_vals[i] != 0:
            plus_di[i] = 100 * plus_dm_smooth[i] / atr_vals[i]
            minus_di[i] = 100 * minus_dm_smooth[i] / atr_vals[i]
        di_sum = plus_di[i] + minus_di[i]
        if di_sum != 0:
            dx[i] = 100 * abs(plus_di[i] - minus_di[i]) / di_sum

    # ADX
    adx_vals = np.zeros(length)
    adx_vals[2 * period - 1] = np.mean(dx[period:2 * period])
    for i in range(2 * period, length):
        adx_vals[i] = (adx_vals[i - 1] * (period - 1) + dx[i]) / period

    return adx_vals, plus_di, minus_di
