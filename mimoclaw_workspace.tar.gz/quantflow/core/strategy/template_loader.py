"""
Strategy template loader.
Reads YAML strategy templates from strategies/templates/ directory.
"""

import yaml
from pathlib import Path
from typing import List, Dict, Any, Optional
from loguru import logger


class StrategyTemplateLoader:
    """Load and manage strategy templates from YAML files."""

    def __init__(self, templates_dir: str = "./strategies/templates"):
        self._dir = Path(templates_dir)

    def load_all(self) -> List[Dict[str, Any]]:
        """Load all strategy templates."""
        templates = []
        if not self._dir.exists():
            logger.warning(f"Templates directory not found: {self._dir}")
            return templates

        for yaml_file in self._dir.glob("*.yaml"):
            try:
                template = self._load_file(yaml_file)
                if template:
                    templates.append(template)
            except Exception as e:
                logger.error(f"Failed to load template {yaml_file}: {e}")

        return templates

    def load(self, strategy_id: str) -> Optional[Dict[str, Any]]:
        """Load a specific strategy template by ID."""
        for yaml_file in self._dir.glob("*.yaml"):
            try:
                template = self._load_file(yaml_file)
                if template and template.get("strategy_id") == strategy_id:
                    return template
            except Exception:
                continue
        return None

    def _load_file(self, path: Path) -> Optional[Dict[str, Any]]:
        """Load a single YAML template file."""
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if data and isinstance(data, dict):
            data["_file"] = str(path)
            return data
        return None

    def get_risk_color(self, risk_level: str) -> str:
        """Get display color for risk level."""
        colors = {
            "low": "#00ff88",
            "medium": "#f59e0b",
            "high": "#ef4444",
        }
        return colors.get(risk_level, "#888888")

    def get_risk_label(self, risk_level: str) -> str:
        """Get display label for risk level."""
        labels = {
            "low": "低风险",
            "medium": "中风险",
            "high": "高风险",
        }
        return labels.get(risk_level, "未知")
