"""
Security audit and code integrity verification.

Provides:
    - AuditLogger: tamper-proof operation audit log with HMAC-signed chain
    - CodeIntegrityChecker: SHA256 hash verification of strategy code directories
"""

import hashlib
import hmac
import json
import os
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any

from loguru import logger


class AuditLogger:
    """Tamper-proof operation audit logger backed by SQLite.

    Each record includes an HMAC signature that chains to the previous record,
    forming a blockchain-like tamper-evident log. Any modification to a past
    record will invalidate all subsequent signatures.

    Args:
        db_path: Path to the SQLite database file.
        hmac_key: Secret key for HMAC signing. If not provided, reads from
            the environment variable specified by ``hmac_key_env``.
        hmac_key_env: Name of environment variable holding the HMAC key.
    """

    def __init__(
        self,
        db_path: str = "./data/audit.db",
        hmac_key: Optional[str] = None,
        hmac_key_env: str = "QUANT_AUDIT_HMAC_KEY",
    ):
        self._db_path = db_path
        self._hmac_key = hmac_key or os.environ.get(hmac_key_env, "default_audit_key_change_me")
        self._conn: Optional[sqlite3.Connection] = None
        self._init_db()

    def _init_db(self) -> None:
        """Initialize the SQLite database and create the audit table if needed."""
        db_dir = os.path.dirname(self._db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)

        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp   TEXT    NOT NULL,
                user        TEXT    NOT NULL,
                action      TEXT    NOT NULL,
                target      TEXT    NOT NULL,
                detail      TEXT    NOT NULL DEFAULT '',
                prev_hash   TEXT    NOT NULL,
                record_hash TEXT    NOT NULL,
                hmac_sig    TEXT    NOT NULL
            )
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_audit_timestamp
            ON audit_log(timestamp)
        """)
        self._conn.commit()

    def _compute_record_hash(
        self, timestamp: str, user: str, action: str,
        target: str, detail: str, prev_hash: str,
    ) -> str:
        """Compute SHA256 hash of the record content."""
        content = f"{timestamp}|{user}|{action}|{target}|{detail}|{prev_hash}"
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def _compute_hmac(self, record_hash: str) -> str:
        """Compute HMAC-SHA256 signature for a record hash."""
        return hmac.new(
            self._hmac_key.encode("utf-8"),
            record_hash.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def _get_last_hash(self) -> str:
        """Retrieve the record_hash of the most recent audit entry."""
        cursor = self._conn.execute(
            "SELECT record_hash FROM audit_log ORDER BY id DESC LIMIT 1"
        )
        row = cursor.fetchone()
        return row[0] if row else "GENESIS"

    def log(
        self,
        user: str,
        action: str,
        target: str,
        detail: str = "",
    ) -> int:
        """Append a new audit record.

        Args:
            user: Who performed the action (username or system identifier).
            action: What was done (e.g. "ORDER_SUBMIT", "PARAM_CHANGE").
            target: What was acted upon (e.g. order ID, config key).
            detail: Additional detail (JSON string recommended).

        Returns:
            The ID of the newly inserted record.
        """
        timestamp = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        prev_hash = self._get_last_hash()
        record_hash = self._compute_record_hash(
            timestamp, user, action, target, detail, prev_hash,
        )
        hmac_sig = self._compute_hmac(record_hash)

        cursor = self._conn.execute(
            """INSERT INTO audit_log
               (timestamp, user, action, target, detail, prev_hash, record_hash, hmac_sig)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (timestamp, user, action, target, detail, prev_hash, record_hash, hmac_sig),
        )
        self._conn.commit()

        record_id = cursor.lastrowid
        logger.info(f"Audit #{record_id}: {user} {action} {target}")
        return record_id

    def verify_chain(self) -> Dict[str, Any]:
        """Verify the integrity of the entire audit chain.

        Returns:
            Dict with keys:
                - valid (bool): True if the entire chain is intact.
                - total_records (int): Number of records checked.
                - first_invalid_id (int|None): ID of the first tampered record.
                - message (str): Human-readable summary.
        """
        cursor = self._conn.execute(
            "SELECT id, timestamp, user, action, target, detail, prev_hash, record_hash, hmac_sig "
            "FROM audit_log ORDER BY id ASC"
        )
        rows = cursor.fetchall()

        if not rows:
            return {
                "valid": True,
                "total_records": 0,
                "first_invalid_id": None,
                "message": "Empty audit log — nothing to verify.",
            }

        expected_prev = "GENESIS"
        for row in rows:
            record_id, timestamp, user, action, target, detail, prev_hash, record_hash, hmac_sig = row

            # Check chain link
            if prev_hash != expected_prev:
                return {
                    "valid": False,
                    "total_records": len(rows),
                    "first_invalid_id": record_id,
                    "message": f"Chain break at #{record_id}: prev_hash mismatch.",
                }

            # Recompute hash
            computed_hash = self._compute_record_hash(
                timestamp, user, action, target, detail, prev_hash,
            )
            if computed_hash != record_hash:
                return {
                    "valid": False,
                    "total_records": len(rows),
                    "first_invalid_id": record_id,
                    "message": f"Tampered record at #{record_id}: hash mismatch.",
                }

            # Verify HMAC
            computed_hmac = self._compute_hmac(record_hash)
            if computed_hmac != hmac_sig:
                return {
                    "valid": False,
                    "total_records": len(rows),
                    "first_invalid_id": record_id,
                    "message": f"HMAC mismatch at #{record_id}: signature invalid.",
                }

            expected_prev = record_hash

        return {
            "valid": True,
            "total_records": len(rows),
            "first_invalid_id": None,
            "message": f"All {len(rows)} records verified — chain intact.",
        }

    def query(
        self,
        user: Optional[str] = None,
        action: Optional[str] = None,
        target: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, str]]:
        """Query audit records with optional filters.

        Args:
            user: Filter by user.
            action: Filter by action type.
            target: Filter by target.
            since: ISO timestamp — only return records after this time.
            limit: Maximum number of records to return.

        Returns:
            List of record dicts.
        """
        conditions = []
        params = []

        if user:
            conditions.append("user = ?")
            params.append(user)
        if action:
            conditions.append("action = ?")
            params.append(action)
        if target:
            conditions.append("target = ?")
            params.append(target)
        if since:
            conditions.append("timestamp >= ?")
            params.append(since)

        where = " WHERE " + " AND ".join(conditions) if conditions else ""
        query = f"SELECT id, timestamp, user, action, target, detail FROM audit_log{where} ORDER BY id DESC LIMIT ?"
        params.append(limit)

        cursor = self._conn.execute(query, params)
        columns = ["id", "timestamp", "user", "action", "target", "detail"]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None

    def __del__(self):
        self.close()


class CodeIntegrityChecker:
    """SHA256-based code integrity checker for strategy directories.

    Generates a snapshot of all files in the watched directories and their
    SHA256 hashes. Later verification compares the current state against
    the baseline and reports any additions, modifications, or deletions.

    Args:
        watch_dirs: List of directory paths to monitor.
        baseline_path: Path to the JSON file storing the baseline snapshot.
    """

    def __init__(
        self,
        watch_dirs: Optional[List[str]] = None,
        baseline_path: str = "./data/code_baseline.json",
    ):
        self._watch_dirs = watch_dirs or ["./strategies", "./core/strategy"]
        self._baseline_path = baseline_path

    def _hash_file(self, filepath: str) -> str:
        """Compute SHA256 hash of a single file."""
        sha256 = hashlib.sha256()
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)
        return sha256.hexdigest()

    def _scan_dirs(self) -> Dict[str, str]:
        """Scan all watched directories and return {relative_path: sha256}."""
        hashes: Dict[str, str] = {}
        for watch_dir in self._watch_dirs:
            base = Path(watch_dir)
            if not base.exists():
                logger.warning(f"Watch directory does not exist: {watch_dir}")
                continue
            for filepath in sorted(base.rglob("*.py")):
                rel = str(filepath)
                try:
                    hashes[rel] = self._hash_file(str(filepath))
                except OSError as e:
                    logger.error(f"Failed to hash {filepath}: {e}")
        return hashes

    def snapshot(self) -> Dict[str, str]:
        """Generate and save a baseline snapshot.

        Returns:
            Dict mapping file paths to their SHA256 hashes.
        """
        hashes = self._scan_dirs()
        baseline_dir = os.path.dirname(self._baseline_path)
        if baseline_dir:
            os.makedirs(baseline_dir, exist_ok=True)

        snapshot_data = {
            "created_at": datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
            "file_count": len(hashes),
            "hashes": hashes,
        }

        with open(self._baseline_path, "w", encoding="utf-8") as f:
            json.dump(snapshot_data, f, indent=2, ensure_ascii=False)

        logger.info(f"Code integrity snapshot saved: {len(hashes)} files → {self._baseline_path}")
        return hashes

    def verify(self) -> Dict[str, Any]:
        """Verify current code state against the saved baseline.

        Returns:
            Dict with keys:
                - valid (bool): True if no changes detected.
                - added (list): Files present now but not in baseline.
                - modified (list): Files whose hash changed.
                - deleted (list): Files in baseline but missing now.
                - message (str): Human-readable summary.
        """
        if not os.path.exists(self._baseline_path):
            return {
                "valid": False,
                "added": [],
                "modified": [],
                "deleted": [],
                "message": "No baseline found. Run snapshot() first.",
            }

        with open(self._baseline_path, "r", encoding="utf-8") as f:
            baseline = json.load(f)

        baseline_hashes = baseline.get("hashes", {})
        current_hashes = self._scan_dirs()

        baseline_files = set(baseline_hashes.keys())
        current_files = set(current_hashes.keys())

        added = sorted(current_files - baseline_files)
        deleted = sorted(baseline_files - current_files)
        modified = sorted(
            f for f in baseline_files & current_files
            if baseline_hashes[f] != current_hashes[f]
        )

        valid = not added and not modified and not deleted

        if valid:
            message = f"Code integrity OK — {len(current_files)} files match baseline."
        else:
            parts = []
            if added:
                parts.append(f"{len(added)} added")
            if modified:
                parts.append(f"{len(modified)} modified")
            if deleted:
                parts.append(f"{len(deleted)} deleted")
            message = f"Code integrity ALERT: {', '.join(parts)}."

        result = {
            "valid": valid,
            "total_files": len(current_files),
            "baseline_created_at": baseline.get("created_at", "unknown"),
            "added": added,
            "modified": modified,
            "deleted": deleted,
            "message": message,
        }

        if not valid:
            logger.warning(message)
            if modified:
                for f in modified:
                    logger.warning(f"  Modified: {f}")
            if added:
                for f in added:
                    logger.warning(f"  Added: {f}")
            if deleted:
                for f in deleted:
                    logger.warning(f"  Deleted: {f}")

        return result
