"""
Security utilities for QuantFlow.
Credential encryption, input sanitization, sensitive data masking.
"""

import os
import base64
import hashlib
import json
import re
from pathlib import Path
from typing import Optional
from loguru import logger

# ── Credential Encryption ──────────────────────────────────────

_KEY_FILE = Path("./data/.encryption_key")


def _get_or_create_key() -> bytes:
    """Get or create a local encryption key."""
    if _KEY_FILE.exists():
        return base64.b64decode(_KEY_FILE.read_text().strip())
    # Generate random key
    key = os.urandom(32)
    _KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
    _KEY_FILE.write_text(base64.b64encode(key).decode())
    # Restrict file permissions (Unix-like systems)
    try:
        os.chmod(str(_KEY_FILE), 0o600)
    except (OSError, AttributeError):
        pass
    return key


def encrypt_credential(plaintext: str) -> str:
    """Encrypt a credential string using XOR + base64.

    Note: This is a lightweight encryption suitable for local storage.
    For production, consider using the `cryptography` library with Fernet.
    """
    if not plaintext:
        return ""
    key = _get_or_create_key()
    # XOR encryption
    data = plaintext.encode("utf-8")
    encrypted = bytes(b ^ key[i % len(key)] for i, b in enumerate(data))
    return base64.b64encode(encrypted).decode("ascii")


def decrypt_credential(ciphertext: str) -> str:
    """Decrypt a credential string."""
    if not ciphertext:
        return ""
    key = _get_or_create_key()
    try:
        data = base64.b64decode(ciphertext)
        decrypted = bytes(b ^ key[i % len(key)] for i, b in enumerate(data))
        return decrypted.decode("utf-8")
    except Exception as e:
        logger.error(f"Failed to decrypt credential: {e}")
        return ""


# ── Sensitive Data Masking ─────────────────────────────────────

_SENSITIVE_PATTERNS = [
    (re.compile(r'(password|passwd|pwd|token|secret|api_key|apikey)\s*[=:]\s*\S+', re.IGNORECASE),
     r'\1=***MASKED***'),
    (re.compile(r'(\d{6})(\d{6})(\d{4})'), r'\1******\3'),  # ID card
    (re.compile(r'(\d{4})(\d{4})(\d{4})(\d{4})'), r'\1****\3****'),  # Bank card
]


def mask_sensitive(text: str) -> str:
    """Mask sensitive information in text."""
    for pattern, replacement in _SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def mask_webhook_url(url: str) -> str:
    """Mask webhook URL for logging."""
    if not url:
        return ""
    if len(url) > 20:
        return url[:15] + "***" + url[-5:]
    return "***"


# ── Input Sanitization ─────────────────────────────────────────

def sanitize_symbol(symbol: str) -> str:
    """Sanitize stock symbol input."""
    if not symbol:
        return ""
    # Only allow alphanumeric, dots, underscores
    cleaned = re.sub(r'[^a-zA-Z0-9._]', '', symbol.strip())
    return cleaned[:20]  # Max length


def sanitize_number(value: str, min_val: float = None, max_val: float = None) -> Optional[float]:
    """Sanitize numeric input."""
    try:
        num = float(value)
        if min_val is not None and num < min_val:
            return None
        if max_val is not None and num > max_val:
            return None
        return num
    except (ValueError, TypeError):
        return None


# ── Config Security ────────────────────────────────────────────

def load_secure_config(config_path: str = "./config/settings.yaml") -> dict:
    """Load config with credential decryption."""
    import yaml
    path = Path(config_path)
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}

    # Decrypt credential fields
    credential_paths = [
        ("execution", "qmt", "password"),
        ("notification", "dingtalk", "webhook"),
        ("notification", "wechat", "token"),
        ("data", "sources", "tushare_token"),
    ]
    for path_keys in credential_paths:
        obj = config
        for key in path_keys[:-1]:
            obj = obj.get(key, {})
        final_key = path_keys[-1]
        if final_key in obj and obj[final_key]:
            # Check if it looks encrypted (base64)
            val = str(obj[final_key])
            if not val.startswith("plain:"):
                try:
                    obj[final_key] = decrypt_credential(val)
                except Exception:
                    pass  # Keep original value if decryption fails
    return config


# ── Network Security ───────────────────────────────────────────

def validate_url(url: str) -> bool:
    """Validate URL is safe (not SSRF)."""
    if not url:
        return False
    # Only allow http/https
    if not url.startswith(("http://", "https://")):
        return False
    # Block internal IPs
    import ipaddress
    from urllib.parse import urlparse
    try:
        parsed = urlparse(url)
        host = parsed.hostname
        if host:
            # Block localhost and private IPs
            if host in ("localhost", "127.0.0.1", "0.0.0.0", "::1"):
                return False
            try:
                ip = ipaddress.ip_address(host)
                if ip.is_private or ip.is_loopback or ip.is_link_local:
                    return False
            except ValueError:
                pass  # hostname, not IP - OK
        return True
    except Exception:
        return False
