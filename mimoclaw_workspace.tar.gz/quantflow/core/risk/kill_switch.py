"""
Kill Switch for QuantFlow.
Emergency stop mechanism for all trading activity.
"""

from datetime import datetime
from typing import Optional
from loguru import logger

from ..models import AccountInfo


class KillSwitch:
    """Emergency trading halt mechanism.

    Features:
        - Manual trigger
        - Automatic trigger on drawdown threshold
        - State persistence
        - Logging of all trigger events
    """

    def __init__(self, config):
        self._auto_drawdown_pct = config.get("risk.kill_switch.auto_trigger_drawdown_pct", 0.20)
        self._enabled = config.get("risk.kill_switch.enabled", True)
        self._triggered = False
        self._trigger_reason = ""
        self._trigger_time: Optional[datetime] = None
        self._initial_equity: Optional[float] = None

    def check_drawdown(self, account: AccountInfo) -> bool:
        """Check if drawdown exceeds threshold and trigger if needed.

        Returns True if kill switch was triggered.
        """
        if not self._enabled or self._triggered:
            return self._triggered

        # Set initial equity on first call
        if self._initial_equity is None:
            self._initial_equity = account.total_assets
            return False

        if self._initial_equity <= 0:
            return False

        drawdown = (self._initial_equity - account.total_assets) / self._initial_equity

        if drawdown >= self._auto_drawdown_pct:
            self.trigger(
                f"Auto-triggered: drawdown {drawdown:.2%} >= threshold {self._auto_drawdown_pct:.2%}"
            )
            return True

        return False

    def trigger(self, reason: str = "Manual trigger") -> None:
        """Trigger the kill switch."""
        if self._triggered:
            return

        self._triggered = True
        self._trigger_reason = reason
        self._trigger_time = datetime.now()

        logger.critical(f"🔴 KILL SWITCH TRIGGERED: {reason}")
        logger.critical(f"   Time: {self._trigger_time.isoformat()}")
        logger.critical("   ALL TRADING ACTIVITY IS HALTED")

    def reset(self) -> None:
        """Reset the kill switch (requires explicit action)."""
        if not self._triggered:
            return

        logger.warning(f"Kill switch reset (was triggered: {self._trigger_reason})")
        self._triggered = False
        self._trigger_reason = ""
        self._trigger_time = None
        self._initial_equity = None  # Will be re-set on next check

    def is_triggered(self) -> bool:
        """Check if kill switch is currently active."""
        return self._triggered

    @property
    def status(self) -> dict:
        """Get kill switch status."""
        return {
            "enabled": self._enabled,
            "triggered": self._triggered,
            "reason": self._trigger_reason,
            "trigger_time": self._trigger_time.isoformat() if self._trigger_time else None,
            "drawdown_threshold": self._auto_drawdown_pct,
        }
