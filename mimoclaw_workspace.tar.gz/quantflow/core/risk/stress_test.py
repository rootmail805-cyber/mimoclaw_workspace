"""
压力测试与情景分析引擎
模拟极端市场情景下策略组合的表现，评估最大可能亏损和风险暴露。

支持三种模式：
1. 历史情景回放：使用真实历史极端行情数据（2015股灾/2018贸易战/2020疫情）
2. 自定义情景：用户定义涨跌幅/波动率/相关性变化
3. 蒙特卡洛模拟：随机生成大量情景，计算风险分布
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from loguru import logger


# ── 预设历史情景 ──────────────────────────────────────────────

@dataclass
class StressScenario:
    """压力测试情景"""
    name: str
    description: str
    market_shock: float          # 大盘冲击幅度（如-0.30 = 跌30%）
    volatility_spike: float      # 波动率放大倍数（如2.0 = 波动率翻倍）
    duration_days: int           # 持续天数
    recovery_days: int           # 恢复天数
    sector_shocks: Dict[str, float] = field(default_factory=dict)  # 行业冲击
    correlation_increase: float = 0.3  # 相关性增加幅度


HISTORICAL_SCENARIOS = [
    StressScenario(
        name="2015年A股股灾",
        description="杠杆牛市崩盘，千股跌停，流动性枯竭",
        market_shock=-0.45,
        volatility_spike=4.0,
        duration_days=25,
        recovery_days=180,
        sector_shocks={"金融": -0.40, "科技": -0.55, "消费": -0.35, "周期": -0.50},
        correlation_increase=0.5,
    ),
    StressScenario(
        name="2018年中美贸易战",
        description="贸易摩擦升级，市场持续阴跌",
        market_shock=-0.30,
        volatility_spike=2.0,
        duration_days=120,
        recovery_days=200,
        sector_shocks={"出口": -0.40, "科技": -0.35, "消费": -0.20, "内需": -0.15},
        correlation_increase=0.3,
    ),
    StressScenario(
        name="2020年新冠疫情冲击",
        description="全球疫情爆发，市场恐慌性抛售",
        market_shock=-0.16,
        volatility_spike=3.0,
        duration_days=20,
        recovery_days=60,
        sector_shocks={"航空": -0.40, "旅游": -0.35, "医药": 0.10, "科技": -0.10},
        correlation_increase=0.4,
    ),
    StressScenario(
        name="极端单日暴跌",
        description="类似2015.7.8千股跌停，单日极端冲击",
        market_shock=-0.08,
        volatility_spike=5.0,
        duration_days=1,
        recovery_days=10,
        sector_shocks={},
        correlation_increase=0.7,
    ),
    StressScenario(
        name="持续阴跌（慢熊）",
        description="类似2011-2013年长期低迷",
        market_shock=-0.25,
        volatility_spike=1.2,
        duration_days=250,
        recovery_days=500,
        sector_shocks={},
        correlation_increase=0.2,
    ),
]


@dataclass
class StressTestResult:
    """压力测试结果"""
    scenario_name: str
    description: str
    # 冲击参数
    market_shock: float
    volatility_spike: float
    duration_days: int
    # 组合表现
    portfolio_loss: float = 0.0       # 组合最大亏损
    portfolio_loss_pct: float = 0.0   # 组合最大亏损比例
    max_drawdown: float = 0.0         # 最大回撤
    recovery_days: int = 0            # 预计恢复天数
    # 个股表现
    worst_position: str = ""          # 最差持仓
    worst_position_loss: float = 0.0  # 最差持仓亏损
    # 风险指标
    var_99: float = 0.0               # 99% VaR
    cvar_99: float = 0.0              # 99% CVaR
    # 建议
    recommendation: str = ""


@dataclass
class MonteCarloResult:
    """蒙特卡洛模拟结果"""
    n_simulations: int
    n_days: int
    # 收益分布
    mean_return: float = 0.0
    median_return: float = 0.0
    std_return: float = 0.0
    # 风险指标
    var_95: float = 0.0
    var_99: float = 0.0
    cvar_95: float = 0.0
    cvar_99: float = 0.0
    # 概率
    prob_loss_5pct: float = 0.0
    prob_loss_10pct: float = 0.0
    prob_loss_20pct: float = 0.0
    prob_profit: float = 0.0
    # 回撤
    median_max_drawdown: float = 0.0
    worst_max_drawdown: float = 0.0
    # 分位数
    percentile_5: float = 0.0
    percentile_25: float = 0.0
    percentile_75: float = 0.0
    percentile_95: float = 0.0


class StressTestEngine:
    """压力测试引擎"""

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._scenarios = list(HISTORICAL_SCENARIOS)

    def add_custom_scenario(self, scenario: StressScenario):
        """添加自定义情景"""
        self._scenarios.append(scenario)

    def run_scenario(
        self,
        scenario: StressScenario,
        positions: Dict[str, Any],
        total_assets: float,
        daily_returns: Optional[List[float]] = None,
    ) -> StressTestResult:
        """执行单个情景的压力测试

        Args:
            scenario: 压力测试情景
            positions: 持仓 {symbol: Position}
            total_assets: 总资产
            daily_returns: 历史日收益率（用于波动率估算）

        Returns:
            StressTestResult
        """
        result = StressTestResult(
            scenario_name=scenario.name,
            description=scenario.description,
            market_shock=scenario.market_shock,
            volatility_spike=scenario.volatility_spike,
            duration_days=scenario.duration_days,
        )

        # 计算组合在该情景下的损失
        total_loss = 0.0
        worst_loss = 0.0
        worst_sym = ""

        for symbol, pos in positions.items():
            pos_value = pos.volume * (pos.current_price if pos.current_price > 0 else pos.avg_cost)

            # 基础冲击 = 大盘冲击 * Beta近似值
            # 简化：假设所有股票Beta=1，实际应根据历史数据计算
            shock = scenario.market_shock

            # 叠加行业冲击（如果有的话）
            # 简化：随机分配行业
            for sector, sector_shock in scenario.sector_shocks.items():
                # 简化处理：使用大盘冲击
                pass

            pos_loss = pos_value * shock
            total_loss += pos_loss

            if pos_loss < worst_loss:
                worst_loss = pos_loss
                worst_sym = symbol

        result.portfolio_loss = total_loss
        result.portfolio_loss_pct = total_loss / total_assets if total_assets > 0 else 0
        result.worst_position = worst_sym
        result.worst_position_loss = worst_loss

        # 最大回撤估算
        result.max_drawdown = abs(result.portfolio_loss_pct) * 1.2  # 考虑路径依赖

        # 恢复天数估算（简化：假设月均恢复2%）
        if result.portfolio_loss_pct < 0:
            months_to_recover = abs(result.portfolio_loss_pct) / 0.02
            result.recovery_days = int(months_to_recover * 21)

        # VaR/CVaR估算
        if daily_returns and len(daily_returns) >= 20:
            returns = np.array(daily_returns)
            vol = np.std(returns) * np.sqrt(252)
            # 调整后的VaR
            adjusted_vol = vol * scenario.volatility_spike
            result.var_99 = -adjusted_vol * 2.33 / np.sqrt(252)  # 日度99% VaR
            result.cvar_99 = result.var_99 * 1.3  # CVaR通常比VaR大30%

        # 建议
        if abs(result.portfolio_loss_pct) > 0.20:
            result.recommendation = (
                f"🚨 严重风险！在{scenario.name}情景下预计亏损{abs(result.portfolio_loss_pct):.1%}。"
                f"建议：1)降低仓位 2)增加对冲 3)分散行业集中度"
            )
        elif abs(result.portfolio_loss_pct) > 0.10:
            result.recommendation = (
                f"⚠️ 较高风险。预计亏损{abs(result.portfolio_loss_pct):.1%}。"
                f"建议：适当降低仓位或增加防御性持仓。"
            )
        else:
            result.recommendation = (
                f"✅ 风险可控。预计亏损{abs(result.portfolio_loss_pct):.1%}，"
                f"在可接受范围内。"
            )

        return result

    def run_all_scenarios(
        self,
        positions: Dict[str, Any],
        total_assets: float,
        daily_returns: Optional[List[float]] = None,
    ) -> List[StressTestResult]:
        """执行所有预设情景的压力测试"""
        results = []
        for scenario in self._scenarios:
            try:
                result = self.run_scenario(scenario, positions, total_assets, daily_returns)
                results.append(result)
            except Exception as e:
                logger.error(f"[StressTest] {scenario.name} 失败: {e}")
        return results

    def monte_carlo_simulation(
        self,
        daily_returns: List[float],
        current_equity: float,
        n_simulations: int = 1000,
        n_days: int = 63,
    ) -> MonteCarloResult:
        """蒙特卡洛模拟

        Args:
            daily_returns: 历史日收益率
            current_equity: 当前权益
            n_simulations: 模拟次数
            n_days: 模拟天数

        Returns:
            MonteCarloResult
        """
        result = MonteCarloResult(n_simulations=n_simulations, n_days=n_days)

        if not daily_returns or len(daily_returns) < 20:
            return result

        returns = np.array(daily_returns)

        # 生成模拟路径
        np.random.seed(42)
        simulated = np.random.choice(returns, size=(n_simulations, n_days), replace=True)

        # 计算累计收益
        cumulative = np.cumprod(1 + simulated, axis=1)
        equity_paths = current_equity * cumulative

        # 最终收益
        if current_equity > 0:
            final_returns = (equity_paths[:, -1] - current_equity) / current_equity
        else:
            final_returns = np.zeros(n_simulations)

        result.mean_return = float(np.mean(final_returns))
        result.median_return = float(np.median(final_returns))
        result.std_return = float(np.std(final_returns))

        # 分位数
        result.var_95 = float(np.percentile(final_returns, 5))
        result.var_99 = float(np.percentile(final_returns, 1))
        result.percentile_5 = result.var_95
        result.percentile_25 = float(np.percentile(final_returns, 25))
        result.percentile_75 = float(np.percentile(final_returns, 75))
        result.percentile_95 = float(np.percentile(final_returns, 95))

        # CVaR
        tail_95 = final_returns[final_returns <= result.var_95]
        result.cvar_95 = float(np.mean(tail_95)) if len(tail_95) > 0 else result.var_95
        tail_99 = final_returns[final_returns <= result.var_99]
        result.cvar_99 = float(np.mean(tail_99)) if len(tail_99) > 0 else result.var_99

        # 概率
        result.prob_loss_5pct = float(np.mean(final_returns < -0.05))
        result.prob_loss_10pct = float(np.mean(final_returns < -0.10))
        result.prob_loss_20pct = float(np.mean(final_returns < -0.20))
        result.prob_profit = float(np.mean(final_returns > 0))

        # 最大回撤
        max_dds = []
        for path in equity_paths:
            peak = np.maximum.accumulate(path)
            # 保护除零
            safe_peak = np.where(peak == 0, 1.0, peak)
            dd = (path - peak) / safe_peak
            max_dds.append(float(np.abs(dd.min())))
        result.median_max_drawdown = float(np.median(max_dds))
        result.worst_max_drawdown = float(np.max(max_dds))

        return result

    def format_scenario_result(self, result: StressTestResult) -> str:
        """格式化情景测试结果"""
        lines = [
            f"═══ 压力测试: {result.scenario_name} ═══",
            f"描述: {result.description}",
            f"",
            f"冲击参数:",
            f"  大盘冲击: {result.market_shock:+.1%}",
            f"  波动率放大: {result.volatility_spike:.1f}x",
            f"  持续天数: {result.duration_days}天",
            f"",
            f"组合影响:",
            f"  预计亏损: ¥{result.portfolio_loss:+,.0f} ({result.portfolio_loss_pct:+.1%})",
            f"  最大回撤: {result.max_drawdown:.1%}",
            f"  预计恢复: {result.recovery_days}天",
            f"  最差持仓: {result.worst_position} (¥{result.worst_position_loss:+,.0f})",
        ]
        if result.var_99 != 0:
            lines.append(f"  99% VaR: {result.var_99:.2%}")
            lines.append(f"  99% CVaR: {result.cvar_99:.2%}")
        lines.append(f"")
        lines.append(f"建议: {result.recommendation}")
        return "\n".join(lines)

    def format_monte_carlo(self, result: MonteCarloResult) -> str:
        """格式化蒙特卡洛模拟结果"""
        lines = [
            f"═══ 蒙特卡洛模拟 ═══",
            f"模拟次数: {result.n_simulations}",
            f"模拟天数: {result.n_days}",
            f"",
            f"收益分布:",
            f"  均值: {result.mean_return:+.2%}",
            f"  中位数: {result.median_return:+.2%}",
            f"  标准差: {result.std_return:.2%}",
            f"",
            f"风险指标:",
            f"  5% VaR: {result.var_95:+.2%}",
            f"  1% VaR: {result.var_99:+.2%}",
            f"  5% CVaR: {result.cvar_95:+.2%}",
            f"",
            f"概率:",
            f"  盈利概率: {result.prob_profit:.1%}",
            f"  亏损>5%概率: {result.prob_loss_5pct:.1%}",
            f"  亏损>10%概率: {result.prob_loss_10pct:.1%}",
            f"  亏损>20%概率: {result.prob_loss_20pct:.1%}",
            f"",
            f"回撤:",
            f"  中位数最大回撤: {result.median_max_drawdown:.1%}",
            f"  最差最大回撤: {result.worst_max_drawdown:.1%}",
            f"",
            f"分位数:",
            f"  5%: {result.percentile_5:+.2%}",
            f"  25%: {result.percentile_25:+.2%}",
            f"  75%: {result.percentile_75:+.2%}",
            f"  95%: {result.percentile_95:+.2%}",
        ]
        return "\n".join(lines)
