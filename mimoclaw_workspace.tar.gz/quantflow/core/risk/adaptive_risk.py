"""
波动率自适应风控管理器
根据市场波动率动态调整风控参数，比固定阈值更智能。

核心思路：
- 低波动时期：收紧风控（止损更近、仓位更小）
- 高波动时期：适度放宽（给予策略更大的波动空间）
- 波动率飙升时：紧急降仓或暂停交易
"""

import numpy as np
from typing import Dict, Optional, Any, Tuple
from dataclasses import dataclass
from datetime import datetime
from loguru import logger


@dataclass
class AdaptiveRiskParams:
    """自适应风控参数"""
    # 动态止损（基于ATR倍数）
    stop_loss_atr_multiplier: float = 2.0    # 止损 = 入场价 - N * ATR
    take_profit_atr_multiplier: float = 3.5  # 止盈 = 入场价 + N * ATR

    # 动态仓位（基于波动率反比）
    max_position_pct: float = 0.60           # 最大单票持仓占比
    volatility_budget: float = 0.15          # 组合年化波动率预算

    # 波动率阈值
    vol_normal_low: float = 0.15             # 低波动阈值（年化15%）
    vol_normal_high: float = 0.30            # 高波动阈值（年化30%）
    vol_extreme: float = 0.50                # 极端波动阈值（年化50%）

    # 熔断（自适应）
    circuit_breaker_base: float = 0.05       # 基础熔断阈值5%
    circuit_breaker_vol_factor: float = 1.5  # 波动率调整系数


@dataclass
class RiskState:
    """当前风控状态"""
    current_volatility: float = 0.0          # 当前年化波动率
    volatility_percentile: float = 0.0       # 波动率百分位（0-100）
    regime: str = "normal"                   # low / normal / high / extreme
    adjusted_stop_pct: float = 0.03          # 调整后的止损百分比
    adjusted_max_position: float = 0.60      # 调整后的最大仓位
    adjusted_circuit_breaker: float = 0.05   # 调整后的熔断阈值
    recommendation: str = ""                 # 风控建议
    should_reduce_position: bool = False     # 是否建议降仓
    should_pause_trading: bool = False       # 是否建议暂停交易


class AdaptiveRiskManager:
    """波动率自适应风控管理器"""

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._params = AdaptiveRiskParams()
        self._vol_history: list = []  # 历史波动率记录
        self._max_vol_history = 252   # 保留1年的波动率数据

    @property
    def params(self) -> AdaptiveRiskParams:
        return self._params

    def update_params(self, **kwargs):
        """更新风控参数"""
        for key, value in kwargs.items():
            if hasattr(self._params, key):
                setattr(self._params, key, value)

    def calculate_risk_state(
        self,
        daily_returns: list,
        current_price: float = 0.0,
        avg_cost: float = 0.0,
        position_pct: float = 0.0,
    ) -> RiskState:
        """根据当前市场状态计算自适应风控参数

        Args:
            daily_returns: 近N日的日收益率列表
            current_price: 当前价格
            avg_cost: 持仓成本
            position_pct: 当前仓位占比

        Returns:
            RiskState 风控状态
        """
        state = RiskState()

        if not daily_returns or len(daily_returns) < 10:
            state.recommendation = "数据不足，使用默认风控参数"
            return state

        returns = np.array(daily_returns)

        # 计算当前波动率（近20日年化）
        recent_vol = np.std(returns[-20:]) * np.sqrt(252)
        state.current_volatility = recent_vol

        # 记录波动率历史
        self._vol_history.append(recent_vol)
        if len(self._vol_history) > self._max_vol_history:
            self._vol_history = self._vol_history[-self._max_vol_history:]

        # 计算波动率百分位
        if len(self._vol_history) >= 5:
            state.volatility_percentile = (
                sum(1 for v in self._vol_history if v <= recent_vol)
                / len(self._vol_history) * 100
            )

        # 判断波动率区间
        p = self._params
        if recent_vol < p.vol_normal_low:
            state.regime = "low"
        elif recent_vol < p.vol_normal_high:
            state.regime = "normal"
        elif recent_vol < p.vol_extreme:
            state.regime = "high"
        else:
            state.regime = "extreme"

        # ── 自适应止损 ──
        # 波动率越高，止损距离越宽（给策略更多呼吸空间）
        vol_ratio = recent_vol / p.vol_normal_high  # 相对于正常波动的倍数
        vol_ratio = max(0.5, min(vol_ratio, 3.0))   # 限制在0.5-3倍

        base_stop_pct = p.circuit_breaker_base * 0.6  # 基础止损3%
        state.adjusted_stop_pct = round(base_stop_pct * vol_ratio, 4)

        # ── 自适应最大仓位 ──
        # 波动率越高，允许的最大仓位越小
        if state.regime == "low":
            state.adjusted_max_position = p.max_position_pct
        elif state.regime == "normal":
            state.adjusted_max_position = p.max_position_pct * 0.9
        elif state.regime == "high":
            state.adjusted_max_position = p.max_position_pct * 0.7
        else:  # extreme
            state.adjusted_max_position = p.max_position_pct * 0.5

        # ── 自适应熔断阈值 ──
        # 波动率越高，熔断阈值越宽（避免频繁触发）
        state.adjusted_circuit_breaker = round(
            p.circuit_breaker_base * vol_ratio * p.circuit_breaker_vol_factor, 4
        )
        state.adjusted_circuit_breaker = min(state.adjusted_circuit_breaker, 0.15)  # 上限15%

        # ── 风控建议 ──
        if state.regime == "extreme":
            state.should_reduce_position = True
            state.should_pause_trading = True
            state.recommendation = (
                f"🚨 极端波动！年化波动率{recent_vol:.1%}处于历史高位"
                f"（{state.volatility_percentile:.0f}百分位）。"
                f"建议暂停交易，等待波动率回落。"
            )
        elif state.regime == "high":
            state.should_reduce_position = True
            state.recommendation = (
                f"⚠️ 高波动环境。年化波动率{recent_vol:.1%}。"
                f"建议降低仓位至{state.adjusted_max_position:.0%}以内，"
                f"止损距离调整为{state.adjusted_stop_pct:.1%}。"
            )
        elif state.regime == "low":
            state.recommendation = (
                f"✅ 低波动环境。年化波动率{recent_vol:.1%}。"
                f"市场平稳，可正常交易。止损{state.adjusted_stop_pct:.1%}。"
            )
        else:
            state.recommendation = (
                f"正常波动环境。年化波动率{recent_vol:.1%}。"
                f"止损{state.adjusted_stop_pct:.1%}，最大仓位{state.adjusted_max_position:.0%}。"
            )

        return state

    def calculate_position_size(
        self,
        capital: float,
        price: float,
        atr_value: float,
        risk_per_trade: float = 0.02,
    ) -> int:
        """基于ATR的自适应仓位计算

        Args:
            capital: 可用资金
            price: 当前价格
            atr_value: ATR值
            risk_per_trade: 单笔交易风险（占资金比例）

        Returns:
            建议买入股数（100的整数倍）
        """
        if price <= 0 or atr_value <= 0 or capital <= 0:
            return 0

        # 每股风险 = ATR * 止损倍数
        risk_per_share = atr_value * self._params.stop_loss_atr_multiplier
        if risk_per_share <= 0:
            return 0

        # 允许的风险金额
        risk_amount = capital * risk_per_trade

        # 计算股数
        shares = int(risk_amount / risk_per_share)

        # 取整到100股
        shares = max(100, (shares // 100) * 100)

        # 不超过最大仓位
        max_shares = int(capital * self._params.max_position_pct / price)
        max_shares = (max_shares // 100) * 100
        shares = min(shares, max_shares)

        return shares

    def get_stop_prices(
        self,
        entry_price: float,
        atr_value: float,
        direction: str = "long",
    ) -> Tuple[float, float]:
        """基于ATR计算动态止损止盈价

        Args:
            entry_price: 入场价
            atr_value: ATR值
            direction: 方向（long/short）

        Returns:
            (stop_loss, take_profit) 元组
        """
        if atr_value <= 0:
            atr_value = entry_price * 0.02  # 默认ATR为价格的2%

        sl_distance = atr_value * self._params.stop_loss_atr_multiplier
        tp_distance = atr_value * self._params.take_profit_atr_multiplier

        if direction == "long":
            stop_loss = round(entry_price - sl_distance, 2)
            take_profit = round(entry_price + tp_distance, 2)
        else:
            stop_loss = round(entry_price + sl_distance, 2)
            take_profit = round(entry_price - tp_distance, 2)

        return stop_loss, take_profit

    def get_regime_color(self, regime: str) -> str:
        """获取波动率区间的显示颜色"""
        colors = {
            "low": "#00e87b",      # 绿色
            "normal": "#00d4ff",   # 蓝色
            "high": "#ffaa00",     # 橙色
            "extreme": "#ff3b5c",  # 红色
        }
        return colors.get(regime, "#888888")

    def get_regime_label(self, regime: str) -> str:
        """获取波动率区间的中文标签"""
        labels = {
            "low": "低波动",
            "normal": "正常波动",
            "high": "高波动",
            "extreme": "极端波动",
        }
        return labels.get(regime, "未知")
