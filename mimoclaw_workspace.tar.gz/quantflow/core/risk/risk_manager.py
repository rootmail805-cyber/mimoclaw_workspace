"""
Risk Manager v2 for QuantFlow.
Adds: trailing stop, portfolio-level risk, VaR-based limits.
"""

from typing import Optional, Dict, Any, Tuple, List
from loguru import logger

from .pre_trade import PreTradeChecker, PreTradeResult
from .intra_trade import IntraTradeMonitor, IntraTradeResult
from .post_trade import PostTradeAuditor
from .kill_switch import KillSwitch
from ..models import Order, Signal, Position, AccountInfo
from config.manager import get_config


class TrailingStopManager:
    """Trailing stop-loss manager.

    Tracks positions and triggers sell signals when price drops
    a configured percentage from the peak since entry.
    """

    def __init__(self, trail_pct: float = 0.08):
        """
        Args:
            trail_pct: Trailing stop percentage (0.08 = 8% from peak).
        """
        self._trail_pct = trail_pct
        self._peaks: Dict[str, float] = {}  # symbol -> highest price since entry
        self._entry_prices: Dict[str, float] = {}

    def update(self, symbol: str, current_price: float, has_position: bool) -> Optional[str]:
        """Update trailing stop for a position.

        Returns:
            "SELL" if trailing stop triggered, None otherwise.
        """
        if not has_position:
            # Clean up if no position
            self._peaks.pop(symbol, None)
            self._entry_prices.pop(symbol, None)
            return None

        # Track peak
        prev_peak = self._peaks.get(symbol, current_price)
        self._peaks[symbol] = max(prev_peak, current_price)

        # Check trailing stop
        peak = self._peaks[symbol]
        if peak > 0:
            decline = (peak - current_price) / peak
            if decline >= self._trail_pct:
                logger.warning(
                    f"Trailing stop triggered for {symbol}: "
                    f"peak={peak:.2f}, current={current_price:.2f}, decline={decline:.2%}"
                )
                self._peaks.pop(symbol, None)
                self._entry_prices.pop(symbol, None)
                return "SELL"

        return None

    def set_entry(self, symbol: str, price: float) -> None:
        """Record entry price for a new position."""
        self._entry_prices[symbol] = price
        self._peaks[symbol] = price

    @property
    def tracked_symbols(self) -> List[str]:
        return list(self._peaks.keys())


class PortfolioRiskMonitor:
    """Portfolio-level risk monitoring.

    Monitors:
        - Total portfolio concentration (Herfindahl index)
        - Sector exposure limits
        - Correlation-based diversification
        - Portfolio-level VaR
    """

    def __init__(self, max_concentration: float = 0.40):
        """
        Args:
            max_concentration: Max weight of top-N positions.
        """
        self._max_concentration = max_concentration

    def check_concentration(
        self, positions: Dict[str, Position], total_assets: float,
    ) -> Tuple[bool, str]:
        """Check if portfolio is too concentrated."""
        if total_assets <= 0 or not positions:
            return True, ""

        weights = []
        for pos in positions.values():
            if pos.volume > 0:
                w = pos.market_value / total_assets
                weights.append(w)

        if not weights:
            return True, ""

        weights.sort(reverse=True)
        top3_weight = sum(weights[:3])

        if top3_weight > self._max_concentration:
            return False, (
                f"Portfolio concentration too high: "
                f"top 3 positions = {top3_weight:.1%} > {self._max_concentration:.1%}"
            )

        return True, ""

    def herfindahl_index(self, positions: Dict[str, Position], total_assets: float) -> float:
        """Calculate Herfindahl-Hirschman Index for concentration.

        HHI = sum(wi^2), where wi is weight of position i.
        Range: 1/n (perfectly diversified) to 1 (single position).
        """
        if total_assets <= 0:
            return 0.0

        weights = [
            pos.market_value / total_assets
            for pos in positions.values()
            if pos.volume > 0
        ]

        return sum(w ** 2 for w in weights)


class RiskManager:
    """Central risk management facade v2.

    Architecture:
        ┌─────────────────┐
        │   Pre-trade     │ → Symbol/cash/position checks
        └────────┬────────┘
                 ↓
        ┌─────────────────┐
        │   Intra-trade   │ → Daily loss, drawdown, frequency
        └────────┬────────┘
                 ↓
        ┌─────────────────┐
        │   Portfolio     │ → Concentration, correlation  [NEW]
        └────────┬────────┘
                 ↓
        ┌─────────────────┐
        │   Trailing Stop │ → Dynamic stop-loss           [NEW]
        └────────┬────────┘
                 ↓
        ┌─────────────────┐
        │   Post-trade    │ → Audit logging
        └────────┬────────┘
                 ↓
        ┌─────────────────┐
        │   Kill Switch   │ → Emergency halt
        └─────────────────┘
    """

    def __init__(self, config=None):
        self._config = config or get_config()
        self._pre_trade = PreTradeChecker(self._config)
        self._intra_trade = IntraTradeMonitor(self._config)
        self._post_trade = PostTradeAuditor(self._config)
        self._kill_switch = KillSwitch(self._config)
        self._trailing_stop = TrailingStopManager(
            trail_pct=self._config.get("risk.trailing_stop.trail_pct", 0.08),
        )
        self._portfolio_risk = PortfolioRiskMonitor(
            max_concentration=self._config.get("risk.portfolio.max_concentration", 0.40),
        )
        self._enabled = True

        logger.info("RiskManager v2 initialized")

    def check_order(
        self,
        order: Order,
        positions: Dict[str, Position],
        account: AccountInfo,
    ) -> Tuple[bool, str]:
        """Full risk check pipeline."""
        if not self._enabled:
            return True, "Risk checks disabled"

        # Kill switch
        if self._kill_switch.is_triggered():
            return False, "KILL SWITCH ACTIVE"

        # Pre-trade
        pre_result = self._pre_trade.check(order, positions, account)
        if not pre_result.passed:
            self._post_trade.log_rejection(order, pre_result.reason)
            return False, f"Pre-trade: {pre_result.reason}"

        # Intra-trade
        intra_result = self._intra_trade.check(positions, account)
        if not intra_result.passed:
            self._post_trade.log_rejection(order, intra_result.reason)
            return False, f"Intra-trade: {intra_result.reason}"

        # Portfolio concentration (for buy orders)
        from ..models import OrderSide
        if order.side == OrderSide.BUY:
            ok, reason = self._portfolio_risk.check_concentration(positions, account.total_assets)
            if not ok:
                self._post_trade.log_rejection(order, reason)
                return False, f"Portfolio: {reason}"

        return True, "All checks passed"

    def check_trailing_stops(
        self, positions: Dict[str, Position], prices: Dict[str, float],
    ) -> List[str]:
        """Check trailing stops for all positions.

        Returns list of symbols that should be sold.
        """
        sell_signals = []
        for symbol, pos in positions.items():
            if pos.volume > 0 and symbol in prices:
                result = self._trailing_stop.update(symbol, prices[symbol], True)
                if result == "SELL":
                    sell_signals.append(symbol)
        return sell_signals

    def register_entry(self, symbol: str, price: float) -> None:
        """Register a new position entry for trailing stop."""
        self._trailing_stop.set_entry(symbol, price)

    def record_trade(self, order: Order, fill_price: float, fill_volume: int) -> None:
        self._post_trade.record_trade(order, fill_price, fill_volume)
        self._intra_trade.update_trade_count()

    def check_drawdown(self, account: AccountInfo) -> bool:
        should_kill = self._kill_switch.check_drawdown(account)
        if should_kill:
            logger.critical("KILL SWITCH TRIGGERED by drawdown!")
        return should_kill

    def trigger_kill_switch(self, reason: str = "Manual") -> None:
        self._kill_switch.trigger(reason)
        logger.critical(f"Kill switch triggered: {reason}")

    def reset_kill_switch(self) -> None:
        self._kill_switch.reset()
        logger.warning("Kill switch reset")

    def enable(self) -> None:
        self._enabled = True

    def disable(self) -> None:
        self._enabled = False
        logger.warning("Risk management DISABLED")

    @property
    def is_kill_switch_active(self) -> bool:
        return self._kill_switch.is_triggered()

    @property
    def stats(self) -> Dict[str, Any]:
        return {
            "enabled": self._enabled,
            "kill_switch_active": self._kill_switch.is_triggered(),
            "trades_today": self._intra_trade.trade_count_today,
            "daily_pnl": self._intra_trade.daily_pnl,
            "current_drawdown": self._intra_trade.current_drawdown,
            "trailing_stops_active": len(self._trailing_stop.tracked_symbols),
            "audit_records": self._post_trade.record_count,
        }
