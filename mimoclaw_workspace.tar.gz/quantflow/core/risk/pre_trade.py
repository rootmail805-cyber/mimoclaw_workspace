"""
Pre-trade risk checks for QuantFlow.
Validates orders before submission to ensure compliance.
"""

import re
from dataclasses import dataclass
from typing import Dict, List
from loguru import logger

from ..models import Order, Position, AccountInfo


@dataclass
class PreTradeResult:
    passed: bool
    reason: str = ""
    checks: Dict[str, bool] = None

    def __post_init__(self):
        if self.checks is None:
            self.checks = {}


class PreTradeChecker:
    """Pre-trade risk validation.

    Checks:
        1. Symbol whitelist/blacklist
        2. Position concentration limit
        3. Cash sufficiency
        4. Order size limits
        5. Parameter sanity
    """

    def __init__(self, config):
        self._max_single_position_pct = config.get("risk.pre_trade.max_single_position_pct", 0.20)
        self._allowed_symbols: List[str] = config.get("risk.pre_trade.allowed_symbols", [])
        self._forbidden_patterns: List[str] = config.get("risk.pre_trade.forbidden_symbols", ["*ST*"])
        self._min_cash_ratio = config.get("risk.pre_trade.min_cash_ratio", 0.10)

    def check(
        self,
        order: Order,
        positions: Dict[str, Position],
        account: AccountInfo,
    ) -> PreTradeResult:
        """Run all pre-trade checks."""
        checks = {}

        # 1. Symbol blacklist check
        checks["symbol_allowed"] = self._check_symbol(order.symbol)
        if not checks["symbol_allowed"]:
            return PreTradeResult(False, f"Symbol {order.symbol} is forbidden", checks)

        # 2. Position concentration
        if order.side.value == "BUY":
            checks["position_limit"] = self._check_position_limit(order, positions, account)
            if not checks["position_limit"]:
                return PreTradeResult(False, "Position concentration limit exceeded", checks)

        # 3. Cash sufficiency
        if order.side.value == "BUY":
            checks["cash_sufficient"] = self._check_cash(order, account)
            if not checks["cash_sufficient"]:
                return PreTradeResult(False, "Insufficient cash", checks)

        # 4. Sell volume check
        if order.side.value == "SELL":
            checks["sell_volume"] = self._check_sell_volume(order, positions)
            if not checks["sell_volume"]:
                return PreTradeResult(False, "Insufficient position to sell", checks)

        # 5. Minimum cash ratio after trade
        if order.side.value == "BUY":
            checks["min_cash_ratio"] = self._check_min_cash_ratio(order, account)
            if not checks["min_cash_ratio"]:
                return PreTradeResult(False, f"Would violate minimum cash ratio ({self._min_cash_ratio:.0%})", checks)

        return PreTradeResult(True, "All pre-trade checks passed", checks)

    def _check_symbol(self, symbol: str) -> bool:
        """Check if symbol is allowed."""
        # Check blacklist
        for pattern in self._forbidden_patterns:
            if pattern == "*ST*" and "ST" in symbol.upper():
                return False
            elif pattern in symbol:
                return False

        # Check whitelist (empty = allow all)
        if self._allowed_symbols:
            return symbol in self._allowed_symbols

        return True

    def _check_position_limit(self, order: Order, positions: Dict[str, Position], account: AccountInfo) -> bool:
        """Check single stock position concentration limit."""
        if account.total_assets <= 0:
            return False

        current = positions.get(order.symbol)
        current_value = current.market_value if current else 0
        estimated_new_value = current_value + (order.volume * (order.price or 0))

        new_pct = estimated_new_value / account.total_assets
        return new_pct <= self._max_single_position_pct

    def _check_cash(self, order: Order, account: AccountInfo) -> bool:
        """Check if there's enough cash for the order."""
        if not order.price:
            return True  # Market order, can't pre-check exact cost

        estimated_cost = order.volume * order.price * 1.001  # Add margin for commission
        return account.available_cash >= estimated_cost

    def _check_sell_volume(self, order: Order, positions: Dict[str, Position]) -> bool:
        """Check if there's enough position to sell."""
        pos = positions.get(order.symbol)
        if not pos:
            return False
        return pos.available_volume >= order.volume

    def _check_min_cash_ratio(self, order: Order, account: AccountInfo) -> bool:
        """Check that the trade won't push cash below minimum ratio."""
        if not order.price or account.total_assets <= 0:
            return True

        cost = order.volume * order.price
        remaining_cash = account.cash - cost
        return remaining_cash / account.total_assets >= self._min_cash_ratio
