"""
Intra-trade risk monitoring for QuantFlow.
Real-time risk monitoring during active trading.
"""

from dataclasses import dataclass
from datetime import datetime, date
from typing import Dict
from loguru import logger

from ..models import Position, AccountInfo


@dataclass
class IntraTradeResult:
    passed: bool
    reason: str = ""


class IntraTradeMonitor:
    """Real-time risk monitoring during trading.

    Monitors:
        1. Daily loss limit
        2. Maximum drawdown
        3. Trade frequency limits
        4. Portfolio-level risk metrics
    """

    def __init__(self, config):
        self._max_daily_loss_pct = config.get("risk.intra_trade.max_daily_loss_pct", 0.05)
        self._max_drawdown_pct = config.get("risk.intra_trade.max_drawdown_pct", 0.15)
        self._max_trades_per_day = config.get("risk.intra_trade.max_trades_per_day", 50)
        self._max_trades_per_hour = config.get("risk.intra_trade.max_trades_per_hour", 10)

        # State
        self._trades_today = 0
        self._trades_this_hour = 0
        self._hour_start = datetime.now().hour
        self._today = date.today()
        self._daily_start_equity = 0.0
        self._peak_equity = 0.0
        self._daily_pnl = 0.0
        self._current_drawdown = 0.0

    def check(self, positions: Dict[str, Position], account: AccountInfo) -> IntraTradeResult:
        """Run intra-trade risk checks."""
        self._update_state(account)

        # 1. Daily loss check
        if self._daily_pnl < 0:
            loss_pct = abs(self._daily_pnl) / self._daily_start_equity if self._daily_start_equity > 0 else 0
            if loss_pct >= self._max_daily_loss_pct:
                return IntraTradeResult(
                    False,
                    f"Daily loss limit reached: {loss_pct:.2%} >= {self._max_daily_loss_pct:.2%}"
                )

        # 2. Drawdown check
        if self._current_drawdown >= self._max_drawdown_pct:
            return IntraTradeResult(
                False,
                f"Max drawdown reached: {self._current_drawdown:.2%} >= {self._max_drawdown_pct:.2%}"
            )

        # 3. Trade frequency check (daily)
        if self._trades_today >= self._max_trades_per_day:
            return IntraTradeResult(
                False,
                f"Daily trade limit reached: {self._trades_today} >= {self._max_trades_per_day}"
            )

        # 4. Trade frequency check (hourly)
        if self._trades_this_hour >= self._max_trades_per_hour:
            return IntraTradeResult(
                False,
                f"Hourly trade limit reached: {self._trades_this_hour} >= {self._max_trades_per_hour}"
            )

        return IntraTradeResult(True, "All intra-trade checks passed")

    def _update_state(self, account: AccountInfo) -> None:
        """Update monitoring state with latest account info."""
        today = date.today()

        # Reset daily counters on new day
        if today != self._today:
            self._today = today
            self._trades_today = 0
            self._daily_start_equity = account.total_assets

        # Reset hourly counter
        current_hour = datetime.now().hour
        if current_hour != self._hour_start:
            self._hour_start = current_hour
            self._trades_this_hour = 0

        # Update equity tracking
        if self._daily_start_equity == 0:
            self._daily_start_equity = account.total_assets

        self._daily_pnl = account.total_assets - self._daily_start_equity

        # Track peak for drawdown
        if account.total_assets > self._peak_equity:
            self._peak_equity = account.total_assets

        if self._peak_equity > 0:
            self._current_drawdown = (self._peak_equity - account.total_assets) / self._peak_equity

    def update_trade_count(self) -> None:
        """Increment trade counters."""
        self._trades_today += 1
        self._trades_this_hour += 1

    @property
    def trade_count_today(self) -> int:
        return self._trades_today

    @property
    def daily_pnl(self) -> float:
        return self._daily_pnl

    @property
    def current_drawdown(self) -> float:
        return self._current_drawdown
