"""
Post-trade audit for QuantFlow.
Records all trading activity for compliance and analysis.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
from loguru import logger

from ..models import Order


class PostTradeAuditor:
    """Post-trade audit and compliance logging.

    Features:
        - Append-only audit log (tamper-evident)
        - Trade record persistence
        - Rejection logging
        - Risk metric history
    """

    def __init__(self, config):
        self._retention_days = config.get("risk.post_trade.audit_retention_days", 365)
        self._enabled = config.get("risk.post_trade.audit_enabled", True)
        self._audit_log: List[Dict[str, Any]] = []
        self._log_dir = Path(config.get("system.log_dir", "./logs"))
        self._log_dir.mkdir(parents=True, exist_ok=True)

        # Use audit logger from loguru
        self._audit_logger = logger.bind(audit=True)

    def record_trade(self, order: Order, fill_price: float, fill_volume: int) -> None:
        """Record a completed trade."""
        if not self._enabled:
            return

        record = {
            "type": "TRADE",
            "timestamp": datetime.now().isoformat(),
            "order_id": order.order_id,
            "symbol": order.symbol,
            "side": order.side.value,
            "order_type": order.order_type.value,
            "volume": fill_volume,
            "price": fill_price,
            "commission": order.commission,
            "strategy_id": order.strategy_id,
            "status": order.status.value,
        }

        self._audit_log.append(record)
        self._audit_logger.info(json.dumps(record, ensure_ascii=False))

    def log_rejection(self, order: Order, reason: str) -> None:
        """Log a rejected order."""
        if not self._enabled:
            return

        record = {
            "type": "REJECTION",
            "timestamp": datetime.now().isoformat(),
            "order_id": order.order_id,
            "symbol": order.symbol,
            "side": order.side.value,
            "volume": order.volume,
            "price": order.price,
            "strategy_id": order.strategy_id,
            "reason": reason,
        }

        self._audit_log.append(record)
        self._audit_logger.warning(json.dumps(record, ensure_ascii=False))

    def log_risk_event(self, event_type: str, details: str) -> None:
        """Log a risk event (e.g., kill switch trigger)."""
        if not self._enabled:
            return

        record = {
            "type": "RISK_EVENT",
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            "details": details,
        }

        self._audit_log.append(record)
        self._audit_logger.error(json.dumps(record, ensure_ascii=False))

    def get_audit_trail(
        self,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
        event_type: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Query the audit trail with optional filters."""
        result = self._audit_log

        if start:
            result = [r for r in result if r.get("timestamp", "") >= start.isoformat()]
        if end:
            result = [r for r in result if r.get("timestamp", "") <= end.isoformat()]
        if event_type:
            result = [r for r in result if r.get("type") == event_type]

        return result

    def export_audit_log(self, filepath: Optional[str] = None) -> str:
        """Export audit log to JSON file."""
        if filepath is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = str(self._log_dir / f"audit_export_{timestamp}.json")

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self._audit_log, f, ensure_ascii=False, indent=2)

        logger.info(f"Audit log exported: {filepath} ({len(self._audit_log)} records)")
        return filepath

    @property
    def record_count(self) -> int:
        return len(self._audit_log)
