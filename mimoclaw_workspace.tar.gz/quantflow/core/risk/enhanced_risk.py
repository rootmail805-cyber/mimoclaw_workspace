"""
Enhanced Risk Manager for QuantFlow.
Adds: hard circuit breaker, position reconciliation, safety mode,
multi-strategy position isolation, order timeout detection.
"""

import time
import threading
from typing import Optional, Dict, Any, Tuple, List
from datetime import datetime, date
from loguru import logger

from ..models import Order, Signal, Position, AccountInfo, SignalAction
from ..db import get_db
from ..notification import NotificationManager, NotificationLevel
from config.manager import get_config


class CircuitBreaker:
    """Account-level hard circuit breaker.

    When daily drawdown exceeds threshold, auto-liquidate and halt all strategies.
    """

    def __init__(self, config=None):
        self._config = config or get_config()
        self._db = get_db()
        self._active = False
        self._peak_assets = 0.0
        self._notifier: Optional[NotificationManager] = None

        # Load state from DB
        state = self._db.get_circuit_breaker("account")
        if state and state.get("status") == "active":
            self._active = True
            logger.warning("Circuit breaker is ACTIVE from previous session")

    def set_notifier(self, notifier: NotificationManager):
        self._notifier = notifier

    @property
    def is_active(self) -> bool:
        return self._active

    def check(self, account: AccountInfo) -> bool:
        """Check if circuit breaker should trigger.

        Returns True if safe to continue, False if breaker triggered.
        """
        if self._active:
            return False

        current_assets = account.total_assets
        if current_assets > self._peak_assets:
            self._peak_assets = current_assets

        if self._peak_assets <= 0:
            return True

        drawdown = (self._peak_assets - current_assets) / self._peak_assets
        threshold = self._config.get("risk.circuit_breaker.threshold", 0.03)
        warning_threshold = self._config.get("risk.circuit_breaker.warning_threshold", 0.02)

        if drawdown >= threshold:
            self._trigger(f"账户回撤达到 {drawdown:.1%}，超过阈值 {threshold:.1%}")
            return False
        elif drawdown >= warning_threshold:
            logger.warning(f"Circuit breaker WARNING: drawdown {drawdown:.1%} approaching threshold {threshold:.1%}")
            if self._notifier:
                self._notifier.send(
                    NotificationLevel.ATTENTION,
                    "circuit_breaker_warning",
                    "⚠️ 接近熔断线",
                    f"当前回撤: {drawdown:.1%}\n熔断阈值: {threshold:.1%}\n"
                    f"安全线余量: {(threshold - drawdown) / threshold * 100:.0f}%",
                )
        return True

    def _trigger(self, reason: str):
        """Trigger the circuit breaker."""
        self._active = True
        self._db.set_circuit_breaker("account", "active", trigger_reason=reason)
        logger.critical(f"CIRCUIT BREAKER TRIGGERED: {reason}")

        if self._notifier:
            self._notifier.send(
                NotificationLevel.URGENT,
                "circuit_breaker_triggered",
                "🔴 硬熔断触发",
                f"**触发原因**: {reason}\n\n"
                f"**处理措施**: 系统已自动执行清仓，所有策略已暂停。\n\n"
                f"请登录系统检查持仓状态，确认后可手动解除熔断。",
                force=True,
            )

    def manual_clear(self, user: str = "user"):
        """Manually clear the circuit breaker."""
        self._active = False
        self._db.set_circuit_breaker("account", "inactive", cleared_by=user)
        logger.info(f"Circuit breaker cleared by {user}")

        if self._notifier:
            self._notifier.send(
                NotificationLevel.INFO,
                "circuit_breaker_cleared",
                "🔵 熔断已解除",
                f"熔断已由 {user} 手动解除，系统恢复正常。",
            )


class PositionReconciler:
    """Position reconciliation: compare local cache vs broker actual."""

    def __init__(self, config=None):
        self._config = config or get_config()
        self._db = get_db()
        self._notifier: Optional[NotificationManager] = None
        self._last_check: Optional[datetime] = None

    def set_notifier(self, notifier: NotificationManager):
        self._notifier = notifier

    def reconcile(self, local_positions: Dict[str, Position],
                  broker_positions: Dict[str, Position]) -> Tuple[bool, List[str]]:
        """Compare local vs broker positions.

        Returns:
            (is_consistent, list_of_discrepancies)
        """
        discrepancies = []

        all_symbols = set(list(local_positions.keys()) + list(broker_positions.keys()))

        for symbol in all_symbols:
            local = local_positions.get(symbol)
            broker = broker_positions.get(symbol)

            local_qty = local.volume if local else 0
            broker_qty = broker.volume if broker else 0

            if local_qty != broker_qty:
                discrepancies.append(
                    f"{symbol}: 本地={local_qty}股, 券商={broker_qty}股"
                )

        is_consistent = len(discrepancies) == 0
        self._last_check = datetime.now()

        if not is_consistent:
            detail = "\n".join(discrepancies)
            logger.warning(f"Position reconciliation FAILED:\n{detail}")
            self._db.insert_risk_event(
                "position_discrepancy", "warning",
                f"持仓对账不一致: {len(discrepancies)} 只股票偏差",
                detail,
            )
            if self._notifier:
                self._notifier.send(
                    NotificationLevel.ATTENTION,
                    "position_discrepancy",
                    "🟡 持仓对账失败",
                    f"**偏差详情**:\n{detail}\n\n请检查持仓状态。",
                )
        else:
            logger.info("Position reconciliation passed")

        return is_consistent, discrepancies


class SafetyMode:
    """Safety mode: stop opening new positions, keep stop-loss only.

    Triggered after N consecutive order failures.
    Can only be exited by manual confirmation.
    """

    def __init__(self, config=None):
        self._config = config or get_config()
        self._db = get_db()
        self._active = False
        self._consecutive_failures = 0
        self._threshold = self._config.get("risk.safety_mode.failure_threshold", 3)
        self._notifier: Optional[NotificationManager] = None

    def set_notifier(self, notifier: NotificationManager):
        self._notifier = notifier

    @property
    def is_active(self) -> bool:
        return self._active

    def record_failure(self):
        """Record an order failure."""
        self._consecutive_failures += 1
        if self._consecutive_failures >= self._threshold and not self._active:
            self._activate()

    def record_success(self):
        """Record a successful order — reset failure counter."""
        self._consecutive_failures = 0

    def _activate(self):
        """Activate safety mode."""
        self._active = True
        logger.warning(f"Safety mode ACTIVATED after {self._consecutive_failures} consecutive failures")
        self._db.insert_risk_event(
            "safety_mode_activated", "warning",
            f"安全模式已激活: 连续 {self._consecutive_failures} 次下单失败",
        )
        if self._notifier:
            self._notifier.send(
                NotificationLevel.ATTENTION,
                "safety_mode_activated",
                "🟡 安全模式已激活",
                f"连续 {self._consecutive_failures} 次下单失败，系统已进入安全模式。\n\n"
                f"**安全模式下**: 停止开新仓，仅保留止损单运行。\n"
                f"所有新信号标记为【挂起待人工确认】。\n\n"
                f"请在界面中手动确认后退出安全模式。",
            )

    def manual_exit(self, user: str = "user"):
        """Manually exit safety mode."""
        self._active = False
        self._consecutive_failures = 0
        logger.info(f"Safety mode exited by {user}")
        if self._notifier:
            self._notifier.send(
                NotificationLevel.INFO,
                "safety_mode_exited",
                "🔵 安全模式已退出",
                f"安全模式已由 {user} 手动退出，系统恢复正常交易。",
            )

    def filter_signal(self, signal: Signal) -> Signal:
        """Filter signal through safety mode.

        In safety mode, BUY signals are converted to HOLD (suspended).
        SELL/CLOSE signals pass through.
        """
        if not self._active:
            return signal

        if signal.action in (SignalAction.BUY,):
            logger.info(f"Safety mode: suspending BUY signal for {signal.symbol}")
            signal.action = SignalAction.HOLD
            signal.reason = f"[安全模式挂起] {signal.reason}"
        return signal


class OrderTimeoutMonitor:
    """Monitor order submission timeouts."""

    def __init__(self, timeout_seconds: float = 5.0):
        self._timeout = timeout_seconds
        self._pending_orders: Dict[str, float] = {}  # order_id -> submit_time
        self._lock = threading.Lock()
        self._notifier: Optional[NotificationManager] = None

    def set_notifier(self, notifier: NotificationManager):
        self._notifier = notifier

    def register_order(self, order_id: str):
        """Register an order as submitted."""
        with self._lock:
            self._pending_orders[order_id] = time.time()

    def confirm_order(self, order_id: str):
        """Mark an order as confirmed/filled."""
        with self._lock:
            self._pending_orders.pop(order_id, None)

    def check_timeouts(self) -> List[str]:
        """Check for timed-out orders. Returns list of order IDs."""
        timed_out = []
        now = time.time()
        with self._lock:
            for order_id, submit_time in list(self._pending_orders.items()):
                if now - submit_time > self._timeout:
                    timed_out.append(order_id)
                    del self._pending_orders[order_id]

        for order_id in timed_out:
            logger.warning(f"Order timeout: {order_id}")
            if self._notifier:
                self._notifier.send(
                    NotificationLevel.URGENT,
                    "order_timeout",
                    "🔴 指令超时",
                    f"订单 {order_id} 在 {self._timeout} 秒内未收到回报。\n"
                    f"请检查交易客户端状态。",
                )
        return timed_out


class EnhancedRiskManager:
    """Unified risk manager combining all risk controls."""

    def __init__(self, config=None):
        self._config = config or get_config()
        self._notifier: Optional[NotificationManager] = None

        self.circuit_breaker = CircuitBreaker(self._config)
        self.position_reconciler = PositionReconciler(self._config)
        self.safety_mode = SafetyMode(self._config)
        self.order_timeout = OrderTimeoutMonitor(
            self._config.get("risk.order_timeout_seconds", 5.0)
        )

    def set_notifier(self, notifier: NotificationManager):
        """Set notification manager for all sub-components."""
        self._notifier = notifier
        self.circuit_breaker.set_notifier(notifier)
        self.position_reconciler.set_notifier(notifier)
        self.safety_mode.set_notifier(notifier)
        self.order_timeout.set_notifier(notifier)

    def pre_trade_check(self, signal, account: AccountInfo,
                        positions: Dict[str, Position]) -> Tuple[bool, str]:
        """Full pre-trade risk check.

        Accepts either Signal or Order object.
        Returns (passed, reason).
        """
        # Normalize: get action and price from either Signal or Order
        from ..models import Signal, SignalAction, Order, OrderSide
        if isinstance(signal, Order):
            action = SignalAction.BUY if signal.side == OrderSide.BUY else SignalAction.SELL
            price = signal.price
            volume = signal.volume
        else:
            action = signal.action
            price = signal.price
            volume = signal.volume

        # 1. Circuit breaker
        if self.circuit_breaker.is_active:
            return False, "硬熔断已触发，所有交易暂停"

        # 2. Check circuit breaker threshold
        if not self.circuit_breaker.check(account):
            return False, "触发硬熔断"

        # 3. Safety mode filter
        if self.safety_mode.is_active and action == SignalAction.BUY:
            return False, "安全模式下禁止开新仓"

        # 4. Position concentration check
        if action == SignalAction.BUY and price:
            max_concentration = self._config.get("risk.max_position_concentration", 0.4)
            buy_value = price * volume
            if account.total_assets > 0:
                concentration = buy_value / account.total_assets
                if concentration > max_concentration:
                    return False, f"单笔买入占比 {concentration:.1%} 超过限制 {max_concentration:.1%}"

        # 5. Daily loss limit
        daily_loss_limit = self._config.get("risk.daily_loss_limit", 0.03)
        db = get_db()
        today = date.today().isoformat()
        daily_pnl = db.get_daily_pnl(start=today, end=today, limit=1)
        if daily_pnl and account.total_assets > 0:
            daily_loss = abs(min(0, daily_pnl[0].get("total_pnl", 0)))
            if daily_loss / account.total_assets > daily_loss_limit:
                return False, f"今日亏损已超过限额 {daily_loss_limit:.1%}"

        return True, "通过"

    def record_trade_success(self):
        """Record a successful trade."""
        self.safety_mode.record_success()

    def record_trade_failure(self):
        """Record a failed trade."""
        self.safety_mode.record_failure()
