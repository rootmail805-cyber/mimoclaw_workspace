"""
多标的批量回测（扫股器）
支持预设股票池、自定义股票池、批量回测、结果排行榜
"""

import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Any, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from loguru import logger

import pandas as pd
import numpy as np


# ── 预设股票池 ──────────────────────────────────────────────────

STOCK_POOLS = {
    "沪深300龙头": [
        "600519.SH", "601318.SH", "600036.SH", "000858.SZ", "600276.SH",
        "601166.SH", "000333.SZ", "600030.SH", "601398.SH", "600900.SH",
        "000001.SZ", "600000.SH", "601888.SH", "300750.SZ", "002594.SZ",
        "601012.SH", "600809.SH", "000568.SZ", "002714.SZ", "603259.SH",
        "601669.SH", "600050.SH", "000651.SZ", "002475.SZ", "600585.SH",
        "601899.SH", "600031.SH", "002304.SZ", "601288.SH", "000725.SZ",
    ],
    "科创50精选": [
        "688981.SH", "688012.SH", "688111.SH", "688036.SH", "688009.SH",
        "688561.SH", "688396.SH", "688005.SH", "688599.SH", "688185.SH",
        "688002.SH", "688008.SH", "688126.SH", "688033.SH", "688521.SH",
        "688303.SH", "688065.SH", "688256.SH", "688536.SH", "688388.SH",
    ],
    "金融龙头": [
        "601318.SH", "600036.SH", "601166.SH", "000001.SZ", "600000.SH",
        "601398.SH", "601288.SH", "601939.SH", "601328.SH", "600016.SH",
    ],
    "消费龙头": [
        "600519.SH", "000858.SZ", "000333.SZ", "600809.SH", "000568.SZ",
        "603259.SH", "002714.SZ", "600887.SH", "300015.SZ", "002304.SZ",
    ],
    "科技龙头": [
        "300750.SZ", "002594.SZ", "000725.SZ", "002475.SZ", "600031.SH",
        "601012.SH", "601888.SH", "300059.SZ", "002230.SZ", "600588.SH",
    ],
}


@dataclass
class ScreenerResult:
    """单只股票的回测结果"""
    symbol: str
    name: str = ""
    total_return: float = 0.0
    annualized_return: float = 0.0
    max_drawdown: float = 0.0
    sharpe_ratio: float = 0.0
    win_rate: float = 0.0
    profit_loss_ratio: float = 0.0
    total_trades: int = 0
    volatility: float = 0.0
    elapsed_seconds: float = 0.0
    error: Optional[str] = None


@dataclass
class ScreenerRun:
    """一次批量回测的完整结果"""
    run_id: str
    strategy_id: str
    strategy_name: str
    pool_name: str
    symbol_count: int
    start_date: str
    end_date: str
    results: List[ScreenerResult] = field(default_factory=list)
    elapsed_seconds: float = 0.0
    completed: int = 0
    failed: int = 0
    status: str = "pending"  # pending / running / completed / error


class StockScreener:
    """多标的批量回测引擎"""

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._data_mgr = None
        self._current_run: Optional[ScreenerRun] = None
        self._cancel_flag = False

    def get_stock_pools(self) -> Dict[str, List[str]]:
        """获取所有可用股票池"""
        return dict(STOCK_POOLS)

    def load_custom_pool(self, file_path: str) -> List[str]:
        """从文件加载自定义股票池（TXT每行一个代码，或CSV第一列）"""
        path = Path(file_path)
        symbols = []
        if path.suffix.lower() == '.csv':
            df = pd.read_csv(path, dtype=str)
            col = df.columns[0]
            symbols = df[col].dropna().tolist()
        else:
            with open(path, 'r', encoding='utf-8') as f:
                symbols = [line.strip() for line in f if line.strip()]
        # 清理：确保有后缀
        cleaned = []
        for s in symbols:
            s = s.strip().replace('"', '').replace("'", "")
            if s and s[0].isdigit():
                if '.' not in s:
                    if s.startswith('6'):
                        s += '.SH'
                    else:
                        s += '.SZ'
                cleaned.append(s)
        return cleaned

    def run_batch(
        self,
        symbols: List[str],
        strategy_id: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        progress_callback: Optional[Callable[[int, int, str], None]] = None,
        max_workers: int = 8,
    ) -> ScreenerRun:
        """批量回测一篮子股票（并发优化版）

        Args:
            symbols: 股票代码列表
            strategy_id: 策略ID（如 dual_ma, macd 等）
            start: 开始日期
            end: 结束日期
            progress_callback: 进度回调 callback(current, total, symbol)
            max_workers: 最大并发数（默认8）

        Returns:
            ScreenerRun 包含所有结果
        """
        if start is None:
            start = (datetime.now() - timedelta(days=365 * 3)).strftime("%Y-%m-%d")
        if end is None:
            end = datetime.now().strftime("%Y-%m-%d")

        run_id = f"screener_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        strategy_names = {
            "dual_ma": "双均线策略", "macd": "MACD策略", "bollinger": "布林带策略",
            "rsi": "RSI策略", "kdj": "KDJ策略", "atr_breakout": "ATR通道突破",
            "momentum": "动量突破策略", "vwap": "VWAP策略",
        }

        run = ScreenerRun(
            run_id=run_id,
            strategy_id=strategy_id,
            strategy_name=strategy_names.get(strategy_id, strategy_id),
            pool_name=f"自定义({len(symbols)}只)",
            symbol_count=len(symbols),
            start_date=start,
            end_date=end,
            status="running",
        )
        self._current_run = run
        self._cancel_flag = False

        total = len(symbols)
        start_time = time.time()
        completed_count = 0
        lock = threading.Lock()

        def _process_symbol(symbol):
            nonlocal completed_count
            if self._cancel_flag:
                return ScreenerResult(symbol=symbol, error="已取消")

            result = self._run_single(symbol, strategy_id, start, end)

            with lock:
                completed_count += 1
                if progress_callback:
                    progress_callback(completed_count, total, symbol)

            return result

        # 并发执行（数据获取+回测）
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(_process_symbol, sym): sym for sym in symbols}
            for future in as_completed(futures):
                if self._cancel_flag:
                    run.status = "cancelled"
                    break
                try:
                    result = future.result(timeout=120)
                    run.results.append(result)
                    if result.error:
                        run.failed += 1
                    else:
                        run.completed += 1
                except Exception as e:
                    sym = futures[future]
                    logger.warning(f"[Screener] {sym} failed: {e}")
                    run.results.append(ScreenerResult(symbol=sym, error=str(e)))
                    run.failed += 1

        run.elapsed_seconds = round(time.time() - start_time, 2)
        run.status = "completed" if not self._cancel_flag else "cancelled"

        # 按年化收益率排序
        run.results.sort(key=lambda r: r.annualized_return, reverse=True)

        logger.info(f"[Screener] Done: {run.completed}/{total} succeeded in {run.elapsed_seconds}s")
        return run

    def cancel(self):
        """取消当前批量回测"""
        self._cancel_flag = True

    def _run_single(self, symbol: str, strategy_id: str, start: str, end: str) -> ScreenerResult:
        """对单只股票运行回测"""
        from core.data.data_manager import DataManager
        from core.backtest.engine import BacktestEngine

        if self._data_mgr is None:
            self._data_mgr = DataManager(self._config)

        t0 = time.time()

        # 获取数据
        data = self._data_mgr.get_history(symbol, start, end, freq="daily")
        if data is None or data.empty:
            return ScreenerResult(symbol=symbol, error="数据获取失败", elapsed_seconds=time.time() - t0)

        # 获取股票名称
        name = self._get_stock_name(symbol)

        # 加载策略
        strategy = self._create_strategy(strategy_id, symbol)
        if strategy is None:
            return ScreenerResult(symbol=symbol, name=name, error=f"未知策略: {strategy_id}")

        # 运行回测
        engine = BacktestEngine(self._config)
        engine.add_strategy(strategy)
        results = engine.run(data, symbol)

        m = results.get("metrics", {})

        return ScreenerResult(
            symbol=symbol,
            name=name,
            total_return=m.get("total_return", 0.0),
            annualized_return=m.get("annualized_return", 0.0),
            max_drawdown=m.get("max_drawdown", 0.0),
            sharpe_ratio=m.get("sharpe_ratio", 0.0),
            win_rate=m.get("win_rate", 0.0),
            profit_loss_ratio=m.get("profit_loss_ratio", 0.0),
            total_trades=results.get("total_trades", 0),
            volatility=m.get("volatility", 0.0),
            elapsed_seconds=round(time.time() - t0, 2),
        )

    def _create_strategy(self, strategy_id: str, symbol: str):
        """创建策略实例"""
        import importlib
        strategy_map = {
            "dual_ma": ("strategies.dual_ma", "DualMAStrategy"),
            "macd": ("strategies.macd_strategy", "MACDStrategy"),
            "bollinger": ("strategies.bollinger_strategy", "BollingerStrategy"),
            "rsi": ("strategies.rsi_strategy", "RSIStrategy"),
            "kdj": ("strategies.kdj_strategy", "KDJStrategy"),
            "atr_breakout": ("strategies.atr_breakout_strategy", "ATRBreakoutStrategy"),
            "momentum": ("strategies.momentum_strategy", "MomentumBreakoutStrategy"),
            "vwap": ("strategies.vwap_strategy", "VWAPStrategy"),
        }
        entry = strategy_map.get(strategy_id)
        if not entry:
            return None
        mod_path, cls_name = entry
        try:
            mod = importlib.import_module(mod_path)
            cls = getattr(mod, cls_name)
            return cls(strategy_id=f"screener_{strategy_id}_{symbol}")
        except Exception as e:
            logger.error(f"[Screener] Failed to create strategy {strategy_id}: {e}")
            return None

    def _get_stock_name(self, symbol: str) -> str:
        """获取股票名称（通过akshare）"""
        try:
            import akshare as ak
            code = symbol.split('.')[0]
            df = ak.stock_zh_a_spot_em()
            row = df[df['代码'] == code]
            if not row.empty:
                return str(row.iloc[0].get('名称', ''))
        except Exception:
            pass
        return ""
