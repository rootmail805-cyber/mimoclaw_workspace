"""
模拟影子跟单（试驾模式）
在零资金风险下验证策略在真实市场环境下的表现
"""

import time
import json
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime, date
from pathlib import Path
from loguru import logger

import numpy as np


@dataclass
class ShadowPosition:
    """影子持仓"""
    symbol: str
    name: str = ""
    quantity: int = 0
    avg_cost: float = 0.0
    current_price: float = 0.0
    stop_loss: float = 0.0
    take_profit: float = 0.0
    entry_date: str = ""

    @property
    def market_value(self) -> float:
        return self.quantity * self.current_price

    @property
    def pnl(self) -> float:
        return (self.current_price - self.avg_cost) * self.quantity

    @property
    def pnl_pct(self) -> float:
        if self.avg_cost <= 0:
            return 0.0
        return (self.current_price / self.avg_cost - 1) * 100


@dataclass
class ShadowTrade:
    """影子交易记录"""
    trade_time: str
    symbol: str
    name: str = ""
    side: str = ""  # BUY / SELL
    quantity: int = 0
    price: float = 0.0
    commission: float = 0.0
    slippage_cost: float = 0.0
    pnl: float = 0.0  # 卖出时的盈亏
    reason: str = ""


@dataclass
class ShadowReport:
    """影子模式每日报告"""
    report_date: str = ""
    total_assets: float = 0.0
    cash: float = 0.0
    market_value: float = 0.0
    daily_pnl: float = 0.0
    daily_pnl_pct: float = 0.0
    total_pnl: float = 0.0
    total_pnl_pct: float = 0.0
    max_drawdown: float = 0.0
    win_rate: float = 0.0
    total_trades: int = 0
    positions: List[ShadowPosition] = field(default_factory=list)
    strategy_name: str = ""
    running_days: int = 0


class ShadowTrader:
    """影子交易引擎（试驾模式）

    完全按照实盘逻辑运行，但不实际下单。
    包括：信号生成、仓位计算、风控拦截、滑点、佣金、T+1、涨跌停。
    """

    MAX_SHADOW_HISTORY = 3  # 最多保留3次影子记录

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._data_dir = Path(self._config.get("system.data_dir", "./data")) / "shadow"
        self._data_dir.mkdir(parents=True, exist_ok=True)

        # 运行状态
        self._active = False
        self._strategy_name = ""
        self._symbol = ""
        self._strategy = None
        self._broker = None

        # 账户状态
        self._initial_balance = self._config.get("execution.simulation.initial_balance", 1000000)
        self._cash = self._initial_balance
        self._positions: Dict[str, ShadowPosition] = {}
        self._trades: List[ShadowTrade] = []
        self._daily_pnl_history: List[float] = []
        self._equity_history: List[float] = []
        self._start_date = ""
        self._running_days = 0

        # 交易参数
        self._commission_rate = self._config.get("trading.commission_rate", 0.00025)
        self._slippage_rate = self._config.get("trading.slippage_rate", 0.001)
        self._min_commission = self._config.get("trading.min_commission", 5.0)

        # T+1限制记录
        self._today_bought: set = set()

    @property
    def is_active(self) -> bool:
        return self._active

    @property
    def running_days(self) -> int:
        return self._running_days

    def start(self, strategy, symbol: str, strategy_name: str = ""):
        """启动影子模式"""
        self._active = True
        self._strategy = strategy
        self._symbol = symbol
        self._strategy_name = strategy_name or str(strategy)
        self._start_date = date.today().isoformat()
        self._running_days = 0
        self._cash = self._initial_balance
        self._positions.clear()
        self._trades.clear()
        self._daily_pnl_history.clear()
        self._equity_history.clear()
        self._today_bought.clear()

        logger.info(f"[Shadow] 影子模式启动: {strategy_name} on {symbol}")

    def stop(self):
        """停止影子模式"""
        self._active = False
        # 保存最终报告
        self._save_session()
        logger.info(f"[Shadow] 影子模式停止，运行{self._running_days}天")

    def on_bar(self, bar, risk_manager=None):
        """处理K线数据（模拟实盘逻辑）"""
        if not self._active or self._strategy is None:
            return

        # 更新持仓价格
        for sym, pos in self._positions.items():
            if sym == bar.symbol:
                pos.current_price = bar.close

        # 策略生成信号
        signal = self._strategy.on_bar(bar)
        if signal is None:
            return

        # 风控检查（如果提供了风控管理器）
        if risk_manager is not None:
            try:
                from core.models import Order, OrderSide
                order = Order(
                    symbol=signal.symbol,
                    side=OrderSide.BUY if signal.action.value == "BUY" else OrderSide.SELL,
                    quantity=signal.volume,
                    price=bar.close,
                )
                check = risk_manager.pre_trade_check(order)
                if not check.passed:
                    logger.info(f"[Shadow] 风控拦截: {check.reason}")
                    return
            except Exception:
                pass

        # T+1 检查
        if signal.action.value == "SELL" and signal.symbol in self._today_bought:
            logger.info(f"[Shadow] T+1限制: {signal.symbol} 今日买入不可卖出")
            return

        # 涨跌停检查（简化）
        # 实际应与前一日收盘价比较

        # 执行影子交易
        self._execute_shadow(signal, bar.close)

    def on_new_day(self):
        """新交易日开始"""
        if not self._active:
            return
        self._today_bought.clear()
        self._running_days += 1

        # 计算当日盈亏
        total_market_value = sum(p.market_value for p in self._positions.values())
        total_assets = self._cash + total_market_value
        self._equity_history.append(total_assets)

        if len(self._equity_history) > 1:
            daily_pnl = self._equity_history[-1] - self._equity_history[-2]
            self._daily_pnl_history.append(daily_pnl)

    def _execute_shadow(self, signal, price: float):
        """执行影子交易"""
        symbol = signal.symbol
        side = signal.action.value
        volume = signal.volume

        # 加滑点
        if side == "BUY":
            exec_price = price * (1 + self._slippage_rate)
        else:
            exec_price = price * (1 - self._slippage_rate)

        # 计算佣金
        trade_value = exec_price * volume
        commission = max(trade_value * self._commission_rate, self._min_commission)

        if side == "BUY":
            total_cost = trade_value + commission
            if total_cost > self._cash:
                # 资金不足，调整数量
                volume = int((self._cash - self._min_commission) / exec_price / 100) * 100
                if volume < 100:
                    return
                trade_value = exec_price * volume
                commission = max(trade_value * self._commission_rate, self._min_commission)
                total_cost = trade_value + commission

            self._cash -= total_cost

            if symbol in self._positions:
                pos = self._positions[symbol]
                total_shares = pos.quantity + volume
                pos.avg_cost = (pos.avg_cost * pos.quantity + exec_price * volume) / total_shares
                pos.quantity = total_shares
            else:
                self._positions[symbol] = ShadowPosition(
                    symbol=symbol,
                    quantity=volume,
                    avg_cost=exec_price,
                    current_price=exec_price,
                    entry_date=date.today().isoformat(),
                )

            self._today_bought.add(symbol)

        elif side == "SELL":
            if symbol not in self._positions:
                return
            pos = self._positions[symbol]
            sell_qty = min(volume, pos.quantity)

            pnl = (exec_price - pos.avg_cost) * sell_qty - commission
            self._cash += trade_value - commission

            pos.quantity -= sell_qty
            if pos.quantity <= 0:
                del self._positions[symbol]

        # 记录交易
        trade = ShadowTrade(
            trade_time=datetime.now().isoformat(),
            symbol=symbol,
            side=side,
            quantity=volume,
            price=round(exec_price, 2),
            commission=round(commission, 2),
            slippage_cost=round(abs(exec_price - price) * volume, 2),
            pnl=round(pnl if side == "SELL" else 0.0, 2),
            reason=signal.reason if hasattr(signal, 'reason') else "",
        )
        self._trades.append(trade)

        logger.info(f"[Shadow] {side} {symbol} x{volume} @ {exec_price:.2f} (佣金:{commission:.2f})")

    def get_report(self) -> ShadowReport:
        """生成当前影子模式报告"""
        total_market_value = sum(p.market_value for p in self._positions.values())
        total_assets = self._cash + total_market_value
        total_pnl = total_assets - self._initial_balance

        # 胜率
        winning = len([t for t in self._trades if t.side == "SELL"])
        # 简化：用盈亏历史计算
        if self._daily_pnl_history:
            win_count = len([p for p in self._daily_pnl_history if p > 0])
            win_rate = win_count / len(self._daily_pnl_history)
        else:
            win_rate = 0.0

        # 最大回撤
        max_dd = 0.0
        if self._equity_history:
            peak = self._equity_history[0]
            for eq in self._equity_history:
                peak = max(peak, eq)
                dd = (peak - eq) / peak
                max_dd = max(max_dd, dd)

        # 当日盈亏
        daily_pnl = self._daily_pnl_history[-1] if self._daily_pnl_history else 0

        return ShadowReport(
            report_date=date.today().isoformat(),
            total_assets=round(total_assets, 2),
            cash=round(self._cash, 2),
            market_value=round(total_market_value, 2),
            daily_pnl=round(daily_pnl, 2),
            daily_pnl_pct=round(daily_pnl / self._initial_balance * 100, 2),
            total_pnl=round(total_pnl, 2),
            total_pnl_pct=round(total_pnl / self._initial_balance * 100, 2),
            max_drawdown=round(max_dd * 100, 2),
            win_rate=round(win_rate * 100, 1),
            total_trades=len(self._trades),
            positions=list(self._positions.values()),
            strategy_name=self._strategy_name,
            running_days=self._running_days,
        )

    def get_evaluation(self) -> Optional[Dict]:
        """影子模式运行满20个交易日后，生成评估摘要"""
        if self._running_days < 20:
            return None

        report = self.get_report()

        # 计算年化收益
        n_years = self._running_days / 252
        annualized = (report.total_pnl_pct / 100 / n_years) if n_years > 0 else 0

        # 计算夏普
        if self._daily_pnl_history and len(self._daily_pnl_history) > 1:
            daily_ret = [p / self._initial_balance for p in self._daily_pnl_history]
            sharpe = np.mean(daily_ret) / np.std(daily_ret) * np.sqrt(252) if np.std(daily_ret) > 0 else 0
        else:
            sharpe = 0

        recommendation = "建议部署至实盘"
        if report.max_drawdown > 10:
            recommendation = "回撤较大，建议优化风控参数后再部署"
        elif annualized < 0:
            recommendation = "策略亏损，不建议部署"
        elif sharpe < 0.5:
            recommendation = "风险收益比较低，建议调整策略参数"

        return {
            "running_days": self._running_days,
            "total_return_pct": report.total_pnl_pct,
            "annualized_return_pct": round(annualized * 100, 2),
            "max_drawdown_pct": report.max_drawdown,
            "sharpe_ratio": round(sharpe, 2),
            "win_rate_pct": report.win_rate,
            "total_trades": report.total_trades,
            "recommendation": recommendation,
        }

    def _save_session(self):
        """保存影子模式历史记录"""
        session_file = self._data_dir / f"shadow_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        report = self.get_report()
        data = {
            "report": asdict(report),
            "trades": [asdict(t) for t in self._trades],
            "equity_history": self._equity_history[-252:],  # 保留最近1年
        }
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        # 清理旧记录
        sessions = sorted(self._data_dir.glob("shadow_*.json"))
        while len(sessions) > self.MAX_SHADOW_HISTORY:
            sessions[0].unlink()
            sessions.pop(0)

    def load_history(self) -> List[Dict]:
        """加载历史影子记录"""
        results = []
        for f in sorted(self._data_dir.glob("shadow_*.json"), reverse=True):
            try:
                with open(f, 'r', encoding='utf-8') as fh:
                    data = json.load(fh)
                    data['file'] = str(f)
                    results.append(data)
            except Exception:
                continue
        return results
