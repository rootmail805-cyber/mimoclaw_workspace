"""
Data storage layer for QuantFlow.
Supports SQLite (default), PostgreSQL, and CSV fallback.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any
import pandas as pd
from loguru import logger

try:
    from sqlalchemy import create_engine, text, Column, String, Float, Integer, DateTime, Text
    from sqlalchemy.orm import declarative_base, sessionmaker
    HAS_SQLALCHEMY = True
except ImportError:
    HAS_SQLALCHEMY = False
    logger.warning("SQLAlchemy not installed. Database features limited.")

if HAS_SQLALCHEMY:
    Base = declarative_base()

    class BarRecord(Base):
        __tablename__ = "bars"
        id = Column(Integer, primary_key=True, autoincrement=True)
        symbol = Column(String(20), nullable=False, index=True)
        date = Column(DateTime, nullable=False, index=True)
        open = Column(Float)
        high = Column(Float)
        low = Column(Float)
        close = Column(Float)
        volume = Column(Integer)
        turnover = Column(Float)
        frequency = Column(String(10), default="daily")

    class DataVersion(Base):
        __tablename__ = "data_versions"
        id = Column(Integer, primary_key=True, autoincrement=True)
        version_tag = Column(String(50), unique=True, nullable=False)
        created_at = Column(DateTime, default=datetime.now)
        description = Column(Text)
        symbols = Column(Text)  # JSON list
        record_count = Column(Integer)


class DataStorage:
    """Unified storage interface for market data."""

    def __init__(self, db_url: str = "sqlite:///./data/quantflow.db", csv_dir: str = "./data"):
        self._csv_dir = Path(csv_dir)
        self._csv_dir.mkdir(parents=True, exist_ok=True)

        if HAS_SQLALCHEMY and db_url:
            self._engine = create_engine(db_url, echo=False)
            Base.metadata.create_all(self._engine)
            self._Session = sessionmaker(bind=self._engine)
            logger.info(f"Database connected: {db_url.split('://')[0]}://...")
        else:
            self._engine = None
            self._Session = None
            logger.info("Using CSV-only storage mode")

    def save_bars(self, symbol: str, df: pd.DataFrame, frequency: str = "daily") -> int:
        """Save bar data to database and/or CSV.

        Returns number of records saved.
        """
        if df.empty:
            return 0

        count = 0

        # Save to database
        if self._Session:
            try:
                session = self._Session()
                try:
                    records = []
                    for idx, row in df.iterrows():
                        dt = idx if isinstance(idx, datetime) else pd.to_datetime(idx)
                        records.append(BarRecord(
                            symbol=symbol,
                            date=dt,
                            open=float(row.get("open", 0)),
                            high=float(row.get("high", 0)),
                            low=float(row.get("low", 0)),
                            close=float(row.get("close", 0)),
                            volume=int(row.get("volume", 0)),
                            turnover=float(row.get("turnover", 0)),
                            frequency=frequency,
                        ))
                    session.add_all(records)
                    session.commit()
                    count = len(records)
                finally:
                    session.close()
            except Exception as e:
                logger.error(f"DB save failed for {symbol}: {e}")

        # Always save CSV backup
        csv_path = self._csv_dir / f"{symbol}_{frequency}.csv"
        df_save = df.copy()
        if "symbol" in df_save.columns:
            df_save = df_save.drop(columns=["symbol"])
        df_save.to_csv(csv_path)
        count = max(count, len(df))

        logger.info(f"Saved {count} bars for {symbol} ({frequency})")
        return count

    def load_bars(
        self,
        symbol: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        frequency: str = "daily",
    ) -> pd.DataFrame:
        """Load bar data from database or CSV fallback."""
        df = pd.DataFrame()

        # Try database first
        if self._Session:
            try:
                session = self._Session()
                try:
                    query = session.query(BarRecord).filter(
                        BarRecord.symbol == symbol,
                        BarRecord.frequency == frequency,
                    )
                    if start:
                        query = query.filter(BarRecord.date >= pd.to_datetime(start))
                    if end:
                        query = query.filter(BarRecord.date <= pd.to_datetime(end))

                    records = query.order_by(BarRecord.date).all()
                    if records:
                        df = pd.DataFrame([{
                            "date": r.date,
                            "open": r.open, "high": r.high,
                            "low": r.low, "close": r.close,
                            "volume": r.volume, "turnover": r.turnover,
                        } for r in records])
                        df["date"] = pd.to_datetime(df["date"])
                        df = df.set_index("date")
                        df["symbol"] = symbol
                finally:
                    session.close()
            except Exception as e:
                logger.warning(f"DB load failed, falling back to CSV: {e}")

        # Fallback to CSV
        if df.empty:
            csv_path = self._csv_dir / f"{symbol}_{frequency}.csv"
            if csv_path.exists():
                df = pd.read_csv(csv_path, parse_dates=["date"], index_col="date")
                df["symbol"] = symbol
                if start:
                    df = df.loc[start:]
                if end:
                    df = df.loc[:end]

        logger.debug(f"Loaded {len(df)} bars for {symbol} ({frequency})")
        return df

    def create_snapshot(self, version_tag: str, description: str = "", symbols: List[str] = None) -> None:
        """Create a versioned snapshot of the current data state."""
        if not self._Session:
            logger.warning("Snapshot requires database")
            return

        session = self._Session()
        try:
            # Count records
            count = session.query(BarRecord).count()

            version = DataVersion(
                version_tag=version_tag,
                description=description,
                symbols=json.dumps(symbols or []),
                record_count=count,
            )
            session.add(version)
            session.commit()
            logger.info(f"Snapshot created: {version_tag} ({count} records)")
        except Exception as e:
            session.rollback()
            logger.error(f"Snapshot creation failed: {e}")
        finally:
            session.close()

    def get_versions(self) -> List[Dict[str, Any]]:
        """List all data snapshots."""
        if not self._Session:
            return []

        session = self._Session()
        try:
            versions = session.query(DataVersion).order_by(DataVersion.created_at.desc()).all()
            return [{
                "tag": v.version_tag,
                "created": v.created_at.isoformat(),
                "description": v.description,
                "symbols": json.loads(v.symbols) if v.symbols else [],
                "record_count": v.record_count,
            } for v in versions]
        finally:
            session.close()
