"""
DataManager - Unified facade for all data operations.
Orchestrates providers, cleaning, and storage.
"""

from datetime import datetime, date
from typing import List, Optional, Dict, Any, Callable
import pandas as pd
from loguru import logger

from .providers import BaseProvider, AkShareProvider, CSVProvider, TencentProvider, SinaProvider, EastMoneyProvider, NetEaseProvider
from .cleaner import DataCleaner
from .storage import DataStorage
from ..models import Bar, Tick
from config.manager import get_config


class DataManager:
    """Central data management facade (Singleton).

    Responsibilities:
        - Fetch data from multiple providers with fallback
        - Clean and normalize data
        - Cache frequently accessed data in memory
        - Persist to storage with version management
        - Provide a unified query interface

    Thread-safety: All HTTP requests are serialized via providers._http_lock.
    Singleton: All code paths share the same instance (and cache).
    """

    _instance = None
    _init_lock = __import__('threading').Lock()

    def __new__(cls, config=None):
        with cls._init_lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self, config=None):
        if getattr(self, '_initialized', False):
            return
        self._initialized = True
        self._config = config or get_config()
        self._providers: Dict[str, BaseProvider] = {}
        self._cleaner = DataCleaner()
        self._storage = DataStorage(
            db_url=self._config.get("data.storage.relational.url", "sqlite:///./data/quantflow.db"),
            csv_dir=self._config.get("system.data_dir", "./data"),
        )
        self._cache: Dict[str, pd.DataFrame] = {}
        self._cache_max = self._config.get("data.cache.max_size_mb", 512)
        self._cache_lock = __import__('threading').Lock()
        self._subscribers: Dict[str, List[Callable]] = {}
        self._last_error: Optional[str] = None

        self._init_providers()

    def _init_providers(self) -> None:
        """Initialize configured data providers."""
        # Always available: CSV
        self._providers["csv"] = CSVProvider(
            data_dir=self._config.get("system.data_dir", "./data")
        )

        # Try AkShare (free, no key required)
        try:
            self._providers["akshare"] = AkShareProvider()
        except ImportError:
            logger.warning("AkShare not available")

        # Try Tencent (free, no key required, more reliable from cloud)
        try:
            self._providers["tencent"] = TencentProvider()
        except Exception as e:
            logger.warning(f"Tencent provider not available: {e}")

        # Try Sina (free, no key required)
        try:
            self._providers["sina"] = SinaProvider()
        except Exception as e:
            logger.warning(f"Sina provider not available: {e}")

        # Try EastMoney (free, no key required, very reliable)
        try:
            self._providers["eastmoney"] = EastMoneyProvider()
        except Exception as e:
            logger.warning(f"EastMoney provider not available: {e}")

        # Try NetEase (free, no key required)
        try:
            self._providers["netease"] = NetEaseProvider()
        except Exception as e:
            logger.warning(f"NetEase provider not available: {e}")

        # Try Baostock (free, no key required)
        try:
            from .providers import BaostockProvider
            self._providers["baostock"] = BaostockProvider()
        except (ImportError, Exception) as e:
            logger.warning(f"Baostock provider not available: {e}")

        # Try Tushare (requires token)
        tushare_token = self._config.get("data.sources.history.tushare_token", "")
        if tushare_token:
            try:
                from .providers import TushareProvider
                self._providers["tushare"] = TushareProvider(tushare_token)
            except (ImportError, ValueError) as e:
                logger.warning(f"Tushare not available: {e}")

        logger.info(f"Data providers: {list(self._providers.keys())}")

    def get_history(
        self,
        symbol: str,
        start: str,
        end: str,
        freq: str = "daily",
        adjust: str = "qfq",
        clean: bool = True,
        provider: Optional[str] = None,
    ) -> pd.DataFrame:
        """Get historical bar data with automatic fallback.

        Args:
            symbol: Stock symbol (e.g., '600000.SH')
            start: Start date (YYYY-MM-DD)
            end: End date (YYYY-MM-DD)
            freq: Frequency (daily, weekly, monthly, minute)
            adjust: Adjustment type (qfq, hfq, "")
            clean: Apply data cleaning
            provider: Force specific provider (None=auto)

        Returns:
            DataFrame with OHLCV data indexed by date.
        """
        cache_key = f"{symbol}_{start}_{end}_{freq}_{adjust}"

        # Check cache (thread-safe)
        with self._cache_lock:
            if cache_key in self._cache:
                logger.debug(f"Cache hit: {cache_key}")
                return self._cache[cache_key].copy()

        # Try providers in order: akshare -> eastmoney -> sina -> tencent -> netease -> baostock -> tushare -> csv
        provider_order = [provider] if provider else ["akshare", "eastmoney", "sina", "tencent", "netease", "baostock", "tushare", "csv"]
        df = pd.DataFrame()
        errors = []

        for prov_name in provider_order:
            prov = self._providers.get(prov_name)
            if not prov:
                continue

            try:
                df = prov.get_history_bars(symbol, start, end, freq, adjust)
                if not df.empty:
                    logger.info(f"Got {len(df)} bars from {prov_name} for {symbol}")
                    break
            except Exception as e:
                error_detail = f"[{prov_name}] {type(e).__name__}: {e}"
                errors.append(error_detail)
                logger.warning(f"Provider {prov_name} failed for {symbol}: {error_detail}")

        if df.empty:
            # Try loading from storage as last resort
            try:
                df = self._storage.load_bars(symbol, start, end, freq)
                if not df.empty:
                    logger.info(f"Loaded {len(df)} bars from storage for {symbol}")
            except Exception as e:
                errors.append(f"[storage] {e}")

        if df.empty:
            self._last_error = "\n".join(errors) if errors else "unknown"
            logger.error(f"No data for {symbol} ({start}~{end}). Errors:\n{self._last_error}")
            return df

        self._last_error = None

        # Clean
        if clean:
            df = self._cleaner.clean(df)

        # Persist
        self._storage.save_bars(symbol, df, freq)

        # Cache (thread-safe)
        with self._cache_lock:
            self._cache[cache_key] = df.copy()

        return df

    def get_realtime(self, symbol: str, provider: Optional[str] = None) -> Dict[str, Any]:
        """Get real-time quote for a symbol."""
        prov_name = provider or self._config.get("data.sources.realtime.provider", "akshare")
        prov = self._providers.get(prov_name)
        if not prov:
            logger.error(f"Provider {prov_name} not available")
            return {}
        return prov.get_realtime_quote(symbol)

    def get_symbols(self, market: str = "A") -> List[str]:
        """Get list of available symbols."""
        for prov_name in ["akshare", "tushare", "csv"]:
            prov = self._providers.get(prov_name)
            if prov:
                try:
                    symbols = prov.get_symbols(market)
                    if symbols:
                        return symbols
                except Exception:
                    continue
        return []

    def create_snapshot(self, tag: str, description: str = "") -> None:
        """Create a versioned data snapshot."""
        symbols = list(set(
            key.split("_")[0] for key in self._cache.keys()
        ))
        self._storage.create_snapshot(tag, description, symbols)

    @property
    def last_error(self) -> Optional[str]:
        """Return error detail from the last failed get_history call."""
        return getattr(self, '_last_error', None)

    def test_provider(self, provider_name: str = "akshare") -> dict:
        """Test a specific provider's connectivity."""
        prov = self._providers.get(provider_name)
        if not prov:
            return {"status": "SKIP", "detail": f"Provider '{provider_name}' not initialized"}
        if hasattr(prov, 'test_connection'):
            return prov.test_connection()
        return {"status": "SKIP", "detail": f"Provider '{provider_name}' has no test method"}

    def get_history_voted(
        self,
        symbol: str,
        start: str,
        end: str,
        freq: str = "daily",
        adjust: str = "qfq",
        min_sources: int = 2,
    ) -> pd.DataFrame:
        """Multi-source voting: fetch from multiple providers and cross-validate.

        Gets data from all available providers, compares close prices,
        and returns the consensus data. If a provider's data deviates
        significantly from the majority, it's flagged.

        Args:
            symbol: Stock symbol
            start/end: Date range
            freq: Frequency
            adjust: Adjustment type
            min_sources: Minimum sources needed for voting

        Returns:
            DataFrame from the most reliable source, with voting metadata.
        """
        provider_order = ["akshare", "eastmoney", "sina", "tencent", "netease", "baostock"]
        results = {}

        for prov_name in provider_order:
            prov = self._providers.get(prov_name)
            if not prov:
                continue
            try:
                df = prov.get_history_bars(symbol, start, end, freq, adjust)
                if df is not None and not df.empty and len(df) > 10:
                    results[prov_name] = df
                    logger.info(f"[Voting] {prov_name}: {len(df)} bars for {symbol}")
            except Exception as e:
                logger.warning(f"[Voting] {prov_name} failed for {symbol}: {e}")

        if not results:
            self._last_error = "All providers failed in voting"
            return pd.DataFrame()

        if len(results) < min_sources:
            # Not enough sources for voting, return the best single source
            best_name = max(results, key=lambda k: len(results[k]))
            logger.info(f"[Voting] Only {len(results)} source(s), using {best_name}")
            return results[best_name]

        # Cross-validate: compare close prices on common dates
        all_dates = None
        for name, df in results.items():
            dates = set(df.index)
            all_dates = dates if all_dates is None else all_dates & dates

        if not all_dates or len(all_dates) < 10:
            best_name = max(results, key=lambda k: len(results[k]))
            return results[best_name]

        # Compare close prices on common dates
        close_comparison = {}
        for name, df in results.items():
            common_df = df.loc[df.index.isin(all_dates)]
            close_comparison[name] = common_df["close"]

        close_df = pd.DataFrame(close_comparison)

        # Calculate deviation from median for each provider
        median_close = close_df.median(axis=1)
        deviations = {}
        for col in close_df.columns:
            dev = ((close_df[col] - median_close) / median_close).abs().mean()
            deviations[col] = dev

        # Flag providers with >1% average deviation
        reliable = {k: v for k, v in deviations.items() if v < 0.01}
        flagged = {k: v for k, v in deviations.items() if v >= 0.01}

        if flagged:
            for name, dev in flagged.items():
                logger.warning(f"[Voting] {name} flagged: {dev:.4%} deviation from consensus")

        if not reliable:
            reliable = deviations  # All deviate, use all

        # Return data from the most reliable source with most data
        best_name = max(reliable, key=lambda k: len(results[k]))
        logger.info(f"[Voting] Consensus: {len(reliable)}/{len(results)} sources agree. Using {best_name}")

        self._last_error = None
        return results[best_name]

    def clear_cache(self) -> None:
        """Clear the in-memory data cache."""
        with self._cache_lock:
            self._cache.clear()
        logger.info("Data cache cleared")

    def subscribe(self, symbol: str, callback: Callable) -> None:
        """Subscribe to real-time updates for a symbol."""
        if symbol not in self._subscribers:
            self._subscribers[symbol] = []
        self._subscribers[symbol].append(callback)
        logger.debug(f"Subscribed to {symbol} updates")

    @property
    def cache_stats(self) -> Dict[str, Any]:
        """Return cache statistics."""
        with self._cache_lock:
            total_size = sum(
                df.memory_usage(deep=True).sum() for df in self._cache.values()
            )
            return {
                "entries": len(self._cache),
                "total_size_mb": round(total_size / 1024 / 1024, 2),
                "symbols": list(set(k.split("_")[0] for k in self._cache.keys())),
            }
