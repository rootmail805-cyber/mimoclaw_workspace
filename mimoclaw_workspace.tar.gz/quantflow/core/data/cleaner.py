"""
Data cleaning and preprocessing for QuantFlow.
Handles missing values, outliers, and data normalization.
"""

import numpy as np
import pandas as pd
from typing import Optional, Literal
from loguru import logger


class DataCleaner:
    """Clean and preprocess market data."""

    def __init__(
        self,
        fill_method: Literal["ffill", "bfill", "interpolate", "zero"] = "ffill",
        outlier_std: float = 5.0,
        remove_zero_volume: bool = True,
    ):
        self.fill_method = fill_method
        self.outlier_std = outlier_std
        self.remove_zero_volume = remove_zero_volume

    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        """Full cleaning pipeline.

        Steps:
            1. Remove duplicates
            2. Handle missing values
            3. Remove outliers
            4. Remove zero-volume rows
            5. Sort by date
        """
        if df.empty:
            return df

        original_len = len(df)
        df = df.copy()

        # 1. Remove duplicate indices
        df = df[~df.index.duplicated(keep="first")]

        # 2. Handle missing values
        df = self._fill_missing(df)

        # 3. Remove outliers
        df = self._remove_outliers(df)

        # 4. Remove zero volume rows
        if self.remove_zero_volume and "volume" in df.columns:
            df = df[df["volume"] > 0]

        # 5. Sort
        df = df.sort_index()

        cleaned_len = len(df)
        if cleaned_len < original_len:
            logger.info(
                f"DataCleaner: {original_len} -> {cleaned_len} rows "
                f"({original_len - cleaned_len} removed)"
            )

        return df

    def _fill_missing(self, df: pd.DataFrame) -> pd.DataFrame:
        """Fill missing values using the configured method."""
        numeric_cols = df.select_dtypes(include=[np.number]).columns

        if self.fill_method == "ffill":
            df[numeric_cols] = df[numeric_cols].ffill()
        elif self.fill_method == "bfill":
            df[numeric_cols] = df[numeric_cols].bfill()
        elif self.fill_method == "interpolate":
            df[numeric_cols] = df[numeric_cols].interpolate(method="time")
        elif self.fill_method == "zero":
            df[numeric_cols] = df[numeric_cols].fillna(0)

        # Drop rows still having NaN in critical columns
        critical = ["open", "high", "low", "close", "volume"]
        existing_critical = [c for c in critical if c in df.columns]
        df = df.dropna(subset=existing_critical)

        return df

    def _remove_outliers(self, df: pd.DataFrame) -> pd.DataFrame:
        """Remove rows with price values that are statistical outliers."""
        if "close" not in df.columns or len(df) < 10:
            return df

        # Calculate returns
        returns = df["close"].pct_change()
        mean_ret = returns.mean()
        std_ret = returns.std()

        if std_ret == 0:
            return df

        # Flag outliers
        z_scores = (returns - mean_ret).abs() / std_ret
        outlier_mask = z_scores > self.outlier_std

        if outlier_mask.any():
            n_outliers = outlier_mask.sum()
            logger.warning(f"DataCleaner: {n_outliers} outlier rows detected (>{self.outlier_std}σ)")
            # Don't remove, just flag - removing could break time series continuity
            df["is_outlier"] = outlier_mask

        return df

    def adjust_for_splits(self, df: pd.DataFrame, adjust: str = "qfq") -> pd.DataFrame:
        """Apply forward/backward adjustment for stock splits and dividends.

        Args:
            df: DataFrame with OHLCV data and 'adj_factor' column.
            adjust: 'qfq' for forward, 'hfq' for backward.
        """
        if "adj_factor" not in df.columns:
            logger.warning("No adj_factor column found, skipping adjustment")
            return df

        factor = df["adj_factor"]
        price_cols = ["open", "high", "low", "close"]

        if adjust == "qfq":
            # Forward adjust: multiply by (factor / latest_factor)
            latest = factor.iloc[-1]
            ratio = factor / latest
        elif adjust == "hfq":
            # Backward adjust: multiply by factor directly
            ratio = factor
        else:
            return df

        for col in price_cols:
            if col in df.columns:
                df[col] = df[col] * ratio

        # Volume adjustment (inverse of price adjustment)
        if "volume" in df.columns:
            df["volume"] = (df["volume"] / ratio).astype(int)

        return df
