"""
Data providers for QuantFlow.
Abstract interface + concrete implementations for various data sources.
"""
import time
import threading

# Global HTTP lock: serialize all data source requests to prevent connection conflicts
_http_lock = threading.Lock()
_last_request_time = 0.0
_min_request_interval = 0.3  # 300ms minimum between requests

def rate_limited_get(*args, **kwargs):
    """Thread-safe rate-limited HTTP GET wrapper."""
    global _last_request_time
    import requests
    with _http_lock:
        now = time.time()
        wait = _min_request_interval - (now - _last_request_time)
        if wait > 0:
            time.sleep(wait)
        _last_request_time = time.time()
        return requests.get(*args, **kwargs)


from abc import ABC, abstractmethod
from datetime import datetime, date
from typing import List, Optional, Dict, Any
import pandas as pd
from loguru import logger


class BaseProvider(ABC):
    """Abstract base class for data providers."""

    @abstractmethod
    def get_history_bars(
        self,
        symbol: str,
        start: str,
        end: str,
        freq: str = "daily",
        adjust: str = "qfq",  # qfq=前复权, hfq=后复权, ""=不复权
    ) -> pd.DataFrame:
        """Fetch historical OHLCV bars.

        Returns DataFrame with columns:
            [date, open, high, low, close, volume, turnover]
        """
        pass

    @abstractmethod
    def get_realtime_quote(self, symbol: str) -> Dict[str, Any]:
        """Fetch real-time quote for a symbol."""
        pass

    @abstractmethod
    def get_symbols(self, market: str = "A") -> List[str]:
        """Get list of available symbols."""
        pass


class AkShareProvider(BaseProvider):
    """Data provider using AkShare library (free, no API key required)."""

    def __init__(self):
        try:
            import akshare as ak
            self._ak = ak
            self._patch_requests()
            logger.info("AkShare provider initialized")
        except ImportError:
            raise ImportError("akshare not installed. Run: pip install akshare")

    @staticmethod
    def _patch_requests():
        """No-op: global headers patching removed for thread safety.
        Each provider now uses its own session or rate_limited_get()."""
        pass

    def get_history_bars(
        self,
        symbol: str,
        start: str,
        end: str,
        freq: str = "daily",
        adjust: str = "qfq",
    ) -> pd.DataFrame:
        """Fetch historical data from AkShare."""
        import time

        # Normalize symbol: remove exchange suffix for AkShare
        code = symbol.split(".")[0] if "." in symbol else symbol

        freq_map = {
            "daily": "daily",
            "weekly": "weekly",
            "monthly": "monthly",
        }
        ak_freq = freq_map.get(freq, "daily")

        adjust_map = {
            "qfq": "qfq",
            "hfq": "hfq",
            "": "",
        }
        ak_adjust = adjust_map.get(adjust, "qfq")

        start_fmt = start.replace("-", "")
        end_fmt = end.replace("-", "")

        last_error = None
        for attempt in range(3):
            try:
                if attempt > 0:
                    logger.info(f"AkShare retry {attempt}/3 for {symbol}...")
                    time.sleep(2 * attempt)  # Exponential backoff: 2s, 4s

                with _http_lock:
                    df = self._ak.stock_zh_a_hist(
                        symbol=code,
                        period=ak_freq,
                        start_date=start_fmt,
                        end_date=end_fmt,
                        adjust=ak_adjust,
                    )

                if df is None or df.empty:
                    raise ValueError(f"AkShare返回空数据 (symbol={code}, {start_fmt}~{end_fmt})")

                # Normalize column names
                column_map = {
                    "日期": "date",
                    "开盘": "open",
                    "收盘": "close",
                    "最高": "high",
                    "最低": "low",
                    "成交量": "volume",
                    "成交额": "turnover",
                    "振幅": "amplitude",
                    "涨跌幅": "change_pct",
                    "涨跌额": "change",
                    "换手率": "turnover_rate",
                }
                df = df.rename(columns=column_map)

                # Ensure date column
                if "date" in df.columns:
                    df["date"] = pd.to_datetime(df["date"])
                    df = df.set_index("date")

                df["symbol"] = symbol
                logger.info(f"AkShare: fetched {len(df)} bars for {symbol} ({start} ~ {end})")
                return df

            except Exception as e:
                last_error = e
                logger.warning(f"AkShare attempt {attempt+1}/3 failed for {symbol}: {type(e).__name__}: {e}")

        # All retries exhausted — raise with full context
        raise RuntimeError(
            f"AkShare获取 {symbol} 数据失败 (尝试3次): {type(last_error).__name__}: {last_error}\n"
            f"参数: code={code}, freq={ak_freq}, adjust={ak_adjust}, date={start_fmt}~{end_fmt}"
        ) from last_error

    def test_connection(self) -> dict:
        """Test AkShare connectivity and return diagnostic info."""
        import time
        result = {"akshare_version": None, "tests": []}
        try:
            import akshare as ak
            result["akshare_version"] = getattr(ak, '__version__', 'unknown')
        except ImportError:
            result["tests"].append({"name": "import", "status": "FAIL", "detail": "akshare未安装"})
            return result

        # Test 1: realtime spot
        try:
            t0 = time.time()
            with _http_lock:
                df = self._ak.stock_zh_a_spot_em()
            t1 = time.time()
            result["tests"].append({
                "name": "实时行情",
                "status": "OK",
                "detail": f"获取 {len(df)} 只股票, 耗时 {t1-t0:.1f}s"
            })
        except Exception as e:
            result["tests"].append({
                "name": "实时行情",
                "status": "FAIL",
                "detail": f"{type(e).__name__}: {e}"
            })

        # Test 2: history (600000)
        try:
            t0 = time.time()
            with _http_lock:
                df = self._ak.stock_zh_a_hist(
                    symbol="600000", period="daily",
                    start_date="20250601", end_date="20250630", adjust="qfq"
                )
            t1 = time.time()
            result["tests"].append({
                "name": "历史数据(600000)",
                "status": "OK" if (df is not None and not df.empty) else "EMPTY",
                "detail": f"{len(df) if df is not None else 0} 行, 耗时 {t1-t0:.1f}s"
            })
        except Exception as e:
            result["tests"].append({
                "name": "历史数据(600000)",
                "status": "FAIL",
                "detail": f"{type(e).__name__}: {e}"
            })

        return result

    def get_realtime_quote(self, symbol: str) -> Dict[str, Any]:
        """Fetch real-time quote from AkShare."""
        try:
            code = symbol.split(".")[0] if "." in symbol else symbol
            with _http_lock:
                df = self._ak.stock_zh_a_spot_em()
            row = df[df["代码"] == code]
            if row.empty:
                return {}

            row = row.iloc[0]
            return {
                "symbol": symbol,
                "price": float(row.get("最新价", 0)),
                "change_pct": float(row.get("涨跌幅", 0)),
                "volume": int(row.get("成交量", 0)),
                "turnover": float(row.get("成交额", 0)),
                "high": float(row.get("最高", 0)),
                "low": float(row.get("最低", 0)),
                "open": float(row.get("今开", 0)),
                "pre_close": float(row.get("昨收", 0)),
                "timestamp": datetime.now(),
            }
        except Exception as e:
            logger.error(f"AkShare realtime quote failed for {symbol}: {e}")
            return {}

    def get_symbols(self, market: str = "A") -> List[str]:
        """Get list of A-share symbols."""
        try:
            with _http_lock:
                df = self._ak.stock_zh_a_spot_em()
            symbols = df["代码"].tolist()
            return [f"{s}.SH" if s.startswith("6") else f"{s}.SZ" for s in symbols]
        except Exception as e:
            logger.error(f"AkShare get_symbols failed: {e}")
            return []


class TushareProvider(BaseProvider):
    """Data provider using Tushare Pro (requires API token)."""

    def __init__(self, token: str = ""):
        import os
        token = token or os.environ.get("QUANT_TUSHARE_TOKEN", "")
        if not token:
            raise ValueError("Tushare token required. Set QUANT_TUSHARE_TOKEN env var.")
        try:
            import tushare as ts
            ts.set_token(token)
            self._pro = ts.pro_api()
            logger.info("Tushare Pro provider initialized")
        except ImportError:
            raise ImportError("tushare not installed. Run: pip install tushare")

    def get_history_bars(
        self,
        symbol: str,
        start: str,
        end: str,
        freq: str = "daily",
        adjust: str = "qfq",
    ) -> pd.DataFrame:
        """Fetch historical data from Tushare."""
        try:
            # Tushare format: 600000.SH
            ts_code = symbol if "." in symbol else symbol
            freq_map = {"daily": "D", "weekly": "W", "monthly": "M"}
            ts_freq = freq_map.get(freq, "D")

            df = self._pro.daily(
                ts_code=ts_code,
                start_date=start.replace("-", ""),
                end_date=end.replace("-", ""),
            )

            if df is None or df.empty:
                return pd.DataFrame()

            column_map = {
                "trade_date": "date",
                "vol": "volume",
                "amount": "turnover",
            }
            df = df.rename(columns=column_map)
            df["date"] = pd.to_datetime(df["date"])
            df = df.set_index("date").sort_index()
            df["symbol"] = symbol

            logger.info(f"Tushare: fetched {len(df)} bars for {symbol}")
            return df

        except Exception as e:
            logger.error(f"Tushare fetch failed for {symbol}: {e}")
            return pd.DataFrame()

    def get_realtime_quote(self, symbol: str) -> Dict[str, Any]:
        """Tushare realtime requires higher subscription."""
        logger.warning("Tushare realtime quote not available on basic plan")
        return {}

    def get_symbols(self, market: str = "A") -> List[str]:
        """Get stock list from Tushare."""
        try:
            df = self._pro.stock_basic(exchange="", list_status="L")
            return df["ts_code"].tolist()
        except Exception as e:
            logger.error(f"Tushare get_symbols failed: {e}")
            return []


class CSVProvider(BaseProvider):
    """Data provider that reads from local CSV files."""

    def __init__(self, data_dir: str = "./data"):
        from pathlib import Path
        self._dir = Path(data_dir)
        logger.info(f"CSV provider initialized, data_dir={self._dir}")

    def get_history_bars(
        self,
        symbol: str,
        start: str,
        end: str,
        freq: str = "daily",
        adjust: str = "qfq",
    ) -> pd.DataFrame:
        """Read historical data from CSV file."""
        csv_path = self._dir / f"{symbol}_{freq}.csv"
        if not csv_path.exists():
            logger.warning(f"CSV file not found: {csv_path}")
            return pd.DataFrame()

        df = pd.read_csv(csv_path, parse_dates=["date"], index_col="date")
        df = df.loc[start:end]
        df["symbol"] = symbol
        logger.info(f"CSV: loaded {len(df)} bars for {symbol} from {csv_path}")
        return df

    def get_realtime_quote(self, symbol: str) -> Dict[str, Any]:
        logger.warning("CSV provider does not support realtime quotes")
        return {}

    def get_symbols(self, market: str = "A") -> List[str]:
        """List available symbols from CSV filenames."""
        symbols = []
        for f in self._dir.glob("*_daily.csv"):
            symbols.append(f.stem.replace("_daily", ""))
        return symbols

    def save_bars(self, symbol: str, df: pd.DataFrame, freq: str = "daily") -> None:
        """Save bar data to CSV."""
        csv_path = self._dir / f"{symbol}_{freq}.csv"
        self._dir.mkdir(parents=True, exist_ok=True)
        df.to_csv(csv_path)
        logger.info(f"CSV: saved {len(df)} bars for {symbol} to {csv_path}")


class TencentProvider(BaseProvider):
    """Data provider using Tencent Finance API (qt.gtimg.cn).
    Free, no API key required, more reliable than East Money from cloud servers."""

    def __init__(self):
        import requests
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        })
        logger.info("Tencent provider initialized")

    def _symbol_to_tencent(self, symbol: str) -> str:
        """Convert symbol to Tencent format: sh600000 / sz000001"""
        code = symbol.split(".")[0] if "." in symbol else symbol
        if code.startswith("6"):
            return f"sh{code}"
        else:
            return f"sz{code}"

    def get_history_bars(self, symbol: str, start: str, end: str,
                         freq: str = "daily", adjust: str = "qfq") -> pd.DataFrame:
        """Fetch historical data from Tencent (limited to recent data)."""
        try:
            import requests
            code = self._symbol_to_tencent(symbol)

            # Tencent day K-line API
            url = f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"
            params = {
                "param": f"{code},day,{start},{end},640,{adjust}",
            }
            r = rate_limited_get(url, params=params, timeout=10)
            data = r.json()

            # Parse response
            stock_data = data.get("data", {}).get(code, {})
            kline_key = "qfqday" if adjust == "qfq" else "day"
            klines = stock_data.get(kline_key, stock_data.get("day", []))

            if not klines:
                return pd.DataFrame()

            # Build DataFrame
            rows = []
            for k in klines:
                if len(k) >= 6:
                    rows.append({
                        "date": k[0],
                        "open": float(k[1]),
                        "close": float(k[2]),
                        "high": float(k[3]),
                        "low": float(k[4]),
                        "volume": int(float(k[5])) if len(k) > 5 else 0,
                    })

            df = pd.DataFrame(rows)
            if df.empty:
                return df

            df["date"] = pd.to_datetime(df["date"])
            df = df.set_index("date")
            df["turnover"] = 0.0
            df["symbol"] = symbol

            logger.info(f"Tencent: fetched {len(df)} bars for {symbol}")
            return df

        except Exception as e:
            logger.error(f"Tencent fetch failed for {symbol}: {e}")
            return pd.DataFrame()

    def get_realtime_quote(self, symbol: str) -> Dict[str, Any]:
        """Fetch real-time quote from Tencent."""
        try:
            import requests
            code = self._symbol_to_tencent(symbol)
            r = rate_limited_get(f"https://qt.gtimg.cn/q={code}", timeout=10)
            text = r.text

            # Parse: v_sh600000="1~浦发银行~600000~8.66~8.70~..."
            parts = text.split("~")
            if len(parts) < 10:
                return {}

            return {
                "symbol": symbol,
                "name": parts[1],
                "price": float(parts[3]) if parts[3] else 0,
                "pre_close": float(parts[4]) if parts[4] else 0,
                "open": float(parts[5]) if parts[5] else 0,
                "volume": int(float(parts[6])) if parts[6] else 0,
                "timestamp": datetime.now(),
            }
        except Exception as e:
            logger.error(f"Tencent realtime failed for {symbol}: {e}")
            return {}

    def get_symbols(self, market: str = "A") -> List[str]:
        return []  # Not supported via Tencent API


class SinaProvider(BaseProvider):
    """Data provider using Sina Finance API.
    Free, no API key required. Reliable historical K-line data."""

    def __init__(self):
        self._headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': 'https://finance.sina.com.cn',
        }
        logger.info("Sina provider initialized")

    def _symbol_to_sina(self, symbol: str) -> str:
        code = symbol.split(".")[0] if "." in symbol else symbol
        if code.startswith("6"):
            return f"sh{code}"
        else:
            return f"sz{code}"

    def get_history_bars(self, symbol: str, start: str, end: str,
                         freq: str = "daily", adjust: str = "qfq") -> pd.DataFrame:
        """Fetch historical K-line from Sina."""
        try:
            import requests
            code = self._symbol_to_sina(symbol)

            # Sina K-line API: scale=240=daily, datalen=number of bars
            scale_map = {"daily": 240, "weekly": 1200, "monthly": 7200}
            scale = scale_map.get(freq, 240)

            url = "https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData"
            params = {
                "symbol": code,
                "scale": str(scale),
                "ma": "no",
                "datalen": "600",
            }
            r = rate_limited_get(url, params=params, headers=self._headers, timeout=15)

            if r.status_code != 200:
                return pd.DataFrame()

            import json
            data = json.loads(r.text)
            if not data:
                return pd.DataFrame()

            rows = []
            for item in data:
                rows.append({
                    "date": item["day"],
                    "open": float(item["open"]),
                    "high": float(item["high"]),
                    "low": float(item["low"]),
                    "close": float(item["close"]),
                    "volume": int(float(item["volume"])),
                })

            df = pd.DataFrame(rows)
            if df.empty:
                return df

            df["date"] = pd.to_datetime(df["date"])
            df = df.set_index("date")

            # Filter by date range
            if start:
                df = df[df.index >= start]
            if end:
                df = df[df.index <= end]

            df["turnover"] = 0.0
            df["symbol"] = symbol

            logger.info(f"Sina: fetched {len(df)} bars for {symbol}")
            return df

        except Exception as e:
            logger.error(f"Sina fetch failed for {symbol}: {e}")
            return pd.DataFrame()

    def get_realtime_quote(self, symbol: str) -> Dict[str, Any]:
        """Fetch real-time quote from Sina."""
        try:
            import requests
            code = self._symbol_to_sina(symbol)
            r = rate_limited_get(f"https://hq.sinajs.cn/list={code}", headers=self._headers, timeout=10)

            if r.status_code != 200:
                return {}

            # Parse: var hq_str_sh600000="浦发银行,8.690,8.700,8.660,..."
            text = r.text
            parts = text.split('"')[1].split(',') if '"' in text else []
            if len(parts) < 10:
                return {}

            return {
                "symbol": symbol,
                "name": parts[0],
                "open": float(parts[1]),
                "pre_close": float(parts[2]),
                "price": float(parts[3]),
                "high": float(parts[4]),
                "low": float(parts[5]),
                "volume": int(float(parts[8])),
                "timestamp": datetime.now(),
            }
        except Exception as e:
            logger.error(f"Sina realtime failed for {symbol}: {e}")
            return {}

    def get_symbols(self, market: str = "A") -> List[str]:
        return []


class EastMoneyProvider(BaseProvider):
    """Data provider using East Money (eastmoney.com) API.
    Free, no API key required. One of the most reliable sources in China."""

    def __init__(self):
        import requests
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': 'https://quote.eastmoney.com',
        })
        logger.info("EastMoney provider initialized")

    def _symbol_to_em(self, symbol: str) -> tuple:
        """Convert symbol to EastMoney format: (secid, code)
        secid: 1.600000 for SH, 0.000001 for SZ"""
        code = symbol.split(".")[0] if "." in symbol else symbol
        if code.startswith("6"):
            return f"1.{code}", code
        else:
            return f"0.{code}", code

    def get_history_bars(self, symbol: str, start: str, end: str,
                         freq: str = "daily", adjust: str = "qfq") -> pd.DataFrame:
        """Fetch historical data from EastMoney."""
        try:
            import requests
            secid, code = self._symbol_to_em(symbol)

            klt_map = {"daily": "101", "weekly": "102", "monthly": "103"}
            klt = klt_map.get(freq, "101")

            fqt_map = {"qfq": "1", "hfq": "2", "": "0"}
            fqt = fqt_map.get(adjust, "1")

            url = "https://push2his.eastmoney.com/api/qt/stock/kline/get"
            params = {
                "secid": secid,
                "fields1": "f1,f2,f3,f4,f5,f6",
                "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
                "klt": klt,
                "fqt": fqt,
                "beg": start.replace("-", ""),
                "end": end.replace("-", ""),
                "lmt": "1000",
            }
            r = rate_limited_get(url, params=params, timeout=15)
            data = r.json()

            klines = data.get("data", {}).get("klines", [])
            if not klines:
                return pd.DataFrame()

            rows = []
            for line in klines:
                parts = line.split(",")
                if len(parts) >= 7:
                    rows.append({
                        "date": parts[0],
                        "open": float(parts[1]),
                        "close": float(parts[2]),
                        "high": float(parts[3]),
                        "low": float(parts[4]),
                        "volume": int(float(parts[5])),
                        "turnover": float(parts[6]),
                    })

            df = pd.DataFrame(rows)
            if df.empty:
                return df

            df["date"] = pd.to_datetime(df["date"])
            df = df.set_index("date")
            df["symbol"] = symbol

            logger.info(f"EastMoney: fetched {len(df)} bars for {symbol}")
            return df

        except Exception as e:
            logger.error(f"EastMoney fetch failed for {symbol}: {e}")
            return pd.DataFrame()

    def get_realtime_quote(self, symbol: str) -> Dict[str, Any]:
        try:
            import requests
            secid, code = self._symbol_to_em(symbol)
            url = "https://push2.eastmoney.com/api/qt/stock/get"
            params = {
                "secid": secid,
                "fields": "f43,f44,f45,f46,f47,f48,f50,f57,f58,f60,f170",
            }
            r = rate_limited_get(url, params=params, timeout=10)
            data = r.json().get("data", {})
            if not data:
                return {}

            return {
                "symbol": symbol,
                "price": float(data.get("f43", 0)) / 100 if data.get("f43") else 0,
                "high": float(data.get("f44", 0)) / 100 if data.get("f44") else 0,
                "low": float(data.get("f45", 0)) / 100 if data.get("f45") else 0,
                "open": float(data.get("f46", 0)) / 100 if data.get("f46") else 0,
                "volume": int(data.get("f47", 0)),
                "turnover": float(data.get("f48", 0)),
                "change_pct": float(data.get("f170", 0)) / 100 if data.get("f170") else 0,
                "timestamp": datetime.now(),
            }
        except Exception as e:
            logger.error(f"EastMoney realtime failed for {symbol}: {e}")
            return {}

    def get_symbols(self, market: str = "A") -> List[str]:
        return []


class NetEaseProvider(BaseProvider):
    """Data provider using NetEase Finance API (quotes.money.163.com).
    Free, no API key required. Good for historical data."""

    def __init__(self):
        import requests
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        })
        logger.info("NetEase provider initialized")

    def _symbol_to_netease(self, symbol: str) -> str:
        code = symbol.split(".")[0] if "." in symbol else symbol
        if code.startswith("6"):
            return f"0{code}"
        else:
            return f"1{code}"

    def get_history_bars(self, symbol: str, start: str, end: str,
                         freq: str = "daily", adjust: str = "qfq") -> pd.DataFrame:
        try:
            import requests
            import csv
            import io

            code = self._symbol_to_netease(symbol)
            start_fmt = start.replace("-", "")
            end_fmt = end.replace("-", "")

            url = "http://quotes.money.163.com/service/chddata.html"
            params = {
                "code": code,
                "start": start_fmt,
                "end": end_fmt,
                "fields": "TCLOSE;HIGH;LOW;TOPEN;LCLOSE;CHG;PCHG;TURNOVER;VOTURNOVER;VATURNOVER",
            }

            r = rate_limited_get(url, params=params, timeout=15)
            r.encoding = "gb2312"

            reader = csv.DictReader(io.StringIO(r.text))
            rows = []
            for row in reader:
                try:
                    close_val = float(row.get("TCLOSE", 0) or 0)
                    if close_val == 0:
                        continue
                    rows.append({
                        "date": row.get("DATE", ""),
                        "open": float(row.get("TOPEN", 0) or 0),
                        "high": float(row.get("HIGH", 0) or 0),
                        "low": float(row.get("LOW", 0) or 0),
                        "close": close_val,
                        "volume": int(float(row.get("VOTURNOVER", 0) or 0)),
                        "turnover": float(row.get("VATURNOVER", 0) or 0),
                    })
                except (ValueError, TypeError):
                    continue

            if not rows:
                return pd.DataFrame()

            df = pd.DataFrame(rows)
            df["date"] = pd.to_datetime(df["date"])
            df = df.set_index("date").sort_index()
            df["symbol"] = symbol

            logger.info(f"NetEase: fetched {len(df)} bars for {symbol}")
            return df

        except Exception as e:
            logger.error(f"NetEase fetch failed for {symbol}: {e}")
            return pd.DataFrame()

    def get_realtime_quote(self, symbol: str) -> Dict[str, Any]:
        return {}

    def get_symbols(self, market: str = "A") -> List[str]:
        return []


class BaostockProvider(BaseProvider):
    """Data provider using Baostock (baostock.com).
    Free, no API key required. Popular among Chinese quant traders."""

    def __init__(self):
        try:
            import baostock as bs
            self._bs = bs
            self._logged_in = False
            logger.info("Baostock provider initialized")
        except ImportError:
            raise ImportError("baostock not installed. Run: pip install baostock")

    def _ensure_login(self):
        if not self._logged_in:
            with _http_lock:
                self._bs.login()
                self._logged_in = True

    def _symbol_to_bs(self, symbol: str) -> str:
        code = symbol.split(".")[0] if "." in symbol else symbol
        if code.startswith("6"):
            return f"sh.{code}"
        else:
            return f"sz.{code}"

    def get_history_bars(self, symbol: str, start: str, end: str,
                         freq: str = "daily", adjust: str = "qfq") -> pd.DataFrame:
        try:
            self._ensure_login()
            bs_code = self._symbol_to_bs(symbol)

            freq_map = {"daily": "d", "weekly": "w", "monthly": "m"}
            bs_freq = freq_map.get(freq, "d")

            adjust_map = {"qfq": "2", "hfq": "1", "": "3"}
            bs_adjust = adjust_map.get(adjust, "2")

            rs = self._bs.query_history_k_data_plus(
                bs_code,
                "date,open,high,low,close,volume,amount",
                start_date=start,
                end_date=end,
                frequency=bs_freq,
                adjustflag=bs_adjust,
            )

            rows = []
            while rs.error_code == "0" and rs.next():
                row = rs.get_row_data()
                if len(row) >= 7:
                    try:
                        rows.append({
                            "date": row[0],
                            "open": float(row[1]),
                            "high": float(row[2]),
                            "low": float(row[3]),
                            "close": float(row[4]),
                            "volume": int(float(row[5])) if row[5] else 0,
                            "turnover": float(row[6]) if row[6] else 0,
                        })
                    except (ValueError, TypeError):
                        continue

            if not rows:
                return pd.DataFrame()

            df = pd.DataFrame(rows)
            df["date"] = pd.to_datetime(df["date"])
            df = df.set_index("date")
            df["symbol"] = symbol

            logger.info(f"Baostock: fetched {len(df)} bars for {symbol}")
            return df

        except Exception as e:
            logger.error(f"Baostock fetch failed for {symbol}: {e}")
            return pd.DataFrame()

    def get_realtime_quote(self, symbol: str) -> Dict[str, Any]:
        return {}

    def get_symbols(self, market: str = "A") -> List[str]:
        return []

    def __del__(self):
        if hasattr(self, '_logged_in') and self._logged_in:
            try:
                self._bs.logout()
            except Exception:
                pass
