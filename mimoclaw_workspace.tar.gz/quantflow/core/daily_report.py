"""
移动端每日战报推送
每日收盘后自动生成精简战报，通过钉钉/微信/邮件推送
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime, date, timedelta
from loguru import logger

import numpy as np


@dataclass
class DailyReport:
    """每日战报"""
    report_date: str = ""
    # 今日盈亏
    daily_pnl: float = 0.0
    daily_pnl_pct: float = 0.0
    # 总资产
    total_assets: float = 0.0
    cash: float = 0.0
    market_value: float = 0.0
    # 仓位
    position_ratio: float = 0.0  # 仓位比例
    # 前三大持仓
    top_positions: List[Dict] = field(default_factory=list)  # [{symbol, name, pnl, pnl_pct}]
    # 风控状态
    risk_status: str = "正常"
    risk_warning: str = ""
    # 策略信息
    strategy_name: str = ""
    running_days: int = 0
    # 交易统计
    total_trades_today: int = 0
    # 异常标记
    is_alert: bool = False
    alert_message: str = ""


@dataclass
class WeeklyReport:
    """周度摘要"""
    week_start: str = ""
    week_end: str = ""
    weekly_return: float = 0.0
    weekly_return_pct: float = 0.0
    max_drawdown: float = 0.0
    total_trades: int = 0
    win_rate: float = 0.0
    profit_loss_ratio: float = 0.0
    best_trade: Optional[Dict] = None
    worst_trade: Optional[Dict] = None


class DailyReporter:
    """每日战报生成器"""

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._notifier = None

    def set_notifier(self, notifier):
        """设置通知管理器"""
        self._notifier = notifier

    def generate_daily(
        self,
        account: Any,
        positions: Dict,
        trades: List[Dict],
        strategy_name: str = "",
        running_days: int = 0,
        daily_loss_limit: float = 0.03,
    ) -> DailyReport:
        """生成每日战报

        Args:
            account: 账户对象（含 total_assets, cash, market_value）
            positions: 持仓字典 {symbol: position}
            trades: 今日交易记录
            strategy_name: 策略名称
            running_days: 运行天数
            daily_loss_limit: 单日亏损限额（如0.03表示3%）

        Returns:
            DailyReport 战报对象
        """
        total_assets = getattr(account, 'total_assets', 0)
        cash = getattr(account, 'cash', 0)
        market_value = getattr(account, 'market_value', 0)

        # 今日盈亏
        daily_pnl = sum(t.get("pnl", 0) for t in trades if t.get("trade_time", "")[:10] == date.today().isoformat())
        daily_pnl_pct = (daily_pnl / total_assets * 100) if total_assets > 0 else 0

        # 仓位比例
        position_ratio = (market_value / total_assets * 100) if total_assets > 0 else 0

        # 前三大持仓
        pos_list = []
        for sym, pos in positions.items():
            pnl = getattr(pos, 'pnl', 0)
            pnl_pct = getattr(pos, 'pnl_pct', 0)
            pos_list.append({
                "symbol": sym,
                "name": getattr(pos, 'name', sym),
                "quantity": getattr(pos, 'volume', 0),
                "pnl": round(pnl, 2),
                "pnl_pct": round(pnl_pct, 2),
            })
        pos_list.sort(key=lambda x: abs(x["pnl"]), reverse=True)
        top3 = pos_list[:3]

        # 风控状态
        risk_status = "正常"
        risk_warning = ""
        is_alert = False
        alert_message = ""

        if daily_loss_limit > 0 and total_assets > 0:
            loss_ratio = abs(daily_pnl) / total_assets if daily_pnl < 0 else 0
            if loss_ratio >= daily_loss_limit:
                risk_status = "熔断"
                risk_warning = f"单日亏损已达限额({loss_ratio:.1%} >= {daily_loss_limit:.1%})"
                is_alert = True
                alert_message = f"⚠️ 今日亏损较大，已达单日限额的{loss_ratio / daily_loss_limit * 100:.0f}%"
            elif loss_ratio >= daily_loss_limit * 0.5:
                risk_status = "警告"
                risk_warning = f"单日亏损接近限额({loss_ratio:.1%})"
                is_alert = True
                alert_message = f"⚠️ 今日亏损已达单日限额的{loss_ratio / daily_loss_limit * 100:.0f}%"

        report = DailyReport(
            report_date=date.today().isoformat(),
            daily_pnl=round(daily_pnl, 2),
            daily_pnl_pct=round(daily_pnl_pct, 2),
            total_assets=round(total_assets, 2),
            cash=round(cash, 2),
            market_value=round(market_value, 2),
            position_ratio=round(position_ratio, 1),
            top_positions=top3,
            risk_status=risk_status,
            risk_warning=risk_warning,
            strategy_name=strategy_name,
            running_days=running_days,
            total_trades_today=len([t for t in trades if t.get("trade_time", "")[:10] == date.today().isoformat()]),
            is_alert=is_alert,
            alert_message=alert_message,
        )

        return report

    def format_daily_message(self, report: DailyReport) -> str:
        """格式化每日战报为推送消息"""
        pnl_sign = "+" if report.daily_pnl >= 0 else ""
        pnl_emoji = "📈" if report.daily_pnl >= 0 else "📉"

        lines = [
            f"{'═' * 30}",
            f"  📊 QuantFlow 每日战报",
            f"  {report.report_date}",
            f"{'═' * 30}",
            "",
            f"  {pnl_emoji} 今日盈亏: ¥{pnl_sign}{report.daily_pnl:,.2f} ({pnl_sign}{report.daily_pnl_pct:.2f}%)",
            f"  💰 总资产: ¥{report.total_assets:,.2f}",
            f"  💵 可用资金: ¥{report.cash:,.2f}",
            f"  📦 仓位比例: {report.position_ratio:.1f}%",
            "",
        ]

        # 异常突出显示
        if report.is_alert:
            lines.append(f"  🚨 {report.alert_message}")
            lines.append("")

        # 前三大持仓
        if report.top_positions:
            lines.append("  ◆ 主要持仓:")
            for i, p in enumerate(report.top_positions, 1):
                p_sign = "+" if p["pnl"] >= 0 else ""
                p_emoji = "🟢" if p["pnl"] >= 0 else "🔴"
                lines.append(f"    {p_emoji} {p['symbol']}: ¥{p_sign}{p['pnl']:,.0f} ({p_sign}{p['pnl_pct']:.1f}%)")
            lines.append("")

        # 风控状态
        risk_emoji = {"正常": "🟢", "警告": "🟡", "熔断": "🔴"}.get(report.risk_status, "⚪")
        lines.append(f"  🛡️ 风控状态: {risk_emoji} {report.risk_status}")
        if report.risk_warning:
            lines.append(f"     {report.risk_warning}")
        lines.append("")

        # 策略信息
        if report.strategy_name:
            lines.append(f"  📋 策略: {report.strategy_name} (运行{report.running_days}天)")

        lines.append(f"  📝 今日交易: {report.total_trades_today}笔")
        lines.append("")
        lines.append(f"{'═' * 30}")

        return "\n".join(lines)

    def generate_weekly(self, daily_reports: List[DailyReport], trades: List[Dict]) -> WeeklyReport:
        """生成周度摘要"""
        if not daily_reports:
            return WeeklyReport()

        total_pnl = sum(r.daily_pnl for r in daily_reports)
        initial_assets = daily_reports[0].total_assets - daily_reports[0].daily_pnl
        weekly_return_pct = (total_pnl / initial_assets * 100) if initial_assets > 0 else 0

        # 最大回撤
        equity = [initial_assets]
        for r in daily_reports:
            equity.append(equity[-1] + r.daily_pnl)
        peak = np.maximum.accumulate(equity)
        dd = [(p - e) / p for p, e in zip(peak, equity)]
        max_dd = max(dd) * 100 if dd else 0

        # 胜率
        winning = len([t for t in trades if t.get("pnl", 0) > 0])
        total = len(trades)
        win_rate = (winning / total * 100) if total > 0 else 0

        # 盈亏比
        wins = [t.get("pnl", 0) for t in trades if t.get("pnl", 0) > 0]
        losses = [abs(t.get("pnl", 0)) for t in trades if t.get("pnl", 0) < 0]
        avg_win = np.mean(wins) if wins else 0
        avg_loss = np.mean(losses) if losses else 1
        pl_ratio = avg_win / avg_loss if avg_loss > 0 else 0

        # 最好/最差交易
        best = max(trades, key=lambda t: t.get("pnl", 0)) if trades else None
        worst = min(trades, key=lambda t: t.get("pnl", 0)) if trades else None

        return WeeklyReport(
            week_start=daily_reports[0].report_date,
            week_end=daily_reports[-1].report_date,
            weekly_return=round(total_pnl, 2),
            weekly_return_pct=round(weekly_return_pct, 2),
            max_drawdown=round(max_dd, 2),
            total_trades=total,
            win_rate=round(win_rate, 1),
            profit_loss_ratio=round(pl_ratio, 2),
            best_trade=best,
            worst_trade=worst,
        )

    def format_weekly_message(self, report: WeeklyReport) -> str:
        """格式化周度摘要为推送消息"""
        sign = "+" if report.weekly_return >= 0 else ""

        lines = [
            f"{'═' * 30}",
            f"  📊 QuantFlow 周度摘要",
            f"  {report.week_start} ~ {report.week_end}",
            f"{'═' * 30}",
            "",
            f"  💰 周收益: ¥{sign}{report.weekly_return:,.2f} ({sign}{report.weekly_return_pct:.2f}%)",
            f"  📉 最大回撤: {report.max_drawdown:.2f}%",
            f"  📝 交易笔数: {report.total_trades}",
            f"  ✅ 胜率: {report.win_rate:.1f}%",
            f"  ⚖️ 盈亏比: {report.profit_loss_ratio:.2f}",
            "",
        ]

        if report.best_trade:
            lines.append(f"  🏆 最佳交易: {report.best_trade.get('symbol', '')} +{report.best_trade.get('pnl', 0):,.0f}")
        if report.worst_trade:
            lines.append(f"  💀 最差交易: {report.worst_trade.get('symbol', '')} {report.worst_trade.get('pnl', 0):,.0f}")

        lines.append(f"{'═' * 30}")
        return "\n".join(lines)

    def push_daily(self, report: DailyReport):
        """推送每日战报"""
        if self._notifier is None:
            logger.warning("[DailyReport] 通知管理器未设置，跳过推送")
            return

        message = self.format_daily_message(report)
        try:
            self._notifier.send(title=f"QuantFlow 战报 {report.report_date}", message=message)
            logger.info("[DailyReport] 每日战报已推送")
        except Exception as e:
            logger.error(f"[DailyReport] 推送失败: {e}")

    def push_weekly(self, report: WeeklyReport):
        """推送周度摘要"""
        if self._notifier is None:
            return

        message = self.format_weekly_message(report)
        try:
            self._notifier.send(title=f"QuantFlow 周报 {report.week_start}~{report.week_end}", message=message)
            logger.info("[DailyReport] 周度摘要已推送")
        except Exception as e:
            logger.error(f"[DailyReport] 推送失败: {e}")
