"""
⚠️ DEPRECATED - 此模块已废弃，未被系统任何组件引用。
保留代码供未来参考，但不应在新代码中使用。
如需使用其中的功能，请先集成到 GUI 和业务流程中。
"""

"""
Persistent signal queue with SQLite backend.

Provides crash-safe signal persistence so that signals survive process
restarts and broker disconnections. Signals are enqueued atomically and
dequeued in FIFO order, with explicit acknowledgment via mark_processed
or mark_failed.
"""

import json
import os
import sqlite3
import time
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any

from loguru import logger


class PersistentSignalQueue:
    """SQLite-backed persistent signal queue.

    Signals survive process crashes and can be replayed after reconnection.
    Each signal moves through the lifecycle: PENDING → PROCESSING → DONE/FAILED.

    Args:
        db_path: Path to the SQLite database file.
        max_retries: Maximum retry count before marking a signal as dead.
    """

    # Signal states
    STATE_PENDING = "PENDING"
    STATE_PROCESSING = "PROCESSING"
    STATE_DONE = "DONE"
    STATE_FAILED = "FAILED"

    def __init__(
        self,
        db_path: str = "./data/signal_queue.db",
        max_retries: int = 3,
    ):
        self._db_path = db_path
        self._max_retries = max_retries
        self._conn: Optional[sqlite3.Connection] = None
        self._init_db()

    def _init_db(self) -> None:
        """Initialize the SQLite database and create the signals table."""
        db_dir = os.path.dirname(self._db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)

        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS signal_queue (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                signal_json TEXT    NOT NULL,
                state       TEXT    NOT NULL DEFAULT 'PENDING',
                retry_count INTEGER NOT NULL DEFAULT 0,
                created_at  TEXT    NOT NULL,
                updated_at  TEXT    NOT NULL,
                error_msg   TEXT    NOT NULL DEFAULT ''
            )
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_sq_state
            ON signal_queue(state)
        """)
        self._conn.commit()

    def enqueue(self, signal_data: Dict[str, Any]) -> int:
        """Enqueue a new signal.

        Args:
            signal_data: Signal payload as a dict. Will be JSON-serialized.

        Returns:
            The ID of the enqueued signal.
        """
        now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        signal_json = json.dumps(signal_data, ensure_ascii=False, default=str)

        cursor = self._conn.execute(
            """INSERT INTO signal_queue (signal_json, state, retry_count, created_at, updated_at)
               VALUES (?, ?, 0, ?, ?)""",
            (signal_json, self.STATE_PENDING, now, now),
        )
        self._conn.commit()

        signal_id = cursor.lastrowid
        logger.debug(f"Signal enqueued: #{signal_id}")
        return signal_id

    def dequeue(self, limit: int = 1) -> List[Dict[str, Any]]:
        """Dequeue pending signals for processing.

        Atomically transitions signals from PENDING to PROCESSING state.

        Args:
            limit: Maximum number of signals to dequeue.

        Returns:
            List of signal dicts, each containing 'id', 'signal_data', and metadata.
        """
        now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        cursor = self._conn.execute(
            """SELECT id, signal_json, retry_count
               FROM signal_queue
               WHERE state = ?
               ORDER BY id ASC
               LIMIT ?""",
            (self.STATE_PENDING, limit),
        )
        rows = cursor.fetchall()

        signals = []
        for row in rows:
            signal_id, signal_json, retry_count = row
            self._conn.execute(
                """UPDATE signal_queue
                   SET state = ?, updated_at = ?
                   WHERE id = ?""",
                (self.STATE_PROCESSING, now, signal_id),
            )
            signals.append({
                "id": signal_id,
                "signal_data": json.loads(signal_json),
                "retry_count": retry_count,
            })

        self._conn.commit()
        return signals

    def mark_processed(self, signal_id: int) -> None:
        """Mark a signal as successfully processed.

        Args:
            signal_id: The signal ID returned by enqueue().
        """
        now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        self._conn.execute(
            """UPDATE signal_queue
               SET state = ?, updated_at = ?
               WHERE id = ?""",
            (self.STATE_DONE, now, signal_id),
        )
        self._conn.commit()
        logger.debug(f"Signal #{signal_id} marked as processed")

    def mark_failed(self, signal_id: int, error_msg: str = "") -> None:
        """Mark a signal as failed.

        If retry_count < max_retries, the signal is re-queued as PENDING.
        Otherwise it is marked FAILED permanently.

        Args:
            signal_id: The signal ID.
            error_msg: Description of the failure.
        """
        now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        cursor = self._conn.execute(
            "SELECT retry_count FROM signal_queue WHERE id = ?",
            (signal_id,),
        )
        row = cursor.fetchone()
        if not row:
            return

        retry_count = row[0] + 1

        if retry_count < self._max_retries:
            new_state = self.STATE_PENDING
            logger.warning(f"Signal #{signal_id} failed (retry {retry_count}/{self._max_retries}): {error_msg}")
        else:
            new_state = self.STATE_FAILED
            logger.error(f"Signal #{signal_id} permanently failed after {retry_count} retries: {error_msg}")

        self._conn.execute(
            """UPDATE signal_queue
               SET state = ?, retry_count = ?, updated_at = ?, error_msg = ?
               WHERE id = ?""",
            (new_state, retry_count, now, error_msg, signal_id),
        )
        self._conn.commit()

    def pending_count(self) -> int:
        """Return the number of pending signals.

        Returns:
            Count of signals in PENDING state.
        """
        cursor = self._conn.execute(
            "SELECT COUNT(*) FROM signal_queue WHERE state = ?",
            (self.STATE_PENDING,),
        )
        return cursor.fetchone()[0]

    def cleanup(self, older_than_hours: int = 72) -> int:
        """Remove old completed and failed signals.

        Args:
            older_than_hours: Remove signals older than this many hours.

        Returns:
            Number of records deleted.
        """
        cutoff = datetime.now(timezone.utc).timestamp() - (older_than_hours * 3600)
        cutoff_iso = datetime.fromtimestamp(cutoff, tz=timezone.utc).isoformat().replace('+00:00', 'Z')

        cursor = self._conn.execute(
            """DELETE FROM signal_queue
               WHERE state IN (?, ?) AND updated_at < ?""",
            (self.STATE_DONE, self.STATE_FAILED, cutoff_iso),
        )
        deleted = cursor.rowcount
        self._conn.commit()

        if deleted > 0:
            logger.info(f"Signal queue cleanup: removed {deleted} old records")
        return deleted

    def get_stats(self) -> Dict[str, int]:
        """Return queue statistics.

        Returns:
            Dict with counts for each state.
        """
        stats = {}
        for state in (self.STATE_PENDING, self.STATE_PROCESSING, self.STATE_DONE, self.STATE_FAILED):
            cursor = self._conn.execute(
                "SELECT COUNT(*) FROM signal_queue WHERE state = ?",
                (state,),
            )
            stats[state.lower()] = cursor.fetchone()[0]
        stats["total"] = sum(stats.values())
        return stats

    def replay_pending(self) -> List[Dict[str, Any]]:
        """Reset all PROCESSING signals back to PENDING.

        Useful after a crash — any signals that were mid-processing
        get a fresh chance.

        Returns:
            List of replayed signal dicts.
        """
        now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        self._conn.execute(
            """UPDATE signal_queue
               SET state = ?, updated_at = ?
               WHERE state = ?""",
            (self.STATE_PENDING, now, self.STATE_PROCESSING),
        )
        self._conn.commit()
        logger.info("Replayed all processing signals back to pending")
        return self.dequeue(limit=1000)

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None

    def __del__(self):
        self.close()
