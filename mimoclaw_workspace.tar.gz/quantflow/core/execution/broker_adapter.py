"""
Broker adapters for QuantFlow.
Professional simulation with T+1, price limits, trading hours, stop-loss/take-profit.
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, List, Callable
from datetime import datetime, date, time as dtime
from loguru import logger
import uuid

from ..models import (
    Order, OrderSide, OrderType, OrderStatus,
    AccountInfo, Position, TradeRecord,
)


class BrokerAdapter(ABC):
    """Abstract broker adapter interface."""

    @abstractmethod
    def connect(self) -> bool:
        pass

    @abstractmethod
    def disconnect(self) -> None:
        pass

    @abstractmethod
    def submit_order(self, order: Order) -> bool:
        pass

    @abstractmethod
    def cancel_order(self, order_id: str) -> bool:
        pass

    @abstractmethod
    def get_account(self) -> AccountInfo:
        pass

    @abstractmethod
    def get_positions(self) -> Dict[str, Position]:
        pass

    @abstractmethod
    def is_connected(self) -> bool:
        pass


class SimulationAdapter(BrokerAdapter):
    """Professional simulation broker with A-share rules.

    Features:
        - T+1 settlement: cannot sell same-day buys
        - Price limits: ±10% normal, ±20% ChiNext/STAR, ±5% ST
        - Trading hours: 9:30-11:30, 13:00-15:00
        - Stop-loss / Take-profit auto-trigger
        - Pending order management
        - Real-time price updates
    """

    def __init__(self, initial_balance: float = 1_000_000.0):
        self._initial = initial_balance
        self._balance = initial_balance
        self._positions: Dict[str, Position] = {}
        self._pending_orders: Dict[str, Order] = {}  # 挂单
        self._filled_orders: Dict[str, Order] = {}   # 已成交
        self._all_orders: Dict[str, Order] = {}      # 全部订单
        self._connected = False
        self._trade_history: List[Dict] = []
        self._max_trade_history = 1000  # 防止内存无限增长

        # Stop-loss / Take-profit: {symbol: {stop_loss, take_profit, trailing_stop, peak_price}}
        self._stop_rules: Dict[str, Dict] = {}

        # Price limit rules: {symbol_prefix: limit_pct}
        self._price_limits = {
            "688": 0.20,   # 科创板 ±20%
            "300": 0.20,   # 创业板 ±20%
            "301": 0.20,   # 创业板 ±20%
            "ST":  0.05,   # ST股 ±5%
        }

        # Callbacks for UI updates
        self._on_order_filled: Optional[Callable] = None
        self._on_position_update: Optional[Callable] = None

    def set_callbacks(self, on_filled=None, on_position=None):
        self._on_order_filled = on_filled
        self._on_position_update = on_position

    def connect(self) -> bool:
        self._connected = True
        logger.info("Simulation broker connected")
        return True

    def disconnect(self) -> None:
        self._connected = False
        logger.info("Simulation broker disconnected")

    # ── 交易时段 ──────────────────────────────────────────────────

    @staticmethod
    def is_trading_hours() -> bool:
        """Check if current time is within A-share trading hours."""
        now = datetime.now()
        # Weekend check
        if now.weekday() >= 5:
            return False
        t = now.time()
        morning = dtime(9, 30) <= t <= dtime(11, 30)
        afternoon = dtime(13, 0) <= t <= dtime(15, 0)
        return morning or afternoon

    @staticmethod
    def is_trading_day() -> bool:
        """Check if today is a trading day (weekday, not holiday)."""
        return datetime.now().weekday() < 5

    # ── 涨跌停 ────────────────────────────────────────────────────

    def _get_price_limit(self, symbol: str) -> float:
        """Get price limit percentage for a symbol."""
        code = symbol.split(".")[0] if "." in symbol else symbol
        for prefix, limit in self._price_limits.items():
            if code.startswith(prefix):
                return limit
        return 0.10  # 默认 ±10%

    def _check_price_limit(self, symbol: str, price: float, prev_close: float) -> bool:
        """Check if price is within daily limit."""
        if prev_close <= 0:
            return True  # No reference price, skip check
        limit = self._get_price_limit(symbol)
        upper = prev_close * (1 + limit)
        lower = prev_close * (1 - limit)
        return lower <= price <= upper

    # ── T+1 ────────────────────────────────────────────────────────

    def _get_available_sell_volume(self, symbol: str) -> int:
        """Get volume available for selling (T+1: exclude today's buys)."""
        pos = self._positions.get(symbol)
        if not pos:
            return 0
        # available = total - today_buy (T+1 rule)
        return max(0, pos.volume - pos.today_buy_volume)

    # ── 下单 ───────────────────────────────────────────────────────

    def submit_order(self, order: Order) -> bool:
        """Submit order with full A-share rule enforcement."""
        if not self._connected:
            order.status = OrderStatus.REJECTED
            return False

        # Generate order ID if missing
        if not order.order_id:
            order.order_id = str(uuid.uuid4())[:8]

        # Validate volume (must be multiple of 100, except sell-all)
        if order.side == OrderSide.BUY and order.volume % 100 != 0:
            order.status = OrderStatus.REJECTED
            logger.warning(f"Order rejected: volume must be multiple of 100")
            return False

        # Check trading hours (allow pending orders outside hours)
        if order.order_type == OrderType.MARKET and not self.is_trading_hours():
            order.status = OrderStatus.REJECTED
            logger.warning(f"Order rejected: outside trading hours")
            return False

        # Price limit check (use last known price as reference)
        if order.price and order.price > 0:
            pos = self._positions.get(order.symbol)
            ref_price = pos.current_price if pos and pos.current_price > 0 else 0
            if ref_price > 0 and not self._check_price_limit(order.symbol, order.price, ref_price):
                order.status = OrderStatus.REJECTED
                limit_pct = self._get_price_limit(order.symbol) * 100
                logger.warning(f"Order rejected: price {order.price} outside ±{limit_pct:.0f}% limit (ref={ref_price})")
                return False

        # BUY: check balance (only for orders with known price)
        if order.side == OrderSide.BUY and order.price and order.price > 0:
            cost = order.price * order.volume
            if cost > self._balance:
                order.status = OrderStatus.REJECTED
                logger.warning(f"Order rejected: insufficient balance")
                return False

        # SELL: check available volume (T+1)
        if order.side == OrderSide.SELL:
            available = self._get_available_sell_volume(order.symbol)
            if order.volume > available:
                order.status = OrderStatus.REJECTED
                logger.warning(f"Order rejected: T+1 restriction, available={available}")
                return False

        # MARKET order: fill immediately
        if order.order_type == OrderType.MARKET:
            return self._fill_order(order, order.price or 0)

        # LIMIT order: check if can fill now, otherwise add to pending
        if order.order_type == OrderType.LIMIT:
            if order.price is None or order.price <= 0:
                order.status = OrderStatus.REJECTED
                logger.warning(f"Limit order rejected: price required")
                return False
            # For simplicity in simulation, limit orders fill immediately
            return self._fill_order(order, order.price)

        # STOP / STOP_LIMIT: add to pending
        if order.order_type in (OrderType.STOP, OrderType.STOP_LIMIT):
            order.status = OrderStatus.SUBMITTED
            self._pending_orders[order.order_id] = order
            self._all_orders[order.order_id] = order
            logger.info(f"Stop order submitted: {order.order_id}")
            return True

        return False

    def _fill_order(self, order: Order, fill_price: float) -> bool:
        """Execute an order fill."""
        order.status = OrderStatus.FILLED
        order.filled_volume = order.volume
        order.filled_price = fill_price
        order.updated_at = datetime.now()

        if order.side == OrderSide.BUY:
            cost = fill_price * order.volume
            self._balance -= cost

            pos = self._positions.get(order.symbol, Position(symbol=order.symbol))
            total_cost = pos.avg_cost * pos.volume + fill_price * order.volume
            pos.volume += order.volume
            pos.avg_cost = total_cost / pos.volume if pos.volume > 0 else 0
            pos.current_price = fill_price
            pos.today_buy_volume += order.volume
            self._positions[order.symbol] = pos

            # Record buy trade
            self._trade_history.append({
                "time": datetime.now().isoformat(),
                "symbol": order.symbol,
                "direction": "BUY",
                "volume": order.volume,
                "price": fill_price,
                "amount": cost,
                "commission": max(cost * 0.00025, 5.0),
                "pnl": 0.0,
                "strategy_id": order.strategy_id,
            })
            # 防止内存无限增长
            if len(self._trade_history) > self._max_trade_history:
                self._trade_history = self._trade_history[-self._max_trade_history:]

        elif order.side == OrderSide.SELL:
            pos = self._positions.get(order.symbol)
            if pos:
                proceeds = fill_price * order.volume
                self._balance += proceeds
                pnl = (fill_price - pos.avg_cost) * order.volume
                pos.volume -= order.volume
                pos.today_sell_volume += order.volume
                if pos.volume <= 0:
                    del self._positions[order.symbol]
                else:
                    pos.current_price = fill_price

                # Record sell trade
                self._trade_history.append({
                    "time": datetime.now().isoformat(),
                    "symbol": order.symbol,
                    "direction": "SELL",
                    "volume": order.volume,
                    "price": fill_price,
                    "amount": proceeds,
                    "commission": max(proceeds * 0.00025, 5.0),
                    "pnl": pnl,
                    "strategy_id": order.strategy_id,
                })
                # 防止内存无限增长
                if len(self._trade_history) > self._max_trade_history:
                    self._trade_history = self._trade_history[-self._max_trade_history:]

        self._filled_orders[order.order_id] = order
        self._all_orders[order.order_id] = order
        self._pending_orders.pop(order.order_id, None)

        logger.debug(f"Filled: {order.order_id} {order.side.value} {order.volume} @ {fill_price}")

        if self._on_order_filled:
            self._on_order_filled(order)

        return True

    # ── 止损止盈 ───────────────────────────────────────────────────

    def set_stop_loss(self, symbol: str, stop_loss: float = None,
                      take_profit: float = None, trailing_pct: float = None):
        """Set stop-loss/take-profit for a position."""
        if symbol not in self._stop_rules:
            self._stop_rules[symbol] = {}
        if stop_loss is not None:
            self._stop_rules[symbol]["stop_loss"] = stop_loss
        if take_profit is not None:
            self._stop_rules[symbol]["take_profit"] = take_profit
        if trailing_pct is not None:
            self._stop_rules[symbol]["trailing_pct"] = trailing_pct
            self._stop_rules[symbol]["peak_price"] = 0
        logger.info(f"Stop rules set for {symbol}: SL={stop_loss}, TP={take_profit}, Trail={trailing_pct}%")

    def check_stop_triggers(self, symbol: str, current_price: float) -> Optional[Order]:
        """Check if stop-loss/take-profit should trigger. Returns order if triggered."""
        rules = self._stop_rules.get(symbol)
        if not rules:
            return None

        pos = self._positions.get(symbol)
        if not pos:
            return None

        # Update peak price for trailing stop
        if "trailing_pct" in rules:
            if current_price > rules.get("peak_price", 0):
                rules["peak_price"] = current_price
            trail_price = rules["peak_price"] * (1 - rules["trailing_pct"] / 100)
            if current_price <= trail_price:
                logger.info(f"Trailing stop triggered for {symbol} at {current_price}")
                return self._create_sell_order(symbol, pos.volume, "trailing_stop")

        # Stop-loss
        if "stop_loss" in rules and current_price <= rules["stop_loss"]:
            logger.info(f"Stop-loss triggered for {symbol} at {current_price}")
            return self._create_sell_order(symbol, pos.volume, "stop_loss")

        # Take-profit
        if "take_profit" in rules and current_price >= rules["take_profit"]:
            logger.info(f"Take-profit triggered for {symbol} at {current_price}")
            return self._create_sell_order(symbol, pos.volume, "take_profit")

        return None

    def _create_sell_order(self, symbol: str, volume: int, reason: str) -> Order:
        """Create a sell order for stop-loss/take-profit."""
        return Order(
            order_id=str(uuid.uuid4())[:8],
            symbol=symbol,
            side=OrderSide.SELL,
            order_type=OrderType.MARKET,
            volume=volume,
            strategy_id=f"auto_{reason}",
        )

    # ── 撤单 ───────────────────────────────────────────────────────

    def cancel_order(self, order_id: str) -> bool:
        order = self._pending_orders.get(order_id)
        if order and order.is_active:
            order.status = OrderStatus.CANCELLED
            order.updated_at = datetime.now()
            del self._pending_orders[order_id]
            logger.info(f"Cancelled: {order_id}")
            return True
        return False

    def cancel_all_pending(self) -> int:
        """Cancel all pending orders. Returns count cancelled."""
        count = 0
        for order_id in list(self._pending_orders.keys()):
            if self.cancel_order(order_id):
                count += 1
        return count

    # ── 查询 ───────────────────────────────────────────────────────

    def get_account(self) -> AccountInfo:
        market_value = sum(
            p.volume * (p.current_price if p.current_price > 0 else p.avg_cost)
            for p in self._positions.values()
        )
        unrealized = sum(
            (p.current_price - p.avg_cost) * p.volume
            for p in self._positions.values()
            if p.current_price > 0
        )
        return AccountInfo(
            account_id="SIM",
            total_assets=self._balance + market_value,
            cash=self._balance,
            market_value=market_value,
            unrealized_pnl=unrealized,
            initial_capital=self._initial,
        )

    def get_positions(self) -> Dict[str, Position]:
        return dict(self._positions)

    def get_pending_orders(self) -> Dict[str, Order]:
        return dict(self._pending_orders)

    def get_filled_orders(self) -> Dict[str, Order]:
        return dict(self._filled_orders)

    def get_trade_history(self) -> List[Dict]:
        return list(self._trade_history)

    def get_position(self, symbol: str) -> Optional[Position]:
        return self._positions.get(symbol)

    def update_prices(self, prices: Dict[str, float]):
        """Update position current prices and check stop triggers."""
        for symbol, price in prices.items():
            pos = self._positions.get(symbol)
            if pos:
                pos.current_price = price
                # Check stop-loss/take-profit
                self.check_stop_triggers(symbol, price)

    def reset_daily_counters(self):
        """Reset daily counters (call at market open)."""
        for pos in self._positions.values():
            pos.today_buy_volume = 0
            pos.today_sell_volume = 0

    def is_connected(self) -> bool:
        return self._connected

    @property
    def initial_capital(self) -> float:
        return self._initial

    @property
    def total_commission(self) -> float:
        return sum(t.get("commission", 0) for t in self._trade_history)
