"""
Multi-broker registry for QuantFlow.
Centralizes all broker adapters with metadata (support level, requirements, etc.)
"""

from typing import Dict, Any, Optional, Type
from .broker_adapter import BrokerAdapter, SimulationAdapter


# ─── 券商注册表 ──────────────────────────────────────────────────

BROKER_REGISTRY: Dict[str, Dict[str, Any]] = {
    "simulation": {
        "name": "模拟交易（纸盘）",
        "adapter_cls": SimulationAdapter,
        "support_level": "full",        # full / good / beta / experimental
        "support_text": "完整支持",
        "support_color": "#00ff88",
        "description": "无需券商账号，使用虚拟资金模拟交易。适合策略验证和学习。",
        "requirements": [
            "无需任何外部依赖",
            "无需券商账号",
            "开箱即用",
        ],
        "risks": "无资金风险",
        "icon": "🎮",
    },
    "easytrader_yinhe": {
        "name": "银河证券 (easytrader)",
        "adapter_cls": None,  # lazy load
        "support_level": "good",
        "support_text": "支持良好",
        "support_color": "#00d4aa",
        "description": "通过 easytrader 自动操控银河证券 PC 客户端下单。最成熟的开源方案。",
        "requirements": [
            "pip install easytrader",
            "银河证券普通账户（无需量化权限）",
            "安装银河证券 PC 客户端（海王星/双子星）",
            "客户端需保持前台运行",
        ],
        "risks": "依赖客户端窗口，弹窗/更新可能导致操作中断",
        "icon": "🏦",
    },
    "easytrader_huatai": {
        "name": "华泰证券 (easytrader)",
        "adapter_cls": None,
        "support_level": "good",
        "support_text": "支持良好",
        "support_color": "#00d4aa",
        "description": "通过 easytrader 自动操控华泰证券 PC 客户端下单。",
        "requirements": [
            "pip install easytrader",
            "华泰证券普通账户（无需量化权限）",
            "安装华泰证券专业版客户端",
            "客户端需保持前台运行",
        ],
        "risks": "依赖客户端窗口，弹窗/更新可能导致操作中断",
        "icon": "🏦",
    },
    "easytrader_guangfa": {
        "name": "广发证券 (easytrader)",
        "adapter_cls": None,
        "support_level": "beta",
        "support_text": "测试中",
        "support_color": "#f59e0b",
        "description": "通过 easytrader 自动操控广发证券客户端。社区反馈可用但测试较少。",
        "requirements": [
            "pip install easytrader",
            "广发证券普通账户",
            "安装广发证券至尊版客户端",
            "客户端需保持前台运行",
        ],
        "risks": "社区维护，稳定性不如银河/华泰，建议先小资金测试",
        "icon": "🏦",
    },
    "qmt": {
        "name": "QMT 迅投量化",
        "adapter_cls": None,
        "support_level": "beta",
        "support_text": "需配置",
        "support_color": "#3b82f6",
        "description": "通过 QMT 量化交易平台下单。需要券商开通量化权限，支持全自动实盘。",
        "requirements": [
            "联系券商客户经理开通 QMT 量化权限",
            "安装 QMT 客户端并登录",
            "pip install xtquant（QMT 自带）",
            "配置 QMT 安装路径和资金账号",
        ],
        "risks": "需要量化权限，部分券商有资金门槛（通常 50 万+）",
        "icon": "⚡",
    },
    "ptrade": {
        "name": "Ptrade 恒生量化",
        "adapter_cls": None,
        "support_level": "experimental",
        "support_text": "实验性",
        "support_color": "#ef4444",
        "description": "通过 Ptrade 恒生量化平台下单。主要面向机构和高净值客户。",
        "requirements": [
            "联系券商开通 Ptrade 权限（通常需 100 万+ 资金）",
            "Ptrade 客户端运行中",
            "恒生 SDK 配置",
        ],
        "risks": "门槛高，接口文档少，建议有经验的用户使用",
        "icon": "🏛️",
    },
}


def get_broker_list() -> list:
    """Return list of broker ids in registration order."""
    return list(BROKER_REGISTRY.keys())


def get_broker_info(broker_id: str) -> Optional[Dict[str, Any]]:
    """Return metadata for a broker."""
    return BROKER_REGISTRY.get(broker_id)


def create_broker_adapter(broker_id: str, config: dict = None) -> BrokerAdapter:
    """Instantiate the appropriate broker adapter."""
    info = BROKER_REGISTRY.get(broker_id)
    if not info:
        raise ValueError(f"Unknown broker: {broker_id}")

    # Simulation — already imported
    if broker_id == "simulation":
        balance = (config or {}).get("initial_balance", 1_000_000.0)
        return SimulationAdapter(initial_balance=balance)

    # easytrader brokers
    if broker_id.startswith("easytrader_"):
        return _create_easytrader_adapter(broker_id, config)

    # QMT
    if broker_id == "qmt":
        return _create_qmt_adapter(config)

    # Ptrade
    if broker_id == "ptrade":
        return _create_ptrade_adapter(config)

    raise ValueError(f"Broker '{broker_id}' has no adapter implementation")


def _create_easytrader_adapter(broker_id: str, config: dict = None) -> BrokerAdapter:
    """Create an easytrader-based adapter."""
    try:
        import easytrader
    except ImportError:
        raise ImportError(
            "easytrader 未安装。请运行: pip install easytrader\n"
            "安装后还需安装 pywinauto: pip install pywinauto"
        )

    broker_map = {
        "easytrader_yinhe": "yh",
        "easytrader_huatai": "ht",
        "easytrader_guangfa": "gf",
    }

    client_type = broker_map.get(broker_id, "yh")
    cfg = config or {}

    return EasyTraderAdapter(
        client_type=client_type,
        broker_name=BROKER_REGISTRY.get(broker_id, {}).get("name", broker_id),
        config_path=cfg.get("config_path", ""),
    )


def _create_qmt_adapter(config: dict = None) -> BrokerAdapter:
    """Create a QMT adapter."""
    cfg = config or {}
    return QMTLiveAdapter(
        qmt_path=cfg.get("path", ""),
        account=cfg.get("account", ""),
        account_type=cfg.get("account_type", "STOCK"),
    )


def _create_ptrade_adapter(config: dict = None) -> BrokerAdapter:
    """Create a Ptrade adapter (placeholder)."""
    cfg = config or {}
    return PtradeAdapter(
        host=cfg.get("host", "127.0.0.1"),
        port=cfg.get("port", 10086),
        account=cfg.get("account", ""),
    )


# ─── 实际适配器实现 ──────────────────────────────────────────────

from loguru import logger
from ..models import Order, OrderStatus, AccountInfo, Position


class EasyTraderAdapter(BrokerAdapter):
    """Easytrader adapter — auto-operates broker desktop client."""

    def __init__(self, client_type: str = "yh", broker_name: str = "", config_path: str = ""):
        self._client_type = client_type
        self._broker_name = broker_name
        self._config_path = config_path
        self._user = None
        self._connected = False

    def connect(self) -> bool:
        try:
            import easytrader
            self._user = easytrader.use(self._client_type)

            if self._config_path:
                self._user.connect(self._config_path)
            else:
                self._user.prepare()

            self._connected = True
            logger.info(f"EasyTrader connected: {self._broker_name}")
            return True
        except Exception as e:
            logger.error(f"EasyTrader connect failed: {e}")
            self._connected = False
            return False

    def disconnect(self) -> None:
        self._user = None
        self._connected = False
        logger.info("EasyTrader disconnected")

    def submit_order(self, order: Order) -> bool:
        if not self._connected or not self._user:
            return False
        try:
            if order.side.value == "BUY":
                result = self._user.buy(order.symbol, price=order.price, amount=order.volume)
            else:
                result = self._user.sell(order.symbol, price=order.price, amount=order.volume)

            order.status = OrderStatus.SUBMITTED
            logger.info(f"Order submitted: {order.order_id} {order.side.value} {order.symbol}")
            return True
        except Exception as e:
            logger.error(f"Order submit failed: {e}")
            order.status = OrderStatus.ERROR
            return False

    def cancel_order(self, order_id: str) -> bool:
        if not self._connected or not self._user:
            return False
        try:
            self._user.cancel_entrust(order_id)
            return True
        except Exception as e:
            logger.error(f"Cancel failed: {e}")
            return False

    def get_account(self) -> AccountInfo:
        if not self._connected or not self._user:
            return AccountInfo(account_id="disconnected")
        try:
            balance = self._user.balance
            return AccountInfo(
                account_id=self._broker_name,
                total_assets=balance.get("总资产", 0),
                cash=balance.get("可用资金", 0),
                market_value=balance.get("股票市值", 0),
            )
        except Exception as e:
            logger.error(f"Get account failed: {e}")
            return AccountInfo(account_id="error")

    def get_positions(self) -> Dict[str, Position]:
        if not self._connected or not self._user:
            return {}
        try:
            positions = {}
            for pos in self._user.position:
                symbol = pos.get("证券代码", "")
                if symbol:
                    positions[symbol] = Position(
                        symbol=symbol,
                        volume=int(pos.get("股票余额", 0)),
                        avg_cost=float(pos.get("成本价", 0)),
                        current_price=float(pos.get("市价", 0)),
                    )
            return positions
        except Exception as e:
            logger.error(f"Get positions failed: {e}")
            return {}

    def is_connected(self) -> bool:
        return self._connected


class QMTLiveAdapter(BrokerAdapter):
    """QMT adapter with real xtquant integration."""

    def __init__(self, qmt_path: str = "", account: str = "", account_type: str = "STOCK"):
        self._path = qmt_path
        self._account = account
        self._account_type = account_type
        self._connected = False
        self._xt_trader = None
        self._session_id = 1

    def connect(self) -> bool:
        try:
            from xtquant import xttrader, xtdata

            self._xt_trader = xttrader.XtQuantTrader(self._path, session_id=self._session_id)
            self._xt_trader.start()

            # Subscribe to account
            connect_result = self._xt_trader.connect()
            if connect_result != 0:
                logger.error(f"QMT connect failed: code={connect_result}")
                return False

            # Login
            from xtquant.xttrader import StockAccount
            account_obj = StockAccount(self._account, self._account_type)
            login_result = self._xt_trader.login(account_obj)
            if login_result != 0:
                logger.error(f"QMT login failed: code={login_result}")
                return False

            self._connected = True
            logger.info(f"QMT connected: {self._account}")
            return True
        except ImportError:
            logger.error("xtquant not installed. Install from QMT client directory.")
            return False
        except Exception as e:
            logger.error(f"QMT connect error: {e}")
            return False

    def disconnect(self) -> None:
        if self._xt_trader:
            try:
                self._xt_trader.stop()
            except Exception:
                pass
        self._connected = False
        logger.info("QMT disconnected")

    def submit_order(self, order: Order) -> bool:
        if not self._connected or not self._xt_trader:
            return False
        try:
            from xtquant.xttype import StockAccount
            from xtquant import xtconstant

            account_obj = StockAccount(self._account, self._account_type)
            direction = xtconstant.STOCK_BUY if order.side.value == "BUY" else xtconstant.STOCK_SELL

            order_id = self._xt_trader.order_stock(
                account_obj,
                order.symbol,
                direction,
                order.volume,
                xtconstant.FIX_PRICE if order.price else xtconstant.LATEST_PRICE,
                order.price or 0,
            )

            if order_id > 0:
                order.status = OrderStatus.SUBMITTED
                logger.info(f"QMT order submitted: {order_id}")
                return True
            else:
                order.status = OrderStatus.REJECTED
                logger.error(f"QMT order rejected: code={order_id}")
                return False
        except Exception as e:
            logger.error(f"QMT submit error: {e}")
            order.status = OrderStatus.ERROR
            return False

    def cancel_order(self, order_id: str) -> bool:
        if not self._connected or not self._xt_trader:
            return False
        try:
            from xtquant.xttype import StockAccount
            account_obj = StockAccount(self._account, self._account_type)
            result = self._xt_trader.cancel_order_stock(account_obj, int(order_id))
            return result == 0
        except Exception as e:
            logger.error(f"QMT cancel error: {e}")
            return False

    def get_account(self) -> AccountInfo:
        if not self._connected or not self._xt_trader:
            return AccountInfo(account_id="disconnected")
        try:
            from xtquant.xttype import StockAccount
            account_obj = StockAccount(self._account, self._account_type)
            asset = self._xt_trader.query_stock_asset(account_obj)
            return AccountInfo(
                account_id=self._account,
                total_assets=asset.total_asset,
                cash=asset.cash,
                market_value=asset.market_value,
            )
        except Exception as e:
            logger.error(f"QMT get_account error: {e}")
            return AccountInfo(account_id="error")

    def get_positions(self) -> Dict[str, Position]:
        if not self._connected or not self._xt_trader:
            return {}
        try:
            from xtquant.xttype import StockAccount
            account_obj = StockAccount(self._account, self._account_type)
            positions = self._xt_trader.query_stock_positions(account_obj)
            result = {}
            for pos in positions:
                if pos.volume > 0:
                    result[pos.stock_code] = Position(
                        symbol=pos.stock_code,
                        volume=pos.volume,
                        avg_cost=pos.avg_price,
                        current_price=pos.market_value / pos.volume if pos.volume > 0 else 0,
                    )
            return result
        except Exception as e:
            logger.error(f"QMT get_positions error: {e}")
            return {}

    def is_connected(self) -> bool:
        return self._connected


class PtradeAdapter(BrokerAdapter):
    """Ptrade adapter (experimental placeholder)."""

    def __init__(self, host: str = "127.0.0.1", port: int = 10086, account: str = ""):
        self._host = host
        self._port = port
        self._account = account
        self._connected = False

    def connect(self) -> bool:
        logger.warning("Ptrade adapter: not yet implemented. Requires Ptrade SDK.")
        return False

    def disconnect(self) -> None:
        self._connected = False

    def submit_order(self, order: Order) -> bool:
        logger.warning("Ptrade submit_order: not implemented")
        return False

    def cancel_order(self, order_id: str) -> bool:
        return False

    def get_account(self) -> AccountInfo:
        return AccountInfo(account_id="ptrade")

    def get_positions(self) -> Dict[str, Position]:
        return {}

    def is_connected(self) -> bool:
        return False
