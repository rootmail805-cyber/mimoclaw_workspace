"""
⚠️ DEPRECATED - 此模块已废弃，未被系统任何组件引用。
保留代码供未来参考，但不应在新代码中使用。
如需使用其中的功能，请先集成到 GUI 和业务流程中。
"""

"""
Enhanced Execution Engine for QuantFlow.
Integrates: event bus, enhanced risk management, notifications,
fee calculation, order timeout monitoring.
"""

import time
import threading
from typing import Optional, Dict, Any
from datetime import datetime, timezone
from loguru import logger

from ..models import (
    Signal, SignalAction, Order, OrderSide, OrderType, OrderStatus,
    AccountInfo, Position, TradeRecord,
)
from ..db import get_db
from ..notification import NotificationManager, NotificationLevel
from ..risk.enhanced_risk import EnhancedRiskManager
from ..market_timing import MarketTimingFilter
from .fee_calculator import FeeCalculator
from .broker_adapter import BrokerAdapter, SimulationAdapter
from .order_manager import OrderManager
from .signal_queue import PersistentSignalQueue
from config.manager import get_config


class EnhancedExecutionEngine:
    """Central execution engine with full risk integration."""

    def __init__(self, config=None):
        self._config = config or get_config()
        self._db = get_db()
        self._order_manager = OrderManager()
        self._broker: Optional[BrokerAdapter] = None
        self._connected = False

        # Risk management
        self._risk = EnhancedRiskManager(self._config)

        # Notifications
        self._notifier = NotificationManager(self._config)
        self._notifier.start()
        self._risk.set_notifier(self._notifier)

        # Fee calculator
        self._fee_calc = FeeCalculator(self._config)

        # Market timing
        self._market_timing = MarketTimingFilter(self._config)

        # Signal queue
        sq_db = self._config.get("execution.signal_queue.db_path", "./data/signal_queue.db")
        self._signal_queue = PersistentSignalQueue(db_path=sq_db, max_retries=3)

        # Callbacks for UI updates
        self._on_trade_callback = None
        self._on_order_update_callback = None

    def set_callbacks(self, on_trade=None, on_order_update=None):
        """Set callbacks for UI updates."""
        self._on_trade_callback = on_trade
        self._on_order_update_callback = on_order_update

    def connect(self, broker_id: str = "simulation", broker_config: dict = None) -> bool:
        """Connect to a broker."""
        from .broker_registry import create_broker_adapter

        try:
            adapter = create_broker_adapter(broker_id, broker_config or {})
            success = adapter.connect()
            if success:
                self._broker = adapter
                self._connected = True
                logger.info(f"Connected to broker: {broker_id}")

                self._notifier.send(
                    NotificationLevel.INFO,
                    "system_started",
                    "🔵 系统已连接",
                    f"已连接到: {broker_id}",
                )
                return True
            else:
                logger.error(f"Failed to connect to broker: {broker_id}")
                return False
        except Exception as e:
            logger.error(f"Broker connection error: {e}")
            return False

    def disconnect(self):
        """Disconnect from broker."""
        if self._broker:
            self._broker.disconnect()
        self._connected = False
        self._notifier.stop()
        logger.info("Disconnected from broker")

    def execute_signal(self, signal: Signal) -> Optional[Order]:
        """Execute a trading signal through the full pipeline.

        Pipeline: fee check → risk check → order creation → broker submit → fill
        """
        if signal.action in (SignalAction.HOLD,):
            return None

        # 1. Fee pre-calculation (for SELL orders)
        if signal.action == SignalAction.SELL and signal.price:
            cost_price = self._get_avg_cost(signal.symbol)
            fees = self._fee_calc.calculate("SELL", signal.price, signal.volume, cost_price)
            if fees["net_pnl"] < 0 and abs(fees["net_pnl"]) < fees["total_cost"]:
                logger.info(f"Skipping trade: fee erosion. Net PnL: {fees['net_pnl']}")
                self._db.insert_risk_event(
                    "fee_erosion", "info",
                    f"手续费侵蚀弃单: {signal.symbol} 净利润={fees['net_pnl']}",
                )
                return None

        # 2. Market timing check (for BUY)
        if signal.action == SignalAction.BUY:
            allowed, reason = self._market_timing.check()
            if not allowed:
                logger.info(f"Market timing blocked: {reason}")
                signal.action = SignalAction.HOLD
                signal.reason = f"[择时过滤] {reason}"
                return None

        # 3. Safety mode filter
        signal = self._risk.safety_mode.filter_signal(signal)
        if signal.action == SignalAction.HOLD:
            return None

        # 4. Risk check
        account = self.account
        positions = self.positions
        passed, reason = self._risk.pre_trade_check(signal, account, positions)
        if not passed:
            logger.warning(f"Risk check failed: {reason}")
            self._db.insert_risk_event("risk_rejected", "warning",
                                       f"风控拦截: {signal.symbol} {signal.action.value} - {reason}")
            return None

        # 5. Create order
        order_type = OrderType.MARKET if signal.price is None else OrderType.LIMIT
        order = self._order_manager.create_order(signal, signal.price, order_type)

        # 6. Submit to broker
        self._risk.order_timeout.register_order(order.order_id)

        try:
            success = self._broker.submit_order(order)
        except Exception as e:
            success = False
            logger.error(f"Order submission error: {e}")

        self._risk.order_timeout.confirm_order(order.order_id)

        if success:
            # Record trade in database
            direction = "BUY" if signal.action == SignalAction.BUY else "SELL"
            cost_price = self._get_avg_cost(signal.symbol) if direction == "SELL" else None
            fees = self._fee_calc.calculate(direction, order.filled_price, order.filled_volume, cost_price)

            trade_record = {
                "trade_time": datetime.now().isoformat(),
                "symbol": signal.symbol,
                "direction": direction,
                "quantity": order.filled_volume,
                "price": order.filled_price,
                "amount": fees["amount"],
                "commission": fees["commission"],
                "tax": fees["tax"],
                "slippage": fees["slippage"],
                "pnl": fees["net_pnl"],
                "strategy_id": signal.strategy_id,
                "order_id": order.order_id,
            }
            self._db.insert_trade(trade_record)
            self._risk.record_trade_success()

            # Notify
            emoji = "🟢" if direction == "BUY" else "🔴"
            self._notifier.send(
                NotificationLevel.ROUTINE,
                "trade_executed",
                f"{emoji} 交易执行",
                f"**{direction}** {signal.symbol} {order.filled_volume}股 @ ¥{order.filled_price:.2f}\n"
                f"手续费: ¥{fees['total_cost']:.2f}",
            )

            # Callback
            if self._on_trade_callback:
                self._on_trade_callback(trade_record)

            logger.info(f"Order filled: {order.order_id} {direction} {signal.symbol}")
        else:
            order.status = OrderStatus.REJECTED
            self._risk.record_trade_failure()
            logger.error(f"Order rejected: {order.order_id}")

        return order

    def _get_avg_cost(self, symbol: str) -> Optional[float]:
        """Get average cost for a position."""
        positions = self.positions
        pos = positions.get(symbol)
        return pos.avg_cost if pos else None

    @property
    def account(self) -> AccountInfo:
        if self._broker:
            return self._broker.get_account()
        return AccountInfo(account_id="disconnected")

    @property
    def positions(self) -> Dict[str, Position]:
        if self._broker:
            return self._broker.get_positions()
        return {}

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def risk_manager(self) -> EnhancedRiskManager:
        return self._risk

    @property
    def notifier(self) -> NotificationManager:
        return self._notifier

    @property
    def market_timing(self) -> MarketTimingFilter:
        return self._market_timing

    @property
    def fee_calculator(self) -> FeeCalculator:
        return self._fee_calc
