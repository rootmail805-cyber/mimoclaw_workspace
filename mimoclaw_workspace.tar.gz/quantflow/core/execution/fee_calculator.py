"""
Tax and fee pre-calculation for QuantFlow.
Calculates real profit after commissions, taxes, and slippage.
"""


class FeeCalculator:
    """Pre-trade fee calculator."""

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()

    def calculate(self, direction: str, price: float, quantity: int,
                  cost_price: float = None) -> dict:
        """Calculate all fees for a trade.

        Args:
            direction: "BUY" or "SELL"
            price: Trade price
            quantity: Number of shares
            cost_price: Cost price (for PnL calculation, SELL only)

        Returns:
            dict with commission, tax, slippage, estimated_pnl, net_pnl
        """
        amount = price * quantity

        # Commission: configurable, default 0.025% (万2.5), min ¥5
        commission_rate = self._config.get("trading.commission_rate", 0.00025)
        commission = max(amount * commission_rate, 5.0)

        # Tax: sell-side only, 0.1% (千一)
        tax = 0.0
        if direction == "SELL":
            tax = amount * 0.001

        # Slippage: configurable, default 0.1%
        slippage_rate = self._config.get("trading.slippage_rate", 0.001)
        slippage = amount * slippage_rate

        total_cost = commission + tax + slippage

        # Estimated PnL (for sell orders)
        estimated_pnl = 0.0
        net_pnl = 0.0
        if direction == "SELL" and cost_price is not None:
            gross_pnl = (price - cost_price) * quantity
            estimated_pnl = gross_pnl
            net_pnl = gross_pnl - total_cost

        return {
            "amount": amount,
            "commission": round(commission, 2),
            "tax": round(tax, 2),
            "slippage": round(slippage, 2),
            "total_cost": round(total_cost, 2),
            "estimated_pnl": round(estimated_pnl, 2),
            "net_pnl": round(net_pnl, 2),
        }

    def should_skip_trade(self, net_pnl: float) -> bool:
        """Check if trade should be skipped due to fee erosion."""
        if net_pnl < 0:
            # Check if the loss is primarily due to fees
            # If net_pnl is negative but gross PnL might be positive,
            # it means fees are eating profits
            return True
        return False
