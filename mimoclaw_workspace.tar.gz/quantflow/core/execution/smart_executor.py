"""
智能订单执行引擎
支持TWAP（时间加权均价）和VWAP（成交量加权均价）算法，
将大单拆分为多笔小单逐步执行，降低市场冲击成本。

适用场景：
- 大资金量买卖（单笔超过日均成交量的1%）
- 流动性较差的股票
- 对执行价格有较高要求的场景
"""

import time
import threading
import numpy as np
from typing import List, Optional, Callable, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from loguru import logger

from ..models import Order, OrderSide, OrderType, OrderStatus


class ExecutionAlgo(Enum):
    """执行算法类型"""
    MARKET = "market"           # 市价单（一次性执行）
    TWAP = "twap"               # 时间加权均价
    VWAP = "vwap"               # 成交量加权均价
    IS = "is"                   # Implementation Shortfall（最小化执行差额）


@dataclass
class AlgoOrderConfig:
    """算法订单配置"""
    algo: ExecutionAlgo = ExecutionAlgo.TWAP
    total_volume: int = 0       # 总委托量
    duration_minutes: int = 30  # 执行时间窗口（分钟）
    num_slices: int = 10        # 拆分笔数
    max_participation: float = 0.10  # 最大参与率（占市场成交量的比例）
    price_limit: float = 0.0    # 价格限制（0=不限制）
    urgency: str = "normal"     # low / normal / high


@dataclass
class AlgoSlice:
    """算法订单的一个切片"""
    slice_id: int
    volume: int
    target_time: datetime
    status: str = "pending"     # pending / sent / filled / failed
    fill_price: float = 0.0
    fill_volume: int = 0
    order_id: str = ""


@dataclass
class AlgoOrderResult:
    """算法订单执行结果"""
    algo: str
    symbol: str
    side: str
    total_volume: int
    filled_volume: int = 0
    avg_fill_price: float = 0.0
    slices: List[AlgoSlice] = field(default_factory=list)
    start_time: datetime = field(default_factory=datetime.now)
    end_time: datetime = field(default_factory=datetime.now)
    total_commission: float = 0.0
    slippage_vs_arrival: float = 0.0  # 相对到达价的滑点
    status: str = "pending"           # pending / running / completed / cancelled


class SmartExecutor:
    """智能订单执行引擎"""

    def __init__(self, broker_adapter=None, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._broker = broker_adapter
        self._broker_lock = threading.Lock()
        self._running_orders: dict = {}  # algo_id -> threading.Thread
        self._cancel_flags: dict = {}    # algo_id -> bool
        self._results: dict = {}         # algo_id -> AlgoOrderResult

    def set_broker(self, broker_adapter):
        """设置券商适配器"""
        self._broker = broker_adapter

    def execute(
        self,
        symbol: str,
        side: OrderSide,
        config: AlgoOrderConfig,
        arrival_price: float = 0.0,
        progress_callback: Optional[Callable] = None,
    ) -> str:
        """提交算法订单执行

        Args:
            symbol: 股票代码
            side: 买卖方向
            config: 算法配置
            arrival_price: 到达价（用于计算滑点）
            progress_callback: 进度回调 callback(current_slice, total_slices, status)

        Returns:
            algo_id: 算法订单ID
        """
        algo_id = f"ALGO_{datetime.now().strftime('%H%M%S')}_{symbol}"

        if config.algo == ExecutionAlgo.MARKET:
            # 市价单直接执行
            return self._execute_market(algo_id, symbol, side, config)

        # 生成切片
        slices = self._generate_slices(config)

        result = AlgoOrderResult(
            algo=config.algo.value,
            symbol=symbol,
            side=side.value,
            total_volume=config.total_volume,
            slices=slices,
            start_time=datetime.now(),
        )
        self._results[algo_id] = result
        self._cancel_flags[algo_id] = False

        # 启动执行线程
        thread = threading.Thread(
            target=self._execute_algo,
            args=(algo_id, symbol, side, config, slices, arrival_price, progress_callback),
            daemon=True,
            name=f"AlgoExec-{algo_id}",
        )
        self._running_orders[algo_id] = thread
        thread.start()

        logger.info(f"[SmartExec] 算法订单已提交: {algo_id} {side.value} {symbol} "
                     f"x{config.total_volume} ({config.algo.value})")
        return algo_id

    def cancel(self, algo_id: str) -> bool:
        """取消算法订单"""
        if algo_id in self._cancel_flags:
            self._cancel_flags[algo_id] = True
            logger.info(f"[SmartExec] 算法订单取消: {algo_id}")
            return True
        return False

    def get_result(self, algo_id: str) -> Optional[AlgoOrderResult]:
        """获取算法订单执行结果"""
        return self._results.get(algo_id)

    def _generate_slices(self, config: AlgoOrderConfig) -> List[AlgoSlice]:
        """生成执行切片"""
        slices = []
        total = config.total_volume
        n = max(config.num_slices, 1)  # 至少1个切片
        base_vol = total // n
        remainder = total % n

        interval_seconds = (config.duration_minutes * 60) / n if n > 0 else 1
        now = datetime.now()

        for i in range(n):
            vol = base_vol + (1 if i < remainder else 0)
            target_time = now + timedelta(seconds=interval_seconds * i)

            slices.append(AlgoSlice(
                slice_id=i + 1,
                volume=vol,
                target_time=target_time,
            ))

        return slices

    def _execute_algo(
        self,
        algo_id: str,
        symbol: str,
        side: OrderSide,
        config: AlgoOrderConfig,
        slices: List[AlgoSlice],
        arrival_price: float,
        progress_callback: Optional[Callable],
    ):
        """执行算法订单（后台线程）"""
        result = self._results[algo_id]
        result.status = "running"

        for i, s in enumerate(slices):
            # 检查取消
            if self._cancel_flags.get(algo_id):
                result.status = "cancelled"
                result.end_time = datetime.now()
                logger.info(f"[SmartExec] {algo_id} 已取消（已完成{i}/{len(slices)}笔）")
                return

            # 等待到目标时间
            now = datetime.now()
            if s.target_time > now:
                wait_seconds = (s.target_time - now).total_seconds()
                # 分段等待，每秒检查一次取消标志
                for _ in range(int(wait_seconds)):
                    if self._cancel_flags.get(algo_id):
                        result.status = "cancelled"
                        result.end_time = datetime.now()
                        return
                    time.sleep(1)

            # 执行当前切片
            s.status = "sent"
            try:
                price = config.price_limit if config.price_limit > 0 else 0
                order = Order(
                    order_id="",
                    symbol=symbol,
                    side=side,
                    order_type=OrderType.LIMIT if price > 0 else OrderType.MARKET,
                    volume=s.volume,
                    price=price if price > 0 else None,
                    strategy_id=f"algo_{algo_id}",
                )

                with self._broker_lock:
                    if self._broker:
                        success = self._broker.submit_order(order)
                    else:
                        success = False

                if success:
                    s.status = "filled"
                    s.fill_volume = s.volume
                    s.fill_price = price if price > 0 else arrival_price
                    s.order_id = order.order_id
                    result.filled_volume += s.fill_volume

                    logger.info(f"[SmartExec] {algo_id} 切片{s.slice_id}/{len(slices)}: "
                                f"成交{s.volume}股 @ {s.fill_price:.2f}")
                else:
                    s.status = "failed"
                    logger.warning(f"[SmartExec] {algo_id} 切片{s.slice_id} 下单失败")

            except Exception as e:
                s.status = "failed"
                logger.error(f"[SmartExec] {algo_id} 切片{s.slice_id} 异常: {e}")

            # 进度回调
            if progress_callback:
                try:
                    progress_callback(i + 1, len(slices), s.status)
                except Exception:
                    pass

        # 计算执行结果
        filled_slices = [s for s in slices if s.status == "filled"]
        if filled_slices:
            total_value = sum(s.fill_price * s.fill_volume for s in filled_slices)
            total_vol = sum(s.fill_volume for s in filled_slices)
            result.avg_fill_price = total_value / total_vol if total_vol > 0 else 0

            if arrival_price > 0:
                if side == OrderSide.BUY:
                    result.slippage_vs_arrival = (result.avg_fill_price - arrival_price) / arrival_price
                else:
                    result.slippage_vs_arrival = (arrival_price - result.avg_fill_price) / arrival_price

        result.end_time = datetime.now()
        result.status = "completed"

        elapsed = (result.end_time - result.start_time).total_seconds()
        logger.info(f"[SmartExec] {algo_id} 完成: 成交{result.filled_volume}/{result.total_volume}股, "
                     f"均价{result.avg_fill_price:.2f}, 滑点{result.slippage_vs_arrival:.4%}, "
                     f"耗时{elapsed:.0f}秒")

    def _execute_market(self, algo_id: str, symbol: str, side: OrderSide, config: AlgoOrderConfig) -> str:
        """市价单直接执行"""
        order = Order(
            order_id="",
            symbol=symbol,
            side=side,
            order_type=OrderType.MARKET,
            volume=config.total_volume,
            strategy_id=f"algo_{algo_id}",
        )

        result = AlgoOrderResult(
            algo="market",
            symbol=symbol,
            side=side.value,
            total_volume=config.total_volume,
            start_time=datetime.now(),
        )

        try:
            with self._broker_lock:
                if self._broker:
                    success = self._broker.submit_order(order)

            if success:
                result.filled_volume = config.total_volume
                result.status = "completed"
            else:
                result.status = "failed"
        except Exception as e:
            result.status = "failed"
            logger.error(f"[SmartExec] 市价单失败: {e}")

        result.end_time = datetime.now()
        self._results[algo_id] = result
        return algo_id

    def suggest_algo(
        self,
        volume: int,
        avg_daily_volume: int,
        urgency: str = "normal",
    ) -> AlgoOrderConfig:
        """根据订单规模智能推荐执行算法

        Args:
            volume: 委托量
            avg_daily_volume: 日均成交量
            urgency: 紧急度

        Returns:
            推荐的算法配置
        """
        if avg_daily_volume <= 0:
            avg_daily_volume = volume * 10  # 保守估计

        participation = volume / avg_daily_volume

        if participation < 0.01:
            # 小单，直接市价
            return AlgoOrderConfig(
                algo=ExecutionAlgo.MARKET,
                total_volume=volume,
            )
        elif participation < 0.05:
            # 中等规模，TWAP
            return AlgoOrderConfig(
                algo=ExecutionAlgo.TWAP,
                total_volume=volume,
                duration_minutes=15 if urgency == "high" else 30,
                num_slices=5 if urgency == "high" else 10,
                max_participation=0.10,
                urgency=urgency,
            )
        elif participation < 0.15:
            # 较大单，VWAP
            return AlgoOrderConfig(
                algo=ExecutionAlgo.VWAP,
                total_volume=volume,
                duration_minutes=30 if urgency == "high" else 60,
                num_slices=10 if urgency == "high" else 20,
                max_participation=0.08,
                urgency=urgency,
            )
        else:
            # 大单，IS算法
            return AlgoOrderConfig(
                algo=ExecutionAlgo.IS,
                total_volume=volume,
                duration_minutes=60 if urgency == "high" else 120,
                num_slices=20 if urgency == "high" else 40,
                max_participation=0.05,
                urgency=urgency,
            )

    def format_result(self, algo_id: str) -> str:
        """格式化算法订单结果"""
        result = self._results.get(algo_id)
        if not result:
            return f"未找到算法订单: {algo_id}"

        elapsed = (result.end_time - result.start_time).total_seconds()
        filled_pct = result.filled_volume / result.total_volume * 100 if result.total_volume > 0 else 0

        lines = [
            f"═══ 算法订单执行报告 ═══",
            f"订单ID: {algo_id}",
            f"算法: {result.algo.upper()}",
            f"标的: {result.symbol}",
            f"方向: {result.side}",
            f"总量: {result.total_volume}股",
            f"已成交: {result.filled_volume}股 ({filled_pct:.0f}%)",
            f"均价: ¥{result.avg_fill_price:.2f}",
            f"到达价滑点: {result.slippage_vs_arrival:.4%}",
            f"耗时: {elapsed:.0f}秒",
            f"状态: {result.status}",
        ]

        if result.slices:
            lines.append(f"\n切片明细:")
            for s in result.slices:
                lines.append(f"  #{s.slice_id}: {s.volume}股 → {s.status} "
                             f"@ ¥{s.fill_price:.2f}" if s.fill_price > 0 else f"  #{s.slice_id}: {s.volume}股 → {s.status}")

        return "\n".join(lines)
