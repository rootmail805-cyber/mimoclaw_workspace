"""
Execution Engine for QuantFlow.
Orchestrates signal -> risk check -> order -> broker pipeline.
"""

import time
from typing import Optional, Dict, Any
from datetime import datetime, timezone
from loguru import logger

from .order_manager import OrderManager
from .broker_adapter import BrokerAdapter, SimulationAdapter
from .signal_queue import PersistentSignalQueue
from ..models import (
    Signal, SignalAction, Order, OrderSide, OrderType, OrderStatus,
    AccountInfo, Position, TradeRecord,
)
from ..risk.risk_manager import RiskManager
from config.manager import get_config


class HeartbeatMonitor:
    """Tracks broker heartbeat and triggers circuit-breaker on timeout.

    The monitor records the last time a heartbeat was received. If the
    elapsed time exceeds ``timeout_seconds``, the broker is considered
    disconnected and the ``on_timeout`` callback is invoked.

    Args:
        timeout_seconds: Seconds of silence before triggering timeout.
        on_timeout: Callback invoked when timeout is detected.
    """

    def __init__(self, timeout_seconds: float = 30.0, on_timeout=None):
        self._timeout = timeout_seconds
        self._on_timeout = on_timeout
        self._last_heartbeat: Optional[datetime] = None
        self._triggered = False

    def beat(self) -> None:
        """Record a heartbeat (call on each successful broker interaction)."""
        self._last_heartbeat = datetime.now(timezone.utc)
        self._triggered = False

    def check(self) -> bool:
        """Check if timeout has been exceeded.

        Returns:
            True if timeout exceeded, False otherwise.
        """
        if self._last_heartbeat is None:
            return False
        elapsed = (datetime.now(timezone.utc) - self._last_heartbeat).total_seconds()
        if elapsed > self._timeout and not self._triggered:
            self._triggered = True
            logger.warning(f"Heartbeat timeout: {elapsed:.1f}s > {self._timeout}s")
            if self._on_timeout:
                self._on_timeout()
            return True
        return False

    @property
    def last_heartbeat(self) -> Optional[datetime]:
        """Return the last heartbeat timestamp."""
        return self._last_heartbeat

    @property
    def is_alive(self) -> bool:
        """Return True if the broker is considered alive.

        This is a read-only check with no side effects (does not
        trigger the timeout callback or set the triggered flag).
        """
        if self._last_heartbeat is None:
            return True  # No heartbeat yet, assume alive
        elapsed = (datetime.now(timezone.utc) - self._last_heartbeat).total_seconds()
        return elapsed <= self._timeout


class ExecutionEngine:
    """Central execution engine.

    Pipeline:
        Signal -> Risk Check -> Order Creation -> Broker Submission -> Fill Handling
    """

    def __init__(self, config=None, risk_manager: Optional[RiskManager] = None):
        self._config = config or get_config()
        self._risk_manager = risk_manager or RiskManager(self._config)
        self._order_manager = OrderManager()
        self._broker: Optional[BrokerAdapter] = None
        self._connected = False
        self._reconnect_attempts = 0

        # Persistent signal queue
        sq_db = self._config.get("execution.signal_queue.db_path", "./data/signal_queue.db")
        sq_max_retries = self._config.get("execution.signal_queue.max_retries", 3)
        self._signal_queue = PersistentSignalQueue(db_path=sq_db, max_retries=sq_max_retries)

        # Heartbeat monitor
        hb_timeout = self._config.get("execution.heartbeat.timeout_seconds", 30.0)
        self._heartbeat = HeartbeatMonitor(timeout_seconds=hb_timeout, on_timeout=self._on_heartbeat_timeout)

        self._init_broker()

    def _init_broker(self) -> None:
        """Initialize the broker adapter."""
        broker_type = self._config.get("execution.broker", "simulation")

        if broker_type == "simulation":
            self._broker = SimulationAdapter(
                initial_balance=self._config.get("execution.simulation.initial_balance", 1_000_000),
            )
        elif broker_type == "qmt":
            from .broker_adapter import QMTAdapter
            self._broker = QMTAdapter(
                qmt_path=self._config.get("execution.qmt.path", ""),
                account=self._config.get("execution.qmt.account", ""),
            )
        else:
            logger.warning(f"Unknown broker type '{broker_type}', falling back to simulation")
            self._broker = SimulationAdapter()

        logger.info(f"Execution engine initialized with {broker_type} broker")

    def connect(self) -> bool:
        """Connect to the broker."""
        if self._broker:
            self._connected = self._broker.connect()
            return self._connected
        return False

    def disconnect(self) -> None:
        """Disconnect from the broker."""
        if self._broker:
            self._broker.disconnect()
        self._connected = False

    def reconnect(self) -> bool:
        """Attempt to reconnect to the broker.

        Tries up to ``execution.retry.max_retries`` times with exponential
        backoff. On success, replays any pending signals from the queue.

        Returns:
            True if reconnection succeeded, False otherwise.
        """
        max_retries = self._config.get("execution.retry.max_retries", 3)
        retry_delay = self._config.get("execution.retry.retry_delay_seconds", 1.0)
        backoff = self._config.get("execution.retry.backoff_multiplier", 2.0)

        logger.info("Attempting broker reconnection...")
        self.disconnect()

        for attempt in range(max_retries + 1):
            try:
                if self.connect():
                    self._reconnect_attempts += 1
                    logger.info(f"Reconnected successfully (attempt {attempt + 1}, total reconnects: {self._reconnect_attempts})")
                    # Replay pending signals
                    self._replay_pending_signals()
                    return True
            except Exception as e:
                logger.error(f"Reconnect attempt {attempt + 1} failed: {e}")

            if attempt < max_retries:
                sleep_time = retry_delay * (backoff ** attempt)
                logger.warning(f"Reconnecting in {sleep_time:.1f}s (attempt {attempt + 1}/{max_retries})")
                time.sleep(sleep_time)

        logger.error("Broker reconnection failed after all attempts")
        return False

    def _on_heartbeat_timeout(self) -> None:
        """Called when the heartbeat monitor detects a timeout."""
        logger.warning("Heartbeat timeout detected — initiating reconnect")
        self._connected = False
        self.reconnect()

    def _replay_pending_signals(self) -> None:
        """Replay all pending signals from the persistent queue."""
        pending = self._signal_queue.replay_pending()
        if pending:
            logger.info(f"Replaying {len(pending)} pending signals")
            for item in pending:
                try:
                    signal_data = item["signal_data"]
                    signal = Signal(**signal_data)
                    self.execute_signal(signal)
                    self._signal_queue.mark_processed(item["id"])
                except Exception as e:
                    logger.error(f"Failed to replay signal #{item['id']}: {e}")
                    self._signal_queue.mark_failed(item["id"], str(e))

    def execute_signal(self, signal: Signal) -> Optional[Order]:
        """Execute a trading signal through the full pipeline.

        Pipeline: enqueue → risk check → order creation → broker submit → fill.
        The signal is persisted to SQLite before submission so it survives crashes.

        Args:
            signal: The trading signal to execute.

        Returns:
            The created Order if successful, None if rejected.
        """
        if signal.action in (SignalAction.HOLD,):
            return None

        # Persist signal to queue before any side effects
        signal_data = {
            "symbol": signal.symbol,
            "action": signal.action.value,
            "volume": signal.volume,
            "price": signal.price,
            "strategy_id": signal.strategy_id,
            "confidence": signal.confidence,
            "reason": signal.reason,
        }
        queue_id = self._signal_queue.enqueue(signal_data)

        # Check heartbeat — refuse to submit if broker is down
        if self._heartbeat.check():
            logger.warning(f"Signal #{queue_id} deferred: broker heartbeat timeout")
            return None

        # Determine order parameters
        order_type = OrderType.MARKET if signal.price is None else OrderType.LIMIT
        price = signal.price

        # Create order
        order = self._order_manager.create_order(signal, price, order_type)

        # Risk check
        positions = self._broker.get_positions() if self._broker else {}
        account = self._broker.get_account() if self._broker else AccountInfo(account_id="unknown")

        passed, reason = self._risk_manager.check_order(order, positions, account)
        if not passed:
            order.status = OrderStatus.REJECTED
            self._signal_queue.mark_failed(queue_id, f"Risk rejected: {reason}")
            logger.warning(f"Order {order.order_id} rejected by risk: {reason}")
            return order

        # Submit to broker
        success = self._retry_submit(order)
        if success:
            self._risk_manager.record_trade(order, order.filled_price, order.filled_volume)
            self._signal_queue.mark_processed(queue_id)
            self._heartbeat.beat()
            logger.info(
                f"Order filled: {order.order_id} {order.side.value} "
                f"{order.filled_volume} {order.symbol} @ {order.filled_price:.3f}"
            )
        else:
            self._signal_queue.mark_failed(queue_id, "Broker submission failed")
            logger.error(f"Order submission failed: {order.order_id}")

        return order

    def _retry_submit(self, order: Order) -> bool:
        """Submit order with retry logic."""
        max_retries = self._config.get("execution.retry.max_retries", 3)
        retry_delay = self._config.get("execution.retry.retry_delay_seconds", 1.0)
        backoff = self._config.get("execution.retry.backoff_multiplier", 2.0)

        for attempt in range(max_retries + 1):
            try:
                if self._broker and self._broker.submit_order(order):
                    return True
            except Exception as e:
                logger.error(f"Submit attempt {attempt + 1} failed: {e}")

            if attempt < max_retries:
                sleep_time = retry_delay * (backoff ** attempt)
                logger.warning(f"Retrying in {sleep_time:.1f}s (attempt {attempt + 1}/{max_retries})")
                time.sleep(sleep_time)

        order.status = OrderStatus.ERROR
        return False

    def cancel_order(self, order_id: str) -> bool:
        """Cancel an order."""
        order = self._order_manager.get_order(order_id)
        if not order:
            return False

        if self._broker:
            success = self._broker.cancel_order(order_id)
            if success:
                order.status = OrderStatus.CANCELLED
            return success
        return False

    def cancel_all(self, symbol: Optional[str] = None) -> int:
        """Cancel all active orders."""
        return self._order_manager.cancel_all(symbol)

    def emergency_stop(self) -> None:
        """Emergency stop: trigger kill switch and cancel all orders."""
        self._risk_manager.trigger_kill_switch("Emergency stop triggered")
        cancelled = self.cancel_all()
        logger.critical(f"Emergency stop: {cancelled} orders cancelled")

    @property
    def account(self) -> AccountInfo:
        if self._broker:
            return self._broker.get_account()
        return AccountInfo(account_id="disconnected")

    @property
    def positions(self) -> Dict[str, Position]:
        if self._broker:
            return self._broker.get_positions()
        return {}

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def stats(self) -> Dict[str, Any]:
        return {
            "connected": self._connected,
            "total_orders": self._order_manager.total_orders,
            "active_orders": self._order_manager.active_count,
            "risk": self._risk_manager.stats,
        }
