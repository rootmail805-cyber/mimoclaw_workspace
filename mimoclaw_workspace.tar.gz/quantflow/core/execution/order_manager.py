"""
Order Manager for QuantFlow.
Handles order lifecycle, tracking, and retry logic.
"""

import uuid
from datetime import datetime
from typing import Dict, Optional, List
from loguru import logger

from ..models import Order, OrderSide, OrderType, OrderStatus, Signal, SignalAction


class OrderManager:
    """Manages order creation, tracking, and lifecycle."""

    def __init__(self):
        self._orders: Dict[str, Order] = {}
        self._order_history: List[str] = []  # Ordered list of order IDs

    def create_order(
        self,
        signal: Signal,
        price: Optional[float] = None,
        order_type: OrderType = OrderType.LIMIT,
    ) -> Order:
        """Create an order from a trading signal."""
        order_id = f"ORD_{uuid.uuid4().hex[:12].upper()}"

        side = OrderSide.BUY if signal.action == SignalAction.BUY else OrderSide.SELL
        volume = signal.volume or 100

        order = Order(
            order_id=order_id,
            symbol=signal.symbol,
            side=side,
            order_type=order_type,
            volume=volume,
            price=price or signal.price,
            strategy_id=signal.strategy_id,
            status=OrderStatus.PENDING,
        )

        self._orders[order_id] = order
        self._order_history.append(order_id)

        logger.info(f"Order created: {order_id} {side.value} {volume} {signal.symbol} @ {price}")
        return order

    def get_order(self, order_id: str) -> Optional[Order]:
        """Get an order by ID."""
        return self._orders.get(order_id)

    def update_status(self, order_id: str, status: OrderStatus, **kwargs) -> None:
        """Update order status."""
        order = self._orders.get(order_id)
        if not order:
            return

        order.status = status
        order.updated_at = datetime.now()

        if "filled_volume" in kwargs:
            order.filled_volume = kwargs["filled_volume"]
        if "filled_price" in kwargs:
            order.filled_price = kwargs["filled_price"]
        if "commission" in kwargs:
            order.commission = kwargs["commission"]
        if "broker_order_id" in kwargs:
            order.broker_order_id = kwargs["broker_order_id"]

    def get_active_orders(self, symbol: Optional[str] = None) -> List[Order]:
        """Get all active orders, optionally filtered by symbol."""
        orders = [o for o in self._orders.values() if o.is_active]
        if symbol:
            orders = [o for o in orders if o.symbol == symbol]
        return orders

    def cancel_all(self, symbol: Optional[str] = None) -> int:
        """Cancel all active orders. Returns count cancelled."""
        count = 0
        for order in self._orders.values():
            if order.is_active:
                if symbol is None or order.symbol == symbol:
                    order.status = OrderStatus.CANCELLED
                    order.updated_at = datetime.now()
                    count += 1
        return count

    @property
    def total_orders(self) -> int:
        return len(self._orders)

    @property
    def active_count(self) -> int:
        return sum(1 for o in self._orders.values() if o.is_active)
