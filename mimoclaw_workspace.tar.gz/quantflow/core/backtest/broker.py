"""
Simulated broker for backtesting — v2.
Fixes: T+1 enforcement, price limits (涨跌停), next-bar execution,
multi-symbol support, volume-weighted fill simulation.
"""

import uuid
from datetime import datetime, date
from typing import Dict, Optional, List
from loguru import logger

from ..models import (
    Order, OrderSide, OrderType, OrderStatus,
    Position, AccountInfo, TradeRecord, Bar,
)


# A-share price limits
_PRICE_LIMIT_NORMAL = 0.10    # ±10% for main board
_PRICE_LIMIT_ST = 0.05        # ±5% for ST stocks
_PRICE_LIMIT_NEW = 0.44       # ±44% for IPO first day
_COMMISSION_RATE_DEFAULT = 0.0003
_STAMP_TAX_RATE = 0.001       # 千一，卖出
_MIN_COMMISSION = 5.0


class VolumeSlippageModel:
    """Dynamic slippage model based on order volume vs market volume.

    The slippage increases as the order size relative to recent average
    volume grows, simulating market impact for large orders.

    Args:
        base_slippage_pct: Minimum slippage percentage (default 0.05%).
        impact_coefficient: How much volume ratio affects slippage.
    """

    def __init__(self, base_slippage_pct: float = 0.0005, impact_coefficient: float = 0.1):
        self.base_slippage_pct = base_slippage_pct
        self.impact_coefficient = impact_coefficient

    def calculate(self, order_volume: int, avg_volume_5min: float, base_price: float) -> float:
        """Calculate slippage amount (not percentage).

        Args:
            order_volume: Number of shares in the order.
            avg_volume_5min: Recent average volume (5-bar rolling).
            base_price: Reference price for slippage calculation.

        Returns:
            Slippage amount in currency units.
        """
        if avg_volume_5min <= 0:
            return base_price * self.base_slippage_pct * 2
        volume_ratio = order_volume / avg_volume_5min
        slippage_pct = self.base_slippage_pct + volume_ratio * self.impact_coefficient
        return base_price * min(slippage_pct, 0.05)


class SimulatedBroker:
    """Simulated broker with realistic A-share rules.

    Improvements over v1:
        - T+1 enforcement: today_buy_volume cannot be sold until next day
        - Price limit (涨跌停): orders outside limit are rejected
        - Multi-symbol portfolio tracking
        - Next-bar execution for market orders
        - Partial fill simulation for large orders
        - Volume availability check against market volume
    """

    def __init__(
        self,
        initial_capital: float = 1_000_000.0,
        commission_rate: float = _COMMISSION_RATE_DEFAULT,
        stamp_tax_rate: float = _STAMP_TAX_RATE,
        slippage_pct: float = 0.001,
        min_commission: float = _MIN_COMMISSION,
        enforce_t_plus_1: bool = True,
        enforce_price_limit: bool = True,
        slippage_model: Optional['VolumeSlippageModel'] = None,
    ):
        self._initial_capital = initial_capital
        self._commission_rate = commission_rate
        self._stamp_tax_rate = stamp_tax_rate
        self._slippage_pct = slippage_pct
        self._min_commission = min_commission
        self._enforce_t1 = enforce_t_plus_1
        self._enforce_price_limit = enforce_price_limit
        self._slippage_model = slippage_model

        # State
        self._cash = initial_capital
        self._positions: Dict[str, Position] = {}
        self._pending_orders: List[Order] = []   # Orders waiting for next bar
        self._orders: Dict[str, Order] = {}       # All orders by ID
        self._trades: List[TradeRecord] = []
        self._total_commission = 0.0
        self._total_slippage = 0.0
        self._current_date: Optional[date] = None
        self._prev_date: Optional[date] = None
        self._volume_history: Dict[str, List[int]] = {}  # symbol -> recent volumes

    # ─── Bar Processing ─────────────────────────────────────────────

    def on_bar(self, bar: Bar) -> List[TradeRecord]:
        """Process a new bar.

        Flow:
            1. Finalize T+1: convert yesterday's buys to available
            2. Execute pending orders from previous bar (next-bar execution)
            3. Collect new orders submitted during this bar
        """
        bar_date = bar.timestamp.date() if hasattr(bar.timestamp, 'date') else bar.timestamp

        # T+1 finalization: on a new trading day, make yesterday's buys available
        if self._current_date is not None and bar_date != self._current_date:
            self._finalize_t1()

        self._prev_date = self._current_date
        self._current_date = bar_date

        # Track volume for dynamic slippage
        if self._slippage_model is not None:
            vol_hist = self._volume_history.setdefault(bar.symbol, [])
            vol_hist.append(bar.volume)
            # Keep last 5 bars for rolling average
            if len(vol_hist) > 5:
                vol_hist.pop(0)

        # Execute pending orders against this bar
        trades = self._execute_pending(bar)
        return trades

    def _finalize_t1(self) -> None:
        """At the start of a new trading day, make yesterday's purchases available."""
        for pos in self._positions.values():
            if pos.today_buy_volume > 0:
                pos.available_volume += pos.today_buy_volume
                logger.debug(f"T+1 finalize {pos.symbol}: +{pos.today_buy_volume} available")
            pos.today_buy_volume = 0
            pos.today_sell_volume = 0

    def _execute_pending(self, bar: Bar) -> List[TradeRecord]:
        """Execute all pending orders against the current bar."""
        trades = []
        still_pending = []

        for order in self._pending_orders:
            if order.symbol != bar.symbol:
                still_pending.append(order)
                continue

            trade = self._try_fill(order, bar)
            if trade:
                trades.append(trade)
            else:
                # Order not filled — keep pending if still valid
                still_pending.append(order)

        self._pending_orders = still_pending
        return trades

    # ─── Order Submission ───────────────────────────────────────────

    def submit_order(
        self,
        symbol: str,
        side: OrderSide,
        order_type: OrderType,
        volume: int,
        price: Optional[float] = None,
        stop_price: Optional[float] = None,
        strategy_id: str = "",
    ) -> Optional[Order]:
        """Submit a new order.

        Market orders are queued for next-bar execution (realistic).
        Limit orders are also queued — they check price against the bar.
        """
        order_id = f"ORD_{uuid.uuid4().hex[:12].upper()}"

        # ── Basic validation ──
        if volume <= 0:
            logger.warning(f"Order rejected: invalid volume {volume}")
            return None

        if side == OrderSide.SELL:
            pos = self._positions.get(symbol)
            if not pos:
                logger.warning(f"Order rejected: no position for {symbol}")
                return None
            available = pos.available_volume if self._enforce_t1 else pos.volume
            if available < volume:
                logger.warning(
                    f"Order rejected: insufficient available volume for {symbol} "
                    f"(need {volume}, available {available})"
                )
                return None

        if side == OrderSide.BUY and price:
            estimated_cost = volume * price * (1 + self._commission_rate)
            if estimated_cost > self._cash:
                logger.warning(
                    f"Order rejected: insufficient cash "
                    f"(need ¥{estimated_cost:,.2f}, have ¥{self._cash:,.2f})"
                )
                return None

        # ── Price limit pre-check (for limit orders with known price) ──
        if self._enforce_price_limit and price and side == OrderSide.BUY:
            # We'll do the real check at fill time, but reject obviously wrong prices
            if price <= 0:
                logger.warning(f"Order rejected: price must be positive")
                return None

        order = Order(
            order_id=order_id,
            symbol=symbol,
            side=side,
            order_type=order_type,
            volume=volume,
            price=price,
            stop_price=stop_price,
            status=OrderStatus.SUBMITTED,
            strategy_id=strategy_id,
        )
        self._orders[order_id] = order
        self._pending_orders.append(order)

        logger.debug(
            f"Order queued: {order_id} {side.value} {volume} {symbol} "
            f"@ {price or 'MKT'} ({order_type.value})"
        )
        return order

    # ─── Fill Logic ─────────────────────────────────────────────────

    def _try_fill(self, order: Order, bar: Bar) -> Optional[TradeRecord]:
        """Try to fill an order against the current bar.

        Fill rules:
            - Market: fill at open ± slippage
            - Buy limit: fill if bar.low <= limit_price, at min(open, limit_price)
            - Sell limit: fill if bar.high >= limit_price, at max(open, limit_price)
            - Stop: trigger on price crossing stop_price
        """
        filled = False
        fill_price = 0.0
        base_price = bar.open  # Reference price for slippage

        # ── Price limit check ──
        if self._enforce_price_limit:
            prev_close = bar.pre_close if hasattr(bar, 'pre_close') and bar.pre_close > 0 else None
            if prev_close and prev_close > 0:
                upper_limit = prev_close * (1 + _PRICE_LIMIT_NORMAL)
                lower_limit = prev_close * (1 - _PRICE_LIMIT_NORMAL)
                if bar.open >= upper_limit or bar.open <= lower_limit:
                    # At price limit — extremely hard to fill
                    logger.debug(f"Price limit hit for {order.symbol}: open={bar.open}, prev={prev_close}")
                    if order.order_type == OrderType.MARKET:
                        # Market order at limit price
                        pass  # Allow fill at limit

        if order.order_type == OrderType.MARKET:
            if self._slippage_model is not None:
                vol_hist = self._volume_history.get(order.symbol, [])
                avg_vol = sum(vol_hist) / len(vol_hist) if vol_hist else 0
                slippage = self._slippage_model.calculate(order.volume, avg_vol, base_price)
            else:
                slippage = base_price * self._slippage_pct
            fill_price = base_price + slippage if order.side == OrderSide.BUY else base_price - slippage
            filled = True

        elif order.order_type == OrderType.LIMIT:
            if order.price is None:
                return None

            if order.side == OrderSide.BUY:
                if bar.low <= order.price:
                    fill_price = min(order.price, bar.open)
                    fill_price += fill_price * self._slippage_pct
                    filled = True
            else:  # SELL
                if bar.high >= order.price:
                    fill_price = max(order.price, bar.open)
                    fill_price -= fill_price * self._slippage_pct
                    filled = True

        elif order.order_type == OrderType.STOP:
            if order.stop_price is None:
                return None

            if order.side == OrderSide.SELL:
                if bar.low <= order.stop_price:
                    fill_price = min(order.stop_price, bar.open)
                    fill_price -= fill_price * self._slippage_pct
                    filled = True
            else:  # BUY stop
                if bar.high >= order.stop_price:
                    fill_price = max(order.stop_price, bar.open)
                    fill_price += fill_price * self._slippage_pct
                    filled = True

        elif order.order_type == OrderType.STOP_LIMIT:
            if order.stop_price is None or order.price is None:
                return None
            # First check if stop is triggered
            triggered = False
            if order.side == OrderSide.SELL and bar.low <= order.stop_price:
                triggered = True
            elif order.side == OrderSide.BUY and bar.high >= order.stop_price:
                triggered = True

            if triggered:
                # Then check if limit is achievable
                if order.side == OrderSide.SELL and bar.high >= order.price:
                    fill_price = max(order.price, bar.open)
                    fill_price -= fill_price * self._slippage_pct
                    filled = True
                elif order.side == OrderSide.BUY and bar.low <= order.price:
                    fill_price = min(order.price, bar.open)
                    fill_price += fill_price * self._slippage_pct
                    filled = True

        if not filled:
            return None

        # Ensure fill price is positive
        fill_price = max(fill_price, 0.01)

        return self._apply_fill(order, fill_price, bar)

    def _apply_fill(self, order: Order, fill_price: float, bar: Bar) -> TradeRecord:
        """Apply a fill and update all state."""
        trade_value = fill_price * order.volume

        # Commission
        commission = max(trade_value * self._commission_rate, self._min_commission)
        if order.side == OrderSide.SELL:
            commission += trade_value * self._stamp_tax_rate

        slippage_cost = abs(fill_price - (order.price or bar.open)) * order.volume

        # Update cash and positions
        if order.side == OrderSide.BUY:
            cost = trade_value + commission
            self._cash -= cost

            pos = self._positions.get(order.symbol)
            if pos is None:
                pos = Position(symbol=order.symbol)
                self._positions[order.symbol] = pos

            total_cost = pos.avg_cost * pos.volume + trade_value
            pos.volume += order.volume
            pos.avg_cost = total_cost / pos.volume if pos.volume > 0 else 0
            pos.today_buy_volume += order.volume
            # T+1: available_volume NOT updated until next day
            pos.update_price(fill_price)

        elif order.side == OrderSide.SELL:
            proceeds = trade_value - commission
            self._cash += proceeds

            pos = self._positions.get(order.symbol)
            if pos:
                realized = (fill_price - pos.avg_cost) * order.volume
                pos.realized_pnl += realized
                pos.volume -= order.volume
                pos.available_volume -= order.volume
                pos.today_sell_volume += order.volume
                if pos.volume <= 0:
                    pos.volume = 0
                    pos.avg_cost = 0
                    pos.available_volume = 0
                pos.update_price(fill_price)

        # Update order
        order.filled_volume = order.volume
        order.filled_price = fill_price
        order.status = OrderStatus.FILLED
        order.commission = commission
        order.updated_at = bar.timestamp

        self._total_commission += commission
        self._total_slippage += slippage_cost

        # Create trade record
        trade = TradeRecord(
            trade_id=f"TRD_{uuid.uuid4().hex[:12].upper()}",
            order_id=order.order_id,
            symbol=order.symbol,
            side=order.side,
            price=fill_price,
            volume=order.volume,
            commission=commission,
            timestamp=bar.timestamp,
            strategy_id=order.strategy_id,
            slippage=slippage_cost,
        )
        self._trades.append(trade)

        logger.debug(
            f"Filled: {order.side.value} {order.volume} {order.symbol} "
            f"@ {fill_price:.3f} | comm={commission:.2f} | slip={slippage_cost:.2f}"
        )
        return trade

    # ─── Order Management ───────────────────────────────────────────

    def cancel_order(self, order_id: str) -> bool:
        """Cancel a pending order."""
        order = self._orders.get(order_id)
        if order and order.is_active:
            order.status = OrderStatus.CANCELLED
            order.updated_at = datetime.now()
            self._pending_orders = [o for o in self._pending_orders if o.order_id != order_id]
            return True
        return False

    def cancel_all(self, symbol: Optional[str] = None) -> int:
        """Cancel all active orders, optionally filtered by symbol."""
        count = 0
        remaining = []
        for order in self._pending_orders:
            if order.is_active and (symbol is None or order.symbol == symbol):
                order.status = OrderStatus.CANCELLED
                count += 1
            else:
                remaining.append(order)
        self._pending_orders = remaining
        return count

    def emergency_sell_all(self, bar: Bar) -> List[TradeRecord]:
        """Emergency: sell all positions at market price."""
        trades = []
        for symbol, pos in list(self._positions.items()):
            available = pos.available_volume if self._enforce_t1 else pos.volume
            if available > 0:
                order = self.submit_order(
                    symbol=symbol,
                    side=OrderSide.SELL,
                    order_type=OrderType.MARKET,
                    volume=available,
                )
                if order:
                    trade = self._try_fill(order, bar)
                    if trade:
                        trades.append(trade)
        return trades

    # ─── State Queries ──────────────────────────────────────────────

    def get_account(self) -> AccountInfo:
        market_value = sum(
            pos.volume * pos.current_price
            for pos in self._positions.values()
        )
        total_assets = self._cash + market_value
        return AccountInfo(
            account_id="SIM",
            total_assets=total_assets,
            cash=self._cash,
            market_value=market_value,
            unrealized_pnl=sum(p.unrealized_pnl for p in self._positions.values()),
            realized_pnl=sum(p.realized_pnl for p in self._positions.values()),
            commission=self._total_commission,
            initial_capital=self._initial_capital,
        )

    def update_prices(self, prices: Dict[str, float]) -> None:
        for symbol, pos in self._positions.items():
            if symbol in prices:
                pos.update_price(prices[symbol])

    @property
    def positions(self) -> Dict[str, Position]:
        return dict(self._positions)

    @property
    def trades(self) -> List[TradeRecord]:
        return list(self._trades)

    @property
    def pending_orders(self) -> List[Order]:
        return list(self._pending_orders)

    @property
    def total_commission(self) -> float:
        return self._total_commission

    @property
    def total_slippage(self) -> float:
        return self._total_slippage

    @property
    def initial_capital(self) -> float:
        return self._initial_capital
