"""Backtesting engine: historical replay, simulation, and performance analysis."""

from .engine import BacktestEngine
from .broker import SimulatedBroker, VolumeSlippageModel
from .performance import PerformanceAnalyzer, TradeAnalysis
from .report import ReportGenerator

__all__ = [
    "BacktestEngine",
    "SimulatedBroker",
    "VolumeSlippageModel",
    "PerformanceAnalyzer",
    "TradeAnalysis",
    "ReportGenerator",
]
