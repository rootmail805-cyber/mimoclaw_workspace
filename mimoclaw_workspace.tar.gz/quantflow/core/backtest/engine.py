"""
Backtest Engine v2 — multi-symbol, walk-forward, parameter optimization.
"""

import time
import itertools
from datetime import datetime
from typing import List, Optional, Dict, Any, Callable, Tuple
from concurrent.futures import ProcessPoolExecutor, as_completed
import pandas as pd
import numpy as np
from loguru import logger

from .broker import SimulatedBroker
from .performance import PerformanceAnalyzer
from ..models import Bar, Signal, SignalAction, OrderSide, OrderType
from ..strategy.base import BaseStrategy
from config.manager import get_config


class BacktestEngine:
    """Event-driven backtesting engine.

    v2 improvements:
        - Multi-symbol portfolio backtest
        - Walk-forward analysis
        - Parameter grid optimization
        - Benchmark comparison
        - Progress reporting
    """

    def __init__(self, config=None):
        self._config = config or get_config()
        self._strategies: List[BaseStrategy] = []
        self._equity_curve: List[Dict[str, Any]] = []
        self._running = False
        self._broker: Optional[SimulatedBroker] = None

    def _create_broker(self) -> SimulatedBroker:
        """Create a SimulatedBroker from configuration.

        Supports both static slippage (``slippage_pct``) and dynamic
        volume-based slippage (``slippage_model``). When the config
        contains ``backtest.slippage_model: volume``, a
        :class:`VolumeSlippageModel` is used instead of the fixed percentage.
        """
        from .broker import VolumeSlippageModel

        slippage_model = None
        model_type = self._config.get("backtest.slippage_model", "static")
        if model_type == "volume":
            base_pct = self._config.get("backtest.volume_slippage.base_slippage_pct", 0.0005)
            impact = self._config.get("backtest.volume_slippage.impact_coefficient", 0.1)
            slippage_model = VolumeSlippageModel(
                base_slippage_pct=base_pct,
                impact_coefficient=impact,
            )

        return SimulatedBroker(
            initial_capital=self._config.get("backtest.initial_capital", 1_000_000),
            commission_rate=self._config.get("backtest.commission_rate", 0.0003),
            stamp_tax_rate=self._config.get("backtest.stamp_tax_rate", 0.001),
            slippage_pct=self._config.get("backtest.slippage_pct", 0.001),
            enforce_t_plus_1=True,
            enforce_price_limit=True,
            slippage_model=slippage_model,
        )

    def add_strategy(self, strategy: BaseStrategy) -> None:
        self._strategies.append(strategy)
        logger.info(f"Added strategy: {strategy.strategy_id}")

    # ─── Single-Symbol Backtest ─────────────────────────────────────

    def run(
        self,
        data: pd.DataFrame,
        symbol: str,
        freq: str = "daily",
        benchmark: Optional[pd.DataFrame] = None,
    ) -> Dict[str, Any]:
        """Run backtest on a single symbol.

        Args:
            data: OHLCV DataFrame (index=date).
            symbol: Stock symbol.
            freq: Data frequency.
            benchmark: Optional benchmark OHLCV for comparison.

        Returns:
            Results dict with equity curve, trades, and performance metrics.
        """
        if not self._strategies:
            raise ValueError("No strategies added.")
        if data.empty:
            raise ValueError("Empty data provided")

        self._broker = self._create_broker()
        self._equity_curve = []

        logger.info(
            f"Starting backtest: {symbol} | {data.index[0]} ~ {data.index[-1]} | "
            f"{len(data)} bars | {len(self._strategies)} strategies"
        )

        self._running = True
        start_time = time.time()

        for strategy in self._strategies:
            strategy.on_start()

        # ── Main loop ──
        prev_row = None
        for i, (timestamp, row) in enumerate(data.iterrows()):
            if not self._running:
                break

            bar = self._row_to_bar(row, symbol, timestamp, freq)

            # Step 1: Broker processes bar (T+1 finalization + pending order execution)
            trades = self._broker.on_bar(bar)

            # Notify strategies of fills
            for trade in trades:
                for strategy in self._strategies:
                    strategy.on_trade(trade.symbol, trade.side.value, trade.price, trade.volume)

            # Step 2: Feed bar to strategies → generate signals
            for strategy in self._strategies:
                signal = strategy._feed_bar(bar)
                if signal and signal.action != SignalAction.HOLD:
                    self._process_signal(signal, bar)

            # Step 3: Record equity
            self._broker.update_prices({symbol: bar.close})
            account = self._broker.get_account()
            self._equity_curve.append({
                "date": bar.timestamp,
                "total_assets": account.total_assets,
                "cash": account.cash,
                "market_value": account.market_value,
                "unrealized_pnl": account.unrealized_pnl,
                "realized_pnl": account.realized_pnl,
            })

            prev_row = row

        for strategy in self._strategies:
            strategy.on_stop()

        elapsed = time.time() - start_time
        logger.info(f"Backtest completed in {elapsed:.2f}s | {len(data)} bars processed")

        return self._build_results(symbol, data, elapsed, benchmark)

    # ─── Multi-Symbol Portfolio Backtest ────────────────────────────

    def run_portfolio(
        self,
        data_dict: Dict[str, pd.DataFrame],
        freq: str = "daily",
        benchmark: Optional[pd.DataFrame] = None,
    ) -> Dict[str, Any]:
        """Run backtest across multiple symbols simultaneously.

        Args:
            data_dict: {symbol: OHLCV_DataFrame} — all must have same date index.
            freq: Data frequency.
            benchmark: Optional benchmark data.

        Returns:
            Portfolio-level results.
        """
        if not self._strategies:
            raise ValueError("No strategies added.")
        if not data_dict:
            raise ValueError("Empty data_dict")

        self._broker = self._create_broker()
        self._equity_curve = []

        symbols = list(data_dict.keys())
        logger.info(f"Starting portfolio backtest: {len(symbols)} symbols")

        # Align all data to common dates (deduplicated)
        common_dates = None
        for sym, df in data_dict.items():
            dates = set(df.index)
            common_dates = dates if common_dates is None else common_dates & dates
        common_dates = sorted(common_dates)

        if not common_dates:
            raise ValueError("No common dates across symbols")

        # Defensive: ensure each symbol has unique dates
        for sym in data_dict:
            if data_dict[sym].index.duplicated().any():
                logger.warning(f"Duplicate dates in {sym}, keeping first occurrence")
                data_dict[sym] = data_dict[sym][~data_dict[sym].index.duplicated(keep='first')]

        logger.info(f"Common dates: {len(common_dates)} | {common_dates[0]} ~ {common_dates[-1]}")

        self._running = True
        start_time = time.time()

        for strategy in self._strategies:
            strategy.on_start()

        # ── Main loop ──
        for ts in common_dates:
            if not self._running:
                break

            for symbol in symbols:
                row = data_dict[symbol].loc[ts]
                bar = self._row_to_bar(row, symbol, ts, freq)

                # Broker processes bar
                trades = self._broker.on_bar(bar)
                for trade in trades:
                    for strategy in self._strategies:
                        strategy.on_trade(trade.symbol, trade.side.value, trade.price, trade.volume)

                # Strategy generates signals
                for strategy in self._strategies:
                    signal = strategy._feed_bar(bar)
                    if signal and signal.action != SignalAction.HOLD:
                        self._process_signal(signal, bar)

            # Update all prices and record equity
            prices = {sym: data_dict[sym].loc[ts, "close"] for sym in symbols}
            self._broker.update_prices(prices)
            account = self._broker.get_account()
            self._equity_curve.append({
                "date": ts,
                "total_assets": account.total_assets,
                "cash": account.cash,
                "market_value": account.market_value,
                "unrealized_pnl": account.unrealized_pnl,
                "realized_pnl": account.realized_pnl,
            })

        for strategy in self._strategies:
            strategy.on_stop()

        elapsed = time.time() - start_time
        logger.info(f"Portfolio backtest completed in {elapsed:.2f}s")

        # Build merged data for results
        merged = pd.concat(
            [df.add_suffix(f"_{sym}") for sym, df in data_dict.items()],
            axis=1,
        ).dropna()

        return self._build_results(",".join(symbols), merged, elapsed, benchmark)

    # ─── Walk-Forward Analysis ──────────────────────────────────────

    def walk_forward(
        self,
        data: pd.DataFrame,
        symbol: str,
        strategy_factory: Callable[..., BaseStrategy],
        param_grid: Dict[str, list],
        n_splits: int = 5,
        train_ratio: float = 0.7,
        freq: str = "daily",
    ) -> Dict[str, Any]:
        """Walk-forward analysis with parameter optimization.

        Splits data into n_splits windows. For each window:
            1. Optimize parameters on train portion
            2. Test best parameters on test portion
            3. Collect out-of-sample results

        Args:
            data: Full historical data.
            symbol: Stock symbol.
            strategy_factory: Callable that creates a strategy given params.
            param_grid: {param_name: [values]} to search.
            n_splits: Number of walk-forward windows.
            train_ratio: Fraction of each window used for training.
            freq: Data frequency.

        Returns:
            Walk-forward results with OOS performance.
        """
        total_bars = len(data)
        window_size = total_bars // n_splits
        train_size = int(window_size * train_ratio)
        test_size = window_size - train_size

        logger.info(
            f"Walk-forward: {n_splits} splits | window={window_size} | "
            f"train={train_size} | test={test_size}"
        )

        # Generate parameter combinations
        param_names = list(param_grid.keys())
        param_values = list(param_grid.values())
        param_combos = [dict(zip(param_names, combo)) for combo in itertools.product(*param_values)]
        logger.info(f"Parameter combinations: {len(param_combos)}")

        oos_results = []  # Out-of-sample results
        best_params_per_split = []

        for split_idx in range(n_splits):
            start = split_idx * window_size
            train_end = start + train_size
            test_end = min(start + window_size, total_bars)

            train_data = data.iloc[start:train_end]
            test_data = data.iloc[train_end:test_end]

            if len(test_data) == 0:
                continue

            logger.info(f"Split {split_idx + 1}/{n_splits}: train={len(train_data)} bars, test={len(test_data)} bars")

            # ── Optimize on train set ──
            best_sharpe = -np.inf
            best_params = param_combos[0]

            for params in param_combos:
                strategy = strategy_factory(
                    strategy_id=f"opt_{split_idx}_{hash(str(params))}",
                    params=params,
                )
                broker = self._create_broker()
                equity = self._run_inner(train_data, symbol, strategy, broker, freq)

                if equity:
                    eq_df = pd.DataFrame(equity).set_index("date")
                    analyzer = PerformanceAnalyzer(eq_df, broker.initial_capital)
                    sharpe = analyzer.sharpe_ratio()
                    if sharpe > best_sharpe:
                        best_sharpe = sharpe
                        best_params = params

            best_params_per_split.append(best_params)
            logger.info(f"  Best params: {best_params} (Sharpe={best_sharpe:.4f})")

            # ── Test on OOS ──
            strategy = strategy_factory(
                strategy_id=f"oos_{split_idx}",
                params=best_params,
            )
            broker = self._create_broker()
            equity = self._run_inner(test_data, symbol, strategy, broker, freq)

            if equity:
                eq_df = pd.DataFrame(equity).set_index("date")
                analyzer = PerformanceAnalyzer(eq_df, broker.initial_capital)
                metrics = analyzer.calculate_all()
                oos_results.append({
                    "split": split_idx,
                    "params": best_params,
                    "test_bars": len(test_data),
                    **metrics,
                })

        # ── Aggregate OOS results ──
        if oos_results:
            avg_return = np.mean([r["total_return"] for r in oos_results])
            avg_sharpe = np.mean([r["sharpe_ratio"] for r in oos_results])
            avg_mdd = np.mean([r["max_drawdown"] for r in oos_results])
            win_splits = sum(1 for r in oos_results if r["total_return"] > 0)
        else:
            avg_return = avg_sharpe = avg_mdd = 0
            win_splits = 0

        return {
            "n_splits": n_splits,
            "param_combos": len(param_combos),
            "best_params_per_split": best_params_per_split,
            "oos_results": oos_results,
            "oos_avg_return": avg_return,
            "oos_avg_sharpe": avg_sharpe,
            "oos_avg_max_drawdown": avg_mdd,
            "oos_win_splits": f"{win_splits}/{len(oos_results)}",
        }

    def _run_inner(
        self, data: pd.DataFrame, symbol: str, strategy: BaseStrategy,
        broker: SimulatedBroker, freq: str,
    ) -> List[Dict]:
        """Run a single backtest internally (used by walk-forward)."""
        equity = []
        strategy.on_start()

        for ts, row in data.iterrows():
            bar = self._row_to_bar(row, symbol, ts, freq)
            trades = broker.on_bar(bar)
            for trade in trades:
                strategy.on_trade(trade.symbol, trade.side.value, trade.price, trade.volume)

            signal = strategy._feed_bar(bar)
            if signal and signal.action != SignalAction.HOLD:
                self._process_signal_inner(signal, bar, broker)

            broker.update_prices({symbol: bar.close})
            account = broker.get_account()
            equity.append({
                "date": bar.timestamp,
                "total_assets": account.total_assets,
                "cash": account.cash,
                "market_value": account.market_value,
                "unrealized_pnl": account.unrealized_pnl,
                "realized_pnl": account.realized_pnl,
            })

        strategy.on_stop()
        return equity

    # ─── Signal Processing ──────────────────────────────────────────

    def _process_signal(self, signal: Signal, bar: Bar) -> None:
        self._process_signal_inner(signal, bar, self._broker)

    def _process_signal_inner(self, signal: Signal, bar: Bar, broker: SimulatedBroker) -> None:
        """Convert signal to order and submit to broker."""
        from ..strategy.position_sizing import PositionSizer

        if signal.action == SignalAction.BUY:
            volume = signal.volume or 100
            # Round to lot size (100 shares)
            volume = max(100, (volume // 100) * 100)

            price = signal.price or bar.close
            broker.submit_order(
                symbol=signal.symbol,
                side=OrderSide.BUY,
                order_type=OrderType.LIMIT if signal.price else OrderType.MARKET,
                volume=volume,
                price=price,
                strategy_id=signal.strategy_id,
            )
        elif signal.action in (SignalAction.SELL, SignalAction.CLOSE):
            pos = broker.positions.get(signal.symbol)
            if pos:
                available = pos.available_volume
                if available > 0:
                    volume = signal.volume or available
                    volume = min(volume, available)
                    price = signal.price or bar.close
                    broker.submit_order(
                        symbol=signal.symbol,
                        side=OrderSide.SELL,
                        order_type=OrderType.LIMIT if signal.price else OrderType.MARKET,
                        volume=volume,
                        price=price,
                        strategy_id=signal.strategy_id,
                    )

    # ─── Helpers ────────────────────────────────────────────────────

    def _row_to_bar(self, row: pd.Series, symbol: str, timestamp, freq: str) -> Bar:
        """Convert a DataFrame row to a Bar object."""
        return Bar(
            symbol=symbol,
            open=float(row.get("open", row.get("Open", 0))),
            high=float(row.get("high", row.get("High", 0))),
            low=float(row.get("low", row.get("Low", 0))),
            close=float(row.get("close", row.get("Close", 0))),
            volume=int(row.get("volume", row.get("Volume", 0))),
            turnover=float(row.get("turnover", row.get("Turnover", 0))),
            timestamp=timestamp if isinstance(timestamp, datetime) else pd.to_datetime(timestamp),
            frequency=freq,
        )

    def _build_results(
        self, symbol: str, data: pd.DataFrame, elapsed: float,
        benchmark: Optional[pd.DataFrame] = None,
    ) -> Dict[str, Any]:
        """Build comprehensive results."""
        equity_df = pd.DataFrame(self._equity_curve)
        if equity_df.empty:
            return {"error": "No equity data generated"}

        equity_df = equity_df.set_index("date")

        analyzer = PerformanceAnalyzer(equity_df, self._broker.initial_capital)
        metrics = analyzer.calculate_all()

        # Benchmark comparison
        benchmark_metrics = None
        if benchmark is not None and "close" in benchmark.columns:
            benchmark_metrics = self._compute_benchmark_metrics(equity_df, benchmark)

        return {
            "symbol": symbol,
            "period": f"{data.index[0]} ~ {data.index[-1]}",
            "total_bars": len(data),
            "elapsed_seconds": round(elapsed, 2),
            "equity_curve": equity_df,
            "trades": self._broker.trades,
            "total_trades": len(self._broker.trades),
            "total_commission": self._broker.total_commission,
            "total_slippage": self._broker.total_slippage,
            "final_account": self._broker.get_account(),
            "metrics": metrics,
            "benchmark_metrics": benchmark_metrics,
            "strategies": [s.strategy_id for s in self._strategies],
        }

    def _compute_benchmark_metrics(
        self, equity_df: pd.DataFrame, benchmark: pd.DataFrame,
    ) -> Dict[str, float]:
        """Compute alpha, beta, and information ratio vs benchmark."""
        # Align dates
        strat_returns = equity_df["total_assets"].pct_change().dropna()
        bench_returns = benchmark["close"].pct_change().dropna()

        common = strat_returns.index.intersection(bench_returns.index)
        if len(common) < 10:
            return {}

        sr = strat_returns.loc[common]
        br = bench_returns.loc[common]

        # Beta = Cov(Rs, Rb) / Var(Rb)
        cov = np.cov(sr, br)
        beta = cov[0, 1] / cov[1, 1] if cov[1, 1] != 0 else 0

        # Alpha (annualized)
        alpha = (sr.mean() - beta * br.mean()) * 252

        # Information ratio
        tracking_error = (sr - br).std() * np.sqrt(252)
        info_ratio = ((sr.mean() - br.mean()) * 252) / tracking_error if tracking_error != 0 else 0

        # Correlation
        corr = sr.corr(br)

        return {
            "alpha": alpha,
            "beta": beta,
            "information_ratio": info_ratio,
            "correlation": corr,
            "benchmark_return": (1 + br).prod() - 1,
            "excess_return": ((1 + sr).prod() - 1) - ((1 + br).prod() - 1),
        }

    def stop(self) -> None:
        self._running = False
        logger.info("Backtest stopped by user")
