"""
Performance Analysis v2 for QuantFlow.
Adds: VaR/CVaR, Monte Carlo, trade-level analytics, benchmark comparison.
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from loguru import logger


@dataclass
class TradeAnalysis:
    """Trade-level analytics."""
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate: float = 0.0
    avg_win: float = 0.0
    avg_loss: float = 0.0
    profit_loss_ratio: float = 0.0
    avg_holding_days: float = 0.0
    max_consecutive_wins: int = 0
    max_consecutive_losses: int = 0
    largest_win: float = 0.0
    largest_loss: float = 0.0
    total_commission: float = 0.0
    total_slippage: float = 0.0
    expectancy: float = 0.0  # p*avg_win - (1-p)*avg_loss


class PerformanceAnalyzer:
    """Comprehensive performance analysis engine.

    v2 additions:
        - VaR and CVaR (Conditional VaR)
        - Monte Carlo simulation for robustness
        - Trade-level analytics (holding period, consecutive wins/losses)
        - Expectancy calculation
        - Tail risk metrics
    """

    def __init__(self, equity_curve: pd.DataFrame, initial_capital: float = 1_000_000):
        self._equity = equity_curve
        self._initial = initial_capital
        self._returns = self._calculate_returns()

    def _calculate_returns(self) -> pd.Series:
        if "total_assets" not in self._equity.columns or self._equity.empty:
            return pd.Series(dtype=float)
        return self._equity["total_assets"].pct_change().dropna()

    # ─── Core Metrics ───────────────────────────────────────────────

    def calculate_all(self) -> Dict[str, Any]:
        """Calculate all performance metrics."""
        metrics = {
            # Return metrics
            "total_return": self.total_return(),
            "annualized_return": self.annualized_return(),
            # Risk metrics
            "max_drawdown": self.max_drawdown(),
            "max_drawdown_duration": self.max_drawdown_duration(),
            "volatility": self.volatility(),
            "downside_deviation": self.downside_deviation(),
            "var_95": self.var_95(),
            "cvar_95": self.cvar_95(),
            "var_99": self.var_99(),
            "tail_ratio": self.tail_ratio(),
            # Risk-adjusted metrics
            "sharpe_ratio": self.sharpe_ratio(),
            "sortino_ratio": self.sortino_ratio(),
            "calmar_ratio": self.calmar_ratio(),
            # Trade metrics
            "win_rate": self.win_rate(),
            "profit_loss_ratio": self.profit_loss_ratio(),
            # Counts
            "trading_days": len(self._equity),
        }
        return metrics

    # ─── Return Metrics ─────────────────────────────────────────────

    def total_return(self) -> float:
        if "total_assets" not in self._equity.columns or self._equity.empty:
            return 0.0
        if self._initial == 0:
            return 0.0
        return (self._equity["total_assets"].iloc[-1] - self._initial) / self._initial

    def annualized_return(self) -> float:
        total = self.total_return()
        days = len(self._equity)
        if days <= 1 or total <= -1:
            return 0.0
        years = days / 252
        return (1 + total) ** (1 / years) - 1

    # ─── Risk Metrics ───────────────────────────────────────────────

    def max_drawdown(self) -> float:
        if "total_assets" not in self._equity.columns or self._equity.empty:
            return 0.0
        peak = self._equity["total_assets"].expanding().max()
        # 保护除零：peak为0时跳过
        if (peak == 0).all():
            return 0.0
        drawdown = (self._equity["total_assets"] - peak) / peak.replace(0, 1)
        return abs(drawdown.min())

    def max_drawdown_duration(self) -> int:
        if "total_assets" not in self._equity.columns:
            return 0
        peak = self._equity["total_assets"].expanding().max()
        in_dd = self._equity["total_assets"] < peak
        max_dur = curr_dur = 0
        for is_dd in in_dd:
            if is_dd:
                curr_dur += 1
                max_dur = max(max_dur, curr_dur)
            else:
                curr_dur = 0
        return max_dur

    def volatility(self) -> float:
        if self._returns.empty:
            return 0.0
        return self._returns.std() * np.sqrt(252)

    def downside_deviation(self, threshold: float = 0.0) -> float:
        if self._returns.empty:
            return 0.0
        downside = self._returns[self._returns < threshold]
        if downside.empty:
            return 0.0
        return downside.std() * np.sqrt(252)

    def var_95(self) -> float:
        """Value at Risk at 95% confidence (1-day)."""
        if self._returns.empty:
            return 0.0
        return float(np.percentile(self._returns, 5))

    def var_99(self) -> float:
        """Value at Risk at 99% confidence (1-day)."""
        if self._returns.empty:
            return 0.0
        return float(np.percentile(self._returns, 1))

    def cvar_95(self) -> float:
        """Conditional VaR (Expected Shortfall) at 95% confidence."""
        if self._returns.empty:
            return 0.0
        var = self.var_95()
        tail = self._returns[self._returns <= var]
        return float(tail.mean()) if not tail.empty else var

    def tail_ratio(self) -> float:
        """Ratio of 95th percentile gains to 5th percentile losses."""
        if self._returns.empty:
            return 0.0
        p95 = np.percentile(self._returns, 95)
        p5 = abs(np.percentile(self._returns, 5))
        return p95 / p5 if p5 != 0 else 0.0

    # ─── Risk-Adjusted Metrics ──────────────────────────────────────

    def sharpe_ratio(self, risk_free_rate: float = 0.03) -> float:
        if self._returns.empty:
            return 0.0
        excess = self._returns.mean() - risk_free_rate / 252
        std = self._returns.std()
        return (excess / std * np.sqrt(252)) if std != 0 else 0.0

    def sortino_ratio(self, risk_free_rate: float = 0.03) -> float:
        if self._returns.empty:
            return 0.0
        excess = self._returns.mean() - risk_free_rate / 252
        dd = self.downside_deviation()
        return (excess / dd * np.sqrt(252)) if dd != 0 else 0.0

    def calmar_ratio(self) -> float:
        mdd = self.max_drawdown()
        return self.annualized_return() / mdd if mdd != 0 else 0.0

    # ─── Trade Metrics ──────────────────────────────────────────────

    def win_rate(self) -> float:
        if self._returns.empty:
            return 0.0
        return (self._returns > 0).sum() / len(self._returns)

    def profit_loss_ratio(self) -> float:
        if self._returns.empty:
            return 0.0
        profits = self._returns[self._returns > 0]
        losses = self._returns[self._returns < 0]
        if losses.empty:
            return float("inf") if not profits.empty else 0.0
        if profits.empty:
            return 0.0
        return abs(profits.mean() / losses.mean())

    def analyze_trades(self, trades: list) -> TradeAnalysis:
        """Analyze individual trade records."""
        if not trades:
            return TradeAnalysis()

        from collections import defaultdict
        from ..models import OrderSide

        # Group trades by symbol to compute P&L per round-trip
        pnls = []
        holding_days = []
        wins = []
        losses = []
        total_comm = 0
        total_slip = 0

        # Track buys to compute round-trip P&L
        open_positions: Dict[str, list] = defaultdict(list)  # symbol -> [(price, volume, date)]

        for trade in sorted(trades, key=lambda t: t.timestamp):
            total_comm += trade.commission
            total_slip += trade.slippage

            if trade.side == OrderSide.BUY:
                open_positions[trade.symbol].append({
                    "price": trade.price,
                    "volume": trade.volume,
                    "date": trade.timestamp,
                })
            elif trade.side == OrderSide.SELL:
                # Match against earliest buy (FIFO)
                buys = open_positions.get(trade.symbol, [])
                sell_vol = trade.volume
                sell_price = trade.price

                while sell_vol > 0 and buys:
                    buy = buys[0]
                    matched_vol = min(sell_vol, buy["volume"])
                    pnl = (sell_price - buy["price"]) * matched_vol
                    pnls.append(pnl)

                    if pnl > 0:
                        wins.append(pnl)
                    else:
                        losses.append(pnl)

                    # Holding period
                    if hasattr(trade.timestamp, 'date') and hasattr(buy["date"], 'date'):
                        days = (trade.timestamp - buy["date"]).days
                        holding_days.append(max(days, 0))

                    buy["volume"] -= matched_vol
                    sell_vol -= matched_vol

                    if buy["volume"] <= 0:
                        buys.pop(0)

        # Consecutive wins/losses
        max_cons_w = max_cons_l = curr_w = curr_l = 0
        for pnl in pnls:
            if pnl > 0:
                curr_w += 1
                curr_l = 0
                max_cons_w = max(max_cons_w, curr_w)
            else:
                curr_l += 1
                curr_w = 0
                max_cons_l = max(max_cons_l, curr_l)

        n_win = len(wins)
        n_loss = len(losses)
        n_total = n_win + n_loss
        avg_w = np.mean(wins) if wins else 0
        avg_l = np.mean(losses) if losses else 0
        wr = n_win / n_total if n_total > 0 else 0

        return TradeAnalysis(
            total_trades=n_total,
            winning_trades=n_win,
            losing_trades=n_loss,
            win_rate=wr,
            avg_win=avg_w,
            avg_loss=avg_l,
            profit_loss_ratio=abs(avg_w / avg_l) if avg_l != 0 else float("inf"),
            avg_holding_days=np.mean(holding_days) if holding_days else 0,
            max_consecutive_wins=max_cons_w,
            max_consecutive_losses=max_cons_l,
            largest_win=max(pnls) if pnls else 0,
            largest_loss=min(pnls) if pnls else 0,
            total_commission=total_comm,
            total_slippage=total_slip,
            expectancy=wr * avg_w - (1 - wr) * abs(avg_l),
        )

    # ─── Monte Carlo Simulation ─────────────────────────────────────

    def monte_carlo(
        self,
        n_simulations: int = 1000,
        n_days: int = 252,
        confidence_levels: List[float] = None,
    ) -> Dict[str, Any]:
        """Monte Carlo simulation for robustness testing.

        Randomly resamples historical returns to project future paths.

        Args:
            n_simulations: Number of simulation paths.
            n_days: Number of days to project.
            confidence_levels: Percentiles to report.

        Returns:
            Dict with simulation statistics.
        """
        if self._returns.empty or len(self._returns) < 20:
            return {"error": "Insufficient data for Monte Carlo"}

        if confidence_levels is None:
            confidence_levels = [5, 25, 50, 75, 95]

        returns = self._returns.values
        last_equity = self._equity["total_assets"].iloc[-1]

        # Generate paths by resampling returns with replacement
        np.random.seed(42)
        simulated_returns = np.random.choice(returns, size=(n_simulations, n_days))

        # Build equity paths
        cumulative = np.cumprod(1 + simulated_returns, axis=1)
        equity_paths = last_equity * cumulative

        # Final values
        final_values = equity_paths[:, -1]
        final_returns = (final_values - self._initial) / self._initial

        # Max drawdown per path
        max_dds = []
        for path in equity_paths:
            peak = np.maximum.accumulate(path)
            dd = (path - peak) / peak
            max_dds.append(abs(dd.min()))

        # Percentile paths
        percentiles = {}
        for pct in confidence_levels:
            percentiles[f"p{pct}"] = np.percentile(final_returns, pct)

        return {
            "n_simulations": n_simulations,
            "n_days": n_days,
            "median_return": float(np.median(final_returns)),
            "mean_return": float(np.mean(final_returns)),
            "std_return": float(np.std(final_returns)),
            "prob_positive": float(np.mean(final_returns > 0)),
            "prob_loss_10pct": float(np.mean(final_returns < -0.10)),
            "prob_loss_20pct": float(np.mean(final_returns < -0.20)),
            "median_max_drawdown": float(np.median(max_dds)),
            "worst_max_drawdown": float(np.max(max_dds)),
            "percentiles": percentiles,
            "final_values_mean": float(np.mean(final_values)),
            "final_values_median": float(np.median(final_values)),
        }

    # ─── Monthly Returns ────────────────────────────────────────────

    def monthly_returns(self) -> pd.DataFrame:
        if "total_assets" not in self._equity.columns:
            return pd.DataFrame()
        monthly = self._equity["total_assets"].resample("ME").last()
        returns = monthly.pct_change().dropna()
        result = pd.DataFrame({
            "year": returns.index.year,
            "month": returns.index.month,
            "return": returns.values,
        })
        return result.pivot(index="year", columns="month", values="return")

    # ─── Summary ────────────────────────────────────────────────────

    def summary_text(self, trades: Optional[list] = None) -> str:
        m = self.calculate_all()

        trade_section = ""
        if trades:
            ta = self.analyze_trades(trades)
            trade_section = f"""
╠══════════════════════════════════════════╣
║ 交易级别分析
╠══════════════════════════════════════════╣
║ 总交易笔数:       {ta.total_trades:>10d}
║ 盈利笔数:         {ta.winning_trades:>10d}
║ 亏损笔数:         {ta.losing_trades:>10d}
║ 胜率(交易级):     {ta.win_rate:>10.2%}
║ 平均盈利:         ¥{ta.avg_win:>10,.2f}
║ 平均亏损:         ¥{ta.avg_loss:>10,.2f}
║ 盈亏比(交易级):   {ta.profit_loss_ratio:>10.4f}
║ 期望值:           ¥{ta.expectancy:>10,.2f}
║ 最大连续盈利:     {ta.max_consecutive_wins:>10d}
║ 最大连续亏损:     {ta.max_consecutive_losses:>10d}
║ 平均持仓天数:     {ta.avg_holding_days:>10.1f}
║ 最大单笔盈利:     ¥{ta.largest_win:>10,.2f}
║ 最大单笔亏损:     ¥{ta.largest_loss:>10,.2f}
║ 总佣金:           ¥{ta.total_commission:>10,.2f}
║ 总滑点:           ¥{ta.total_slippage:>10,.2f}"""

        return f"""
╔══════════════════════════════════════════╗
║         策略绩效分析报告 v2              ║
╠══════════════════════════════════════════╣
║ 收益指标
╠══════════════════════════════════════════╣
║ 总收益率:         {m['total_return']:>10.2%}
║ 年化收益率:       {m['annualized_return']:>10.2%}
╠══════════════════════════════════════════╣
║ 风险指标
╠══════════════════════════════════════════╣
║ 最大回撤:         {m['max_drawdown']:>10.2%}
║ 最大回撤持续天数: {m['max_drawdown_duration']:>10d}
║ 年化波动率:       {m['volatility']:>10.4f}
║ 下行偏差:         {m['downside_deviation']:>10.4f}
║ VaR(95%):         {m['var_95']:>10.4f}
║ CVaR(95%):        {m['cvar_95']:>10.4f}
║ VaR(99%):         {m['var_99']:>10.4f}
║ 尾部比率:         {m['tail_ratio']:>10.4f}
╠══════════════════════════════════════════╣
║ 风险调整指标
╠══════════════════════════════════════════╣
║ 夏普比率:         {m['sharpe_ratio']:>10.4f}
║ 索提诺比率:       {m['sortino_ratio']:>10.4f}
║ 卡玛比率:         {m['calmar_ratio']:>10.4f}
║ 胜率(日级):       {m['win_rate']:>10.2%}
║ 盈亏比(日级):     {m['profit_loss_ratio']:>10.4f}
╠══════════════════════════════════════════╣
║ 交易天数:         {m['trading_days']:>10d}{trade_section}
╚══════════════════════════════════════════╝
"""
