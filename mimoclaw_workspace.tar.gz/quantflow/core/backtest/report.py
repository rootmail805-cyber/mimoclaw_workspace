"""
Report generator v2 for QuantFlow.
Enhanced with Monte Carlo results, trade-level analytics, benchmark comparison.
"""

import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
import pandas as pd
from loguru import logger

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False


class ReportGenerator:
    """Generate comprehensive backtest reports."""

    def __init__(self, output_dir: str = "./reports"):
        self._output_dir = Path(output_dir)
        self._output_dir.mkdir(parents=True, exist_ok=True)

    def generate(self, results: Dict[str, Any], format: str = "html") -> str:
        if format == "html":
            return self._generate_html(results)
        else:
            return self._generate_text(results)

    def _generate_html(self, results: Dict[str, Any]) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        symbol = results.get("symbol", "unknown")
        filename = f"backtest_{symbol}_{timestamp}.html"
        filepath = self._output_dir / filename

        metrics = results.get("metrics", {})
        equity_curve = results.get("equity_curve", pd.DataFrame())
        trades = results.get("trades", [])
        benchmark = results.get("benchmark_metrics")

        # Charts
        chart_html = ""
        if HAS_MATPLOTLIB and not equity_curve.empty:
            chart_path = self._equity_chart(equity_curve, symbol, timestamp)
            if chart_path:
                chart_html = f'<img src="{chart_path}" style="max-width:100%;" />'

        # Trade-level analysis
        from .performance import PerformanceAnalyzer
        final_acct = results.get("final_account")
        total_assets = getattr(final_acct, "total_assets", 1_000_000) if final_acct else 1_000_000
        analyzer = PerformanceAnalyzer(equity_curve, total_assets)
        trade_analysis = analyzer.analyze_trades(trades) if trades else None

        trade_section = ""
        if trade_analysis:
            ta = trade_analysis
            trade_section = f"""
    <div class="card">
        <h2>📋 交易级别分析</h2>
        <div class="metrics">
            <div class="metric"><div class="value">{ta.total_trades}</div><div class="label">总交易笔数</div></div>
            <div class="metric"><div class="value positive">{ta.winning_trades}</div><div class="label">盈利笔数</div></div>
            <div class="metric"><div class="value negative">{ta.losing_trades}</div><div class="label">亏损笔数</div></div>
            <div class="metric"><div class="value">{ta.win_rate:.2%}</div><div class="label">胜率(交易级)</div></div>
            <div class="metric"><div class="value">¥{ta.avg_win:,.0f}</div><div class="label">平均盈利</div></div>
            <div class="metric"><div class="value">¥{ta.avg_loss:,.0f}</div><div class="label">平均亏损</div></div>
            <div class="metric"><div class="value">{ta.profit_loss_ratio:.2f}</div><div class="label">盈亏比</div></div>
            <div class="metric"><div class="value">¥{ta.expectancy:,.0f}</div><div class="label">期望值</div></div>
            <div class="metric"><div class="value">{ta.max_consecutive_wins}</div><div class="label">最大连胜</div></div>
            <div class="metric"><div class="value">{ta.max_consecutive_losses}</div><div class="label">最大连亏</div></div>
            <div class="metric"><div class="value">{ta.avg_holding_days:.1f}天</div><div class="label">平均持仓周期</div></div>
            <div class="metric"><div class="value">¥{ta.total_commission:,.0f}</div><div class="label">总佣金</div></div>
        </div>
    </div>"""

        # Benchmark section
        benchmark_section = ""
        if benchmark:
            benchmark_section = f"""
    <div class="card">
        <h2>📊 基准对比</h2>
        <div class="metrics">
            <div class="metric"><div class="value">{benchmark.get('alpha', 0):.4f}</div><div class="label">Alpha (年化)</div></div>
            <div class="metric"><div class="value">{benchmark.get('beta', 0):.4f}</div><div class="label">Beta</div></div>
            <div class="metric"><div class="value">{benchmark.get('information_ratio', 0):.4f}</div><div class="label">信息比率</div></div>
            <div class="metric"><div class="value">{benchmark.get('correlation', 0):.4f}</div><div class="label">相关系数</div></div>
            <div class="metric"><div class="value">{benchmark.get('benchmark_return', 0):.2%}</div><div class="label">基准收益</div></div>
            <div class="metric"><div class="value {'positive' if benchmark.get('excess_return',0)>=0 else 'negative'}">{benchmark.get('excess_return', 0):.2%}</div><div class="label">超额收益</div></div>
        </div>
    </div>"""

        # Monte Carlo section (placeholder — run separately)
        mc_section = ""

        # VaR section
        var_section = f"""
    <div class="card">
        <h2>⚠️ 风险指标 (VaR/CVaR)</h2>
        <div class="metrics">
            <div class="metric"><div class="value negative">{metrics.get('var_95', 0):.4f}</div><div class="label">VaR (95%, 日)</div></div>
            <div class="metric"><div class="value negative">{metrics.get('cvar_95', 0):.4f}</div><div class="label">CVaR (95%, 日)</div></div>
            <div class="metric"><div class="value negative">{metrics.get('var_99', 0):.4f}</div><div class="label">VaR (99%, 日)</div></div>
            <div class="metric"><div class="value">{metrics.get('tail_ratio', 0):.4f}</div><div class="label">尾部比率</div></div>
        </div>
    </div>"""

        # Trade table
        trade_rows = ""
        for t in trades[:200]:
            ts = t.timestamp.strftime('%Y-%m-%d %H:%M') if hasattr(t.timestamp, 'strftime') else t.timestamp
            side_class = 'buy' if t.side.value == 'BUY' else 'sell'
            trade_rows += f"""
            <tr>
                <td>{ts}</td><td>{t.symbol}</td>
                <td class="{side_class}">{t.side.value}</td>
                <td>{t.price:.3f}</td><td>{t.volume}</td>
                <td>{t.commission:.2f}</td><td>{t.slippage:.2f}</td>
            </tr>"""

        html = f"""<!DOCTYPE html>
<html><head>
    <meta charset="utf-8">
    <title>QuantFlow 回测报告 - {symbol}</title>
    <style>
        body {{ font-family: -apple-system, "Microsoft YaHei", sans-serif; margin: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        .header {{ background: linear-gradient(135deg, #1a1a2e, #16213e); color: white; padding: 30px; border-radius: 10px; margin-bottom: 20px; }}
        .header h1 {{ margin: 0; }}
        .card {{ background: white; border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }}
        .card h2 {{ margin-top: 0; color: #1a1a2e; border-bottom: 2px solid #e0e0e0; padding-bottom: 10px; }}
        .metrics {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; }}
        .metric {{ text-align: center; padding: 12px; background: #f8f9fa; border-radius: 8px; }}
        .metric .value {{ font-size: 22px; font-weight: bold; color: #1a1a2e; }}
        .metric .label {{ font-size: 11px; color: #666; margin-top: 4px; }}
        .positive {{ color: #e74c3c !important; }}
        .negative {{ color: #27ae60 !important; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{ padding: 6px 10px; text-align: left; border-bottom: 1px solid #eee; font-size: 13px; }}
        th {{ background: #f8f9fa; }}
        .buy {{ color: #e74c3c; font-weight: bold; }}
        .sell {{ color: #27ae60; font-weight: bold; }}
    </style>
</head><body>
<div class="container">
    <div class="header">
        <h1>📊 QuantFlow 回测报告 v2</h1>
        <p>{symbol} | {results.get('period', '')} | {results.get('total_bars', 0)} bars | {results.get('elapsed_seconds', 0):.2f}s</p>
    </div>

    <div class="card"><h2>📈 权益曲线</h2>{chart_html}</div>

    <div class="card">
        <h2>📊 核心指标</h2>
        <div class="metrics">
            <div class="metric"><div class="value {'positive' if metrics.get('total_return',0)>=0 else 'negative'}">{metrics.get('total_return',0):.2%}</div><div class="label">总收益率</div></div>
            <div class="metric"><div class="value">{metrics.get('annualized_return',0):.2%}</div><div class="label">年化收益率</div></div>
            <div class="metric"><div class="value negative">{metrics.get('max_drawdown',0):.2%}</div><div class="label">最大回撤</div></div>
            <div class="metric"><div class="value">{metrics.get('sharpe_ratio',0):.4f}</div><div class="label">夏普比率</div></div>
            <div class="metric"><div class="value">{metrics.get('sortino_ratio',0):.4f}</div><div class="label">索提诺比率</div></div>
            <div class="metric"><div class="value">{metrics.get('calmar_ratio',0):.4f}</div><div class="label">卡玛比率</div></div>
            <div class="metric"><div class="value">{metrics.get('win_rate',0):.2%}</div><div class="label">胜率(日)</div></div>
            <div class="metric"><div class="value">{metrics.get('volatility',0):.4f}</div><div class="label">年化波动率</div></div>
            <div class="metric"><div class="value">{metrics.get('max_drawdown_duration',0)}</div><div class="label">最大回撤天数</div></div>
        </div>
    </div>

    {var_section}
    {benchmark_section}
    {trade_section}

    <div class="card">
        <h2>📋 交易明细 (前200笔)</h2>
        <table>
            <thead><tr><th>时间</th><th>标的</th><th>方向</th><th>价格</th><th>数量</th><th>佣金</th><th>滑点</th></tr></thead>
            <tbody>{trade_rows}</tbody>
        </table>
    </div>

    <div class="card" style="text-align:center; color:#999; font-size:12px;">
        Generated by QuantFlow v2.0.0 | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
    </div>
</div></body></html>"""

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html)

        logger.info(f"HTML report: {filepath}")
        return str(filepath)

    def _generate_text(self, results: Dict[str, Any]) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        symbol = results.get("symbol", "unknown")
        filepath = self._output_dir / f"backtest_{symbol}_{timestamp}.txt"

        final_acct = results.get("final_account")
        total_assets = getattr(final_acct, "total_assets", 1_000_000) if final_acct else 1_000_000
        analyzer = PerformanceAnalyzer(
            results.get("equity_curve", pd.DataFrame()),
            total_assets,
        )
        text = analyzer.summary_text(results.get("trades"))

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(text)

        logger.info(f"Text report: {filepath}")
        return str(filepath)

    def _equity_chart(self, equity_df: pd.DataFrame, symbol: str, timestamp: str) -> Optional[str]:
        try:
            fig, axes = plt.subplots(2, 1, figsize=(14, 8), gridspec_kw={"height_ratios": [3, 1]})
            fig.suptitle(f"QuantFlow Backtest - {symbol}", fontsize=14)

            ax1 = axes[0]
            ax1.plot(equity_df.index, equity_df["total_assets"], color="#1a73e8", linewidth=1.5)
            initial = equity_df["total_assets"].iloc[0]
            ax1.axhline(y=initial, color="gray", linestyle="--", alpha=0.5)
            ax1.set_ylabel("Total Assets (¥)")
            ax1.grid(True, alpha=0.3)

            ax2 = axes[1]
            peak = equity_df["total_assets"].expanding().max()
            dd = (equity_df["total_assets"] - peak) / peak * 100
            ax2.fill_between(equity_df.index, 0, dd, color="#e74c3c", alpha=0.4)
            ax2.set_ylabel("Drawdown (%)")
            ax2.grid(True, alpha=0.3)

            plt.tight_layout()
            chart_file = f"chart_{symbol}_{timestamp}.png"
            chart_path = self._output_dir / chart_file
            plt.savefig(chart_path, dpi=100, bbox_inches="tight")
            plt.close()
            return chart_file
        except Exception as e:
            logger.error(f"Chart failed: {e}")
            return None
