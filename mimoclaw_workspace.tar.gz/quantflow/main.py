"""
QuantFlow V2.0 — A股量化交易系统
主入口文件

Usage:
    python main.py              # 启动 GUI
    python main.py --cli        # 命令行模式
    python main.py backtest     # 直接运行回测
"""

import sys
import os
from pathlib import Path

# Ensure project root is in path
APP_DIR = Path(__file__).parent
sys.path.insert(0, str(APP_DIR))


def main():
    """Main entry point."""
    import argparse
    parser = argparse.ArgumentParser(description="QuantFlow V2.0 A股量化交易系统")
    parser.add_argument("--cli", action="store_true", help="命令行模式")
    parser.add_argument("command", nargs="?", choices=["backtest", "recommend", "health"],
                        help="直接执行命令")
    parser.add_argument("-s", "--symbol", help="股票代码")
    parser.add_argument("--strategy", default="dual_ma", help="策略名称")
    parser.add_argument("--start", help="开始日期")
    parser.add_argument("--end", help="结束日期")

    args = parser.parse_args()

    if args.command == "health":
        run_health_check()
        return

    if args.command == "backtest":
        run_backtest(args)
        return

    # Default: launch GUI
    try:
        from gui_v2 import QuantFlowApp
        app = QuantFlowApp()
        app.run()
    except ImportError as e:
        print(f"[!] 无法加载 GUI: {e}")
        print("    请确保 tkinter 已安装: pip install tk")
        sys.exit(1)


def run_backtest(args):
    """Run a backtest from command line."""
    from datetime import datetime, timedelta
    from config.manager import get_config
    from core.data.data_manager import DataManager
    from core.backtest.engine import BacktestEngine
    from core.backtest.report import ReportGenerator

    config = get_config()
    symbol = args.symbol or "600000.SH"
    start = args.start or (datetime.now() - timedelta(days=365 * 3)).strftime("%Y-%m-%d")
    end = args.end or datetime.now().strftime("%Y-%m-%d")

    print(f"QuantFlow V2.0 — 回测模式")
    print(f"股票: {symbol} | 策略: {args.strategy} | 区间: {start} ~ {end}")
    print()

    data_mgr = DataManager(config)
    print("[*] 获取历史数据...")
    data = data_mgr.get_history(symbol, start, end, freq="daily")

    if data is None or data.empty:
        print(f"[!] 无法获取 {symbol} 的数据")
        return

    print(f"[+] 获取 {len(data)} 根K线")

    # Import strategy
    strategy_map = {
        "dual_ma": "strategies.dual_ma.DualMAStrategy",
        "macd": "strategies.macd_strategy.MACDStrategy",
        "bollinger": "strategies.bollinger_strategy.BollingerStrategy",
        "rsi": "strategies.rsi_strategy.RSIStrategy",
        "kdj": "strategies.kdj_strategy.KDJStrategy",
    }

    strategy_path = strategy_map.get(args.strategy, strategy_map["dual_ma"])
    module_path, class_name = strategy_path.rsplit(".", 1)

    import importlib
    mod = importlib.import_module(module_path)
    strategy_cls = getattr(mod, class_name)
    strategy = strategy_cls(strategy_id=f"{args.strategy}_{symbol}")

    # Run backtest
    engine = BacktestEngine(config)
    results = engine.run(strategy, data)

    # Generate report
    reporter = ReportGenerator(config)
    report_path = reporter.generate(results, format="html")
    print(f"[+] 报告已生成: {report_path}")

    # Print summary
    print()
    print("═══ 回测结果 ═══")
    for key, value in results.items():
        if isinstance(value, float):
            print(f"  {key}: {value:.4f}")
        elif not isinstance(value, (list, dict)):
            print(f"  {key}: {value}")


def run_health_check():
    """Run system health check."""
    print("QuantFlow V2.0 — 系统健康检查")
    print("=" * 50)

    # Check Python
    print(f"Python: {sys.version}")

    # Check akshare
    try:
        import akshare as ak
        print(f"[OK] akshare {ak.__version__}")
    except ImportError:
        print("[FAIL] akshare 未安装")

    # Check database
    try:
        from core.db import get_db
        db = get_db()
        print("[OK] 数据库已初始化")
    except Exception as e:
        print(f"[FAIL] 数据库: {e}")

    # Check config
    try:
        from config.manager import get_config
        config = get_config()
        print("[OK] 配置已加载")
    except Exception as e:
        print(f"[FAIL] 配置: {e}")

    print()
    print("健康检查完成")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        import traceback
        print(f"\n[FATAL] {type(e).__name__}: {e}")
        traceback.print_exc()
        input("\nPress Enter to exit...")
