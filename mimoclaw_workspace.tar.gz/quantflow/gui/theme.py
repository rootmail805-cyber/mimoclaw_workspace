"""
QuantFlow V2.0 — UI主题系统（科技风单主题，极致优化）
深色科技风格：高对比度、清晰锐利、现代感、专业量化氛围
"""

# ── 主题定义 ──────────────────────────────────────────────────────

THEMES = {
    "tech_dark": {
        "name": "科技深色",
        "description": "深邃科技风，高对比度，专业量化",
        # ── 背景色系（从深到浅） ──
        "bg":           "#05080e",      # 最深：主背景
        "bg_panel":     "#0a0f18",      # 面板背景
        "bg_card":      "#0f1520",      # 卡片背景
        "bg_input":     "#141c28",      # 输入框背景
        "bg_hover":     "#1a2435",      # 悬停态
        "border":       "#1e2d42",      # 边框
        # ── 强调色系 ──
        "accent":       "#00e87b",      # 主强调：科技绿
        "accent_dim":   "#00b860",      # 暗绿
        "cyan":         "#00d4ff",      # 信息蓝
        "cyan_dim":     "#0099cc",      # 暗蓝
        "orange":       "#ffaa00",      # 警告橙
        "red":          "#ff3b5c",      # 危险红
        "red_dim":      "#cc2244",      # 暗红
        "yellow":       "#ffd000",      # 提示黄
        "green":        "#00e87b",      # 盈利绿
        # ── 文字色系（增强对比度） ──
        "text":         "#e0e8f0",      # 主文字：高亮白
        "text_bright":  "#ffffff",      # 最亮：标题/关键数字
        "text_dim":     "#8899aa",      # 次要文字
        "text_muted":   "#4a5a6a",      # 最暗：辅助信息
        # ── 字体 ──
        "font_family":  "Consolas",
        "font_family_ui": "Segoe UI",   # UI元素字体
        "font_size_title": 16,
        "font_size_heading": 13,
        "font_size_body": 11,
        "font_size_small": 9,
        "font_size_big_num": 36,
        "font_size_medium_num": 20,
    },
}

DEFAULT_THEME = "tech_dark"


def get_theme(name: str = None) -> dict:
    """获取主题配置"""
    if name is None:
        name = DEFAULT_THEME
    return THEMES.get(name, THEMES[DEFAULT_THEME])


def list_themes() -> list:
    """列出所有可用主题 [(id, name, description)]"""
    return [(tid, t["name"], t["description"]) for tid, t in THEMES.items()]
