"""
Configuration Manager for QuantFlow.
Loads settings from YAML + environment variables with proper precedence.
"""

import os
import yaml
import threading
from pathlib import Path
from typing import Any, Optional
from copy import deepcopy
from dotenv import load_dotenv

# Load .env file if present
load_dotenv()

_CONFIG_INSTANCE: Optional["ConfigManager"] = None
_CONFIG_LOCK = threading.Lock()


class ConfigManager:
    """Hierarchical configuration manager with env-var overrides."""

    def __init__(self, config_path: Optional[str] = None):
        if config_path is None:
            config_path = Path(__file__).parent / "settings.yaml"
        self._path = Path(config_path)
        self._data: dict = {}
        self._load()

    def _load(self) -> None:
        """Load YAML config and apply environment variable overrides."""
        with open(self._path, "r", encoding="utf-8") as f:
            self._data = yaml.safe_load(f) or {}
        self._apply_env_overrides()

    def _apply_env_overrides(self) -> None:
        """Override config values with environment variables.

        Mapping convention:
            data.sources.realtime.api_key  ->  QUANT_DATA_API_KEY
            data.storage.timeseries.token  ->  QUANT_INFLUX_TOKEN
            risk.kill_switch.enabled       ->  QUANT_RISK_KILL_SWITCH_ENABLED
        """
        env_mapping = {
            "QUANT_DATA_API_KEY": "data.sources.realtime.api_key",
            "QUANT_TUSHARE_TOKEN": "data.sources.history.tushare_token",
            "QUANT_INFLUX_TOKEN": "data.storage.timeseries.token",
            "QUANT_DINGTALK_WEBHOOK": "monitor.alerts.dingtalk.webhook_url",
            "QUANT_EMAIL_PASSWORD": "monitor.alerts.email.password",
            "QUANT_DB_URL": "data.storage.relational.url",
            "QUANT_LOG_LEVEL": "system.log_level",
        }
        for env_var, config_path in env_mapping.items():
            value = os.environ.get(env_var)
            if value is not None:
                self._set_nested(config_path, value)

    def _set_nested(self, dot_path: str, value: Any) -> None:
        """Set a nested dict value using dot notation."""
        keys = dot_path.split(".")
        d = self._data
        for key in keys[:-1]:
            d = d.setdefault(key, {})
        d[keys[-1]] = value

    def get(self, dot_path: str, default: Any = None) -> Any:
        """Get config value by dot-notation path.

        Examples:
            config.get("system.log_level")
            config.get("risk.pre_trade.max_single_position_pct")
        """
        keys = dot_path.split(".")
        d = self._data
        for key in keys:
            if isinstance(d, dict) and key in d:
                d = d[key]
            else:
                return default
        return deepcopy(d) if isinstance(d, (dict, list)) else d

    def set(self, dot_path: str, value: Any) -> None:
        """Set config value by dot-notation path (runtime override)."""
        self._set_nested(dot_path, value)

    def reload(self) -> None:
        """Reload configuration from disk."""
        self._load()

    @property
    def data(self) -> dict:
        return deepcopy(self._data)

    def __repr__(self) -> str:
        env = self._data.get("system", {}).get("env", "unknown")
        return f"<ConfigManager env={env} path={self._path}>"


def get_config(config_path: Optional[str] = None) -> ConfigManager:
    """Get or create the global config singleton (thread-safe)."""
    global _CONFIG_INSTANCE
    if _CONFIG_INSTANCE is None:
        with _CONFIG_LOCK:
            if _CONFIG_INSTANCE is None:
                _CONFIG_INSTANCE = ConfigManager(config_path)
    return _CONFIG_INSTANCE
