"""
Comprehensive test suite for QuantFlow v2.
Covers: broker, backtest engine, performance, indicators, position sizing, risk.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

from core.models import Bar, Signal, SignalAction, OrderSide, OrderType, Position, AccountInfo
from core.backtest.broker import SimulatedBroker
from core.backtest.performance import PerformanceAnalyzer
from core.strategy.base import BaseStrategy
from core.strategy.registry import StrategyRegistry
from core.strategy import indicators as ind
from core.strategy.position_sizing import FixedFractionSizer, FixedRiskSizer, ATRSizer, KellySizer


# ─── Test Data ─────────────────────────────────────────────────────

def generate_test_data(days: int = 500, start_price: float = 10.0, volatility: float = 0.02) -> pd.DataFrame:
    np.random.seed(42)
    dates = pd.date_range(start="2022-01-01", periods=days, freq="B")
    prices = [start_price]
    for _ in range(days - 1):
        prices.append(prices[-1] * (1 + np.random.normal(0, volatility)))
    prices = np.array(prices)
    df = pd.DataFrame({
        "open": prices * (1 + np.random.normal(0, 0.005, days)),
        "high": prices * (1 + np.abs(np.random.normal(0, 0.01, days))),
        "low": prices * (1 - np.abs(np.random.normal(0, 0.01, days))),
        "close": prices,
        "volume": np.random.randint(100000, 10000000, days),
        "turnover": prices * np.random.randint(100000, 10000000, days),
    }, index=dates)
    return df


# ─── Broker Tests ──────────────────────────────────────────────────

class TestSimulatedBroker:

    def test_initial_state(self):
        broker = SimulatedBroker(initial_capital=100000)
        account = broker.get_account()
        assert account.total_assets == 100000
        assert account.cash == 100000

    def test_market_order_queued(self):
        broker = SimulatedBroker()
        order = broker.submit_order("TEST.SH", OrderSide.BUY, OrderType.MARKET, 100)
        assert order is not None
        assert order.status.value == "SUBMITTED"
        assert len(broker.pending_orders) == 1

    def test_market_order_fill_next_bar(self):
        broker = SimulatedBroker(initial_capital=100000)
        bar1 = Bar(symbol="TEST.SH", open=10, high=10.5, low=9.5, close=10,
                   volume=1000000, turnover=10000000, timestamp=datetime(2024, 1, 2))

        order = broker.submit_order("TEST.SH", OrderSide.BUY, OrderType.MARKET, 100)
        trades = broker.on_bar(bar1)  # Executes pending orders
        assert len(trades) == 1
        assert trades[0].side == OrderSide.BUY

    def test_t_plus_1_enforcement(self):
        broker = SimulatedBroker(initial_capital=100000, enforce_t_plus_1=True)
        bar1 = Bar(symbol="TEST.SH", open=10, high=10, low=10, close=10,
                   volume=1000000, turnover=10000000, timestamp=datetime(2024, 1, 2))
        bar2 = Bar(symbol="TEST.SH", open=10, high=10, low=10, close=10,
                   volume=1000000, turnover=10000000, timestamp=datetime(2024, 1, 3))

        # Buy on day 1
        broker.submit_order("TEST.SH", OrderSide.BUY, OrderType.MARKET, 100)
        broker.on_bar(bar1)

        # Try to sell on day 1 — should fail (T+1)
        pos = broker.positions.get("TEST.SH")
        assert pos is not None
        assert pos.available_volume == 0  # Not available until next day

        # On day 2 — should become available
        broker.on_bar(bar2)
        # Now available_volume should be updated via _finalize_t1
        # (happens when date changes)

    def test_sell_without_position_rejected(self):
        broker = SimulatedBroker(initial_capital=100000)
        order = broker.submit_order("TEST.SH", OrderSide.SELL, OrderType.MARKET, 100)
        assert order is None

    def test_insufficient_cash_rejected(self):
        broker = SimulatedBroker(initial_capital=1000)
        order = broker.submit_order("TEST.SH", OrderSide.BUY, OrderType.LIMIT, 1000, price=10.0)
        assert order is None

    def test_commission_deduction(self):
        broker = SimulatedBroker(initial_capital=100000, min_commission=5.0)
        bar = Bar(symbol="T.SH", open=10, high=10, low=10, close=10,
                  volume=1000000, turnover=10000000, timestamp=datetime(2024, 1, 2))
        broker.submit_order("T.SH", OrderSide.BUY, OrderType.LIMIT, 100, price=10.0)
        broker.on_bar(bar)
        assert broker.total_commission >= 5.0

    def test_emergency_sell_all(self):
        broker = SimulatedBroker(initial_capital=100000, enforce_t_plus_1=False)
        bar = Bar(symbol="T.SH", open=10, high=10, low=10, close=10,
                  volume=1000000, turnover=10000000, timestamp=datetime(2024, 1, 2))
        broker.submit_order("T.SH", OrderSide.BUY, OrderType.MARKET, 100)
        broker.on_bar(bar)

        assert broker.positions.get("T.SH") is not None
        trades = broker.emergency_sell_all(bar)
        # Position should be sold
        pos = broker.positions.get("T.SH")
        assert pos is None or pos.volume == 0


# ─── Indicator Tests ───────────────────────────────────────────────

class TestIndicators:

    def test_sma(self):
        data = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], dtype=float)
        result = ind.sma(data, 3)
        assert np.isnan(result[0])
        assert np.isnan(result[1])
        assert abs(result[2] - 2.0) < 1e-10
        assert abs(result[9] - 9.0) < 1e-10

    def test_ema(self):
        data = np.arange(1, 21, dtype=float)
        result = ind.ema(data, 5)
        assert len(result) == len(data)
        assert result[0] == data[0]
        # EMA should track the trend
        assert result[-1] > result[0]

    def test_rsi(self):
        # Uptrend should give RSI > 50
        up = np.arange(10, 30, dtype=float)
        rsi_up = ind.rsi(up, 14)
        assert rsi_up[-1] > 50

        # Downtrend should give RSI < 50
        down = np.arange(30, 10, -1, dtype=float)
        rsi_down = ind.rsi(down, 14)
        assert rsi_down[-1] < 50

    def test_macd(self):
        data = np.arange(1, 51, dtype=float)
        macd_line, signal_line, histogram = ind.macd(data, 12, 26, 9)
        assert len(macd_line) == len(data)
        assert len(signal_line) == len(data)
        assert len(histogram) == len(data)

    def test_bollinger_bands(self):
        data = np.random.normal(100, 5, 100)
        upper, middle, lower = ind.bollinger_bands(data, 20, 2.0)
        # Upper > middle > lower for valid data
        valid = ~np.isnan(upper)
        assert np.all(upper[valid] >= middle[valid])
        assert np.all(middle[valid] >= lower[valid])

    def test_atr(self):
        high = np.array([12, 13, 14, 13, 15, 14, 16, 15, 14, 13], dtype=float)
        low = np.array([10, 11, 12, 11, 13, 12, 14, 13, 12, 11], dtype=float)
        close = np.array([11, 12, 13, 12, 14, 13, 15, 14, 13, 12], dtype=float)
        atr_vals = ind.atr(high, low, close, 5)
        assert len(atr_vals) == len(close)
        assert atr_vals[-1] > 0

    def test_kdj(self):
        high = np.random.uniform(10, 15, 50)
        low = high - np.random.uniform(1, 3, 50)
        close = (high + low) / 2
        k, d, j = ind.kdj(high, low, close, 9, 3, 3)
        assert len(k) == 50
        assert len(d) == 50
        assert len(j) == 50


# ─── Position Sizing Tests ─────────────────────────────────────────

class TestPositionSizing:

    def test_fixed_fraction(self):
        sizer = FixedFractionSizer(fraction=0.10)
        size = sizer.calculate_size(100000, 10.0)
        assert size == 1000  # 100000 * 0.10 / 10.0 = 1000

    def test_fixed_fraction_rounds_to_lot(self):
        sizer = FixedFractionSizer(fraction=0.10)
        size = sizer.calculate_size(100000, 13.0)
        assert size % 100 == 0

    def test_fixed_risk(self):
        sizer = FixedRiskSizer(risk_pct=0.02)
        size = sizer.calculate_size(100000, 10.0, stop_loss_price=9.0)
        # risk = 100000 * 0.02 = 2000
        # risk per share = 10 - 9 = 1
        # shares = 2000 / 1 = 2000
        assert size == 2000

    def test_atr_sizer(self):
        sizer = ATRSizer(risk_pct=0.02, atr_multiplier=2.0)
        size = sizer.calculate_size(100000, 10.0, atr_value=0.5)
        # risk = 2000, risk per share = 0.5 * 2 = 1.0
        assert size == 2000

    def test_kelly_sizer(self):
        sizer = KellySizer(half_kelly=True)
        size = sizer.calculate_size(
            100000, 10.0,
            win_rate=0.6, avg_win=200, avg_loss=100,
        )
        # kelly = (0.6 * 2 - 0.4) / 2 = 0.4, half = 0.2
        # allocation = 100000 * 0.2 = 20000, shares = 2000
        assert size > 0
        assert size % 100 == 0

    def test_zero_price(self):
        sizer = FixedFractionSizer(fraction=0.10)
        assert sizer.calculate_size(100000, 0) == 0


# ─── Performance Analyzer Tests ────────────────────────────────────

class TestPerformanceAnalyzer:

    def test_metrics(self):
        dates = pd.date_range("2022-01-01", periods=252, freq="B")
        equity = 1000000 * (1 + np.cumsum(np.random.normal(0.0005, 0.01, 252)))
        df = pd.DataFrame({"total_assets": equity}, index=dates)
        analyzer = PerformanceAnalyzer(df, 1000000)
        m = analyzer.calculate_all()

        assert "total_return" in m
        assert "sharpe_ratio" in m
        assert "max_drawdown" in m
        assert "var_95" in m
        assert "cvar_95" in m
        assert "tail_ratio" in m
        assert m["trading_days"] == 252

    def test_var_cvar(self):
        # Known return distribution
        dates = pd.date_range("2022-01-01", periods=1000, freq="B")
        returns = np.random.normal(0.0005, 0.01, 1000)
        equity = 1000000 * np.cumprod(1 + returns)
        df = pd.DataFrame({"total_assets": equity}, index=dates)
        analyzer = PerformanceAnalyzer(df, 1000000)

        var95 = analyzer.var_95()
        cvar95 = analyzer.cvar_95()
        # CVaR should be worse than VaR
        assert cvar95 <= var95

    def test_empty_equity(self):
        df = pd.DataFrame(columns=["total_assets"])
        analyzer = PerformanceAnalyzer(df, 1000000)
        assert analyzer.total_return() == 0.0
        assert analyzer.sharpe_ratio() == 0.0
        assert analyzer.var_95() == 0.0

    def test_monte_carlo(self):
        dates = pd.date_range("2022-01-01", periods=252, freq="B")
        equity = 1000000 * (1 + np.cumsum(np.random.normal(0.0005, 0.01, 252)))
        df = pd.DataFrame({"total_assets": equity}, index=dates)
        analyzer = PerformanceAnalyzer(df, 1000000)

        mc = analyzer.monte_carlo(n_simulations=100, n_days=63)
        assert "median_return" in mc
        assert "prob_positive" in mc
        assert "prob_loss_10pct" in mc
        assert 0 <= mc["prob_positive"] <= 1

    def test_trade_analysis(self):
        from core.models import TradeRecord, OrderSide
        trades = [
            TradeRecord("T1", "O1", "A.SH", OrderSide.BUY, 10.0, 100, 5, datetime(2024, 1, 2)),
            TradeRecord("T2", "O1", "A.SH", OrderSide.SELL, 12.0, 100, 5, datetime(2024, 1, 10)),
            TradeRecord("T3", "O2", "A.SH", OrderSide.BUY, 11.0, 100, 5, datetime(2024, 1, 15)),
            TradeRecord("T4", "O2", "A.SH", OrderSide.SELL, 10.0, 100, 5, datetime(2024, 1, 20)),
        ]
        dates = pd.date_range("2024-01-01", periods=25, freq="B")
        df = pd.DataFrame({"total_assets": np.linspace(100000, 102000, 25)}, index=dates)
        analyzer = PerformanceAnalyzer(df, 100000)
        ta = analyzer.analyze_trades(trades)

        assert ta.total_trades == 2
        assert ta.winning_trades == 1
        assert ta.losing_trades == 1
        assert ta.win_rate == 0.5


# ─── Strategy Registry Tests ───────────────────────────────────────

class TestStrategyRegistry:

    def test_builtin_strategies_registered(self):
        import strategies.dual_ma
        import strategies.bollinger_strategy
        import strategies.rsi_strategy

        registered = StrategyRegistry.list_registered()
        assert "dual_ma" in registered
        assert "bollinger" in registered
        assert "rsi" in registered

    def test_create_strategy(self):
        import strategies.dual_ma
        s = StrategyRegistry.create("dual_ma", "test_1", {"short_window": 10})
        assert s.strategy_id == "test_1"
        assert s.get_param("short_window") == 10


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
