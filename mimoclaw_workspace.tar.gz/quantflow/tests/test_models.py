"""
核心数据模型测试
"""
import pytest
import sys
import os
from datetime import datetime
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.models import Bar, Signal, SignalAction, Position


class TestBar:
    def test_bar_creation(self):
        bar = Bar(symbol="600000.SH", open=10.0, high=10.5, low=9.8, close=10.2,
                  volume=100000, turnover=1020000.0, timestamp=datetime.now())
        assert bar.symbol == "600000.SH"
        assert bar.open == 10.0
        assert bar.high == 10.5
        assert bar.low == 9.8
        assert bar.close == 10.2
        assert bar.volume == 100000

    def test_typical_price(self):
        bar = Bar(symbol="test", open=10.0, high=11.0, low=9.0, close=10.0,
                  volume=1000, turnover=10000.0, timestamp=datetime.now())
        assert bar.typical_price == pytest.approx(10.0)  # (11+9+10)/3

    def test_bar_frequency_default(self):
        bar = Bar(symbol="test", open=1.0, high=1.0, low=1.0, close=1.0,
                  volume=0, turnover=0.0, timestamp=datetime.now())
        assert bar.frequency == "daily"


class TestSignal:
    def test_buy_signal(self):
        sig = Signal(symbol="600000.SH", action=SignalAction.BUY, volume=100, strategy_id="test")
        assert sig.symbol == "600000.SH"
        assert sig.action == SignalAction.BUY
        assert sig.volume == 100

    def test_sell_signal(self):
        sig = Signal(symbol="600000.SH", action=SignalAction.SELL, volume=50, strategy_id="test")
        assert sig.action == SignalAction.SELL

    def test_signal_actions(self):
        assert SignalAction.BUY.value == "BUY"
        assert SignalAction.SELL.value == "SELL"
        assert SignalAction.HOLD.value == "HOLD"
        assert SignalAction.CLOSE.value == "CLOSE"


class TestPosition:
    def test_position_defaults(self):
        pos = Position(symbol="600000.SH")
        assert pos.symbol == "600000.SH"
        assert pos.volume == 0
        assert pos.avg_cost == 0.0
        assert pos.available_volume == 0

    def test_market_value(self):
        pos = Position(symbol="600000.SH", volume=100, avg_cost=10.0, current_price=11.0)
        assert pos.market_value == 1100.0

    def test_cost_basis(self):
        pos = Position(symbol="600000.SH", volume=100, avg_cost=10.0, current_price=11.0)
        assert pos.cost_basis == 1000.0

    def test_position_with_strategy(self):
        pos = Position(symbol="600000.SH", volume=100, strategy_id="dual_ma")
        assert pos.strategy_id == "dual_ma"

    def test_t1_fields(self):
        pos = Position(symbol="600000.SH", volume=100, available_volume=50,
                       today_buy_volume=50, today_sell_volume=0)
        assert pos.available_volume == 50
        assert pos.today_buy_volume == 50


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
