"""
技术指标库测试
"""
import pytest
import sys
import os
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.strategy.indicators import sma, ema, macd, rsi, bollinger_bands, kdj, atr, obv, adx


class TestSMA:
    def test_basic(self):
        data = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        result = sma(data, 3)
        assert np.isnan(result[0])
        assert np.isnan(result[1])
        assert result[2] == pytest.approx(2.0)
        assert result[3] == pytest.approx(3.0)
        assert result[4] == pytest.approx(4.0)

    def test_single_period(self):
        data = np.array([5.0, 10.0, 15.0])
        result = sma(data, 1)
        assert result[0] == pytest.approx(5.0)
        assert result[1] == pytest.approx(10.0)


class TestEMA:
    def test_basic(self):
        data = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        result = ema(data, 3)
        assert result[0] == 1.0  # First value = data[0]
        assert len(result) == 5
        # EMA should be smoothed
        assert result[-1] > result[0]

    def test_custom_alpha(self):
        data = np.array([10.0, 20.0, 30.0])
        result = ema(data, 3, alpha=0.5)
        assert result[0] == 10.0
        assert result[1] == pytest.approx(15.0)  # 0.5*20 + 0.5*10


class TestRSI:
    def test_basic(self):
        # Create a trending up series
        data = np.array([10.0 + i * 0.5 for i in range(30)])
        result = rsi(data, 14)
        assert len(result) == 30
        # Strong uptrend should have RSI > 50
        assert result[-1] > 50

    def test_range(self):
        data = np.random.randn(50).cumsum() + 100
        result = rsi(data, 14)
        # RSI should be between 0 and 100
        valid = result[~np.isnan(result)]
        if len(valid) > 0:
            assert all(0 <= v <= 100 for v in valid)


class TestMACD:
    def test_basic(self):
        data = np.array([10.0 + i * 0.1 for i in range(50)])
        macd_line, signal_line, histogram = macd(data)
        assert len(macd_line) == 50
        assert len(signal_line) == 50
        assert len(histogram) == 50

    def test_histogram_relationship(self):
        data = np.random.randn(100).cumsum() + 50
        macd_line, signal_line, histogram = macd(data)
        # Histogram = macd_line - signal_line
        for i in range(len(histogram)):
            if not np.isnan(histogram[i]):
                assert histogram[i] == pytest.approx(macd_line[i] - signal_line[i], abs=1e-10)


class TestBollingerBands:
    def test_basic(self):
        data = np.array([10.0 + np.random.randn() for _ in range(30)])
        upper, middle, lower = bollinger_bands(data, 20, 2.0)
        assert len(upper) == 30
        # Upper > middle > lower (where not NaN)
        for i in range(19, 30):
            if not np.isnan(upper[i]):
                assert upper[i] >= middle[i]
                assert middle[i] >= lower[i]


class TestATR:
    def test_basic(self):
        high = np.array([11.0, 12.0, 13.0, 14.0, 15.0])
        low = np.array([9.0, 10.0, 11.0, 12.0, 13.0])
        close = np.array([10.0, 11.0, 12.0, 13.0, 14.0])
        result = atr(high, low, close, 3)
        assert len(result) == 5
        # ATR should be positive
        assert result[-1] >= 0


class TestADX:
    def test_basic(self):
        n = 50
        high = np.random.randn(n).cumsum() + 50
        low = high - abs(np.random.randn(n))
        close = (high + low) / 2
        adx_vals, plus_di, minus_di = adx(high, low, close, 14)
        assert len(adx_vals) == n
        assert len(plus_di) == n
        assert len(minus_di) == n


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
