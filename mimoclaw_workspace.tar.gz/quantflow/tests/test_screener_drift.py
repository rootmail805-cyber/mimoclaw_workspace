"""
扫股器和漂移检测器测试
"""
import pytest
import sys
import os
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.screener import StockScreener, STOCK_POOLS, ScreenerResult
from core.drift_detector import DriftDetector, AlertLevel, AlertType


class TestStockPools:
    def test_pools_exist(self):
        assert "沪深300龙头" in STOCK_POOLS
        assert "科创50精选" in STOCK_POOLS
        assert "金融龙头" in STOCK_POOLS
        assert "消费龙头" in STOCK_POOLS
        assert "科技龙头" in STOCK_POOLS

    def test_pool_sizes(self):
        assert len(STOCK_POOLS["沪深300龙头"]) == 30
        assert len(STOCK_POOLS["科创50精选"]) == 20
        assert len(STOCK_POOLS["金融龙头"]) == 10
        assert len(STOCK_POOLS["消费龙头"]) == 10
        assert len(STOCK_POOLS["科技龙头"]) == 10

    def test_symbol_format(self):
        for pool_name, symbols in STOCK_POOLS.items():
            for sym in symbols:
                assert "." in sym, f"{sym} in {pool_name} missing suffix"
                assert sym.endswith(".SH") or sym.endswith(".SZ"), f"{sym} invalid suffix"


class TestScreenerResult:
    def test_default_values(self):
        r = ScreenerResult(symbol="600000.SH")
        assert r.symbol == "600000.SH"
        assert r.annualized_return == 0.0
        assert r.error is None

    def test_with_values(self):
        r = ScreenerResult(
            symbol="600000.SH", name="浦发银行",
            annualized_return=0.15, max_drawdown=0.08,
            sharpe_ratio=1.5, win_rate=0.6
        )
        assert r.annualized_return == 0.15
        assert r.sharpe_ratio == 1.5


class TestDriftDetector:
    def test_consecutive_loss_detection(self):
        detector = DriftDetector()
        # 5 consecutive losing trades
        trades = [{"pnl": -100}] * 5
        alert = detector._check_consecutive_loss("test", "测试策略", "600000.SH", trades)
        assert alert is not None
        assert alert.alert_type == AlertType.CONSECUTIVE_LOSS
        assert alert.alert_level == AlertLevel.WARNING

    def test_no_consecutive_loss(self):
        detector = DriftDetector()
        # Mixed wins and losses
        trades = [{"pnl": 100}, {"pnl": -50}, {"pnl": 200}, {"pnl": -30}, {"pnl": 150}]
        alert = detector._check_consecutive_loss("test", "测试策略", "600000.SH", trades)
        assert alert is None

    def test_insufficient_trades(self):
        detector = DriftDetector()
        trades = [{"pnl": -100}] * 3  # Less than threshold
        alert = detector._check_consecutive_loss("test", "测试策略", "600000.SH", trades)
        assert alert is None

    def test_drawdown_breach(self):
        detector = DriftDetector()
        # Create returns that simulate a 10% drawdown
        daily_returns = [0.01] * 20 + [-0.02] * 10
        alert = detector._check_drawdown_breach(
            "test", "测试策略", "600000.SH", daily_returns, hist_max_dd=0.05
        )
        # Current drawdown should exceed 80% of historical max (0.05 * 0.8 = 0.04)
        assert alert is not None
        assert alert.alert_type == AlertType.DRAWDOWN_BREACH

    def test_alert_history(self):
        detector = DriftDetector()
        assert len(detector.get_alert_history()) == 0

    def test_acknowledge(self):
        detector = DriftDetector()
        trades = [{"pnl": -100}] * 5
        detector._check_consecutive_loss("test", "测试策略", "600000.SH", trades)
        # Manually add to history for testing
        from core.drift_detector import DriftAlert
        detector._alert_history.append(DriftAlert(
            alert_time="2026-01-01", alert_type=AlertType.CONSECUTIVE_LOSS,
            alert_level=AlertLevel.WARNING, strategy_id="test",
            strategy_name="测试", symbol="600000.SH", title="test",
            message="test", current_value=5, threshold=5, suggestion="test"
        ))
        detector.acknowledge(0)
        assert detector._alert_history[0].acknowledged is True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
