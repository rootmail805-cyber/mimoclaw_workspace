"""
Shared test fixtures for QuantFlow test suite.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import numpy as np
import pandas as pd


@pytest.fixture
def sample_ohlcv_data():
    """Generate sample OHLCV data for testing (500 business days)."""
    np.random.seed(42)
    days = 500
    start_price = 10.0
    volatility = 0.02
    dates = pd.date_range(start="2022-01-01", periods=days, freq="B")
    prices = [start_price]
    for _ in range(days - 1):
        prices.append(prices[-1] * (1 + np.random.normal(0, volatility)))
    prices = np.array(prices)
    df = pd.DataFrame({
        "open": prices * (1 + np.random.normal(0, 0.005, days)),
        "high": prices * (1 + np.abs(np.random.normal(0, 0.01, days))),
        "low": prices * (1 - np.abs(np.random.normal(0, 0.01, days))),
        "close": prices,
        "volume": np.random.randint(100000, 10000000, days),
        "turnover": prices * np.random.randint(100000, 10000000, days),
    }, index=dates)
    return df


@pytest.fixture
def sample_trades():
    """Generate sample trade records for testing."""
    from core.models import TradeRecord, OrderSide
    from datetime import datetime
    return [
        TradeRecord("T1", "O1", "A.SH", OrderSide.BUY, 10.0, 100, 5, datetime(2024, 1, 2)),
        TradeRecord("T2", "O1", "A.SH", OrderSide.SELL, 12.0, 100, 5, datetime(2024, 1, 10)),
        TradeRecord("T3", "O2", "A.SH", OrderSide.BUY, 11.0, 100, 5, datetime(2024, 1, 15)),
        TradeRecord("T4", "O2", "A.SH", OrderSide.SELL, 10.0, 100, 5, datetime(2024, 1, 20)),
    ]
