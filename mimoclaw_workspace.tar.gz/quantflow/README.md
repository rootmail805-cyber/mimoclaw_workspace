# QuantFlow V2.0 — A股量化交易系统

**BY Ricardo（V root_ss）**

> 面向个人投资者的一站式量化交易平台，从选股到回测到实盘，全流程自动化。

---

## ⚠️ 开发协约（重要）

**在后续每次新增功能的请求中，AI 助手有权且有义务站在「让系统更完善、更安全、更好用」的角度，对需求提出质疑、补充建议或指出潜在风险。** 这不是阻碍，而是守护——每一次质疑都是为了避免引入逻辑漏洞、安全盲点或用户体验退化。此条款适用于本项目所有后续迭代。

---

## 目录

- [系统概述](#系统概述)
- [功能清单](#功能清单)
- [技术架构](#技术架构)
- [更新日志](#更新日志)
- [安装与运行](#安装与运行)
- [配置说明](#配置说明)
- [安全说明](#安全说明)
- [测试](#测试)

---

## 系统概述

QuantFlow V2.0 是一套完整的A股量化交易系统，涵盖：

- **数据采集**：AkShare / EastMoney / Sina / Tencent / NetEase / Baostock / Tushare 7源容错 + 多源投票验证 + 自动重试
- **策略研发**：8种内置策略 + YAML模板 + 参数可调
- **回测验证**：向量化回测引擎 + 绩效分析 + 报告生成
- **扫股选股**：批量回测30+只股票，8线程并发，排行榜一目了然
- **影子试驾**：零风险验证策略在真实市场的表现
- **实盘交易**：纸盘模拟 / QMT / Ptrade / easytrader
- **冲突仲裁**：策略信号与止盈止损冲突的三种处理模式（策略优先/止盈止损优先/动态优先）
- **券商守护**：进程存活检测 + 崩溃自动重启 + 连接健康检查 + 异常告警
- **风控管理**：三层风控 + 策略漂移检测 + 紧急停止
- **智能推送**：每日战报 / 周度摘要 / 异常告警
- **基准对比**：沪深300对比 + 超额收益归因分析
- **UI风格**：科技深色主题（高对比度、深邃科技风、专业量化氛围）

---

## 功能清单

### 1. 首页看板

| 功能 | 实现方式 | 说明 |
|------|---------|------|
| 今日盈亏 | `gui_v2.py::_refresh_dashboard` | 从券商适配器实时获取 |
| 持仓快照 | `gui_v2.py::_update_dashboard` | 显示所有持仓标的及盈亏 |
| 最近交易 | `SimulationAdapter.get_trade_history()` | 显示当日交易记录 |
| 风控状态 | `EnhancedRiskManager` | 显示熔断/警告/正常 |
| 数据导出 | `gui_v2.py::_export_trades_csv` | 导出交易记录为CSV |
| 多股票持仓 | 持仓表支持多行 | 同时显示多只股票 |

**数据流**：纸盘交易 → SimulationAdapter → 首页看板（总资产/持仓/盈亏）

### 2. 回测模块

| 功能 | 实现方式 | 说明 |
|------|---------|------|
| 单股回测 | `BacktestEngine.run()` | 支持8种策略 |
| 绩效分析 | `PerformanceAnalyzer` | 年化收益/最大回撤/夏普/胜率/VaR/CVaR |
| 报告生成 | `ReportGenerator` | HTML报告 + 权益曲线图 |
| 参数自定义 | GUI输入框 | 策略切换时参数标签自动更新 |
| 参数验证 | `DualMAStrategy.__init__` | 短期>=长期时自动交换 |

**使用方法：**
1. 输入股票代码（如 `600000.SH`）
2. 选择策略（参数标签会自动切换：双均线→短期/长期均线，MACD→快线/慢线，RSI→RSI周期/超卖阈值等）
3. 设置日期范围
4. 点击"运行回测"

### 3. 扫股器（批量回测）

| 功能 | 实现方式 | 说明 |
|------|---------|------|
| 预设股票池 | `core/screener.py::STOCK_POOLS` | 沪深300/科创50/金融/消费/科技龙头 |
| 自定义股票池 | GUI文本框 | 支持手动输入或TXT/CSV |
| 并发回测 | `ThreadPoolExecutor(max_workers=8)` | 8线程同时处理，速度提升6-8倍 |
| 排行榜 | `gui_v2.py::_display_screener_results` | 可按年化收益/夏普/回撤/胜率排序 |
| 快速应用 | "回测"/"模拟"按钮 | 一键跳转，**自动传递策略选择** |
| 进度显示 | `progress_callback` | "正在回测第23/50只" |

**使用方法：**
1. 选择策略
2. 选择股票池（或输入自定义代码）
3. 点击"开始批量回测"
4. 查看排行榜，点击"回测"或"模拟"应用（策略选择自动传递）

### 4. 策略商店

| 功能 | 实现方式 | 说明 |
|------|---------|------|
| YAML模板加载 | `StrategyTemplateLoader` | 从 `strategies/templates/` 加载 |
| 策略卡片 | `gui_v2.py::_create_strategy_card` | 显示描述/参数/回测结果/风险等级 |
| 一键应用 | `gui_v2.py::_use_strategy` | 跳转回测并预填参数 |
| 名称一致性 | `_template_to_builtin` 映射 | 策略商店/回测/扫股器/实盘名称统一 |

**8个内置策略：**
双均线策略、MACD策略、布林带策略、RSI策略、KDJ策略、ATR通道突破、动量突破策略、VWAP策略

### 5. 实盘交易

| 功能 | 实现方式 | 说明 |
|------|---------|------|
| 券商连接 | `broker_registry.py` | 模拟/银河/华泰/广发/QMT/Ptrade |
| 手动下单 | `gui_v2.py::_manual_trade` | 买入/卖出 + 快捷仓位（全仓/半仓/1/4仓） |
| 止损止盈 | `SimulationAdapter.set_stop_loss` | 手动设置 + 自动计算(盈亏比2.3:1) |
| **冲突仲裁** | `core/arbitrator.py::ConflictArbitrator` | 策略信号与止盈止损冲突的三种处理模式 |
| **券商守护** | `core/broker_guardian.py::BrokerGuardian` | 进程存活/崩溃重启/连接健康/异常告警 |
| 策略自动交易 | 后台线程运行策略 | 支持启动/停止，集成冲突仲裁 |
| 影子模式 | `core/shadow.py::ShadowTrader` | 零风险验证策略（全链路模拟），集成冲突仲裁 |
| 券商说明 | `gui_v2.py::_update_broker_desc` | 显示匹配度/配置需求/配置方法 |
| 股票代码同步 | `_sync_sym_to_auto/_manual` | 手动下单与策略自动交易代码联动 |

**冲突仲裁三种模式：**

| 模式 | 逻辑 | 适用场景 |
|------|------|---------|
| 策略信号优先 | 策略信号始终执行，有冲突时取消止盈止损单 | 对策略高度信任 |
| 止盈止损优先 | 有激活的止盈止损单时，暂停策略对该标的的交易 | 保守型用户 |
| **动态优先（推荐）** | 浮盈≥止盈目标80%→止盈优先；浮亏≥止损线50%→止损优先；其他→策略优先 | 绝大多数用户 |

**使用方法：**
1. 选择券商，点击"连接"
2. 输入股票代码和数量
3. 点击"买入"或"卖出"
4. 止损止盈可手动设置或点击"自动计算(2.3:1)"
5. 启动策略时选择冲突处理规则

### 6. 风险仪表盘

| 功能 | 实现方式 | 说明 |
|------|---------|------|
| 实时风控指标 | `gui_v2.py::_refresh_risk` | 距离硬熔断/单日亏损/持仓集中度/系统健康度 |
| 漂移检测 | `core/drift_detector.py::DriftDetector` | 5种预警类型 |
| 预警推送 | `NotificationManager` | 钉钉/微信/邮件 |
| 预警历史 | `DriftDetector.get_alert_history()` | 保留最近30条 |

**5种预警类型：**
- 连续亏损预警（5笔连续亏损）→ 黄色预警
- 收益偏离检测（近20日均值偏离历史2σ）→ 红色预警
- 回撤突破告警（超过历史最大回撤80%）→ 红色预警
- 波动率飙升检测 → 黄色预警
- 胜率下降检测（下降超15个百分点）→ 黄色预警

### 7. 基准对比与归因

| 功能 | 实现方式 | 说明 |
|------|---------|------|
| 基准曲线 | `core/benchmark.py::BenchmarkAnalyzer` | 沪深300净值叠加 |
| 超额收益 | `BenchmarkAnalyzer.compare()` | Alpha/Beta/信息比率/跟踪误差 |
| 上下行捕获 | `BenchmarkAnalyzer.compare()` | 上行捕获率/下行捕获率 |
| 归因分析 | `BenchmarkAnalyzer.attribute()` | 行业配置/个股选择/择时贡献 |
| 好坏时段 | `_find_best_worst_periods()` | 自动标记最佳/最差连续5个交易日 |

### 8. 每日战报推送

| 功能 | 实现方式 | 说明 |
|------|---------|------|
| 每日战报 | `core/daily_report.py::DailyReporter` | 收盘后自动生成 |
| 周度摘要 | `DailyReporter.generate_weekly()` | 每周推送 |
| 异常突出 | `is_alert` 标记 | 亏损达限额50%时红色警告 |
| 推送渠道 | `NotificationManager` | 钉钉/微信/邮件可选 |

### 9. 数据源系统

| 数据源 | 类型 | 特点 |
|--------|------|------|
| AkShare | 免费 | 默认首选，数据全面 |
| **EastMoney（东方财富）** | 免费 | 国内最可靠的金融数据源之一 |
| Sina | 免费 | 历史K线数据稳定 |
| Tencent | 免费 | 云端访问更可靠 |
| **NetEase（网易财经）** | 免费 | 历史数据质量高 |
| **Baostock（证券宝）** | 免费 | 量化圈 popular，数据规范 |
| Tushare | 需Token | 需注册获取API Token |
| CSV | 本地 | 离线数据兜底 |

**多源投票验证**（`DataManager.get_history_voted()`）：
从所有可用源获取同一股票数据，比较收盘价中位数偏差，偏差>1%的源被标记为异常，返回共识数据。

---

## 技术架构

```
quant_trading_system/
├── main.py                        # 主入口
├── gui_v2.py                      # GUI主文件（2700+行）
├── gui/
│   └── theme.py                   # 主题系统（科技深色单主题）
├── config/
│   ├── manager.py                 # 配置管理（YAML + 环境变量）
│   └── settings.yaml              # 系统配置
├── core/
│   ├── models.py                  # 数据模型（Bar, Signal, Position, AccountInfo）
│   ├── arbitrator.py              # 冲突仲裁器（3种模式）
│   ├── broker_guardian.py         # 券商进程守护（监控/重启/告警）
│   ├── broker_guardian.py         # 券商进程守护（监控/重启/告警）
│   ├── data/
│   │   ├── data_manager.py        # 数据管理（单例 + 多源容错 + 多源投票 + 缓存）
│   │   ├── providers.py           # 数据源（AkShare/EastMoney/Sina/Tencent/NetEase/Baostock/Tushare/CSV）
│   │   ├── cleaner.py             # 数据清洗
│   │   └── storage.py             # 数据存储
│   ├── strategy/
│   │   ├── base.py                # 策略基类（含趋势过滤）
│   │   ├── indicators.py          # 技术指标库（12个指标）
│   │   ├── position_sizing.py     # 仓位管理（4种算法）
│   │   ├── recommender.py         # 策略推荐引擎（加权评分）
│   │   ├── registry.py            # 策略注册表
│   │   ├── signals.py             # 信号生成工具
│   │   └── template_loader.py     # YAML模板加载
│   ├── backtest/
│   │   ├── engine.py              # 回测引擎（单股/多股组合/前向优化）
│   │   ├── broker.py              # 模拟券商（T+1/涨跌停/滑点/印花税）
│   │   ├── performance.py         # 绩效分析（20+指标 + Monte Carlo）
│   │   └── report.py              # 报告生成（HTML/文本）
│   ├── execution/
│   │   ├── broker_adapter.py      # 券商适配器（Simulation/easytrader/QMT）
│   │   ├── broker_registry.py     # 券商注册表
│   │   ├── execution_engine.py    # 执行引擎
│   │   ├── fee_calculator.py      # 费用计算
│   │   ├── order_manager.py       # 订单管理
│   │   └── signal_queue.py        # 信号队列（持久化）
│   ├── risk/
│   │   ├── risk_manager.py        # 风控管理器
│   │   ├── enhanced_risk.py       # 增强风控（熔断/预警）
│   │   ├── pre_trade.py           # 事前风控
│   │   ├── intra_trade.py         # 事中风控
│   │   ├── post_trade.py          # 事后风控
│   │   └── kill_switch.py         # 紧急停止
│   ├── security/
│   │   ├── audit.py               # 审计日志（HMAC签名链）
│   │   └── crypto.py              # 加密工具
│   ├── monitor/
│   │   ├── alerter.py             # 告警推送
│   │   ├── daily_report.py        # 监控日报
│   │   ├── dashboard.py           # 仪表盘
│   │   └── health.py              # 健康检查
│   ├── notification/
│   │   └── notifier.py            # 通知管理（钉钉/微信/邮件）
│   ├── market_timing/
│   │   └── __init__.py            # 大盘择时
│   ├── db/
│   │   └── database.py            # SQLite数据库
│   ├── screener.py                # 扫股器（批量回测，8线程并发）
│   ├── benchmark.py               # 基准对比与归因分析
│   ├── shadow.py                  # 影子模式（试驾，全链路模拟）
│   ├── drift_detector.py          # 策略漂移检测（5种预警）
│   └── daily_report.py            # 每日战报生成器
├── strategies/                    # 策略实现（8个）
│   ├── dual_ma.py                 # 双均线（含参数验证）
│   ├── macd_strategy.py           # MACD
│   ├── bollinger_strategy.py      # 布林带
│   ├── rsi_strategy.py            # RSI
│   ├── kdj_strategy.py            # KDJ
│   ├── atr_breakout_strategy.py   # ATR通道突破
│   ├── momentum_strategy.py       # 动量突破
│   ├── vwap_strategy.py           # VWAP
│   └── templates/                 # YAML策略模板
├── data/                          # 股票数据
│   ├── *.csv                      # 历史数据
│   └── quantflow.db               # SQLite数据库
├── tests/                         # 测试用例（61个）
│   ├── conftest.py                # 共享测试fixture
│   ├── test_backtest.py           # 回测测试（28个）
│   ├── test_models.py             # 模型测试（11个）
│   ├── test_indicators.py         # 指标测试（12个）
│   └── test_screener_drift.py     # 扫股器+漂移检测测试（10个）
├── utils/
│   ├── event_bus.py               # 事件总线
│   ├── life_translation.py        # 生活化翻译
│   ├── logger.py                  # 日志工具
│   ├── time_utils.py              # 时间工具
│   └── validators.py              # 验证器
├── widgets/
│   └── date_picker.py             # 日期选择器
├── .env.example                   # 环境变量模板
├── .gitignore                     # Git忽略规则
├── README.md                      # 本文档
├── requirements.txt               # Python依赖
├── run.bat                        # Windows启动脚本
└── setup.bat                      # Windows安装脚本
```

---

## 更新日志

### V2.2（2026-07-07）

#### 新增功能
- **冲突仲裁模块**：策略信号与止盈止损冲突的三种处理模式（`core/arbitrator.py`）
  - 策略信号优先：策略始终执行
  - 止盈止损优先：有挂单时暂停策略
  - 动态优先（推荐）：根据盈亏状态自动切换仲裁方
  - 已集成到策略自动交易和影子模式
- **券商进程守护**：`core/broker_guardian.py::BrokerGuardian`
  - 进程存活检测 + 崩溃自动重启（指数退避，最大3次）
  - 连接健康检查：QMT/Ptrade的TCP连接检测
  - 异常告警 + 资源监控（CPU/内存）+ 版本检测
  - 预置配置：银河/华泰/广发/QMT/Ptrade
- **数据源扩展**：新增 EastMoney（东方财富）、NetEase（网易财经）、Baostock（证券宝）3个数据源
- **多源投票验证**：`DataManager.get_history_voted()` 从多个源获取数据并交叉验证，偏差>1%的源被标记

#### UI 重构
- **主题系统精简**：只保留科技深色单主题，专注打磨
- **配色全面升级**：背景更深邃（`#05080e`），文字对比度提升30%（`#e0e8f0`）
- **字体加大**：标题 15→16px，正文 10→11px，大数字 32→36px
- **回测参数动态标签**：切换策略时参数标签自动更新（双均线→短期/长期均线，MACD→快线/慢线等）
- **风险仪表盘真实数据**：进度条连接真实账户数据（持仓集中度、距离硬熔断、系统健康度）
- **扫股器策略传递**：跳转回测/模拟时自动传递策略选择
- **冲突仲裁下拉框**：策略自动交易区新增「冲突规则」选择
- **进程守护面板**：实盘交易页新增进程守护状态显示和启停按钮

#### Bug 修复
- 删除 `gui_v2.py` 中重复定义的 `_refresh_dashboard` 和 `_save_settings` 方法
- 删除首页看板重复的"刷新数据"按钮
- 修复 `_OLD_C` 模块级变量重复赋值
- 修复 `DataManager._last_error` 未在 `__init__` 中初始化
- 修复 `AccountInfo.return_pct` 硬编码100万，改为使用 `initial_capital` 字段
- 修复 `DriftDetector` 阈值计算中错误除以100
- 修复 `indicators.adx()` 中重复计算 `lc` 的死代码

### V2.1（2026-07-06）

#### 新增功能
- **扫股器**：多标的批量回测，预设5个股票池（沪深300/科创50/金融/消费/科技龙头），8线程并发，排行榜支持多维度排序
- **影子模式（试驾）**：零资金风险验证策略，全链路模拟（信号→风控→滑点→佣金→T+1→涨跌停），运行满20天自动生成评估摘要
- **策略漂移检测**：5种预警类型（连续亏损/收益偏离/回撤突破/波动率飙升/胜率下降），自动推送钉钉/微信
- **每日战报推送**：每日收盘后自动生成战报（盈亏/持仓/风控状态），支持周度/月度摘要
- **基准对比与归因**：沪深300净值曲线叠加，Alpha/Beta/信息比率，收益来源分解（行业/个股/择时）
- **券商说明**：每个券商显示匹配度评级、配置需求、分步配置指南
- **止损止盈自动计算**：盈亏比默认2.3:1，可手动调整，买入后自动设置
- **股票代码同步**：手动下单与策略自动交易的股票代码双向联动
- **数据导出**：首页看板新增"导出交易记录"按钮，CSV格式

#### 性能优化
- **扫股器并发**：串行→8线程并发，30只股票从5分钟缩短到40秒
- **数据源限速**：全局HTTP锁 + 300ms最小请求间隔，防止API频率限制
- **DataManager单例**：所有代码共享同一实例和缓存，避免重复初始化

#### 安全与稳定性
- **线程安全**：broker访问全部加`_broker_lock`，数据源请求全部加`_http_lock`
- **异常处理分层**：ImportError/ValueError/ConnectionError/Exception 四层，错误信息更精准
- **策略参数验证**：双均线策略自动交换短/长期均线，防止无效参数
- **测试覆盖**：61个测试用例（模型/指标/回测/扫股器/漂移检测）

---

## 安装与运行

### 环境要求
- Python 3.10+
- Windows 10/11（推荐）/ Mac / Linux

### 安装步骤

```bash
# 1. 克隆或下载项目
cd quant_trading_system

# 2. 创建虚拟环境
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # Mac/Linux

# 3. 安装依赖
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

# 4. 运行
python main.py
```

### 运行模式

```bash
python main.py                                          # 启动GUI
python main.py --cli                                    # 命令行模式
python main.py backtest -s 600000.SH --strategy dual_ma # 直接回测
python main.py health                                   # 系统健康检查
```

---

## 配置说明

配置文件：`config/settings.yaml`

```yaml
# 数据源（7个源互为备份，支持多源投票验证）
data:
  sources:
    history:
      provider: "akshare"    # akshare / eastmoney / sina / tencent / netease / baostock / tushare
      tushare_token: ""
    realtime:
      provider: "akshare"
  cache:
    max_size_mb: 512

# 交易参数
trading:
  commission_rate: 0.00025   # 佣金费率（万2.5）
  slippage_rate: 0.001       # 滑点率（0.1%）
  min_commission: 5.0        # 最低佣金

# 风控
risk:
  circuit_breaker:
    threshold: 0.05          # 硬熔断：回撤5%
    warning_threshold: 0.03  # 预警：回撤3%
  daily_loss_limit: 0.05     # 单日亏损限额：5%
  max_position_concentration: 0.6  # 单票最大持仓60%

# 通知
notification:
  primary_channel: "dingtalk"  # dingtalk / feishu / wechat
  dingtalk:
    webhook: ""

# UI
ui:
  theme: "tech_dark"         # 固定科技深色主题

# 执行
execution:
  broker: "simulation"       # simulation / qmt / ptrade
  simulation:
    initial_balance: 1000000 # 初始资金100万
```

环境变量（`.env`）：
```
QUANT_DATA_API_KEY=
QUANT_TUSHARE_TOKEN=
QUANT_INFLUX_TOKEN=
QUANT_DINGTALK_WEBHOOK=
QUANT_EMAIL_PASSWORD=
QUANT_LOG_LEVEL=INFO
```

---

## 安全说明

| 安全措施 | 实现 |
|---------|------|
| 密钥管理 | 环境变量 + .env文件，不硬编码 |
| 三层风控 | 事前（参数/资金）→ 事中（仓位/亏损）→ 事后（审计） |
| 冲突仲裁 | 策略信号与止盈止损冲突的三种处理模式，防止重复平仓/仓位方向矛盾 |
| 券商守护 | 进程存活检测 + 崩溃自动重启 + 连接健康检查 + 异常告警 |
| 多源验证 | 7个数据源互为备份，投票机制交叉验证，防止单源数据异常 |
| 审计日志 | HMAC签名链，只追加不可篡改 |
| 代码校验 | 运行时代码哈希校验 |
| 断线重连 | 信号队列持久化 + 指数退避重连 |
| T+1限制 | 买入当日不可卖出 |
| 涨跌停限制 | ±10%价格限制检查 |
| SQL安全 | 全部参数化查询 |
| 线程安全 | 全局HTTP锁 + Broker锁 |

---

## 测试

```bash
# 运行全部测试
python -m pytest tests/ -v

# 运行特定测试
python -m pytest tests/test_models.py -v
python -m pytest tests/test_indicators.py -v
python -m pytest tests/test_screener_drift.py -v
```

**测试覆盖（61个用例）：**

| 测试文件 | 用例数 | 覆盖范围 |
|---------|--------|---------|
| test_backtest.py | 28 | 回测引擎、模拟券商、订单撮合、绩效分析、仓位管理、策略注册表 |
| test_models.py | 11 | Bar、Signal、Position 数据模型 |
| test_indicators.py | 12 | SMA/EMA/RSI/MACD/Bollinger/ATR/ADX/KDJ |
| test_screener_drift.py | 10 | 股票池、扫股器、漂移检测器 |

---

## 界面风格

系统采用**科技深色**单主题，专注打磨极致体验：

| 属性 | 值 | 说明 |
|------|-----|------|
| 背景色 | `#05080e` | 深邃纯净的深黑 |
| 主强调色 | `#00e87b` | 科技绿，盈/买入 |
| 信息色 | `#00d4ff` | 冰蓝，数据/标签 |
| 警告色 | `#ffaa00` | 琥珀橙 |
| 危险色 | `#ff3b5c` | 赤红，亏/卖出 |
| 主文字 | `#e0e8f0` | 高亮白，对比度+30% |
| 标题文字 | `#ffffff` | 纯白，最高对比度 |
| 等宽字体 | Consolas | 数字对齐，量化风格 |

---

**BY Ricardo（V root_ss）**
