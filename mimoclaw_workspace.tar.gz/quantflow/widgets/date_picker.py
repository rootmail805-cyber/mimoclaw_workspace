"""
Custom Date Picker widget for tkinter.
Pure tkinter implementation — no external dependencies.
Goby dark theme style.
"""

import tkinter as tk
from tkinter import Toplevel, Frame, Label, Button
import calendar
from datetime import datetime, date


# Goby theme colors
_C = {
    "bg":         "#0a0e14",
    "bg_panel":   "#0f1923",
    "bg_card":    "#131d27",
    "bg_hover":   "#1e3044",
    "border":     "#1c2e40",
    "accent":     "#00ff88",
    "accent_dim": "#00cc6a",
    "cyan":       "#00d4aa",
    "text":       "#c9d1d9",
    "text_dim":   "#6b7d8e",
    "text_bright":"#e6edf3",
    "red":        "#ef4444",
    "orange":     "#f59e0b",
    "today":      "#3b82f6",
    "selected":   "#00ff88",
    "disabled":   "#2a2a3e",
}


class DatePicker:
    """A popup calendar date picker.

    Usage:
        picker = DatePicker(parent_widget)
        selected_date = picker.pick()  # Returns "YYYY-MM-DD" or None
    """

    def __init__(self, parent, initial_date=None):
        """
        Args:
            parent: Parent tkinter widget.
            initial_date: Initial date string "YYYY-MM-DD" or datetime/date object.
        """
        self._parent = parent
        self._result = None

        # Parse initial date
        if isinstance(initial_date, str):
            try:
                self._current = datetime.strptime(initial_date, "%Y-%m-%d").date()
            except ValueError:
                self._current = date.today()
        elif isinstance(initial_date, (datetime, date)):
            self._current = initial_date if isinstance(initial_date, date) else initial_date.date()
        else:
            self._current = date.today()

        self._view_year = self._current.year
        self._view_month = self._current.month

    def pick(self) -> str:
        """Show the calendar popup and return selected date as "YYYY-MM-DD".

        Returns None if the user cancels.
        """
        self._create_popup()
        self._parent.wait_window(self._top)
        return self._result

    def _create_popup(self):
        self._top = Toplevel(self._parent)
        self._top.title("选择日期")
        self._top.configure(bg=_C["bg"])
        self._top.resizable(False, False)
        self._top.transient(self._parent)
        self._top.grab_set()

        # Size and position
        w, h = 340, 380
        px = self._parent.winfo_rootx() + 50
        py = self._parent.winfo_rooty() + 50
        self._top.geometry(f"{w}x{h}+{px}+{py}")

        # Header: year/month navigation
        header = Frame(self._top, bg=_C["bg_card"], height=48)
        header.pack(fill="x")
        header.pack_propagate(False)

        self._btn_prev = Button(header, text="◀", font=("Consolas", 14, "bold"),
                                bg=_C["bg_card"], fg=_C["cyan"], bd=0,
                                activebackground=_C["bg_hover"],
                                cursor="hand2", command=self._prev_month)
        self._btn_prev.pack(side="left", padx=(12, 4))

        self._month_label = Label(header, text="", font=("Consolas", 13, "bold"),
                                   bg=_C["bg_card"], fg=_C["text_bright"])
        self._month_label.pack(side="left", expand=True)

        self._btn_next = Button(header, text="▶", font=("Consolas", 14, "bold"),
                                bg=_C["bg_card"], fg=_C["cyan"], bd=0,
                                activebackground=_C["bg_hover"],
                                cursor="hand2", command=self._next_month)
        self._btn_next.pack(side="right", padx=(4, 12))

        # Weekday headers
        week_frame = Frame(self._top, bg=_C["bg"])
        week_frame.pack(fill="x", padx=8, pady=(8, 0))
        for wd in ["一", "二", "三", "四", "五", "六", "日"]:
            Label(week_frame, text=wd, font=("Consolas", 10, "bold"),
                  bg=_C["bg"], fg=_C["text_dim"], width=4).pack(side="left")

        # Calendar grid
        self._grid_frame = Frame(self._top, bg=_C["bg"])
        self._grid_frame.pack(fill="both", expand=True, padx=8, pady=4)

        # Today button + Cancel
        btn_frame = Frame(self._top, bg=_C["bg"], height=44)
        btn_frame.pack(fill="x", padx=8, pady=(0, 8))

        Button(btn_frame, text="今天", font=("Consolas", 10),
               bg=_C["bg_card"], fg=_C["cyan"], bd=0,
               activebackground=_C["bg_hover"], cursor="hand2",
               command=self._select_today).pack(side="left", padx=(0, 8))

        Button(btn_frame, text="取消", font=("Consolas", 10),
               bg=_C["bg_card"], fg=_C["text_dim"], bd=0,
               activebackground=_C["bg_hover"], cursor="hand2",
               command=self._cancel).pack(side="right")

        self._render_calendar()

    def _render_calendar(self):
        """Render the calendar grid for the current view month."""
        for widget in self._grid_frame.winfo_children():
            widget.destroy()

        self._month_label.config(text=f"{self._view_year} 年 {self._view_month} 月")

        cal = calendar.monthcalendar(self._view_year, self._view_month)
        today = date.today()

        for row_idx, week in enumerate(cal):
            row = Frame(self._grid_frame, bg=_C["bg"])
            row.pack(fill="x")
            for col_idx, day in enumerate(week):
                if day == 0:
                    Label(row, text="", bg=_C["bg"], width=4).pack(side="left")
                    continue

                d = date(self._view_year, self._view_month, day)
                is_today = (d == today)
                is_selected = (d == self._current)
                is_weekend = col_idx >= 5

                # Determine colors
                bg = _C["bg"]
                fg = _C["text"]
                if is_selected:
                    bg = _C["selected"]
                    fg = _C["bg"]
                elif is_today:
                    bg = _C["today"]
                    fg = "#ffffff"
                elif is_weekend:
                    fg = _C["orange"]

                btn = Button(
                    row, text=str(day), font=("Consolas", 10),
                    bg=bg, fg=fg, bd=0, width=4,
                    activebackground=_C["bg_hover"],
                    activeforeground=_C["accent"],
                    cursor="hand2",
                    command=lambda dd=d: self._on_select(dd),
                )
                btn.pack(side="left")

    def _prev_month(self):
        if self._view_month == 1:
            self._view_month = 12
            self._view_year -= 1
        else:
            self._view_month -= 1
        self._render_calendar()

    def _next_month(self):
        if self._view_month == 12:
            self._view_month = 1
            self._view_year += 1
        else:
            self._view_month += 1
        self._render_calendar()

    def _on_select(self, d: date):
        self._result = d.strftime("%Y-%m-%d")
        self._top.destroy()

    def _select_today(self):
        self._result = date.today().strftime("%Y-%m-%d")
        self._top.destroy()

    def _cancel(self):
        self._result = None
        self._top.destroy()


class DateEntry(Frame):
    """A date entry field with a calendar popup button.

    Usage:
        de = DateEntry(parent, initial_date="2023-01-01")
        de.get()  # Returns "YYYY-MM-DD"
    """

    def __init__(self, parent, initial_date=None, **kwargs):
        super().__init__(parent, bg=_C["bg_panel"])

        import tkinter as tk
        from tkinter import StringVar

        self._var = StringVar(value=initial_date or date.today().strftime("%Y-%m-%d"))

        # Entry field
        self._entry = tk.Entry(
            self, textvariable=self._var,
            font=("Consolas", 10),
            bg=_C["bg_card"],
            fg=_C["accent"],
            insertbackground=_C["accent"],
            relief="flat", bd=0,
            highlightthickness=1,
            highlightbackground=_C["border"],
            highlightcolor=_C["cyan"],
        )
        self._entry.pack(side="left", fill="x", expand=True, ipady=6)

        # Calendar button
        self._btn = Button(
            self, text="📅", font=("Consolas", 11),
            bg=_C["bg_card"], fg=_C["cyan"],
            bd=0, cursor="hand2",
            activebackground=_C["bg_hover"],
            command=self._open_picker,
        )
        self._btn.pack(side="right", padx=(4, 0), ipady=3)

    def _open_picker(self):
        picker = DatePicker(self, initial_date=self._var.get())
        result = picker.pick()
        if result:
            self._var.set(result)

    def get(self) -> str:
        return self._var.get()

    def set(self, value: str):
        self._var.set(value)
