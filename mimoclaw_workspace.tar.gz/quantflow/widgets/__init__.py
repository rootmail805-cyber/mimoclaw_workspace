"""Custom widgets for QuantFlow GUI."""
