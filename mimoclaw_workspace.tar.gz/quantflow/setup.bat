@echo off
chcp 936 >NUL 2>&1
cd /d "%~dp0"
title QuantFlow V2.0 - Setup

echo.
echo ============================================================
echo   QuantFlow V2.0 - One-Click Setup
echo ============================================================
echo.

echo [1/3] Checking Python...
python --version >NUL 2>&1
if errorlevel 1 (
    echo [X] Python not found!
    echo.
    echo     Please install Python 3.10+ from:
    echo     https://www.python.org/downloads/
    echo.
    echo     IMPORTANT: Check "Add Python to PATH" during install!
    echo.
    pause
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set "PYVER=%%v"
echo   Python %PYVER% - OK

echo.
echo [2/3] Creating virtual environment...
if exist "venv\Scripts\activate.bat" (
    echo   venv already exists - OK
) else (
    python -m venv venv
    if errorlevel 1 (
        echo [X] Failed to create venv!
        pause
        exit /b 1
    )
    echo   venv created - OK
)

echo.
echo [3/3] Installing dependencies (Tsinghua mirror)...
call venv\Scripts\activate.bat
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple --trusted-host pypi.tuna.tsinghua.edu.cn akshare pandas numpy pyyaml python-dotenv loguru requests psutil pydantic >NUL 2>&1
if errorlevel 1 (
    echo [X] pip install failed! Check network.
    pause
    exit /b 1
)
echo   All dependencies installed - OK

echo.
echo ============================================================
echo   Setup complete!
echo.
echo   To start: double-click run.bat
echo ============================================================
echo.
pause
