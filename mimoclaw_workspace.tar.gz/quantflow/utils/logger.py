"""
Centralized logging for QuantFlow.
Uses loguru for structured logging with rich console output.
Supports Windows-compatible file paths and rotation.
"""

import sys
import os
from pathlib import Path
from typing import Optional
from loguru import logger as _logger

# Remove default handler
_logger.remove()

_initialized = False


def setup_logger(
    log_dir: str = "./logs",
    log_level: str = "INFO",
    console_output: bool = True,
    file_output: bool = True,
) -> None:
    """Configure the global logger.

    Args:
        log_dir: Directory for log files.
        log_level: Minimum log level (DEBUG/INFO/WARNING/ERROR/CRITICAL).
        console_output: Enable rich console output.
        file_output: Enable file logging with rotation.
    """
    global _initialized
    if _initialized:
        return

    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)

    # Console handler with rich formatting
    if console_output:
        _logger.add(
            sys.stderr,
            level=log_level,
            format=(
                "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
                "<level>{level: <8}</level> | "
                "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
                "<level>{message}</level>"
            ),
            colorize=True,
        )

    # File handler - general log with rotation
    if file_output:
        _logger.add(
            str(log_path / "quantflow_{time:YYYY-MM-DD}.log"),
            level=log_level,
            format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | {name}:{function}:{line} | {message}",
            rotation="00:00",     # New file at midnight
            retention="30 days",  # Keep 30 days
            compression="zip",
            encoding="utf-8",
        )

        # Separate error log
        _logger.add(
            str(log_path / "errors_{time:YYYY-MM-DD}.log"),
            level="ERROR",
            format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | {name}:{function}:{line} | {message}",
            rotation="00:00",
            retention="90 days",
            compression="zip",
            encoding="utf-8",
        )

        # Trade audit log (append-only, no rotation)
        _logger.add(
            str(log_path / "trade_audit.log"),
            level="INFO",
            format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {message}",
            filter=lambda record: "audit" in record["extra"],
            rotation="100 MB",
            retention="365 days",
            compression="zip",
            encoding="utf-8",
        )

    _initialized = True
    _logger.info(f"Logger initialized | level={log_level} | dir={log_path.resolve()}")


def get_logger(name: Optional[str] = None):
    """Get a named logger instance.

    Args:
        name: Module/component name for log filtering.

    Returns:
        A loguru logger bound to the given name.
    """
    if name:
        return _logger.bind(module=name)
    return _logger


def get_audit_logger():
    """Get a logger that writes to the trade audit log."""
    return _logger.bind(audit=True)
