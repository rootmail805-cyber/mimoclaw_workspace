"""
Time utilities for QuantFlow.
Handles trading calendars, market hours, and timezone conversions.
"""

import pytz
from datetime import datetime, date, time, timedelta
from typing import List, Optional, Tuple

# China A-share market holidays (2024-2026, update annually)
# Format: (month, day)
_CN_HOLIDAYS_2024 = [
    (1, 1),   # 元旦
    (2, 10), (2, 11), (2, 12), (2, 13), (2, 14), (2, 15), (2, 16), (2, 17),  # 春节
    (4, 4), (4, 5), (4, 6),   # 清明
    (5, 1), (5, 2), (5, 3), (5, 4), (5, 5),  # 劳动节
    (6, 8), (6, 9), (6, 10),  # 端午
    (9, 15), (9, 16), (9, 17),  # 中秋
    (10, 1), (10, 2), (10, 3), (10, 4), (10, 5), (10, 6), (10, 7),  # 国庆
]

_CN_HOLIDAYS_2025 = [
    (1, 1),
    (1, 28), (1, 29), (1, 30), (1, 31), (2, 1), (2, 2), (2, 3), (2, 4),
    (4, 4), (4, 5), (4, 6),
    (5, 1), (5, 2), (5, 3), (5, 4), (5, 5),
    (5, 31), (6, 1), (6, 2),
    (10, 1), (10, 2), (10, 3), (10, 4), (10, 5), (10, 6), (10, 7), (10, 8),
]

_CN_HOLIDAYS_2026 = [
    (1, 1), (1, 2), (1, 3),
    (2, 17), (2, 18), (2, 19), (2, 20), (2, 21), (2, 22), (2, 23),
    (4, 5), (4, 6), (4, 7),
    (5, 1), (5, 2), (5, 3), (5, 4), (5, 5),
    (6, 19), (6, 20), (6, 21),
    (10, 1), (10, 2), (10, 3), (10, 4), (10, 5), (10, 6), (10, 7),
]

_ALL_HOLIDAYS = set()
for year, holidays in [(2024, _CN_HOLIDAYS_2024), (2025, _CN_HOLIDAYS_2025), (2026, _CN_HOLIDAYS_2026)]:
    for m, d in holidays:
        _ALL_HOLIDAYS.add(date(year, m, d))

TZ_SHANGHAI = pytz.timezone("Asia/Shanghai")
TZ_UTC = pytz.utc


def is_trading_day(d: Optional[date] = None) -> bool:
    """Check if a date is a trading day (weekday and not a holiday)."""
    if d is None:
        d = datetime.now(TZ_SHANGHAI).date()
    if d.weekday() >= 5:  # Saturday or Sunday
        return False
    if d in _ALL_HOLIDAYS:
        return False
    return True


def get_trading_calendar(start: date, end: date) -> List[date]:
    """Get list of trading days between start and end (inclusive)."""
    result = []
    current = start
    while current <= end:
        if is_trading_day(current):
            result.append(current)
        current += timedelta(days=1)
    return result


def is_market_open(dt: Optional[datetime] = None) -> bool:
    """Check if the A-share market is currently open.

    Market hours:
        Morning:   09:30 - 11:30
        Afternoon: 13:00 - 15:00
    """
    if dt is None:
        dt = datetime.now(TZ_SHANGHAI)
    if not is_trading_day(dt.date()):
        return False

    t = dt.time()
    morning = time(9, 30) <= t <= time(11, 30)
    afternoon = time(13, 0) <= t <= time(15, 0)
    return morning or afternoon


def get_next_trading_day(d: Optional[date] = None) -> date:
    """Get the next trading day after the given date."""
    if d is None:
        d = datetime.now(TZ_SHANGHAI).date()
    d = d + timedelta(days=1)
    while not is_trading_day(d):
        d += timedelta(days=1)
    return d


def get_prev_trading_day(d: Optional[date] = None) -> date:
    """Get the previous trading day before the given date."""
    if d is None:
        d = datetime.now(TZ_SHANGHAI).date()
    d = d - timedelta(days=1)
    while not is_trading_day(d):
        d -= timedelta(days=1)
    return d


def to_shanghai_time(dt: datetime) -> datetime:
    """Convert a datetime to Shanghai timezone."""
    if dt.tzinfo is None:
        return TZ_SHANGHAI.localize(dt)
    return dt.astimezone(TZ_SHANGHAI)
