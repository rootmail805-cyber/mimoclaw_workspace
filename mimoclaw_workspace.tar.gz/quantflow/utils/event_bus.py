"""
Event-driven architecture backbone for QuantFlow.
Provides a publish-subscribe event bus for inter-module communication.
"""

import asyncio
import threading
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from loguru import logger


class EventType(Enum):
    """All system event types."""
    # Data events
    DATA_TICK = auto()
    DATA_BAR = auto()
    DATA_CONNECTED = auto()
    DATA_DISCONNECTED = auto()

    # Strategy events
    SIGNAL_GENERATED = auto()
    STRATEGY_STARTED = auto()
    STRATEGY_STOPPED = auto()

    # Risk events
    RISK_CHECK_PASSED = auto()
    RISK_CHECK_FAILED = auto()
    RISK_KILL_SWITCH = auto()
    RISK_ALERT = auto()

    # Execution events
    ORDER_SUBMITTED = auto()
    ORDER_FILLED = auto()
    ORDER_PARTIALLY_FILLED = auto()
    ORDER_CANCELLED = auto()
    ORDER_REJECTED = auto()
    ORDER_ERROR = auto()

    # System events
    SYSTEM_STARTUP = auto()
    SYSTEM_SHUTDOWN = auto()
    SYSTEM_HEALTH_CHECK = auto()
    SYSTEM_ERROR = auto()


@dataclass
class Event:
    """Immutable event object."""
    type: EventType
    data: Any = None
    source: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    id: str = ""

    def __post_init__(self):
        if not self.id:
            self.id = f"{self.type.name}_{self.timestamp.strftime('%Y%m%d%H%M%S%f')}"


# Type alias for event handlers
EventHandler = Callable[[Event], None]


class EventBus:
    """Thread-safe publish-subscribe event bus.

    Supports both sync and async handlers. Events are dispatched
    synchronously in publish() and asynchronously via dispatch().
    """

    def __init__(self):
        self._handlers: Dict[EventType, List[EventHandler]] = {}
        self._lock = threading.Lock()
        self._async_queue: asyncio.Queue = asyncio.Queue()
        self._running = False

    def subscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """Register a handler for an event type."""
        with self._lock:
            if event_type not in self._handlers:
                self._handlers[event_type] = []
            self._handlers[event_type].append(handler)
            logger.debug(f"Subscribed {handler.__name__} to {event_type.name}")

    def unsubscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """Remove a handler for an event type."""
        with self._lock:
            if event_type in self._handlers:
                try:
                    self._handlers[event_type].remove(handler)
                except ValueError:
                    pass

    def publish(self, event: Event) -> None:
        """Publish an event and call all subscribed handlers synchronously.

        Args:
            event: The event to publish.
        """
        handlers = []
        with self._lock:
            handlers = list(self._handlers.get(event.type, []))

        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                logger.error(
                    f"Handler {handler.__name__} failed for {event.type.name}: {e}"
                )

    async def publish_async(self, event: Event) -> None:
        """Publish an event asynchronously."""
        await self._async_queue.put(event)

    async def start_async_dispatch(self) -> None:
        """Start the async event dispatch loop."""
        self._running = True
        logger.info("Async event dispatch started")
        while self._running:
            try:
                event = await asyncio.wait_for(
                    self._async_queue.get(), timeout=1.0
                )
                self.publish(event)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Async dispatch error: {e}")

    def stop(self) -> None:
        """Stop the async dispatch loop."""
        self._running = False
        logger.info("Event bus stopped")

    @property
    def subscriber_count(self) -> Dict[str, int]:
        """Return count of subscribers per event type."""
        with self._lock:
            return {et.name: len(handlers) for et, handlers in self._handlers.items()}
