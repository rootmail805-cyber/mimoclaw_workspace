"""
Life translation utility.
Converts abstract financial numbers into relatable life comparisons.
"""


class LifeTranslator:
    """Translate financial numbers into life-relatable expressions."""

    def __init__(self, config=None):
        from config.manager import get_config
        self._config = config or get_config()
        self._enabled = self._config.get("life_translation.enabled", True)
        self._meal_cost = self._config.get("life_translation.meal_cost", 300)
        self._monthly_salary = self._config.get("life_translation.monthly_salary", 15000)
        self._mortgage = self._config.get("life_translation.mortgage", 5000)
        self._mode = self._config.get("life_translation.compare_mode", "meal")

    def translate(self, amount: float) -> str:
        """Translate an amount into a life comparison.

        Args:
            amount: The profit/loss amount (positive=profit, negative=loss)

        Returns:
            Translated string, e.g., "够吃 4 顿海底捞"
        """
        if not self._enabled:
            return ""

        abs_amount = abs(amount)

        # Don't translate very small amounts or amounts less than one unit
        if abs_amount < self._meal_cost * 0.5:
            return ""

        if self._mode == "meal":
            meals = int(abs_amount / self._meal_cost)
            if meals < 1:
                return ""
            if amount >= 0:
                return f"够吃 {meals} 顿海底捞"
            else:
                return f"少吃了 {meals} 顿海底捞"
        elif self._mode == "salary":
            months = abs_amount / self._monthly_salary
            if amount >= 0:
                if months >= 1:
                    return f"相当于 {months:.1f} 个月工资"
                else:
                    days = int(abs_amount / (self._monthly_salary / 22))
                    return f"相当于 {days} 天工资"
            else:
                if months >= 1:
                    return f"亏了 {months:.1f} 个月工资"
                else:
                    days = int(abs_amount / (self._monthly_salary / 22))
                    return f"亏了 {days} 天工资"
        elif self._mode == "mortgage":
            months = int(abs_amount / self._mortgage)
            if amount >= 0:
                return f"够还 {months} 个月房贷"
            else:
                return f"少还了 {months} 个月房贷"

        return ""

    def translate_short(self, amount: float) -> str:
        """Short translation for inline display."""
        if not self._enabled:
            return ""
        abs_amount = abs(amount)
        if abs_amount < self._meal_cost * 0.5:
            return ""
        meals = int(abs_amount / self._meal_cost)
        if meals >= 1:
            return f"≈{meals}顿海底捞" if amount >= 0 else f"≈-{meals}顿海底捞"
        return ""
