"""
Input validators for QuantFlow.
Validates symbols, orders, and other trading-related data.
"""

import re
from typing import Optional, Tuple
from dataclasses import dataclass


# A-share symbol patterns
_SYMBOL_PATTERNS = {
    "sh": r"^(6\d{5}|\d{6}\.SH)$",       # Shanghai: 600xxx, 601xxx, 603xxx
    "sz": r"^(0\d{5}|3\d{5}|\d{6}\.SZ)$", # Shenzhen: 000xxx, 002xxx, 300xxx
    "bj": r"^(8\d{5}|\d{6}\.BJ)$",        # Beijing: 8xxxxx
}

_EXCHANGE_MAP = {
    "6": "SH", "0": "SZ", "3": "SZ", "8": "BJ", "9": "SH",
}


@dataclass
class ValidationResult:
    """Result of a validation check."""
    valid: bool
    message: str = ""
    normalized: str = ""


def validate_symbol(symbol: str) -> ValidationResult:
    """Validate and normalize a stock symbol.

    Accepts formats: '600000', '600000.SH', 'sh600000'
    Returns normalized format: '600000.SH'
    """
    if not symbol:
        return ValidationResult(False, "Symbol cannot be empty")

    symbol = symbol.strip().upper()

    # Already in standard format: 600000.SH
    if re.match(r"^\d{6}\.(SH|SZ|BJ)$", symbol):
        return ValidationResult(True, normalized=symbol)

    # Pure digits
    digits = re.sub(r"[^\d]", "", symbol)
    if len(digits) == 6:
        exchange = _EXCHANGE_MAP.get(digits[0])
        if exchange:
            return ValidationResult(True, normalized=f"{digits}.{exchange}")
        return ValidationResult(False, f"Unknown exchange for symbol starting with {digits[0]}")

    # With prefix: SH600000, SZ000001
    match = re.match(r"^(SH|SZ|BJ)(\d{6})$", symbol)
    if match:
        return ValidationResult(True, normalized=f"{match.group(2)}.{match.group(1)}")

    return ValidationResult(False, f"Invalid symbol format: {symbol}")


@dataclass
class OrderParams:
    """Validated order parameters."""
    symbol: str
    action: str          # BUY or SELL
    volume: int          # Must be positive, multiple of 100 for A-share
    price: Optional[float] = None  # None for market orders
    order_type: str = "LIMIT"      # LIMIT, MARKET, STOP
    strategy_id: str = ""


def validate_order(
    symbol: str,
    action: str,
    volume: int,
    price: Optional[float] = None,
    order_type: str = "LIMIT",
    strategy_id: str = "",
) -> Tuple[bool, str, Optional[OrderParams]]:
    """Validate order parameters.

    Returns:
        (valid, error_message, order_params)
    """
    # Validate symbol
    sym_result = validate_symbol(symbol)
    if not sym_result.valid:
        return False, sym_result.message, None

    # Validate action
    action = action.upper()
    if action not in ("BUY", "SELL"):
        return False, f"Invalid action: {action}. Must be BUY or SELL", None

    # Validate volume
    if volume <= 0:
        return False, f"Volume must be positive, got {volume}", None

    # A-share: volume must be multiple of 100 (except for SELL all)
    if action == "BUY" and volume % 100 != 0:
        return False, f"Buy volume must be multiple of 100, got {volume}", None

    # Validate price for limit orders
    if order_type.upper() in ("LIMIT", "STOP_LIMIT") and (price is None or price <= 0):
        return False, f"Price required and must be positive for {order_type} orders", None

    return True, "", OrderParams(
        symbol=sym_result.normalized,
        action=action,
        volume=volume,
        price=price,
        order_type=order_type.upper(),
        strategy_id=strategy_id,
    )


def validate_capital(capital: float) -> ValidationResult:
    """Validate capital amount."""
    if capital < 0:
        return ValidationResult(False, "Capital cannot be negative")
    if capital > 1_000_000_000:
        return ValidationResult(False, "Capital exceeds maximum limit (1B)")
    return ValidationResult(True)
